# إبراهيم شواف للمساحة (Ibrahim Shawaf for Surveying)

## Overview

A comprehensive water network analysis tool for engineers working with water distribution systems. The application provides tools for analyzing water networks, calculating pressures based on elevation, visualizing networks on interactive maps, and extracting data from CAD/KML files.

**Features:**
- Import KML/KMZ files with water network data
- **NEW: Import Shapefile (ZIP) - ESRI GIS format support**
- Automatic elevation fetching from satellite data (Open-Elevation API)
- Pressure calculations based on elevation differences (ΔP = ρ × g × Δh / 100000 bar)
- Network visualization with pressure-based color coding
- Multi-zone pressure analysis
- Extract and display pipe and meter data
- Bilingual support (Arabic/English)
- Interactive maps with Leaflet
- User-friendly feature tour for new users

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Updates (Session Nov 30, 2025) - COMPLETED

**Tier 1 Improvements:**
- ✅ **Tools Categorization & Organization** (📐 المساحة، 🏗️ الإنشاء، 🎨 التشطيب، ⚡ الميكانيكا، 📁 الملفات)
  - Color-coded categories with intuitive grouping
  - Search bar to find tools quickly
  - Responsive grid layout
- ✅ **Foundation Design Calculator (🏛️ أساسات):**
  - Strip, raft, isolated, pile foundation types
  - Column load, soil bearing capacity calculations
  - Required vs. actual area comparison
  - Concrete volume and rebar weight estimation
  - Cost estimation and adequacy assessment
  - Safety margin analysis
- ✅ **Project Manager (💾 المشاريع):**
  - Save/load calculations to localStorage
  - Project history with timestamps (Arabic dates)
  - Auto-recovery of project data
  - Simple one-click load/save interface
- ✅ **Excel/CSV Export Utility:**
  - Export calculation results to CSV format
  - Timestamp included for traceability
  - Compatible with Excel spreadsheet tools

**Previous Features from This Session:**
- ✅ **Theme Toggle (Dark/Light Mode):** Egyptian flag-inspired light theme with gold accents
  - Toggle button in header with Sun/Moon icons
  - Persisted preference in localStorage
  - Light mode: Red, White, Black with Gold accents
  - Dark mode: Gradient dark theme
- ✅ **Detailed Rebar Calculator (🔩 حديد):**
  - Complete rebar weight table (Ø6-Ø40mm)
  - Weight formula: W = Ø² × 0.00617 kg/m
  - Add/remove multiple rebar items
  - Real-time weight preview per item
  - Price estimation with multiple currencies (EGP, SAR, USD, EUR, AED)
  - Summary by diameter with bar count, weight, and percentage
  - Detailed breakdown table
  - Export to TXT and CSV formats
- ✅ **Electrical Load Calculator (⚡ كهرباء):**
  - Multi-room/space support with different types (bedroom, living, kitchen, bathroom, office, shop, factory, warehouse)
  - Light points, sockets, AC units, heaters calculation
  - Configurable voltage (110V/220V/380V), power factor, demand factor, safety factor
  - Automatic calculation of:
    - Total load (kW)
    - Demand load with safety margin
    - Required current (A)
    - Main breaker size
    - Cable size (mm²)
    - Meter size
  - Room-by-room load distribution with percentages
  - Smart recommendations for panel splitting, 3-phase systems, RCD protection
  - Export to TXT and PDF reports
- ✅ **Sewage Network Simulator (🌊 صرف):**
  - Network type selection: Gravity, Pressure, Vacuum, Combined
  - Population and flow data: population, peak factor, infiltration rate
  - Pipe properties: diameter (150-1200mm), slope, Manning n (HDPE/GRP/PVC/Concrete/Clay)
  - Manning's equation: V = (1/n) × R^(2/3) × S^(1/2)
  - Hydraulic calculations:
    - Average flow (200 L/person/day)
    - Peak flow with demand factor
    - Design flow with infiltration
    - Pipe capacity and fill ratio
    - Velocity and self-cleansing check (≥0.6 m/s)
    - Froude number and shear stress
  - Smart recommendations for sedimentation, erosion, pipe sizing
  - Export to TXT and PDF reports
- ✅ **PDF Export for All Calculators:**
  - Professional A4 reports with jsPDF
  - Bilingual support (Arabic/English)
  - Tables, summaries, and recommendations
  - Available for: Brick, Paint, Tiles, Stairs, Tank, Electrical, HVAC, Cost, Sewage

## Recent Updates (Session Nov 29, 2025)

**Calculation Accuracy Improvements:**
- ✅ **Geodesic Area:** Replaced equirectangular approximation with WGS84-based local tangent plane projection using meridional (M) and prime-vertical (N) radii for accurate area measurements
- ✅ **Average End Area (Cut & Fill):** Fixed volume calculation to use proper formula: Volume = ((A1 + A2) / 2) × spacing; verified with test case (10m² + 20m² × 20m = 300 m³)
- ✅ **Sign Change Handling:** Prismoidal volume splitting at zero-crossing for cut-to-fill transitions

**Advanced Hydraulic Analysis Tab (🔬 هيدروليك):**
- ✅ **Flow Velocity Analysis:** Categorizes pipes as too_low (<0.3 m/s), optimal (0.3-1.5 m/s), high (1.5-2.5 m/s), too_high (>2.5 m/s)
- ✅ **Hazen-Williams Head Loss:** h_f = 10.67·L·Q^1.852/(C^1.852·d^4.87) with critical pipe identification (>0.5 bar loss)
- ✅ **Darcy-Weisbach Analysis:** Total D-W loss, max velocity, average Reynolds number
- ✅ **Water Age Analysis:** Total volume, max age, stagnant pipe count (>24h)
- ✅ **Diameter Optimization:** Identifies undersized, optimal, and oversized pipes based on flow requirements
- ✅ **Pressure Adequacy:** Evaluates pressure sufficiency for multi-story buildings (2 bar + 0.35/floor)
- ✅ **Network Connectivity:** Node count, dead-end detection, junction identification
- ✅ **Loop Analysis:** Euler's formula (E - N + 1), reliability scoring, risk level assessment
- ✅ **Emergency Simulation:**
  - Pipe break analysis with high-risk identification
  - Isolation valve analysis with coverage metrics
  - Affected areas assessment
  - Emergency recommendations
- ✅ **Demand Calculator:** Population-based peak flow calculation
- ✅ **Fire Flow Requirements:** Standards for residential (10 L/s), commercial (30 L/s), industrial (50 L/s), high-rise (60 L/s)
- ✅ **Hydraulic Details Table:** Comprehensive pipe data with velocity, Reynolds, regime, and head loss columns

**Implemented:**
- ✅ **NEW: 3D Visualization for Cut & Fill Calculator** with:
  - Interactive 3D terrain mesh using react-three-fiber
  - Delaunator triangulation for surface generation
  - Color-coded difference display (red=cut, green=fill, yellow=balanced)
  - Click-to-inspect point details with elevation info
  - Layer visibility toggles (existing, design, difference)
  - Smart data alignment by station ID or spatial proximity
  - Performance optimization with point sampling (max 5000 points)
  - Quick statistics panel (cut/fill/balanced counts)
  - Bilingual labels (Arabic/English)
- ✅ Feature Tour for Home page and Cut & Fill Calculator
- ✅ Help button to restart tours

## Recent Updates (Session Nov 27, 2025)

**Implemented:**
- ✅ Automatic elevation fetching from Open-Elevation API with timeout/retry logic
- ✅ Pressure calculations based solely on elevation (pipe diameter ignored per user request)
- ✅ User-friendly tour component for onboarding new users
- ✅ Pressure visualization on map with color-coded lines (red=low, blue=high)
- ✅ Data extraction tab showing detailed pipes & meters table from KML
- ✅ Improved KML parsing with multiple fallback methods for reading diameter/flow data
- ✅ Console logging to show which data was read vs. using defaults
- ✅ **Pipe length calculation** using Haversine formula with total length summary
- ✅ **Elevation and capacity display** in elements data table
- ✅ **Longitudinal Profile tab** (المقطع الطولي)
- ✅ **Advanced Tools Tab** (🔧 أدوات) with:
  - Coordinate conversion (WGS84 ↔ UTM)
  - Data quality check (duplicates, disconnected elements)
  - Valve isolation tracing
  - Water demand analysis
  - What-if scenario simulations
  - Report generation (TXT/CSV/JSON exports)
- ✅ **NEW: Measurement Tab** (📐 قياس) with:
  - Distance measurement (Haversine formula)
  - Polygon area calculation (Shoelace formula)
  - Slope/gradient calculation
  - GPS location detection
  - Go-to-location (Google Maps integration)
  - GPX file export
- ✅ **NEW: Terrain Analysis Tab** (🏔️ تضاريس) with:
  - Contour lines analysis with configurable intervals
  - Watershed analysis based on tanks and zones
  - Flood simulation with affected elements count
- ✅ **NEW: Project Management Tab** (📁 مشاريع) with:
  - Save/load projects (localStorage and file)
  - Network comparison (before/after)
  - Map printing (A4/A3 formats)
  - Professional report generation
- ✅ **PWA (Progressive Web App)** - التطبيق قابل للتثبيت على الهواتف:
  - manifest.json للتطبيق
  - Service Worker للعمل بدون إنترنت
  - أيقونات بأحجام متعددة (72-512px)
  - رسالة تثبيت تلقائية للمستخدمين

## System Architecture

### Frontend Architecture

**Framework:** React with TypeScript using Vite as the build tool

**UI Components:** Shadcn UI component library with Radix UI primitives

**Styling:** Tailwind CSS v4 

**Routing:** Wouter for lightweight client-side routing

**Map Visualization:** Leaflet for interactive water network maps

**State Management:** React hooks + local state management

**Key Pages:**
- Water Network Unified (`/water-network`) - Main page for water network analysis
  - Upload tab: Import KML/KMZ files
  - Map tab: Visualize network with pressure-coded colors
  - Data tab: View extracted pipes and elements in tables
  - Calculate tab: Tank pressure calculations
  - Results tab: Display analysis results

### KML Data Parsing

**Supported Element Types:**
- Points: Tanks (خزان), Pumps (مضخة), Meters (عداد), Valves (محبس)
- LineStrings: Pipes with diameter and flow attributes
- Polygons: Treated as connected line segments
- MultiGeometry: Complex network structures

**Data Extraction Methods (in priority order):**
1. ExtendedData with multiple field name variations
2. SimpleData within SchemaData
3. Description text parsing with regex
4. Default values (50mm diameter, 10L/s flow)

**Logging:** Each line logs whether data was found or defaults were used: `[KML] Line: name, Diameter: X (found/default), Flow: Y (found/default)`

### Pressure Calculation

**Formula:** ΔP = (ρ × g × |Δh|) / 100000
- ρ = 1000 kg/m³ (water density)
- g = 9.81 m/s²
- Δh = Elevation difference in meters
- Result in bar

**Map Color Scheme:**
- Red (#FF0000): 0 bar - No pressure
- Orange (#FF6600): < 1 bar - Very low
- Yellow (#FFCC00): < 2 bar - Low  
- Lime (#99FF00): < 3 bar - Medium
- Green (#00CC00): < 5 bar - Good
- Cyan (#00CCFF): < 10 bar - High
- Blue (#0033FF): >= 10 bar - Very high

### Elevation Data

**Source:** Open-Elevation API (free satellite/terrain data)
- URL: `https://api.open-elevation.com/api/v1/lookup?locations=lat,lng`
- Timeout: 5 seconds per request
- Fallback: Uses 0 elevation if API fails

### Tour System

**FeatureTour Component:**
- Location: `client/src/components/FeatureTour.tsx`
- Bilingual support (Arabic/English)
- Persists state using localStorage
- Highlights key UI elements
- Keyboard navigation support

## External Dependencies

**Third-Party APIs:**
- Open-Elevation API - Satellite elevation data

**Key Libraries:**
- Leaflet - Interactive maps
- JSZip - KML/KMZ file handling
- DOMParser - XML parsing
- Sonner - Toast notifications

**Development Tools:**
- Vite - Build tool
- TypeScript - Type safety
- Tailwind CSS - Styling

## Technical Notes

**Known Limitations:**
- API elevation fetching may timeout on poor connections
- Large KML files (>10K lines) may impact performance
- Coordinate system depends on KML file format (may need swapping)

**Console Logging:**
- `[KML]` - KML parsing logs
- `[Elevation]` - Elevation API fetch logs
- `[Map]` - Map rendering logs
- `[TankMap]` - Tank detail map logs

**Performance:**
- Parsed 9956 pipes and 5183 elements in test file (Egypt water network)
- Created 217 zones (211 tanks + 6 unconnected networks)
