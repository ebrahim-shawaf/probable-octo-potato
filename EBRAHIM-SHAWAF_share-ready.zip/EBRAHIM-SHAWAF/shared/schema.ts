import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, jsonb, timestamp, unique, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const districts = pgTable("districts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  geometry: jsonb("geometry").notNull(),
  population: integer("population"),
});

export const subareas = pgTable("subareas", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  districtId: varchar("district_id").notNull().references(() => districts.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  geometry: jsonb("geometry").notNull(),
});

export const candidates = pgTable("candidates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  party: text("party").notNull(),
  color: text("color").notNull().default("#3b82f6"),
  imageUrl: text("image_url"),
});

export const votes = pgTable("votes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  districtId: varchar("district_id").notNull().references(() => districts.id, { onDelete: "cascade" }),
  candidateId: varchar("candidate_id").notNull().references(() => candidates.id, { onDelete: "cascade" }),
  voteCount: integer("vote_count").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
}, (table) => ({
  uniqueDistrictCandidate: unique().on(table.districtId, table.candidateId),
}));

export const predictions = pgTable("predictions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  districtId: varchar("district_id").notNull().references(() => districts.id, { onDelete: "cascade" }),
  candidateId: varchar("candidate_id").notNull().references(() => candidates.id, { onDelete: "cascade" }),
  predictedVotes: real("predicted_votes").notNull(),
  confidence: real("confidence").notNull().default(0.85),
  generatedAt: timestamp("generated_at").notNull().default(sql`now()`),
}, (table) => ({
  uniqueDistrictCandidatePrediction: unique().on(table.districtId, table.candidateId),
}));

export const voters = pgTable("voters", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  districtId: varchar("district_id").notNull().references(() => districts.id, { onDelete: "cascade" }),
  pollingStation: text("polling_station").notNull(),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const structuralElements = pgTable("structural_elements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // "column", "beam", "wall", "slab", "footing"
  length: real("length").notNull(),
  width: real("width").notNull(),
  height: real("height").notNull(),
  thickness: real("thickness"), // For walls and slabs
  qty: integer("qty").notNull().default(1),
});

export const insertDistrictSchema = createInsertSchema(districts).omit({ id: true });
export const insertSubareaSchema = createInsertSchema(subareas).omit({ id: true });
export const insertCandidateSchema = createInsertSchema(candidates).omit({ id: true });
export const insertVoteSchema = createInsertSchema(votes).omit({ id: true, updatedAt: true });
export const insertPredictionSchema = createInsertSchema(predictions).omit({ id: true, generatedAt: true });
export const insertVoterSchema = createInsertSchema(voters).omit({ id: true, createdAt: true });
export const insertStructuralElementSchema = createInsertSchema(structuralElements).omit({ id: true });

export type District = typeof districts.$inferSelect;
export type InsertDistrict = z.infer<typeof insertDistrictSchema>;

export type Subarea = typeof subareas.$inferSelect;
export type InsertSubarea = z.infer<typeof insertSubareaSchema>;

export type Candidate = typeof candidates.$inferSelect;
export type InsertCandidate = z.infer<typeof insertCandidateSchema>;

export type Vote = typeof votes.$inferSelect;
export type InsertVote = z.infer<typeof insertVoteSchema>;

export type Prediction = typeof predictions.$inferSelect;
export type InsertPrediction = z.infer<typeof insertPredictionSchema>;

export type Voter = typeof voters.$inferSelect;
export type InsertVoter = z.infer<typeof insertVoterSchema>;

export type StructuralElement = typeof structuralElements.$inferSelect;
export type InsertStructuralElement = z.infer<typeof insertStructuralElementSchema>;
