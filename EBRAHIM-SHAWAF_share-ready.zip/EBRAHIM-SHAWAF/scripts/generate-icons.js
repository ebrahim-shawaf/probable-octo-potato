const fs = require('fs');
const path = require('path');

const sizes = [72, 96, 128, 144, 152, 192, 384, 512];
const iconsDir = path.join(__dirname, '../client/public/icons');

const svgTemplate = (size) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" width="${size}" height="${size}">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#3b82f6"/>
      <stop offset="100%" style="stop-color:#8b5cf6"/>
    </linearGradient>
  </defs>
  <rect width="${size}" height="${size}" rx="${size * 0.2}" fill="url(#bg)"/>
  <g fill="white" transform="translate(${size * 0.1}, ${size * 0.1}) scale(${size * 0.8 / 512})">
    <path d="M256 80c-97.2 0-176 78.8-176 176s78.8 176 176 176 176-78.8 176-176S353.2 80 256 80zm0 320c-79.4 0-144-64.6-144-144s64.6-144 144-144 144 64.6 144 144-64.6 144-144 144z"/>
    <circle cx="256" cy="256" r="24"/>
    <rect x="248" y="140" width="16" height="80" rx="8"/>
    <rect x="248" y="292" width="16" height="80" rx="8"/>
    <rect x="140" y="248" width="80" height="16" rx="8"/>
    <rect x="292" y="248" width="80" height="16" rx="8"/>
  </g>
</svg>`;

if (!fs.existsSync(iconsDir)) {
  fs.mkdirSync(iconsDir, { recursive: true });
}

sizes.forEach(size => {
  const svgContent = svgTemplate(size);
  const filePath = path.join(iconsDir, `icon-${size}x${size}.svg`);
  fs.writeFileSync(filePath, svgContent);
  console.log(`Created: icon-${size}x${size}.svg`);
});

console.log('Done! SVG icons created.');
console.log('Note: For PNG icons, use an online converter or install sharp/canvas packages.');
