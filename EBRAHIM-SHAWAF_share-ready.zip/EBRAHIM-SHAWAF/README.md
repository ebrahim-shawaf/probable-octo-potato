# Ibrahim Shawaf for Surveying (إبراهيم شواف للمساحة)

A web application built on **Vite + React** (frontend) and **Node.js/Express** (backend), originally developed on Replit.

This repository is a **cleaned, share-ready** version of the project (removed Replit/system folders like `.git`, `.local`, `.config`, and large `attached_assets` exports).

---

## Features (high level)
- Surveying / GIS-oriented workflow (KML parsing, zones/DMAs, and related utilities)
- Bilingual-friendly UI (Arabic/English)
- Postgres database via **Drizzle ORM** + **Neon serverless driver**

> Notes and technical details from the original Replit workspace are preserved in **replit.md**.

---

## Requirements
- **Node.js 18+** (recommended: Node 20+)
- npm (or any Node package manager; this repo includes **package-lock.json** for npm)

---

## Quick start (Development)

### 1) Install dependencies
```bash
npm install
```

### 2) Create an `.env` file
Create a file named `.env` in the project root (same level as `package.json`):

```env
DATABASE_URL="postgresql://USER:PASSWORD@HOST:PORT/DBNAME"
ADMIN_KEY="change-this-to-a-random-secret"   # optional
PORT=5000                                    # optional
```

**Important:** `DATABASE_URL` is required. The server will stop with an error if it’s missing.

### 3) Run the app
```bash
npm run dev
```

This runs the backend in development and the Vite client on port **5000** (see scripts in `package.json`).

---

## Build & run (Production)

### Build
```bash
npm run build
```

### Start
```bash
npm start
```

---

## Database
This project expects a Postgres database.

Common free options:
- **Neon** (serverless Postgres)
- Local Postgres (Docker or installed locally)

After setting `DATABASE_URL`, you can run:
```bash
npm run db:push
```
to push schema changes (Drizzle Kit).

---

## License
MIT License — free to use, modify, and share.

---

## Author
**Ebrahim Shawaf**  
If you share this publicly, consider adding a link back to your profile or website.
