import fs from "node:fs";
import { type Server } from "node:http";
import path from "node:path";

import express, { type Express, type Request } from "express";

import runApp from "./app";

export async function serveStatic(app: Express, server: Server) {
  const distPath = path.resolve(import.meta.dirname, "public");

  console.log(`[Production] Looking for build directory at: ${distPath}`);

  if (!fs.existsSync(distPath)) {
    console.error(`[Production] Build directory not found: ${distPath}`);
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`,
    );
  }

  console.log(`[Production] Build directory found, serving static files`);
  app.use(express.static(distPath));

  // fall through to index.html if the file doesn't exist
  app.use("*", (_req, res) => {
    res.sendFile(path.resolve(distPath, "index.html"));
  });
}

console.log(`[Production] Starting server...`);
console.log(`[Production] PORT=${process.env.PORT || '5000'}`);

(async () => {
  try {
    await runApp(serveStatic);
    console.log(`[Production] Server started successfully`);
  } catch (error) {
    console.error(`[Production] Failed to start server:`, error);
    process.exit(1);
  }
})();
