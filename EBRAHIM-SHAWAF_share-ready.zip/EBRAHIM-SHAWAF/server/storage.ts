import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import { eq, and } from "drizzle-orm";
import * as schema from "@shared/schema";
import type { 
  District, 
  InsertDistrict,
  Subarea,
  InsertSubarea,
  Candidate, 
  InsertCandidate, 
  Vote, 
  InsertVote,
  Prediction,
  InsertPrediction,
  Voter,
  InsertVoter
} from "@shared/schema";

const sql = neon(process.env.DATABASE_URL!);
const db = drizzle(sql, { schema });

export interface IStorage {
  // Districts
  getAllDistricts(): Promise<District[]>;
  getDistrict(id: string): Promise<District | undefined>;
  createDistrict(district: InsertDistrict): Promise<District>;
  
  // Subareas
  getAllSubareas(): Promise<Subarea[]>;
  getSubareasByDistrict(districtId: string): Promise<Subarea[]>;
  createSubarea(subarea: InsertSubarea): Promise<Subarea>;
  
  // Candidates
  getAllCandidates(): Promise<Candidate[]>;
  getCandidate(id: string): Promise<Candidate | undefined>;
  createCandidate(candidate: InsertCandidate): Promise<Candidate>;
  
  // Votes
  getAllVotes(): Promise<Vote[]>;
  getVotesByDistrict(districtId: string): Promise<Vote[]>;
  upsertVote(vote: InsertVote): Promise<Vote>;
  
  // Predictions
  getAllPredictions(): Promise<Prediction[]>;
  getPredictionsByDistrict(districtId: string): Promise<Prediction[]>;
  upsertPrediction(prediction: InsertPrediction): Promise<Prediction>;
  
  // Voters
  getAllVoters(): Promise<Voter[]>;
  getVotersByDistrict(districtId: string): Promise<Voter[]>;
  createVoter(voter: InsertVoter): Promise<Voter>;
  
  // Results aggregation
  getElectionResults(): Promise<Array<{
    district: District;
    votes: Array<Vote & { candidate: Candidate }>;
    predictions: Array<Prediction & { candidate: Candidate }>;
  }>>;
}

class DatabaseStorage implements IStorage {
  // Districts
  async getAllDistricts(): Promise<District[]> {
    return await db.select().from(schema.districts);
  }

  async getDistrict(id: string): Promise<District | undefined> {
    const result = await db.select().from(schema.districts).where(eq(schema.districts.id, id));
    return result[0];
  }

  async createDistrict(district: InsertDistrict): Promise<District> {
    const result = await db.insert(schema.districts).values(district).returning();
    return result[0];
  }

  // Subareas
  async getAllSubareas(): Promise<Subarea[]> {
    return await db.select().from(schema.subareas);
  }

  async getSubareasByDistrict(districtId: string): Promise<Subarea[]> {
    return await db.select().from(schema.subareas).where(eq(schema.subareas.districtId, districtId));
  }

  async createSubarea(subarea: InsertSubarea): Promise<Subarea> {
    const result = await db.insert(schema.subareas).values(subarea).returning();
    return result[0];
  }

  // Candidates
  async getAllCandidates(): Promise<Candidate[]> {
    return await db.select().from(schema.candidates);
  }

  async getCandidate(id: string): Promise<Candidate | undefined> {
    const result = await db.select().from(schema.candidates).where(eq(schema.candidates.id, id));
    return result[0];
  }

  async createCandidate(candidate: InsertCandidate): Promise<Candidate> {
    const result = await db.insert(schema.candidates).values(candidate).returning();
    return result[0];
  }

  // Votes
  async getAllVotes(): Promise<Vote[]> {
    return await db.select().from(schema.votes);
  }

  async getVotesByDistrict(districtId: string): Promise<Vote[]> {
    return await db.select().from(schema.votes).where(eq(schema.votes.districtId, districtId));
  }

  async upsertVote(vote: InsertVote): Promise<Vote> {
    // Validate vote count exists and is non-negative
    if (typeof vote.voteCount !== 'number' || vote.voteCount < 0) {
      throw new Error("Vote count must be a non-negative number");
    }

    // Use atomic upsert with onConflict to prevent race conditions
    const result = await db
      .insert(schema.votes)
      .values({ ...vote, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: [schema.votes.districtId, schema.votes.candidateId],
        set: {
          voteCount: vote.voteCount,
          updatedAt: new Date(),
        },
      })
      .returning();
    
    return result[0];
  }

  // Predictions
  async getAllPredictions(): Promise<Prediction[]> {
    return await db.select().from(schema.predictions);
  }

  async getPredictionsByDistrict(districtId: string): Promise<Prediction[]> {
    return await db.select().from(schema.predictions).where(eq(schema.predictions.districtId, districtId));
  }

  async upsertPrediction(prediction: InsertPrediction): Promise<Prediction> {
    if (typeof prediction.predictedVotes !== 'number' || prediction.predictedVotes < 0) {
      throw new Error("Predicted votes must be a non-negative number");
    }

    const result = await db
      .insert(schema.predictions)
      .values({ ...prediction, generatedAt: new Date() })
      .onConflictDoUpdate({
        target: [schema.predictions.districtId, schema.predictions.candidateId],
        set: {
          predictedVotes: prediction.predictedVotes,
          confidence: prediction.confidence,
          generatedAt: new Date(),
        },
      })
      .returning();
    
    return result[0];
  }

  // Voters
  async getAllVoters(): Promise<Voter[]> {
    return await db.select().from(schema.voters);
  }

  async getVotersByDistrict(districtId: string): Promise<Voter[]> {
    return await db.select().from(schema.voters).where(eq(schema.voters.districtId, districtId));
  }

  async createVoter(voter: InsertVoter): Promise<Voter> {
    const result = await db.insert(schema.voters).values(voter).returning();
    return result[0];
  }

  async getElectionResults() {
    const districts = await this.getAllDistricts();
    const candidates = await this.getAllCandidates();
    const allVotes = await this.getAllVotes();
    const allPredictions = await this.getAllPredictions();

    return districts.map(district => {
      const districtVotes = allVotes
        .filter(v => v.districtId === district.id)
        .map(vote => ({
          ...vote,
          candidate: candidates.find(c => c.id === vote.candidateId)!
        }));

      const districtPredictions = allPredictions
        .filter(p => p.districtId === district.id)
        .map(pred => ({
          ...pred,
          candidate: candidates.find(c => c.id === pred.candidateId)!
        }));

      return {
        district,
        votes: districtVotes,
        predictions: districtPredictions
      };
    });
  }
}

export const storage = new DatabaseStorage();
