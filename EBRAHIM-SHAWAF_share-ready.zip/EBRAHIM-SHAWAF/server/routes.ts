import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertDistrictSchema, insertSubareaSchema, insertCandidateSchema, insertVoteSchema, insertVoterSchema } from "@shared/schema";
import fs from "fs";
import path from "path";
import { execSync } from "child_process";
import os from "os";
import { LibreDwg } from "@mlightcad/libredwg-web";

// Simple admin authentication middleware
// In production, replace with proper authentication (OAuth, JWT, etc.)
function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const adminKey = req.headers["x-admin-key"];
  const validKey = process.env.ADMIN_KEY || "demo-admin-key-2024";
  
  if (adminKey !== validKey) {
    return res.status(401).json({ message: "Unauthorized: Admin access required" });
  }
  
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint for deployment
  app.get("/health", (_req, res) => {
    res.status(200).json({ status: "ok", timestamp: new Date().toISOString() });
  });
  
  app.get("/api/health", (_req, res) => {
    res.status(200).json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Districts
  app.get("/api/districts", async (_req, res) => {
    const districts = await storage.getAllDistricts();
    res.json(districts);
  });

  app.get("/api/districts/:id", async (req, res) => {
    const district = await storage.getDistrict(req.params.id);
    if (!district) {
      return res.status(404).json({ message: "District not found" });
    }
    res.json(district);
  });

  app.post("/api/districts", requireAdmin, async (req, res) => {
    try {
      const data = insertDistrictSchema.parse(req.body);
      const district = await storage.createDistrict(data);
      res.status(201).json(district);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Subareas
  app.get("/api/subareas", async (_req, res) => {
    const subareas = await storage.getAllSubareas();
    res.json(subareas);
  });

  app.get("/api/subareas/district/:districtId", async (req, res) => {
    const subareas = await storage.getSubareasByDistrict(req.params.districtId);
    res.json(subareas);
  });

  app.post("/api/subareas", requireAdmin, async (req, res) => {
    try {
      const data = insertSubareaSchema.parse(req.body);
      const subarea = await storage.createSubarea(data);
      res.status(201).json(subarea);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Candidates
  app.get("/api/candidates", async (_req, res) => {
    const candidates = await storage.getAllCandidates();
    res.json(candidates);
  });

  app.get("/api/candidates/:id", async (req, res) => {
    const candidate = await storage.getCandidate(req.params.id);
    if (!candidate) {
      return res.status(404).json({ message: "Candidate not found" });
    }
    res.json(candidate);
  });

  app.post("/api/candidates", requireAdmin, async (req, res) => {
    try {
      const data = insertCandidateSchema.parse(req.body);
      const candidate = await storage.createCandidate(data);
      res.status(201).json(candidate);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Votes
  app.get("/api/votes", async (_req, res) => {
    const votes = await storage.getAllVotes();
    res.json(votes);
  });

  app.get("/api/votes/district/:districtId", async (req, res) => {
    const votes = await storage.getVotesByDistrict(req.params.districtId);
    res.json(votes);
  });

  app.post("/api/votes", requireAdmin, async (req, res) => {
    try {
      const data = insertVoteSchema.parse(req.body);
      
      // Server-side validation for non-negative votes
      if (typeof data.voteCount !== 'number' || data.voteCount < 0) {
        return res.status(400).json({ message: "Vote count must be a non-negative number" });
      }
      
      const vote = await storage.upsertVote(data);
      res.json(vote);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Voters
  app.get("/api/voters", async (_req, res) => {
    const voters = await storage.getAllVoters();
    res.json(voters);
  });

  app.get("/api/voters/district/:districtId", async (req, res) => {
    const voters = await storage.getVotersByDistrict(req.params.districtId);
    res.json(voters);
  });

  // Get voter statistics by district and polling station
  app.get("/api/voters/stats", async (_req, res) => {
    try {
      const voters = await storage.getAllVoters();
      const districts = await storage.getAllDistricts();

      // Group voters by district and polling station
      const stats: {[key: string]: {districtId: string; districtName: string; totalVoters: number; stations: {[key: string]: number}}} = {};
      
      for (const voter of voters) {
        const district = districts.find(d => d.id === voter.districtId);
        if (district) {
          if (!stats[district.id]) {
            stats[district.id] = {
              districtId: district.id,
              districtName: district.name,
              totalVoters: 0,
              stations: {}
            };
          }
          stats[district.id].totalVoters++;
          stats[district.id].stations[voter.pollingStation] = (stats[district.id].stations[voter.pollingStation] || 0) + 1;
        }
      }
      
      res.json(Object.values(stats));
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/voters", requireAdmin, async (req, res) => {
    try {
      const data = insertVoterSchema.parse(req.body);
      const voter = await storage.createVoter(data);
      res.status(201).json(voter);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Import voters from CSV data
  app.post("/api/voters/import", requireAdmin, async (req, res) => {
    try {
      const { csvData } = req.body as { csvData: string };
      
      if (!csvData) {
        return res.status(400).json({ message: "CSV data is required" });
      }

      const lines = csvData.trim().split('\n');
      const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
      
      const nameIdx = headers.indexOf('name');
      const districtIdx = headers.indexOf('district');
      const stationIdx = headers.indexOf('polling_station');

      if (nameIdx === -1 || districtIdx === -1 || stationIdx === -1) {
        return res.status(400).json({ message: "CSV must have name, district, and polling_station columns" });
      }

      const districts = await storage.getAllDistricts();
      let imported = 0;
      let failed = 0;
      const errors: string[] = [];

      for (let i = 1; i < lines.length; i++) {
        if (!lines[i].trim()) continue;

        const parts = lines[i].split(',').map(p => p.trim().replace(/^"|"$/g, ''));
        const name = parts[nameIdx];
        const districtName = parts[districtIdx];
        const pollingStation = parts[stationIdx];

        if (!name || !districtName || !pollingStation) {
          errors.push(`Row ${i + 1}: Missing required fields`);
          failed++;
          continue;
        }

        const district = districts.find(d => d.name === districtName);
        if (!district) {
          errors.push(`Row ${i + 1}: District "${districtName}" not found`);
          failed++;
          continue;
        }

        try {
          await storage.createVoter({
            name,
            districtId: district.id,
            pollingStation,
          });
          imported++;
        } catch (error: any) {
          errors.push(`Row ${i + 1}: ${error.message}`);
          failed++;
        }
      }

      res.json({
        success: true,
        imported,
        failed,
        errors: errors.slice(0, 10), // Return first 10 errors
        message: `Imported ${imported} voters${failed > 0 ? `, ${failed} failed` : ''}`,
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Predictions
  app.get("/api/predictions", async (_req, res) => {
    const predictions = await storage.getAllPredictions();
    res.json(predictions);
  });

  app.get("/api/predictions/district/:districtId", async (req, res) => {
    const predictions = await storage.getPredictionsByDistrict(req.params.districtId);
    res.json(predictions);
  });

  app.post("/api/predictions", requireAdmin, async (req, res) => {
    try {
      const { insertPredictionSchema } = await import("@shared/schema");
      const data = insertPredictionSchema.parse(req.body);
      
      if (typeof data.predictedVotes !== 'number' || data.predictedVotes < 0) {
        return res.status(400).json({ message: "Predicted votes must be a non-negative number" });
      }
      
      const prediction = await storage.upsertPrediction(data);
      res.json(prediction);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/predictions/generate", requireAdmin, async (req, res) => {
    try {
      const candidates = await storage.getAllCandidates();
      const districts = await storage.getAllDistricts();
      const votes = await storage.getAllVotes();

      // Simple prediction: add 10-20% to actual votes with random variance
      for (const district of districts) {
        for (const candidate of candidates) {
          const actual = votes.find(v => v.districtId === district.id && v.candidateId === candidate.id);
          const actualVotes = actual?.voteCount || 0;
          
          // Generate prediction: base on actual votes + 15% with ±5% variance
          const variance = (Math.random() - 0.5) * 0.1; // ±5%
          const growthFactor = 1.15 + variance;
          const predictedVotes = Math.round(actualVotes * growthFactor);
          const confidence = 0.75 + (Math.random() * 0.2); // 75-95% confidence

          await storage.upsertPrediction({
            districtId: district.id,
            candidateId: candidate.id,
            predictedVotes,
            confidence
          });
        }
      }

      res.json({ message: "Predictions generated successfully", count: candidates.length * districts.length });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Election Results
  app.get("/api/results", async (_req, res) => {
    const results = await storage.getElectionResults();
    res.json(results);
  });

  // Export votes as CSV
  app.get("/api/export/votes", async (_req, res) => {
    try {
      const votes = await storage.getAllVotes();
      const districts = await storage.getAllDistricts();
      const candidates = await storage.getAllCandidates();

      // Build CSV
      const headers = ["district,candidate_1,candidate_2,candidate_3,total_voters"];
      const rows = new Map<string, {[key: string]: string | number}>();

      // Initialize all districts with 0 votes
      for (const district of districts) {
        const row: {[key: string]: string | number} = {
          district: district.name,
        };
        for (const candidate of candidates) {
          row[candidate.id] = 0;
        }
        rows.set(district.id, row);
      }

      // Fill in actual votes
      for (const vote of votes) {
        const row = rows.get(vote.districtId);
        if (row) {
          row[vote.candidateId] = vote.voteCount;
        }
      }

      // Calculate total voters per district and format CSV
      const csvData = Array.from(rows.values()).map(row => {
        const districtName = row.district as string;
        const cand1Votes = row[candidates[0]?.id || "cand1"] || 0;
        const cand2Votes = row[candidates[1]?.id || "cand2"] || 0;
        const cand3Votes = row[candidates[2]?.id || "cand3"] || 0;
        const totalVoters = (cand1Votes as number) + (cand2Votes as number) + (cand3Votes as number);

        return `"${districtName}",${cand1Votes},${cand2Votes},${cand3Votes},${totalVoters}`;
      });

      const csv = headers.join("\n") + "\n" + csvData.join("\n");

      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="voter_data_${new Date().toISOString().split('T')[0]}.csv"`);
      res.send(csv);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Export voters data as CSV
  app.get("/api/export/voters", async (_req, res) => {
    try {
      const voters = await storage.getAllVoters();
      const districts = await storage.getAllDistricts();

      // Build CSV with voter data
      const headers = ["name,district,polling_station"];
      const csvData = voters.map(voter => {
        const district = districts.find(d => d.id === voter.districtId);
        return `"${voter.name}","${district?.name || 'Unknown'}","${voter.pollingStation}"`;
      });

      const csv = headers.join("\n") + "\n" + csvData.join("\n");

      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="voters_${new Date().toISOString().split('T')[0]}.csv"`);
      res.send(csv);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // CAD File Parser Endpoint - Extract ALL geometric data
  app.post("/api/cad/parse", async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const allowedExts = ['.dxf', '.dwg', '.txt'];
      const fileExt = path.extname(req.file.originalname).toLowerCase();
      
      if (!allowedExts.includes(fileExt)) {
        return res.status(400).json({ error: "Invalid file type. Only DXF, DWG, and TXT files are allowed." });
      }

      const fileBuffer = req.file.buffer;
      const fileExtLower = fileExt.toLowerCase();
      const geometry = fileExtLower === '.dwg' 
        ? await parseAllGeometryDWG(fileBuffer) 
        : parseAllGeometryDXF(fileBuffer);

      res.json({
        success: true,
        count: geometry.length,
        elements: geometry
      });
    } catch (error: any) {
      console.error('CAD Parse Error:', error);
      res.status(500).json({ error: "Failed to parse CAD file" });
    }
  });

  // Parse DXF - Extract ALL geometric entities
  function parseAllGeometryDXF(buffer: Buffer): any[] {
    const geometry: any[] = [];
    
    try {
      const str = buffer.toString('utf8');
      let id = 1;
      
      // Extract ALL LINE entities
      const linePattern = /^\s*0\s*\nLINE\s*\n([\s\S]*?)(?=^\s*0\s*\n)/gm;
      let match;
      
      while ((match = linePattern.exec(str)) !== null) {
        const block = match[1];
        const x1Match = block.match(/^\s*10\s*\n\s*(-?\d+\.?\d*)/m);
        const y1Match = block.match(/^\s*20\s*\n\s*(-?\d+\.?\d*)/m);
        const z1Match = block.match(/^\s*30\s*\n\s*(-?\d+\.?\d*)/m);
        const x2Match = block.match(/^\s*11\s*\n\s*(-?\d+\.?\d*)/m);
        const y2Match = block.match(/^\s*21\s*\n\s*(-?\d+\.?\d*)/m);
        const z2Match = block.match(/^\s*31\s*\n\s*(-?\d+\.?\d*)/m);
        
        if (x1Match && y1Match && x2Match && y2Match) {
          const line = {
            id: id++,
            type: 'line',
            x1: parseFloat(x1Match[1]),
            y1: parseFloat(y1Match[1]),
            z1: z1Match ? parseFloat(z1Match[1]) : 0,
            x2: parseFloat(x2Match[1]),
            y2: parseFloat(y2Match[1]),
            z2: z2Match ? parseFloat(z2Match[1]) : 0
          };
          geometry.push(line);
        }
      }
      
      // Extract ALL POLYLINE/LWPOLYLINE entities
      const polyPattern = /^\s*0\s*\n(LWPOLYLINE|POLYLINE)\s*\n([\s\S]*?)(?=^\s*0\s*\n)/gm;
      
      while ((match = polyPattern.exec(str)) !== null) {
        const block = match[2];
        const coords: Array<[number, number, number]> = [];
        const coordPattern = /^\s*10\s*\n\s*(-?\d+\.?\d*)\s*\n\s*20\s*\n\s*(-?\d+\.?\d*)/gm;
        let coordMatch;
        
        while ((coordMatch = coordPattern.exec(block)) !== null) {
          const x = parseFloat(coordMatch[1]);
          const y = parseFloat(coordMatch[2]);
          const zMatch = /^\s*30\s*\n\s*(-?\d+\.?\d*)/m.exec(block.substring(coordMatch.index + coordMatch[0].length));
          const z = zMatch ? parseFloat(zMatch[1]) : 0;
          coords.push([x, y, z]);
        }
        
        if (coords.length > 0) {
          geometry.push({
            id: id++,
            type: 'polyline',
            points: coords
          });
        }
      }
      
      // Extract ALL CIRCLE entities
      const circlePattern = /^\s*0\s*\nCIRCLE\s*\n([\s\S]*?)(?=^\s*0\s*\n)/gm;
      
      while ((match = circlePattern.exec(str)) !== null) {
        const block = match[1];
        const xMatch = block.match(/^\s*10\s*\n\s*(-?\d+\.?\d*)/m);
        const yMatch = block.match(/^\s*20\s*\n\s*(-?\d+\.?\d*)/m);
        const zMatch = block.match(/^\s*30\s*\n\s*(-?\d+\.?\d*)/m);
        const rMatch = block.match(/^\s*40\s*\n\s*(-?\d+\.?\d*)/m);
        
        if (xMatch && yMatch && rMatch) {
          geometry.push({
            id: id++,
            type: 'circle',
            x: parseFloat(xMatch[1]),
            y: parseFloat(yMatch[1]),
            z: zMatch ? parseFloat(zMatch[1]) : 0,
            radius: parseFloat(rMatch[1])
          });
        }
      }
      
      // Extract ALL ARC entities
      const arcPattern = /^\s*0\s*\nARC\s*\n([\s\S]*?)(?=^\s*0\s*\n)/gm;
      
      while ((match = arcPattern.exec(str)) !== null) {
        const block = match[1];
        const xMatch = block.match(/^\s*10\s*\n\s*(-?\d+\.?\d*)/m);
        const yMatch = block.match(/^\s*20\s*\n\s*(-?\d+\.?\d*)/m);
        const zMatch = block.match(/^\s*30\s*\n\s*(-?\d+\.?\d*)/m);
        const rMatch = block.match(/^\s*40\s*\n\s*(-?\d+\.?\d*)/m);
        const startMatch = block.match(/^\s*50\s*\n\s*(-?\d+\.?\d*)/m);
        const endMatch = block.match(/^\s*51\s*\n\s*(-?\d+\.?\d*)/m);
        
        if (xMatch && yMatch && rMatch) {
          geometry.push({
            id: id++,
            type: 'arc',
            x: parseFloat(xMatch[1]),
            y: parseFloat(yMatch[1]),
            z: zMatch ? parseFloat(zMatch[1]) : 0,
            radius: parseFloat(rMatch[1]),
            startAngle: startMatch ? parseFloat(startMatch[1]) : 0,
            endAngle: endMatch ? parseFloat(endMatch[1]) : 360
          });
        }
      }
      
      // Extract ALL TEXT entities
      const textPattern = /^\s*0\s*\nTEXT\s*\n([\s\S]*?)(?=^\s*0\s*\n)/gm;
      
      while ((match = textPattern.exec(str)) !== null) {
        const block = match[1];
        const xMatch = block.match(/^\s*10\s*\n\s*(-?\d+\.?\d*)/m);
        const yMatch = block.match(/^\s*20\s*\n\s*(-?\d+\.?\d*)/m);
        const zMatch = block.match(/^\s*30\s*\n\s*(-?\d+\.?\d*)/m);
        const contentMatch = block.match(/^\s*1\s*\n\s*(.+)/m);
        
        if (xMatch && yMatch && contentMatch) {
          geometry.push({
            id: id++,
            type: 'text',
            x: parseFloat(xMatch[1]),
            y: parseFloat(yMatch[1]),
            z: zMatch ? parseFloat(zMatch[1]) : 0,
            text: contentMatch[1].trim()
          });
        }
      }
      
      console.log(`[DXF] Extracted ${geometry.length} total geometric entities`);
      return geometry;
      
    } catch (e) {
      console.error('DXF Parse Error:', e);
      return [];
    }
  }

  // Parse DWG using LibreDwg (professional parser)
  async function parseAllGeometryDWG(buffer: Buffer): Promise<any[]> {
    const geometry: any[] = [];
    let id = 1;
    
    try {
      // Skip LibreDwg - go straight to LibreOffice conversion
      throw new Error('Using LibreOffice conversion');
    } catch (e: any) {
      console.error('[DWG] ❌ LibreDwg failed:', e.message);
      console.log('[DWG] Attempting DWG→DXF conversion via LibreOffice...');
      
      const tempDir = os.tmpdir();
      const dwgFile = path.join(tempDir, `temp_${Date.now()}.dwg`);
      const dxfFile = path.join(tempDir, `temp_${Date.now()}.dxf`);
      
      try {
        fs.writeFileSync(dwgFile, buffer);
        execSync(`libreoffice --headless --convert-to dxf --outdir "${tempDir}" "${dwgFile}" 2>/dev/null`, { timeout: 60000 });
        
        if (fs.existsSync(dxfFile)) {
          const dxfBuf = fs.readFileSync(dxfFile);
          fs.unlinkSync(dwgFile);
          fs.unlinkSync(dxfFile);
          const dxfGeometry = parseAllGeometryDXF(dxfBuf);
          console.log(`[DWG] ✅ Converted DWG→DXF successfully. Extracted ${dxfGeometry.length} entities`);
          return dxfGeometry;
        }
      } catch (err) {
        console.log('[DWG] LibreOffice conversion failed, using basic extraction');
        try {
          if (fs.existsSync(dwgFile)) fs.unlinkSync(dwgFile);
          if (fs.existsSync(dxfFile)) fs.unlinkSync(dxfFile);
        } catch (e) {}
      }
      
      // Fallback: Basic extraction
      const str = buffer.toString('latin1');
      const numberPattern = /-?\d+\.?\d*/g;
      const allNumbers: number[] = [];
      let numMatch;
      
      while ((numMatch = numberPattern.exec(str)) !== null) {
        const num = parseFloat(numMatch[0]);
        if (!isNaN(num) && Math.abs(num) < 50000) {
          allNumbers.push(num);
        }
      }
      
      for (let i = 0; i < allNumbers.length - 3; i += 4) {
        geometry.push({
          id: id++,
          type: 'line',
          x1: allNumbers[i],
          y1: allNumbers[i + 1],
          z1: 0,
          x2: allNumbers[i + 2],
          y2: allNumbers[i + 3],
          z2: 0
        });
      }
      
      console.log(`[DWG] Basic extraction found ${geometry.length} entities`);
      return geometry;
    }
  }

  const httpServer = createServer(app);
  return httpServer;
}
