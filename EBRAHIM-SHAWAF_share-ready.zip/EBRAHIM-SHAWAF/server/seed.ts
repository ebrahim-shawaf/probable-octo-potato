import { storage } from "./storage";
import fs from "fs";
import path from "path";

// Load GeoJSON with all Egyptian governorates
function loadEgyptDistricts() {
  try {
    const geojsonPath = path.resolve(import.meta.dirname, "../attached_assets/egypt-districts.geojson");
    const geojsonData = JSON.parse(fs.readFileSync(geojsonPath, "utf-8"));
    
    return geojsonData.features.map((feature: any) => ({
      name: feature.properties.name,
      geometry: feature.geometry,
      population: Math.floor(Math.random() * 10000000) + 1000000 // Mock population
    }));
  } catch (error) {
    console.warn("Could not load egypt-districts.geojson, using defaults");
    return defaultDistricts;
  }
}

const defaultDistricts = [
  {
    name: "القاهرة",
    geometry: {
      type: "Polygon",
      coordinates: [[[31.2, 30.0], [31.3, 30.0], [31.3, 30.1], [31.2, 30.1], [31.2, 30.0]]]
    },
    population: 9500000
  },
  {
    name: "الإسكندرية",
    geometry: {
      type: "Polygon",
      coordinates: [[[29.9, 31.2], [30.1, 31.2], [30.1, 31.3], [29.9, 31.3], [29.9, 31.2]]]
    },
    population: 5200000
  },
  {
    name: "الجيزة",
    geometry: {
      type: "Polygon",
      coordinates: [[[31.1, 29.9], [31.3, 29.9], [31.3, 30.0], [31.1, 30.0], [31.1, 29.9]]]
    },
    population: 8600000
  },
  {
    name: "أسيوط",
    geometry: {
      type: "Polygon",
      coordinates: [[[31.1, 27.1], [31.3, 27.1], [31.3, 27.3], [31.1, 27.3], [31.1, 27.1]]]
    },
    population: 4400000
  }
];

const candidates = [
  { name: "أحمد محمد", party: "الحزب الوطني الديمقراطي", color: "#dc2626" },
  { name: "محمود عبد الله", party: "حزب الحرية والعدالة", color: "#16a34a" },
  { name: "خالد إبراهيم", party: "الحزب المصري الديمقراطي الاجتماعي", color: "#2563eb" },
];

export async function seedDatabase() {
  console.log("🌱 Seeding database...");

  try {
    const egyptDistricts = loadEgyptDistricts();
    
    // Check if districts already exist
    const existingDistricts = await storage.getAllDistricts();
    
    if (existingDistricts.length === 0) {
      // Create districts
      console.log(`Creating ${egyptDistricts.length} districts...`);
      for (const district of egyptDistricts) {
        await storage.createDistrict(district);
      }
      console.log(`✅ Created ${egyptDistricts.length} districts`);
    } else {
      console.log(`ℹ️  Districts already exist (${existingDistricts.length} found)`);
    }

    // Check if candidates already exist
    const existingCandidates = await storage.getAllCandidates();
    
    if (existingCandidates.length === 0) {
      // Create candidates
      console.log("Creating candidates...");
      for (const candidate of candidates) {
        await storage.createCandidate(candidate);
      }
      console.log(`✅ Created ${candidates.length} candidates`);
    } else {
      console.log(`ℹ️  Candidates already exist (${existingCandidates.length} found)`);
    }

    console.log("✨ Database seeded successfully!");
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}
