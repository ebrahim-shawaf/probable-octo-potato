#!/bin/bash

# Egyptian first names
FIRST_NAMES=("أحمد" "محمد" "علي" "حسن" "إبراهيم" "عبدالله" "فاطمة" "عائشة" "هناء" "زينب" "نور" "أمل" "سارة" "ليلى" "مريم" "نادية" "رانية" "شيماء" "ايمان" "سلمى" "منى" "هدى" "غادة" "دينا" "ريم" "ندى" "لمى" "ايمن" "محمود" "ياسين" "عماد" "خالد" "سيف" "طارق" "عزيز" "سامي" "جمال" "نزيه" "حازم" "أشرف" "إياد" "رامي" "عبدالرزاق" "يوسف" "صادق" "وائل" "جواد" "أمير" "بشار" "حسام")

LAST_NAMES=("محمود" "علي" "حسن" "عبدالعزيز" "عبدالرحمن" "عبدالفتاح" "محمد" "سالم" "سعد" "قاسم" "علوان" "حامد" "ناصر" "خليل" "رضا" "صالح" "فرج" "حجازي" "إمام" "عبدة")

STREETS=("مدرسة" "لجنة" "جامعة" "نادي" "مركز" "كنيسة")
STREET_TYPES=("الثانوية" "الإعدادية" "الابتدائية" "الرياضية" "العسكرية" "الفنية")

# Get districts from API
DISTRICTS=$(curl -s http://localhost:5000/api/districts | grep -o '"id":"[^"]*"[^}]*"name":"[^"]*"' | sed 's/.*"id":"//' | sed 's/".*"name":"/,/' | sed 's/".*//')

# Function to generate random name
generate_name() {
  local first=${FIRST_NAMES[$RANDOM % ${#FIRST_NAMES[@]}]}
  local second=${FIRST_NAMES[$RANDOM % ${#FIRST_NAMES[@]}]}
  local last=${LAST_NAMES[$RANDOM % ${#LAST_NAMES[@]}]}
  echo "$first $second $last"
}

# Function to generate random polling station
generate_station() {
  local street=${STREETS[$RANDOM % ${#STREETS[@]}]}
  local type=${STREET_TYPES[$RANDOM % ${#STREET_TYPES[@]}]}
  echo "$street $type $((RANDOM % 10 + 1))"
}

# Clear old data
psql "$DATABASE_URL" -c "DELETE FROM voters;" 2>/dev/null

# Import voters
TOTAL=$(echo "$DISTRICTS" | wc -l)
COUNT=0
IMPORTED=0

echo "$DISTRICTS" | while read DIST_LINE; do
  DIST_ID=$(echo "$DIST_LINE" | cut -d',' -f1)
  DIST_NAME=$(echo "$DIST_LINE" | cut -d',' -f2)
  
  # Generate 10-15 voters per district (realistic for demo)
  VOTER_COUNT=$((RANDOM % 6 + 10))
  
  for ((i=0; i<VOTER_COUNT; i++)); do
    NAME=$(generate_name)
    STATION=$(generate_station)
    
    curl -s -X POST http://localhost:5000/api/voters \
      -H "Content-Type: application/json" \
      -H "x-admin-key: demo-admin-key-2024" \
      -d "{\"name\":\"$NAME\",\"districtId\":\"$DIST_ID\",\"pollingStation\":\"$STATION\"}" > /dev/null 2>&1 && ((IMPORTED++)) || true
  done
  
  ((COUNT++))
  echo "📊 معالجة المحافظة $COUNT من $TOTAL..."
done

echo "✅ تم استيراد $IMPORTED ناخب من جميع محافظات مصر"
