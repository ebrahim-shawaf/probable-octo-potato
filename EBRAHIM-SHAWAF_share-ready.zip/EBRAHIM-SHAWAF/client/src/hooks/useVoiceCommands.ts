import { useEffect, useState, useCallback } from 'react';
import { toast } from 'sonner';

interface VoiceCommand {
  command: string;
  action: () => void;
  keywords: string[];
}

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export const useVoiceCommands = (commands: VoiceCommand[]) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [recognition, setRecognition] = useState<any>(null);

  useEffect(() => {
    // تحقق من دعم Web Speech API
    const SpeechRecognitionAPI = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (!SpeechRecognitionAPI) {
      console.error('Speech Recognition API not supported');
      return;
    }

    const rec = new SpeechRecognitionAPI();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = 'ar-SA'; // العربية
    
    rec.onstart = () => {
      setIsListening(true);
      toast.info('🎤 يستمع...');
    };

    rec.onend = () => {
      setIsListening(false);
      setTranscript('');
    };

    rec.onresult = (event: any) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        
        if (event.results[i].isFinal) {
          finalTranscript += transcript + ' ';
        } else {
          interimTranscript += transcript;
        }
      }

      setTranscript(interimTranscript || finalTranscript);

      // معالجة الأوامر الصوتية الكاملة
      if (finalTranscript) {
        const lowerTranscript = finalTranscript.toLowerCase().trim();
        console.log('🎤 الأمر الصوتي:', lowerTranscript);

        // البحث عن أوامر مطابقة
        for (const cmd of commands) {
          for (const keyword of cmd.keywords) {
            if (lowerTranscript.includes(keyword.toLowerCase())) {
              console.log('✅ تم اكتشاف الأمر:', cmd.command);
              cmd.action();
              toast.success(`✅ تم تنفيذ: ${cmd.command}`);
              return;
            }
          }
        }

        // لم يتم العثور على أمر
        toast.error(`❌ أمر غير مدعوم: "${finalTranscript}"`);
      }
    };

    rec.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      if (event.error !== 'no-speech') {
        toast.error(`❌ خطأ في التعرف الصوتي: ${event.error}`);
      }
    };

    setRecognition(rec);

    return () => {
      try {
        rec.stop();
      } catch (e) {
        // ignore
      }
    };
  }, [commands]);

  const startListening = useCallback(() => {
    if (recognition && !isListening) {
      setTranscript('');
      recognition.start();
    }
  }, [recognition, isListening]);

  const stopListening = useCallback(() => {
    if (recognition && isListening) {
      recognition.stop();
    }
  }, [recognition, isListening]);

  const toggleListening = useCallback(() => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  }, [isListening, startListening, stopListening]);

  return {
    isListening,
    transcript,
    startListening,
    stopListening,
    toggleListening,
    isSupported: recognition !== null
  };
};
