import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster as Sonner } from "@/components/ui/sonner";
import Home from "@/pages/Home";
import QRCodePage from "@/pages/QRCode";
import SurveyCalculator from "@/pages/SurveyCalculator";
import CoordinatesExtractor from "@/pages/CoordinatesExtractor";
import SurveyingScience from "@/pages/SurveyingScience";
import CameraMeasurement from "@/pages/CameraMeasurement";
import CameraCoordinates from "@/pages/CameraCoordinates";
import SurveyingSoftware from "@/pages/SurveyingSoftware";
import Visualization3D from "@/pages/Visualization3D";
import PrecisionCameraMeasurement from "@/pages/PrecisionCameraMeasurement";
import CameraTools from "@/pages/CameraTools";
import UnifiedCameraTools from "@/pages/UnifiedCameraTools";
import WaterNetworkUnified from "@/pages/WaterNetworkUnified";
import CutFillCalculator from "@/pages/CutFillCalculator";
import ConcreteAndSteelCalculator from "@/pages/ConcreteAndSteelCalculator";
import StructuralBOQ from "@/pages/StructuralBOQ";
import UnitConverter from "@/pages/UnitConverter";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/qrcode" component={QRCodePage} />
      <Route path="/calculator" component={SurveyCalculator} />
      <Route path="/coordinates" component={CoordinatesExtractor} />
      <Route path="/science" component={SurveyingScience} />
      <Route path="/camera" component={CameraTools} />
      <Route path="/camera-gps" component={CameraTools} />
      <Route path="/camera-tools" component={CameraTools} />
      <Route path="/software" component={SurveyingSoftware} />
      <Route path="/visualization" component={Visualization3D} />
      <Route path="/precision-camera" component={PrecisionCameraMeasurement} />
      <Route path="/water-network" component={WaterNetworkUnified} />
      <Route path="/cut-fill" component={CutFillCalculator} />
      <Route path="/concrete-steel" component={ConcreteAndSteelCalculator} />
      <Route path="/structural-boq" component={StructuralBOQ} />
      <Route path="/unit-converter" component={UnitConverter} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
