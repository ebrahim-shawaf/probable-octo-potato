declare module 'shpjs' {
  interface GeoJSONFeature {
    type: string;
    geometry: {
      type: string;
      coordinates: any;
    };
    properties: Record<string, any>;
  }

  interface GeoJSONFeatureCollection {
    type: string;
    features: GeoJSONFeature[];
  }

  function shp(input: ArrayBuffer | string): Promise<GeoJSONFeatureCollection | GeoJSONFeatureCollection[]>;
  
  export default shp;
}
