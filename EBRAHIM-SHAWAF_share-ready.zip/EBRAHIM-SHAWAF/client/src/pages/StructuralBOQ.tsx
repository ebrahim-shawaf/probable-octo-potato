import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowRight, Plus, Trash2, Download } from "lucide-react";
import { useLanguage } from "@/lib/i18n";
import { toast } from "sonner";

interface Item {
  id: number;
  type: 'column' | 'foundation' | 'stair';
  length: number;
  width: number;
  height: number;
  qty: number;
  description: string;
}

export default function StructuralBOQ() {
  const { language } = useLanguage();
  const isRTL = language === 'ar';
  
  const [items, setItems] = useState<Item[]>([
    { id: 1, type: 'column', length: 0.5, width: 0.5, height: 3, qty: 1, description: 'عمود' }
  ]);
  const [nextId, setNextId] = useState(2);
  const [steelRatio, setSteelRatio] = useState(1.5);

  const addItem = (type: 'column' | 'foundation' | 'stair') => {
    let desc = '';
    if (type === 'column') desc = language === 'ar' ? 'عمود' : 'Column';
    else if (type === 'foundation') desc = language === 'ar' ? 'قاعدة' : 'Foundation';
    else desc = language === 'ar' ? 'سلم' : 'Stair';
    
    setItems([...items, { id: nextId, type, length: 0.5, width: 0.5, height: 3, qty: 1, description: desc }]);
    setNextId(nextId + 1);
  };

  const removeItem = (id: number) => {
    if (items.length > 1) setItems(items.filter(i => i.id !== id));
  };

  const updateItem = (id: number, field: string, value: any) => {
    setItems(items.map(i => i.id === id ? { ...i, [field]: value } : i));
  };

  const calcVolume = (item: Item) => {
    if (item.type === 'column') return item.length * item.width * item.height * item.qty;
    if (item.type === 'foundation') return item.length * item.width * item.height * item.qty;
    if (item.type === 'stair') return item.length * item.width * (item.height / 2) * item.qty; // Simplified stair volume
    return 0;
  };

  const getTotalByConcrete = () => {
    const columns = items.filter(i => i.type === 'column').reduce((sum, i) => sum + calcVolume(i), 0);
    const foundations = items.filter(i => i.type === 'foundation').reduce((sum, i) => sum + calcVolume(i), 0);
    const stairs = items.filter(i => i.type === 'stair').reduce((sum, i) => sum + calcVolume(i), 0);
    return { columns, foundations, stairs, total: columns + foundations + stairs };
  };

  const getTypeLabel = (type: string) => {
    if (type === 'column') return language === 'ar' ? 'أعمدة' : 'Columns';
    if (type === 'foundation') return language === 'ar' ? 'قواعد' : 'Foundations';
    if (type === 'stair') return language === 'ar' ? 'سلالم' : 'Stairs';
    return '';
  };

  const totals = getTotalByConcrete();
  const totalWeight = totals.total * 2400;
  const totalSteel = (totalWeight * steelRatio) / 100;

  const exportReport = () => {
    let csv = 'البند\tالطول\tالعرض\tالارتفاع\tالعدد\tالحجم\n';
    items.forEach(i => {
      csv += `${i.description}\t${i.length}\t${i.width}\t${i.height}\t${i.qty}\t${calcVolume(i).toFixed(3)}\n`;
    });
    csv += '\n\nالملخص\n';
    csv += `أعمدة: ${totals.columns.toFixed(3)} م³\n`;
    csv += `قواعد: ${totals.foundations.toFixed(3)} م³\n`;
    csv += `سلالم: ${totals.stairs.toFixed(3)} م³\n`;
    csv += `الإجمالي: ${totals.total.toFixed(3)} م³\n`;
    csv += `وزن الخرسانة: ${totalWeight.toFixed(0)} كغ\n`;
    csv += `الفولاذ (${steelRatio}%): ${totalSteel.toFixed(2)} كغ\n`;

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `boq-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(language === 'ar' ? '✅ تم التصدير' : '✅ Exported');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900/20 to-slate-900" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 right-10 w-72 h-72 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-10 left-10 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="sticky top-0 z-50 bg-black/40 backdrop-blur-md border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
          <Link href="/">
            <Button variant="ghost" className="text-white hover:bg-white/10" data-testid="button-back-home">
              <ArrowRight className="w-5 h-5 ml-2" />
              {language === 'ar' ? 'الرئيسية' : 'Home'}
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-white">📋 {language === 'ar' ? 'حصر البنود' : 'BOQ'}</h1>
        </div>
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 py-6 space-y-6">
        {/* Settings */}
        <Card className="bg-white/10 border-white/20">
          <CardHeader>
            <CardTitle className="text-white">{language === 'ar' ? 'الإعدادات' : 'Settings'}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label className="text-gray-200">{language === 'ar' ? 'نسبة التسليح %' : 'Steel Ratio %'}</Label>
                <Input type="number" value={steelRatio} onChange={(e) => setSteelRatio(parseFloat(e.target.value) || 1.5)} min="0.5" step="0.1" className="bg-white/10 border-white/20 text-white" data-testid="input-steel-ratio" />
              </div>
              <div className="flex gap-2 items-end">
                <Button onClick={() => addItem('column')} className="flex-1 bg-green-600 hover:bg-green-700" size="sm" data-testid="button-add-column">
                  {language === 'ar' ? '+ عمود' : '+ Column'}
                </Button>
              </div>
              <div className="flex gap-2 items-end">
                <Button onClick={() => addItem('foundation')} className="flex-1 bg-blue-600 hover:bg-blue-700" size="sm" data-testid="button-add-foundation">
                  {language === 'ar' ? '+ قاعدة' : '+ Foundation'}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Items Table */}
        <Card className="bg-white/10 border-white/20">
          <CardHeader>
            <CardTitle className="text-white">{language === 'ar' ? 'البنود' : 'Items'}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-gray-200">
                <thead>
                  <tr className="border-b border-white/20">
                    <th className="text-left px-3 py-2">#</th>
                    <th className="text-left px-3 py-2">{language === 'ar' ? 'النوع' : 'Type'}</th>
                    <th className="text-left px-3 py-2">{language === 'ar' ? 'الطول' : 'Length'}</th>
                    <th className="text-left px-3 py-2">{language === 'ar' ? 'العرض' : 'Width'}</th>
                    <th className="text-left px-3 py-2">{language === 'ar' ? 'الارتفاع' : 'Height'}</th>
                    <th className="text-left px-3 py-2">{language === 'ar' ? 'العدد' : 'Qty'}</th>
                    <th className="text-left px-3 py-2">{language === 'ar' ? 'الحجم' : 'Volume'}</th>
                    <th className="text-center px-3 py-2">{language === 'ar' ? 'حذف' : 'Delete'}</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((item, idx) => (
                    <tr key={item.id} className="border-b border-white/10 hover:bg-white/5">
                      <td className="px-3 py-2">{idx + 1}</td>
                      <td className="px-3 py-2 font-semibold">{getTypeLabel(item.type)}</td>
                      <td className="px-3 py-2">
                        <Input type="number" value={item.length} onChange={(e) => updateItem(item.id, 'length', parseFloat(e.target.value))} step="0.1" className="bg-white/5 border-white/10 text-white w-16 h-8 text-xs" data-testid={`input-length-${item.id}`} />
                      </td>
                      <td className="px-3 py-2">
                        <Input type="number" value={item.width} onChange={(e) => updateItem(item.id, 'width', parseFloat(e.target.value))} step="0.1" className="bg-white/5 border-white/10 text-white w-16 h-8 text-xs" data-testid={`input-width-${item.id}`} />
                      </td>
                      <td className="px-3 py-2">
                        <Input type="number" value={item.height} onChange={(e) => updateItem(item.id, 'height', parseFloat(e.target.value))} step="0.1" className="bg-white/5 border-white/10 text-white w-16 h-8 text-xs" data-testid={`input-height-${item.id}`} />
                      </td>
                      <td className="px-3 py-2">
                        <Input type="number" value={item.qty} onChange={(e) => updateItem(item.id, 'qty', parseInt(e.target.value))} min="1" className="bg-white/5 border-white/10 text-white w-14 h-8 text-xs" data-testid={`input-qty-${item.id}`} />
                      </td>
                      <td className="px-3 py-2 font-semibold text-amber-400">{calcVolume(item).toFixed(3)} m³</td>
                      <td className="px-3 py-2 text-center">
                        <Button onClick={() => removeItem(item.id)} variant="destructive" size="sm" className="h-6 w-6 p-0" data-testid={`button-remove-${item.id}`}>
                          ×
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-green-500/20 to-emerald-600/20 border-green-400/30">
            <CardContent className="pt-6">
              <p className="text-gray-300 text-sm">{language === 'ar' ? 'أعمدة' : 'Columns'}</p>
              <p className="text-2xl font-bold text-white" data-testid="text-columns-volume">{totals.columns.toFixed(3)}</p>
              <p className="text-xs text-gray-400">m³</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-blue-500/20 to-indigo-600/20 border-blue-400/30">
            <CardContent className="pt-6">
              <p className="text-gray-300 text-sm">{language === 'ar' ? 'قواعد' : 'Foundations'}</p>
              <p className="text-2xl font-bold text-white" data-testid="text-foundations-volume">{totals.foundations.toFixed(3)}</p>
              <p className="text-xs text-gray-400">m³</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-purple-500/20 to-pink-600/20 border-purple-400/30">
            <CardContent className="pt-6">
              <p className="text-gray-300 text-sm">{language === 'ar' ? 'الإجمالي' : 'Total'}</p>
              <p className="text-2xl font-bold text-white" data-testid="text-total-volume">{totals.total.toFixed(3)}</p>
              <p className="text-xs text-gray-400">m³</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-yellow-500/20 to-orange-600/20 border-yellow-400/30">
            <CardContent className="pt-6">
              <p className="text-gray-300 text-sm">{language === 'ar' ? 'الفولاذ' : 'Steel'}</p>
              <p className="text-2xl font-bold text-white" data-testid="text-steel-weight">{totalSteel.toFixed(0)}</p>
              <p className="text-xs text-gray-400">kg</p>
            </CardContent>
          </Card>
        </div>

        <Button onClick={exportReport} className="w-full bg-amber-600 hover:bg-amber-700" size="lg" data-testid="button-export">
          <Download className="w-5 h-5 ml-2" />
          {language === 'ar' ? '📥 تصدير الحصر' : '📥 Export BOQ'}
        </Button>
      </div>
    </div>
  );
}
