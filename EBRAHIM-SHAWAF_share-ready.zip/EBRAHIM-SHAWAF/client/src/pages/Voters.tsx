import { useQuery } from "@tanstack/react-query";
import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Download, Users } from "lucide-react";
import type { Voter } from "@shared/schema";

async function fetchVoters() {
  const [votersRes, districtsRes] = await Promise.all([
    fetch("/api/voters"),
    fetch("/api/districts"),
  ]);

  const voters = await votersRes.json() as Voter[];
  const districts = await districtsRes.json();

  return { voters, districts };
}

export default function Voters() {
  const { data, isLoading } = useQuery({
    queryKey: ["voters"],
    queryFn: fetchVoters,
    refetchInterval: 5000,
  });

  const [searchName, setSearchName] = useState("");
  const [selectedDistrict, setSelectedDistrict] = useState<string>("");

  const filtered = useMemo(() => {
    if (!data?.voters) return [];

    return data.voters.filter(voter => {
      const matchName = voter.name.toLowerCase().includes(searchName.toLowerCase());
      const matchDistrict = !selectedDistrict || voter.districtId === selectedDistrict;
      return matchName && matchDistrict;
    });
  }, [data?.voters, searchName, selectedDistrict]);

  const downloadVoterData = async () => {
    const response = await fetch("/api/export/voters");
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `voters_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-card to-background p-6">
        <div className="max-w-6xl mx-auto space-y-6">
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      </div>
    );
  }

  const { voters, districts } = data!;
  const uniqueDistricts = Array.from(new Map(
    voters.map(v => {
      const d = districts.find((d: any) => d.id === v.districtId);
      return [v.districtId, d];
    })
  ).values());

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card to-background p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-primary text-primary-foreground rounded-lg p-6 shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Users className="w-8 h-8" />
              <div>
                <h1 className="text-3xl font-bold">بيانات الناخبين</h1>
                <p className="text-sm opacity-90 mt-1">إدارة وتصفح المسجلين بقاعدة البيانات</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-4xl font-bold">{voters.length}</div>
              <p className="text-sm opacity-90">ناخب مسجل</p>
            </div>
          </div>
        </div>

        {/* Filters and Export */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle>الفلاتر والبحث</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label htmlFor="search" className="text-sm font-medium">البحث بالاسم</label>
                <Input
                  id="search"
                  data-testid="input-search-voter"
                  placeholder="اكتب اسم الناخب..."
                  value={searchName}
                  onChange={(e) => setSearchName(e.target.value)}
                  className="text-right"
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="district-filter" className="text-sm font-medium">المحافظة</label>
                <Select value={selectedDistrict || "all"} onValueChange={(value) => setSelectedDistrict(value === "all" ? "" : value)}>
                  <SelectTrigger id="district-filter" data-testid="select-district-filter">
                    <SelectValue placeholder="كل المحافظات" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">كل المحافظات</SelectItem>
                    {uniqueDistricts.map((district: any) => (
                      <SelectItem key={district.id} value={district.id}>
                        {district.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">&nbsp;</label>
                <Button
                  data-testid="button-export-voters"
                  onClick={downloadVoterData}
                  className="w-full"
                  variant="outline"
                >
                  <Download className="w-4 h-4 ml-2" />
                  تحميل البيانات
                </Button>
              </div>
            </div>
            <div className="text-sm text-muted-foreground">
              عدد النتائج: <strong>{filtered.length}</strong>
            </div>
          </CardContent>
        </Card>

        {/* Voters Table */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle>قائمة الناخبين</CardTitle>
          </CardHeader>
          <CardContent>
            {filtered.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <p>لا توجد نتائج للبحث</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right text-sm">
                  <thead className="bg-muted border-b-2 border-border">
                    <tr>
                      <th className="px-4 py-3 font-semibold">الاسم</th>
                      <th className="px-4 py-3 font-semibold">المحافظة</th>
                      <th className="px-4 py-3 font-semibold">اللجنة / المدرسة</th>
                      <th className="px-4 py-3 font-semibold">تاريخ التسجيل</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {filtered.map((voter, idx) => {
                      const district = districts.find((d: any) => d.id === voter.districtId);
                      const createdDate = new Date(voter.createdAt).toLocaleDateString('ar-EG', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      });

                      return (
                        <tr key={voter.id} data-testid={`row-voter-${idx}`} className="hover:bg-muted/50 transition-colors">
                          <td className="px-4 py-3">
                            <span className="font-medium">{voter.name}</span>
                          </td>
                          <td className="px-4 py-3">
                            <Badge variant="secondary">
                              {district?.name || "Unknown"}
                            </Badge>
                          </td>
                          <td className="px-4 py-3 text-sm">
                            {voter.pollingStation}
                          </td>
                          <td className="px-4 py-3 text-xs text-muted-foreground">
                            {createdDate}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle className="text-lg">توزيع الناخبين حسب المحافظة</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {uniqueDistricts.map((district: any) => {
                  const count = voters.filter((v: Voter) => v.districtId === district.id).length;
                  const percentage = Math.round((count / voters.length) * 100);
                  return (
                    <div key={district.id} className="flex items-center justify-between">
                      <span className="text-sm font-medium">{district.name}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-32 h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary rounded-full transition-all"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                        <span className="text-sm font-semibold w-12 text-left">{count}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle className="text-lg">إحصائيات</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">إجمالي الناخبين المسجلين</p>
                <p className="text-3xl font-bold text-primary">{voters.length}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">عدد المحافظات</p>
                <p className="text-3xl font-bold text-primary">{uniqueDistricts.length}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">عدد اللجان الفريدة</p>
                <p className="text-3xl font-bold text-primary">
                  {new Set(voters.map(v => v.pollingStation)).size}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
