import { useState, useRef, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Camera, RotateCcw, Download, Info } from "lucide-react";

interface Point {
  x: number;
  y: number;
  id: number;
}

export default function CameraMeasurement() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [points, setPoints] = useState<Point[]>([]);
  const [cameraActive, setCameraActive] = useState(false);
  const [measurements, setMeasurements] = useState<number[]>([]);
  const [nextId, setNextId] = useState(0);
  const [calibrationDistance, setCalibrationDistance] = useState(1); // في متر
  const [showDetails, setShowDetails] = useState(true);

  // تنظيف الموارد عند الخروج من الصفحة
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  useEffect(() => {
    if (cameraActive) {
      startCamera();
    } else {
      stopCamera();
    }
  }, [cameraActive]);

  const startCamera = async () => {
    try {
      // تنظيف الكاميرا السابقة
      if (videoRef.current?.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach((track) => track.stop());
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (error: any) {
      console.error("Error accessing camera:", error);
      let errorMessage = "لا يمكن الوصول للكاميرا";
      if (error.name === "NotAllowedError") {
        errorMessage = "تم رفض إذن الكاميرا. يرجى السماح بالوصول للكاميرا.";
      } else if (error.name === "NotFoundError") {
        errorMessage = "لم يتم العثور على كاميرا على جهازك.";
      }
      alert(errorMessage);
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach((track) => track.stop());
    }
  };

  const getCanvasCoordinates = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    return { x, y };
  };

  const addPoint = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const coords = getCanvasCoordinates(e);
    if (!coords) return;

    const newPoint: Point = {
      x: coords.x,
      y: coords.y,
      id: nextId,
    };

    const newPoints = [...points, newPoint];
    setPoints(newPoints);
    setNextId(nextId + 1);

    // إذا كان لدينا نقطتين أو أكثر، احسب المسافة بين آخر نقطتين
    if (newPoints.length >= 2) {
      const lastPoint = newPoints[newPoints.length - 1];
      const prevPoint = newPoints[newPoints.length - 2];

      const pixelDistance = Math.sqrt(
        Math.pow(lastPoint.x - prevPoint.x, 2) +
          Math.pow(lastPoint.y - prevPoint.y, 2)
      );

      const realDistance = (pixelDistance / 100) * calibrationDistance; // تحويل البكسل لمتر
      setMeasurements([...measurements, realDistance]);
    }

    drawPoints(newPoints);
  };

  const drawPoints = (pointsList: Point[]) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // امسح الرسم السابق
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // رسم النقاط
    pointsList.forEach((point, index) => {
      // رسم الدائرة
      ctx.beginPath();
      ctx.arc(point.x, point.y, 8, 0, 2 * Math.PI);
      ctx.fillStyle = "#3B82F6";
      ctx.fill();
      ctx.strokeStyle = "#FFFFFF";
      ctx.lineWidth = 2;
      ctx.stroke();

      // رسم الرقم
      ctx.fillStyle = "#FFFFFF";
      ctx.font = "bold 12px Arial";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText((index + 1).toString(), point.x, point.y);
    });

    // رسم الخطوط بين النقاط
    if (pointsList.length > 1) {
      ctx.beginPath();
      ctx.moveTo(pointsList[0].x, pointsList[0].y);

      for (let i = 1; i < pointsList.length; i++) {
        ctx.lineTo(pointsList[i].x, pointsList[i].y);

        // رسم المسافة بين النقطتين
        const distance = measurements[i - 1];
        if (distance !== undefined) {
          const midX = (pointsList[i].x + pointsList[i - 1].x) / 2;
          const midY = (pointsList[i].y + pointsList[i - 1].y) / 2;

          ctx.fillStyle = "#10B981";
          ctx.font = "bold 14px Arial";
          ctx.fillText(
            distance.toFixed(2) + " م",
            midX,
            midY - 15
          );
        }
      }

      ctx.strokeStyle = "#3B82F6";
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  };

  const clearMeasurements = () => {
    setPoints([]);
    setMeasurements([]);
    setNextId(0);
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext("2d");
      if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  const downloadMeasurements = () => {
    if (measurements.length === 0) {
      alert("لا توجد قياسات لتحميلها");
      return;
    }

    let text = "تقرير قياسات الكاميرا\n";
    text += "==================\n\n";
    text += `تاريخ القياس: ${new Date().toLocaleString('ar-EG')}\n`;
    text += `المسافة المرجعية المستخدمة: ${calibrationDistance.toFixed(2)} متر\n\n`;

    text += "القياسات:\n";
    text += "---------\n";

    measurements.forEach((measure, index) => {
      text += `المسافة ${index + 1}: ${measure.toFixed(2)} متر\n`;
    });

    const totalDistance = measurements.reduce((a, b) => a + b, 0);
    text += `\nإجمالي المسافات: ${totalDistance.toFixed(2)} متر\n`;
    text += `عدد القياسات: ${measurements.length}\n`;
    text += `المتوسط: ${(totalDistance / measurements.length).toFixed(2)} متر\n`;

    text += "\nملاحظات:\n";
    text += "- القياسات التقريبية بناءً على كاميرا الجوال\n";
    text += "- الدقة تعتمد على المعايرة الصحيحة\n";
    text += "- يفضل استخدام قياس مرجعي معروف للمعايرة\n";

    const blob = new Blob([text], { type: "text/plain" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `measurements_${Date.now()}.txt`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 to-slate-800 text-white" data-testid="camera-measurement-page">
      {/* Navigation */}
      <div className="sticky top-0 z-10 bg-black/30 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">قياس الكاميرا</h1>
          <Link href="/">
            <Button variant="ghost" className="text-white hover:bg-white/10" data-testid="button-back-home">
              <ArrowRight className="w-4 h-4 ml-2" />
              العودة للرئيسية
            </Button>
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid md:grid-cols-3 gap-6">
          {/* Camera and Canvas */}
          <div className="md:col-span-2">
            {/* Combined Camera View with Canvas Overlay */}
            <div className="bg-black rounded-xl overflow-hidden border-2 border-blue-400 mb-6 relative">
              {!cameraActive ? (
                <div className="aspect-video flex items-center justify-center bg-gray-900">
                  <div className="text-center">
                    <Camera className="w-12 h-12 mx-auto mb-4 text-gray-500" />
                    <p className="text-gray-400 mb-4">انقر لتشغيل الكاميرا</p>
                  </div>
                </div>
              ) : (
                <div className="aspect-video relative w-full h-full" style={{ paddingBottom: '66.67%' }}>
                  {/* Video Stream */}
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    className="absolute top-0 left-0 w-full h-full object-cover"
                  />
                  
                  {/* Canvas Overlay for Measurements */}
                  <canvas
                    ref={canvasRef}
                    width={640}
                    height={480}
                    onClick={addPoint}
                    className="absolute top-0 left-0 w-full h-full cursor-crosshair"
                    style={{ display: 'block' }}
                    data-testid="measurement-canvas"
                  />
                </div>
              )}
            </div>

            {cameraActive && (
              <p className="text-sm text-gray-400 text-center mb-6">
                اضغط على النقاط لقياس المسافات (النقطة الأولى = البداية، النقطة الثانية = النهاية)
              </p>
            )}

            {/* Controls */}
            <div className="flex gap-4 flex-wrap mb-6">
              <Button
                onClick={() => setCameraActive(!cameraActive)}
                size="lg"
                className="flex-1"
                data-testid="button-toggle-camera"
              >
                <Camera className="w-4 h-4 ml-2" />
                {cameraActive ? "إيقاف الكاميرا" : "تشغيل الكاميرا"}
              </Button>

              {cameraActive && (
                <>
                  <Button
                    onClick={clearMeasurements}
                    variant="secondary"
                    size="lg"
                    className="flex-1"
                    data-testid="button-clear"
                  >
                    <RotateCcw className="w-4 h-4 ml-2" />
                    مسح القياسات
                  </Button>

                  <Button
                    onClick={downloadMeasurements}
                    variant="secondary"
                    size="lg"
                    className="flex-1"
                    data-testid="button-download"
                  >
                    <Download className="w-4 h-4 ml-2" />
                    حفظ التقرير
                  </Button>
                </>
              )}
            </div>
          </div>

          {/* Sidebar - Settings and Results */}
          <div className="space-y-6">
            {/* Calibration */}
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
              <h3 className="text-lg font-bold text-blue-400 mb-4">⚙️ المعايرة</h3>
              <div className="space-y-4">
                <p className="text-sm text-gray-300">
                  حدد المسافة المرجعية (بالمتر) لمعايرة القياسات:
                </p>
                <input
                  type="number"
                  value={calibrationDistance}
                  onChange={(e) => setCalibrationDistance(parseFloat(e.target.value) || 1)}
                  className="w-full bg-black/30 border border-blue-400/30 rounded-lg px-3 py-2 text-white text-center"
                  placeholder="المسافة بالمتر"
                  min="0.1"
                  step="0.1"
                  data-testid="input-calibration"
                />
                <p className="text-xs text-gray-400">
                  القيمة الحالية: {calibrationDistance.toFixed(2)} متر
                </p>
              </div>
            </div>

            {/* Measurements */}
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
              <h3 className="text-lg font-bold text-green-400 mb-4">✓ القياسات</h3>

              {measurements.length === 0 ? (
                <p className="text-sm text-gray-400 text-center py-4">
                  لم يتم تسجيل قياسات بعد
                </p>
              ) : (
                <div className="space-y-2">
                  {measurements.map((measure, index) => (
                    <div
                      key={index}
                      className="bg-black/30 rounded-lg p-3 flex justify-between items-center border border-green-400/30"
                      data-testid={`measurement-item-${index}`}
                    >
                      <span className="text-sm">المسافة {index + 1}</span>
                      <span className="font-bold text-green-400">
                        {measure.toFixed(2)} م
                      </span>
                    </div>
                  ))}

                  {measurements.length > 0 && (
                    <div className="bg-blue-500/20 border border-blue-400 rounded-lg p-3 mt-4 space-y-2">
                      <div className="flex justify-between items-center text-sm">
                        <span>الإجمالي</span>
                        <span className="font-bold text-blue-400">
                          {measurements.reduce((a, b) => a + b, 0).toFixed(2)} م
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-xs text-gray-300">
                        <span>المتوسط</span>
                        <span>
                          {(measurements.reduce((a, b) => a + b, 0) / measurements.length).toFixed(2)} م
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-xs text-gray-300">
                        <span>العدد</span>
                        <span>{measurements.length}</span>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Toggle Details */}
            <Button
              onClick={() => setShowDetails(!showDetails)}
              variant="outline"
              className="w-full"
              data-testid="button-toggle-details"
            >
              <Info className="w-4 h-4 ml-2" />
              {showDetails ? "إخفاء التفاصيل" : "عرض التفاصيل"}
            </Button>
          </div>
        </div>

        {/* Detailed Guide */}
        {showDetails && (
          <div className="grid md:grid-cols-2 gap-6 mt-12">
            {/* How It Works */}
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10">
              <h3 className="text-2xl font-bold text-blue-400 mb-6">🎯 كيفية الاستخدام</h3>
              
              <div className="space-y-6">
                <div>
                  <h4 className="text-lg font-bold text-white mb-2">1️⃣ تشغيل الكاميرا</h4>
                  <p className="text-gray-300 text-sm">
                    اضغط على زر "تشغيل الكاميرا" لفتح كاميرا جهازك. سيطلب منك التطبيق إذن للوصول للكاميرا.
                  </p>
                </div>

                <div>
                  <h4 className="text-lg font-bold text-white mb-2">2️⃣ معايرة الكاميرا</h4>
                  <p className="text-gray-300 text-sm mb-2">
                    حدد مسافة مرجعية معروفة (مثل متر واحد)، ثم صور هذه المسافة وأدخل قيمتها في حقل "المعايرة".
                  </p>
                  <p className="text-yellow-400 text-xs bg-yellow-500/10 p-2 rounded border border-yellow-500/30">
                    💡 نصيحة: استخدم مسطرة بطول 1 متر أو 50 سم للمعايرة الدقيقة
                  </p>
                </div>

                <div>
                  <h4 className="text-lg font-bold text-white mb-2">3️⃣ إضافة النقاط</h4>
                  <p className="text-gray-300 text-sm">
                    اضغط على نقطة البداية ثم نقطة النهاية على الشاشة. سيتم حساب المسافة تلقائياً وعرضها بالأمتار.
                  </p>
                </div>

                <div>
                  <h4 className="text-lg font-bold text-white mb-2">4️⃣ حفظ النتائج</h4>
                  <p className="text-gray-300 text-sm">
                    اضغط "حفظ التقرير" لتحميل ملف نصي يحتوي على جميع القياسات والإحصائيات.
                  </p>
                </div>
              </div>
            </div>

            {/* Tips and Notes */}
            <div className="space-y-6">
              {/* Tips */}
              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10">
                <h3 className="text-2xl font-bold text-cyan-400 mb-6">💡 نصائح الاستخدام</h3>
                
                <ul className="space-y-3 text-sm text-gray-300">
                  <li className="flex gap-3">
                    <span className="text-cyan-400 font-bold min-w-fit">✓</span>
                    <span>تأكد من أن الكاميرا موازية للسطح المراد قياسه</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-cyan-400 font-bold min-w-fit">✓</span>
                    <span>استخدم إضاءة جيدة لرؤية واضحة</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-cyan-400 font-bold min-w-fit">✓</span>
                    <span>اضغط على النقاط بدقة في منتصف الجسم</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-cyan-400 font-bold min-w-fit">✓</span>
                    <span>كلما قربت الكاميرا، زادت الدقة</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-cyan-400 font-bold min-w-fit">✓</span>
                    <span>معايرة صحيحة = قياسات دقيقة</span>
                  </li>
                </ul>
              </div>

              {/* Important Notes */}
              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10">
                <h3 className="text-2xl font-bold text-orange-400 mb-6">⚠️ ملاحظات مهمة</h3>
                
                <ul className="space-y-3 text-sm text-gray-300">
                  <li className="flex gap-3">
                    <span className="text-orange-400 font-bold min-w-fit">•</span>
                    <span>هذه الأداة تقريبية وليست دقيقة 100%</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-orange-400 font-bold min-w-fit">•</span>
                    <span>الدقة تعتمد على جودة كاميرا جهازك</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-orange-400 font-bold min-w-fit">•</span>
                    <span>لا تستخدم للقياسات الهندسية الدقيقة جداً</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-orange-400 font-bold min-w-fit">•</span>
                    <span>المنظور والزوايا تؤثر على الدقة</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-orange-400 font-bold min-w-fit">•</span>
                    <span>مناسبة للقياسات التقريبية السريعة</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
