import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowRight } from "lucide-react";
import { useLanguage } from "@/lib/i18n";

interface Conversion {
  from: string;
  to: string;
  factor: number;
}

const lengthConversions: Conversion[] = [
  { from: 'm', to: 'ft', factor: 3.28084 },
  { from: 'm', to: 'km', factor: 0.001 },
  { from: 'm', to: 'mi', factor: 0.000621371 },
  { from: 'm', to: 'cm', factor: 100 },
  { from: 'm', to: 'mm', factor: 1000 },
  { from: 'm', to: 'in', factor: 39.3701 },
  { from: 'm', to: 'yd', factor: 1.09361 },
  { from: 'ft', to: 'm', factor: 0.3048 },
  { from: 'ft', to: 'km', factor: 0.0003048 },
  { from: 'ft', to: 'mi', factor: 0.000189394 },
  { from: 'km', to: 'm', factor: 1000 },
  { from: 'km', to: 'ft', factor: 3280.84 },
  { from: 'km', to: 'mi', factor: 0.621371 },
];

const angleConversions: Conversion[] = [
  { from: '°', to: 'grad', factor: 1.11111 },
  { from: '°', to: 'rad', factor: 0.0174533 },
  { from: '°', to: '\'', factor: 60 },
  { from: '°', to: '"', factor: 3600 },
  { from: 'grad', to: '°', factor: 0.9 },
  { from: 'grad', to: 'rad', factor: 0.0157080 },
  { from: 'rad', to: '°', factor: 57.2958 },
  { from: 'rad', to: 'grad', factor: 63.6620 },
  { from: "'", to: '°', factor: 0.0166667 },
  { from: '"', to: '°', factor: 0.000277778 },
];

const areaConversions: Conversion[] = [
  { from: 'm²', to: 'ft²', factor: 10.7639 },
  { from: 'm²', to: 'hectare', factor: 0.0001 },
  { from: 'm²', to: 'acre', factor: 0.000247105 },
  { from: 'ft²', to: 'm²', factor: 0.092903 },
  { from: 'hectare', to: 'm²', factor: 10000 },
  { from: 'hectare', to: 'acre', factor: 2.47105 },
  { from: 'acre', to: 'm²', factor: 4046.86 },
  { from: 'acre', to: 'hectare', factor: 0.404686 },
];

const volumeConversions: Conversion[] = [
  { from: 'm³', to: 'ft³', factor: 35.3147 },
  { from: 'm³', to: 'L', factor: 1000 },
  { from: 'm³', to: 'gal', factor: 264.172 },
  { from: 'ft³', to: 'm³', factor: 0.0283168 },
  { from: 'ft³', to: 'L', factor: 28.3168 },
  { from: 'L', to: 'm³', factor: 0.001 },
  { from: 'L', to: 'ft³', factor: 0.0353147 },
  { from: 'gal', to: 'm³', factor: 0.00378541 },
];

function convertValue(value: number, conversions: Conversion[], fromUnit: string, toUnit: string): number {
  if (!value || isNaN(value)) return 0;
  
  let result = value;
  
  // Direct conversion
  const direct = conversions.find(c => c.from === fromUnit && c.to === toUnit);
  if (direct) return value * direct.factor;
  
  // Reverse conversion
  const reverse = conversions.find(c => c.from === toUnit && c.to === fromUnit);
  if (reverse) return value / reverse.factor;
  
  // Convert through base unit
  if (fromUnit === toUnit) return value;
  
  return 0;
}

function ConversionSection({ 
  title, 
  conversions, 
  units,
  language 
}: { 
  title: string; 
  conversions: Conversion[]; 
  units: string[];
  language: string;
}) {
  const [value, setValue] = useState<number>(1);
  const [fromUnit, setFromUnit] = useState(units[0]);
  const [toUnit, setToUnit] = useState(units[1] || units[0]);

  const result = convertValue(value, conversions, fromUnit, toUnit);

  return (
    <Card className="bg-white/10 border-white/20">
      <CardHeader>
        <CardTitle className="text-white">{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-gray-200">{language === 'ar' ? 'من' : 'From'}</Label>
            <div className="flex gap-2 mt-2">
              <Input
                type="number"
                value={value}
                onChange={(e) => setValue(parseFloat(e.target.value) || 0)}
                className="bg-white/10 border-white/20 text-white flex-1"
                data-testid={`input-value-${title}`}
              />
              <select
                value={fromUnit}
                onChange={(e) => setFromUnit(e.target.value)}
                className="bg-white/10 border border-white/20 text-white px-3 py-2 rounded"
                data-testid={`select-from-${title}`}
              >
                {units.map(u => <option key={u} value={u}>{u}</option>)}
              </select>
            </div>
          </div>

          <div>
            <Label className="text-gray-200">{language === 'ar' ? 'إلى' : 'To'}</Label>
            <div className="flex gap-2 mt-2">
              <Input
                type="number"
                value={result.toFixed(6)}
                readOnly
                className="bg-white/10 border-white/20 text-white flex-1"
                data-testid={`output-value-${title}`}
              />
              <select
                value={toUnit}
                onChange={(e) => setToUnit(e.target.value)}
                className="bg-white/10 border border-white/20 text-white px-3 py-2 rounded"
                data-testid={`select-to-${title}`}
              >
                {units.map(u => <option key={u} value={u}>{u}</option>)}
              </select>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function UnitConverter() {
  const { language } = useLanguage();
  const isRTL = language === 'ar';

  const lengthUnits = ['m', 'ft', 'km', 'mi', 'cm', 'mm', 'in', 'yd'];
  const angleUnits = ['°', 'grad', 'rad', "'", '"'];
  const areaUnits = ['m²', 'ft²', 'hectare', 'acre'];
  const volumeUnits = ['m³', 'ft³', 'L', 'gal'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 right-10 w-72 h-72 bg-purple-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-10 left-10 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="sticky top-0 z-50 bg-black/40 backdrop-blur-md border-b border-white/10">
        <div className="max-w-4xl mx-auto px-4 py-3 flex justify-between items-center">
          <Link href="/">
            <Button variant="ghost" className="text-white hover:bg-white/10" data-testid="button-back-home">
              <ArrowRight className="w-5 h-5 ml-2" />
              {language === 'ar' ? 'الرئيسية' : 'Home'}
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-white">⚙️ {language === 'ar' ? 'محول الوحدات' : 'Unit Converter'}</h1>
        </div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 py-6">
        <Tabs defaultValue="length" className="w-full">
          <TabsList className="grid grid-cols-4 w-full bg-white/10 border border-white/20">
            <TabsTrigger 
              value="length" 
              className="text-white data-[state=active]:bg-white/20"
              data-testid="tab-length"
            >
              {language === 'ar' ? 'طول' : 'Length'}
            </TabsTrigger>
            <TabsTrigger 
              value="angle" 
              className="text-white data-[state=active]:bg-white/20"
              data-testid="tab-angle"
            >
              {language === 'ar' ? 'زوايا' : 'Angles'}
            </TabsTrigger>
            <TabsTrigger 
              value="area" 
              className="text-white data-[state=active]:bg-white/20"
              data-testid="tab-area"
            >
              {language === 'ar' ? 'مساحة' : 'Area'}
            </TabsTrigger>
            <TabsTrigger 
              value="volume" 
              className="text-white data-[state=active]:bg-white/20"
              data-testid="tab-volume"
            >
              {language === 'ar' ? 'حجم' : 'Volume'}
            </TabsTrigger>
          </TabsList>

          <div className="mt-6 space-y-6">
            <TabsContent value="length">
              <ConversionSection 
                title={language === 'ar' ? 'تحويل الأطوال' : 'Length Conversion'} 
                conversions={lengthConversions} 
                units={lengthUnits}
                language={language}
              />
            </TabsContent>

            <TabsContent value="angle">
              <ConversionSection 
                title={language === 'ar' ? 'تحويل الزوايا' : 'Angle Conversion'} 
                conversions={angleConversions} 
                units={angleUnits}
                language={language}
              />
            </TabsContent>

            <TabsContent value="area">
              <ConversionSection 
                title={language === 'ar' ? 'تحويل المساحات' : 'Area Conversion'} 
                conversions={areaConversions} 
                units={areaUnits}
                language={language}
              />
            </TabsContent>

            <TabsContent value="volume">
              <ConversionSection 
                title={language === 'ar' ? 'تحويل الأحجام' : 'Volume Conversion'} 
                conversions={volumeConversions} 
                units={volumeUnits}
                language={language}
              />
            </TabsContent>
          </div>
        </Tabs>

        {/* Info Card */}
        <Card className="bg-white/10 border-white/20 mt-8">
          <CardHeader>
            <CardTitle className="text-white">ℹ️ {language === 'ar' ? 'معلومات' : 'Information'}</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-2 text-sm">
            <p>• {language === 'ar' ? 'محول متخصص لوحدات المساحة والهندسة' : 'Specialized converter for surveying and engineering units'}</p>
            <p>• {language === 'ar' ? 'يدعم التحويل السريع بين الوحدات المختلفة' : 'Fast conversion between different units'}</p>
            <p>• {language === 'ar' ? 'يشمل: أطوال، زوايا، مساحات، وأحجام' : 'Includes: Lengths, Angles, Areas, and Volumes'}</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
