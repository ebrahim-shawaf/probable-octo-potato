import { useState, useCallback } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowRight, Upload, FileText, Calculator, Download, Trash2, Table, BarChart3, HelpCircle, Box } from "lucide-react";
import CutFill3DView from "@/components/CutFill3DView";
import { useLanguage } from "@/lib/i18n";
import { toast } from "sonner";
import * as XLSX from "xlsx";
import DxfParser from "dxf-parser";
import FeatureTour from "@/components/FeatureTour";

interface SurfacePoint {
  station: string;
  x: number;
  y: number;
  z: number;
}

interface StationResult {
  station: string;
  existingElev: number;
  designElev: number;
  difference: number;
  area: number;
  cutVolume: number;
  fillVolume: number;
  netVolume: number;
  type: 'cut' | 'fill' | 'balanced';
}

interface TotalResults {
  totalCut: number;
  totalFill: number;
  netVolume: number;
  totalArea: number;
  stationCount: number;
}

export default function CutFillCalculator() {
  const { language } = useLanguage();
  const isRTL = language === 'ar';

  const [existingData, setExistingData] = useState<SurfacePoint[]>([]);
  const [designData, setDesignData] = useState<SurfacePoint[]>([]);
  const [existingFileName, setExistingFileName] = useState<string>('');
  const [designFileName, setDesignFileName] = useState<string>('');
  const [stationResults, setStationResults] = useState<StationResult[]>([]);
  const [totalResults, setTotalResults] = useState<TotalResults | null>(null);
  const [stationSpacing, setStationSpacing] = useState<number>(20);
  const [sectionWidth, setSectionWidth] = useState<number>(10);
  const [isCalculating, setIsCalculating] = useState(false);

  const cutFillTourSteps = [
    {
      id: 'welcome',
      title: language === 'ar' ? '⛏️ حاسبة الحفر والردم' : '⛏️ Cut & Fill Calculator',
      description: language === 'ar' 
        ? 'أداة لحساب كميات الحفر والردم من ملفات الأرض الطبيعية والتصميمية' 
        : 'Tool to calculate cut and fill volumes from existing and design surface files'
    },
    {
      id: 'upload',
      title: language === 'ar' ? '📤 رفع الملفات' : '📤 Upload Files',
      description: language === 'ar'
        ? 'ارفع ملفين: الأول للأرض الطبيعية (الوضع الحالي) والثاني للأرض التصميمية (المطلوب). الصيغ المدعومة: CSV, TXT, Excel, DXF'
        : 'Upload two files: first for existing ground and second for design surface. Supported formats: CSV, TXT, Excel, DXF',
      target: '[data-testid="tab-upload"]'
    },
    {
      id: '3d-view',
      title: language === 'ar' ? '🗺️ خريطة ثلاثية الأبعاد' : '🗺️ 3D Map View',
      description: language === 'ar'
        ? 'اعرض الأرض الطبيعية والتصميمية في خريطة 3D تفاعلية. انقر على أي نقطة لعرض المنسوب والفرق. الألوان تدل على مناطق الحفر (أحمر) والردم (أخضر)'
        : 'View existing and design surfaces in an interactive 3D map. Click any point to see elevation and difference. Colors indicate cut (red) and fill (green) areas',
      target: '[data-testid="tab-3d"]'
    },
    {
      id: 'settings',
      title: language === 'ar' ? '⚙️ إعدادات الحساب' : '⚙️ Calculation Settings',
      description: language === 'ar'
        ? 'حدد المسافة بين المحطات وعرض القطاع لحساب الكميات بدقة'
        : 'Set station spacing and section width for accurate volume calculation',
      target: '[data-testid="tab-calculate"]'
    },
    {
      id: 'results',
      title: language === 'ar' ? '📊 النتائج' : '📊 Results',
      description: language === 'ar'
        ? 'اعرض نتائج كل محطة بالتفصيل: منسوب طبيعي، تصميمي، الفرق، وكميات الحفر والردم. يمكنك تصدير النتائج كملف CSV'
        : 'View detailed results per station: existing elevation, design elevation, difference, and cut/fill volumes. Export results as CSV',
      target: '[data-testid="tab-results"]'
    }
  ];

  const resetTour = () => {
    localStorage.removeItem('tour-cutfill-tour');
    window.location.reload();
  };

  const parseFile = useCallback(async (file: File): Promise<SurfacePoint[]> => {
    const extension = file.name.split('.').pop()?.toLowerCase();
    
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const content = e.target?.result;
          let points: SurfacePoint[] = [];
          
          if (extension === 'xlsx' || extension === 'xls') {
            const workbook = XLSX.read(content, { type: 'binary' });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const data = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];
            
            for (let i = 1; i < data.length; i++) {
              const row = data[i];
              if (row.length >= 3) {
                const station = row[0]?.toString() || `ST-${i}`;
                const x = parseFloat(row[1]) || parseFloat(row[0]) || 0;
                const y = parseFloat(row[2]) || parseFloat(row[1]) || 0;
                const z = parseFloat(row[3]) || parseFloat(row[2]) || 0;
                
                if (!isNaN(z)) {
                  points.push({ station, x, y, z });
                }
              }
            }
          } else if (extension === 'dxf') {
            const text = content as string;
            const parser = new DxfParser();
            const dxf = parser.parse(text);
            
            if (dxf && dxf.entities) {
              let pointIndex = 0;
              
              dxf.entities.forEach((entity: any) => {
                if (entity.type === 'POINT' && entity.position) {
                  pointIndex++;
                  const x = entity.position.x || 0;
                  const y = entity.position.y || 0;
                  const z = entity.position.z || 0;
                  points.push({ station: `PT-${pointIndex}`, x, y, z });
                }
                else if (entity.type === 'LINE') {
                  if (entity.vertices && entity.vertices.length >= 2) {
                    entity.vertices.forEach((v: any, idx: number) => {
                      pointIndex++;
                      points.push({ 
                        station: `L${pointIndex}-${idx + 1}`, 
                        x: v.x || 0, 
                        y: v.y || 0, 
                        z: v.z || 0 
                      });
                    });
                  } else if (entity.start && entity.end) {
                    pointIndex++;
                    points.push({ 
                      station: `L${pointIndex}-S`, 
                      x: entity.start.x || 0, 
                      y: entity.start.y || 0, 
                      z: entity.start.z || 0 
                    });
                    points.push({ 
                      station: `L${pointIndex}-E`, 
                      x: entity.end.x || 0, 
                      y: entity.end.y || 0, 
                      z: entity.end.z || 0 
                    });
                  }
                }
                else if (entity.type === 'POLYLINE' || entity.type === 'LWPOLYLINE') {
                  if (entity.vertices) {
                    entity.vertices.forEach((v: any, idx: number) => {
                      pointIndex++;
                      points.push({ 
                        station: `PL${pointIndex}`, 
                        x: v.x || 0, 
                        y: v.y || 0, 
                        z: v.z || v.bulge || 0 
                      });
                    });
                  }
                }
                else if (entity.type === '3DFACE') {
                  if (entity.vertices) {
                    entity.vertices.forEach((v: any, idx: number) => {
                      pointIndex++;
                      points.push({ 
                        station: `3D-${pointIndex}`, 
                        x: v.x || 0, 
                        y: v.y || 0, 
                        z: v.z || 0 
                      });
                    });
                  }
                }
                else if (entity.type === 'INSERT' && entity.position) {
                  pointIndex++;
                  points.push({ 
                    station: entity.name || `BLK-${pointIndex}`, 
                    x: entity.position.x || 0, 
                    y: entity.position.y || 0, 
                    z: entity.position.z || 0 
                  });
                }
                else if (entity.type === 'TEXT' || entity.type === 'MTEXT') {
                  if (entity.position || entity.startPoint) {
                    const pos = entity.position || entity.startPoint;
                    pointIndex++;
                    const label = entity.text || `TXT-${pointIndex}`;
                    points.push({ 
                      station: label.substring(0, 20), 
                      x: pos.x || 0, 
                      y: pos.y || 0, 
                      z: pos.z || 0 
                    });
                  }
                }
              });
              
              console.log(`[DXF] Parsed ${points.length} points from ${dxf.entities.length} entities`);
            }
          } else {
            const text = content as string;
            const lines = text.split(/\r?\n/).filter(line => line.trim());
            
            for (let i = 0; i < lines.length; i++) {
              const line = lines[i];
              if (line.startsWith('#') || line.startsWith('//')) continue;
              
              const parts = line.split(/[,\t\s]+/).filter(p => p.trim());
              if (parts.length >= 3) {
                const station = parts.length >= 4 ? parts[0] : `ST-${i + 1}`;
                const startIdx = parts.length >= 4 ? 1 : 0;
                const x = parseFloat(parts[startIdx]);
                const y = parseFloat(parts[startIdx + 1]);
                const z = parseFloat(parts[startIdx + 2]);
                
                if (!isNaN(x) && !isNaN(y) && !isNaN(z)) {
                  points.push({ station, x, y, z });
                }
              }
            }
          }
          
          resolve(points);
        } catch (error) {
          reject(error);
        }
      };
      
      reader.onerror = () => reject(new Error('Failed to read file'));
      
      if (extension === 'xlsx' || extension === 'xls') {
        reader.readAsBinaryString(file);
      } else {
        reader.readAsText(file);
      }
    });
  }, []);

  const handleExistingFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    try {
      const points = await parseFile(file);
      setExistingData(points);
      setExistingFileName(file.name);
      toast.success(language === 'ar' 
        ? `✅ تم تحميل ${points.length} نقطة من الأرض الطبيعية` 
        : `✅ Loaded ${points.length} existing ground points`);
    } catch (error) {
      toast.error(language === 'ar' ? '❌ خطأ في قراءة الملف' : '❌ Error reading file');
    }
  };

  const handleDesignFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    try {
      const points = await parseFile(file);
      setDesignData(points);
      setDesignFileName(file.name);
      toast.success(language === 'ar' 
        ? `✅ تم تحميل ${points.length} نقطة من الأرض التصميمية` 
        : `✅ Loaded ${points.length} design surface points`);
    } catch (error) {
      toast.error(language === 'ar' ? '❌ خطأ في قراءة الملف' : '❌ Error reading file');
    }
  };

  const calculateVolumes = () => {
    if (existingData.length === 0 || designData.length === 0) {
      toast.error(language === 'ar' ? '❌ يرجى تحميل كلا الملفين' : '❌ Please upload both files');
      return;
    }

    setIsCalculating(true);
    
    try {
      interface AlignedStation {
        station: string;
        existing: SurfacePoint;
        design: SurfacePoint;
        difference: number;
      }

      const alignedStations: AlignedStation[] = [];
      const designByStation = new Map<string, SurfacePoint>();
      designData.forEach(p => designByStation.set(p.station, p));

      for (const existing of existingData) {
        let design = designByStation.get(existing.station);
        
        if (!design) {
          let minDist = Infinity;
          for (const d of designData) {
            const dist = Math.sqrt(Math.pow(d.x - existing.x, 2) + Math.pow(d.y - existing.y, 2));
            if (dist < minDist && dist < 5.0) {
              minDist = dist;
              design = d;
            }
          }
        }
        
        if (design) {
          alignedStations.push({
            station: existing.station,
            existing,
            design,
            difference: design.z - existing.z
          });
        }
      }

      alignedStations.sort((a, b) => {
        const numA = parseFloat(a.station.replace(/\D/g, '')) || 0;
        const numB = parseFloat(b.station.replace(/\D/g, '')) || 0;
        if (numA !== numB) return numA - numB;
        return a.station.localeCompare(b.station);
      });

      if (alignedStations.length < 2) {
        toast.error(language === 'ar' ? '❌ يجب وجود محطتين على الأقل' : '❌ At least 2 stations required');
        setIsCalculating(false);
        return;
      }

      const results: StationResult[] = [];
      let totalCut = 0;
      let totalFill = 0;
      let totalArea = 0;

      for (let i = 0; i < alignedStations.length - 1; i++) {
        const current = alignedStations[i];
        const next = alignedStations[i + 1];
        
        const dx = next.existing.x - current.existing.x;
        const dy = next.existing.y - current.existing.y;
        let actualSpacing = Math.sqrt(dx * dx + dy * dy);
        
        if (actualSpacing < 0.01) actualSpacing = stationSpacing;
        
        const currentArea = Math.abs(current.difference) * sectionWidth;
        const nextArea = Math.abs(next.difference) * sectionWidth;
        
        const avgArea = (currentArea + nextArea) / 2;
        totalArea += avgArea * actualSpacing;
        
        const sameSign = (current.difference >= 0 && next.difference >= 0) || 
                         (current.difference <= 0 && next.difference <= 0);
        
        if (sameSign) {
          const segmentVolume = avgArea * actualSpacing;
          
          if (current.difference < 0 || next.difference < 0) {
            totalCut += segmentVolume;
          } else if (current.difference > 0 || next.difference > 0) {
            totalFill += segmentVolume;
          }
        } else {
          const absD1 = Math.abs(current.difference);
          const absD2 = Math.abs(next.difference);
          const ratio = absD1 / (absD1 + absD2);
          const zeroPoint = actualSpacing * ratio;
          
          const vol1 = (currentArea / 2) * zeroPoint;
          const vol2 = (nextArea / 2) * (actualSpacing - zeroPoint);
          
          if (current.difference < 0) {
            totalCut += vol1;
            totalFill += vol2;
          } else {
            totalFill += vol1;
            totalCut += vol2;
          }
        }
      }

      for (let i = 0; i < alignedStations.length; i++) {
        const current = alignedStations[i];
        const crossSectionArea = Math.abs(current.difference) * sectionWidth;
        
        let contributedCut = 0;
        let contributedFill = 0;
        
        if (i < alignedStations.length - 1) {
          const next = alignedStations[i + 1];
          const dx = next.existing.x - current.existing.x;
          const dy = next.existing.y - current.existing.y;
          let spacing = Math.sqrt(dx * dx + dy * dy);
          if (spacing < 0.01) spacing = stationSpacing;
          
          const nextArea = Math.abs(next.difference) * sectionWidth;
          const segVol = ((crossSectionArea + nextArea) / 2) * spacing;
          
          const sameSign = (current.difference >= 0 && next.difference >= 0) || 
                           (current.difference <= 0 && next.difference <= 0);
          
          if (sameSign) {
            const stationShare = segVol * (crossSectionArea / (crossSectionArea + nextArea + 0.0001));
            if (current.difference < 0) {
              contributedCut = stationShare;
            } else if (current.difference > 0) {
              contributedFill = stationShare;
            }
          } else {
            const absD1 = Math.abs(current.difference);
            const absD2 = Math.abs(next.difference);
            const ratio = absD1 / (absD1 + absD2);
            const vol1 = (crossSectionArea * spacing * ratio) / 2;
            
            if (current.difference < 0) {
              contributedCut = vol1;
            } else {
              contributedFill = vol1;
            }
          }
        }
        
        results.push({
          station: current.station,
          existingElev: current.existing.z,
          designElev: current.design.z,
          difference: current.difference,
          area: crossSectionArea,
          cutVolume: contributedCut,
          fillVolume: contributedFill,
          netVolume: contributedFill - contributedCut,
          type: current.difference < 0 ? 'cut' : current.difference > 0 ? 'fill' : 'balanced'
        });
      }

      setStationResults(results);
      setTotalResults({
        totalCut,
        totalFill,
        netVolume: totalFill - totalCut,
        totalArea,
        stationCount: results.length
      });

      toast.success(language === 'ar' 
        ? `✅ تم حساب الكميات لـ ${results.length} محطة بطريقة Average End Area` 
        : `✅ Calculated volumes for ${results.length} stations using Average End Area method`);
    } catch (error) {
      toast.error(language === 'ar' ? '❌ خطأ في الحساب' : '❌ Calculation error');
    } finally {
      setIsCalculating(false);
    }
  };

  const exportResults = () => {
    if (stationResults.length === 0) {
      toast.error(language === 'ar' ? '❌ لا توجد نتائج للتصدير' : '❌ No results to export');
      return;
    }

    const headers = [
      language === 'ar' ? 'المحطة' : 'Station',
      language === 'ar' ? 'منسوب طبيعي' : 'Existing Elev',
      language === 'ar' ? 'منسوب تصميمي' : 'Design Elev',
      language === 'ar' ? 'الفرق' : 'Difference',
      language === 'ar' ? 'المساحة (م²)' : 'Area (m²)',
      language === 'ar' ? 'حفر (م³)' : 'Cut (m³)',
      language === 'ar' ? 'ردم (م³)' : 'Fill (m³)',
      language === 'ar' ? 'صافي (م³)' : 'Net (m³)',
      language === 'ar' ? 'النوع' : 'Type'
    ];

    let csv = headers.join(',') + '\n';
    
    stationResults.forEach(r => {
      csv += [
        r.station,
        r.existingElev.toFixed(3),
        r.designElev.toFixed(3),
        r.difference.toFixed(3),
        r.area.toFixed(2),
        r.cutVolume.toFixed(3),
        r.fillVolume.toFixed(3),
        r.netVolume.toFixed(3),
        r.type === 'cut' ? (language === 'ar' ? 'حفر' : 'Cut') : 
        r.type === 'fill' ? (language === 'ar' ? 'ردم' : 'Fill') : 
        (language === 'ar' ? 'متوازن' : 'Balanced')
      ].join(',') + '\n';
    });

    if (totalResults) {
      csv += '\n';
      csv += `${language === 'ar' ? 'الإجمالي' : 'TOTAL'},,,,${totalResults.totalArea.toFixed(2)},${totalResults.totalCut.toFixed(3)},${totalResults.totalFill.toFixed(3)},${totalResults.netVolume.toFixed(3)},\n`;
    }

    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cut-fill-report-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    toast.success(language === 'ar' ? '✅ تم تصدير التقرير' : '✅ Report exported');
  };

  const clearAll = () => {
    setExistingData([]);
    setDesignData([]);
    setExistingFileName('');
    setDesignFileName('');
    setStationResults([]);
    setTotalResults(null);
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 via-amber-900/20 to-slate-900" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 right-10 w-72 h-72 bg-amber-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-10 left-10 w-96 h-96 bg-orange-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="sticky top-0 z-50 bg-black/40 backdrop-blur-md border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
          <Link href="/">
            <Button variant="ghost" className="text-white hover:bg-white/10" data-testid="button-back-home">
              <ArrowRight className="w-5 h-5 ml-2" />
              {language === 'ar' ? 'الرئيسية' : 'Home'}
            </Button>
          </Link>
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold text-white flex items-center gap-2">
              <span className="text-2xl">⛏️</span>
              {language === 'ar' ? 'حاسبة الحفر والردم' : 'Cut & Fill Calculator'}
            </h1>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={resetTour}
              className="text-white hover:bg-white/10"
              data-testid="button-help-tour"
            >
              <HelpCircle className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 py-6">
        <Tabs defaultValue="upload" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-white/10 mb-6">
            <TabsTrigger value="upload" className="data-[state=active]:bg-amber-500/30 text-white" data-testid="tab-upload">
              <Upload className="w-4 h-4 ml-2" />
              {language === 'ar' ? 'رفع الملفات' : 'Upload Files'}
            </TabsTrigger>
            <TabsTrigger value="3d" className="data-[state=active]:bg-amber-500/30 text-white" data-testid="tab-3d">
              <Box className="w-4 h-4 ml-2" />
              {language === 'ar' ? 'خريطة 3D' : '3D View'}
            </TabsTrigger>
            <TabsTrigger value="calculate" className="data-[state=active]:bg-amber-500/30 text-white" data-testid="tab-calculate">
              <Calculator className="w-4 h-4 ml-2" />
              {language === 'ar' ? 'الحساب' : 'Calculate'}
            </TabsTrigger>
            <TabsTrigger value="results" className="data-[state=active]:bg-amber-500/30 text-white" data-testid="tab-results">
              <Table className="w-4 h-4 ml-2" />
              {language === 'ar' ? 'النتائج' : 'Results'}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-white/10 backdrop-blur-md border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <span className="text-2xl">🏔️</span>
                    {language === 'ar' ? 'الأرض الطبيعية (الوضع الحالي)' : 'Existing Ground Surface'}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-2 border-dashed border-amber-500/50 rounded-xl p-6 text-center hover:border-amber-400 transition-colors">
                    <input
                      type="file"
                      id="existing-file"
                      accept=".csv,.txt,.xlsx,.xls,.dxf"
                      onChange={handleExistingFileUpload}
                      className="hidden"
                      data-testid="input-existing-file"
                    />
                    <label htmlFor="existing-file" className="cursor-pointer">
                      <Upload className="w-12 h-12 mx-auto text-amber-400 mb-3" />
                      <p className="text-white font-medium">
                        {existingFileName || (language === 'ar' ? 'اختر ملف الأرض الطبيعية' : 'Select Existing Ground File')}
                      </p>
                      <p className="text-gray-400 text-sm mt-1">CSV, TXT, Excel, DXF</p>
                    </label>
                  </div>
                  {existingData.length > 0 && (
                    <div className="bg-green-500/20 rounded-lg p-3 text-green-300">
                      ✅ {existingData.length} {language === 'ar' ? 'نقطة' : 'points'}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-white/10 backdrop-blur-md border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <span className="text-2xl">📐</span>
                    {language === 'ar' ? 'الأرض التصميمية (المطلوب)' : 'Design Surface'}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-2 border-dashed border-orange-500/50 rounded-xl p-6 text-center hover:border-orange-400 transition-colors">
                    <input
                      type="file"
                      id="design-file"
                      accept=".csv,.txt,.xlsx,.xls,.dxf"
                      onChange={handleDesignFileUpload}
                      className="hidden"
                      data-testid="input-design-file"
                    />
                    <label htmlFor="design-file" className="cursor-pointer">
                      <Upload className="w-12 h-12 mx-auto text-orange-400 mb-3" />
                      <p className="text-white font-medium">
                        {designFileName || (language === 'ar' ? 'اختر ملف الأرض التصميمية' : 'Select Design Surface File')}
                      </p>
                      <p className="text-gray-400 text-sm mt-1">CSV, TXT, Excel, DXF</p>
                    </label>
                  </div>
                  {designData.length > 0 && (
                    <div className="bg-green-500/20 rounded-lg p-3 text-green-300">
                      ✅ {designData.length} {language === 'ar' ? 'نقطة' : 'points'}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardHeader>
                <CardTitle className="text-white">
                  {language === 'ar' ? '📋 صيغ الملفات المدعومة' : '📋 Supported File Formats'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-black/30 rounded-lg p-4 font-mono text-sm text-gray-300">
                  <p className="text-amber-400 mb-2 font-bold">📄 CSV / TXT / Excel:</p>
                  <p className="text-gray-400 mb-1"># {language === 'ar' ? 'صيغة: المحطة، X، Y، المنسوب' : 'Format: Station, X, Y, Elevation'}</p>
                  <p>ST-0, 100.000, 200.000, 15.500</p>
                  <p>ST-20, 120.000, 200.000, 16.200</p>
                  <p>ST-40, 140.000, 200.000, 14.800</p>
                </div>
                <div className="bg-blue-500/20 rounded-lg p-4 text-blue-200">
                  <p className="font-bold mb-2">📐 AutoCAD DXF:</p>
                  <p className="text-sm">
                    {language === 'ar' 
                      ? 'يتم استخراج النقاط من: POINT, LINE, POLYLINE, 3DFACE, TEXT مع إحداثيات X, Y, Z' 
                      : 'Extracts points from: POINT, LINE, POLYLINE, 3DFACE, TEXT with X, Y, Z coordinates'}
                  </p>
                  <p className="text-xs text-blue-300 mt-2">
                    {language === 'ar' 
                      ? '💡 تأكد من تصدير الملف بصيغة DXF من أوتوكاد أو سيفل 3D' 
                      : '💡 Make sure to export as DXF from AutoCAD or Civil 3D'}
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="3d" className="space-y-6" data-testid="tab-content-3d">
            <CutFill3DView 
              existingData={existingData}
              designData={designData}
              language={language}
            />
          </TabsContent>

          <TabsContent value="calculate" className="space-y-6">
            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <span className="text-2xl">⚙️</span>
                  {language === 'ar' ? 'إعدادات الحساب' : 'Calculation Settings'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label className="text-white">{language === 'ar' ? 'المسافة بين المحطات (م)' : 'Station Spacing (m)'}</Label>
                    <Input
                      type="number"
                      value={stationSpacing}
                      onChange={(e) => setStationSpacing(parseFloat(e.target.value) || 20)}
                      className="bg-white/10 border-white/30 text-white"
                      data-testid="input-station-spacing"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white">{language === 'ar' ? 'عرض القطاع (م)' : 'Section Width (m)'}</Label>
                    <Input
                      type="number"
                      value={sectionWidth}
                      onChange={(e) => setSectionWidth(parseFloat(e.target.value) || 10)}
                      className="bg-white/10 border-white/30 text-white"
                      data-testid="input-section-width"
                    />
                  </div>
                </div>

                <div className="bg-blue-500/20 rounded-lg p-4 text-blue-200">
                  <p className="font-bold mb-2">📊 {language === 'ar' ? 'طريقة الحساب: متوسط المساحة النهائية' : 'Method: Average End Area'}</p>
                  <p className="text-sm">
                    {language === 'ar' 
                      ? 'الحجم = الفرق في المنسوب × المساحة (المسافة × العرض)' 
                      : 'Volume = Elevation Difference × Area (Spacing × Width)'}
                  </p>
                </div>

                <div className="flex gap-4">
                  <Button 
                    onClick={calculateVolumes}
                    disabled={existingData.length === 0 || designData.length === 0 || isCalculating}
                    className="flex-1 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white py-6 text-lg"
                    data-testid="button-calculate"
                  >
                    <Calculator className="w-6 h-6 ml-2" />
                    {isCalculating 
                      ? (language === 'ar' ? 'جاري الحساب...' : 'Calculating...') 
                      : (language === 'ar' ? 'احسب الكميات' : 'Calculate Volumes')}
                  </Button>
                  <Button 
                    onClick={clearAll}
                    variant="outline"
                    className="border-red-500 text-red-400 hover:bg-red-500/20"
                    data-testid="button-clear"
                  >
                    <Trash2 className="w-5 h-5 ml-2" />
                    {language === 'ar' ? 'مسح' : 'Clear'}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {totalResults && (
              <div className="grid md:grid-cols-4 gap-4">
                <Card className="bg-gradient-to-br from-red-500/30 to-red-700/30 border-red-500/50">
                  <CardContent className="p-6 text-center">
                    <p className="text-red-300 text-sm mb-1">{language === 'ar' ? 'إجمالي الحفر' : 'Total Cut'}</p>
                    <p className="text-3xl font-bold text-white">{totalResults.totalCut.toFixed(2)}</p>
                    <p className="text-red-300 text-sm">م³</p>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-green-500/30 to-green-700/30 border-green-500/50">
                  <CardContent className="p-6 text-center">
                    <p className="text-green-300 text-sm mb-1">{language === 'ar' ? 'إجمالي الردم' : 'Total Fill'}</p>
                    <p className="text-3xl font-bold text-white">{totalResults.totalFill.toFixed(2)}</p>
                    <p className="text-green-300 text-sm">م³</p>
                  </CardContent>
                </Card>
                <Card className={`bg-gradient-to-br ${totalResults.netVolume >= 0 ? 'from-green-500/30 to-green-700/30 border-green-500/50' : 'from-red-500/30 to-red-700/30 border-red-500/50'}`}>
                  <CardContent className="p-6 text-center">
                    <p className="text-gray-300 text-sm mb-1">{language === 'ar' ? 'الصافي' : 'Net Volume'}</p>
                    <p className="text-3xl font-bold text-white">{totalResults.netVolume.toFixed(2)}</p>
                    <p className="text-gray-300 text-sm">م³</p>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-blue-500/30 to-blue-700/30 border-blue-500/50">
                  <CardContent className="p-6 text-center">
                    <p className="text-blue-300 text-sm mb-1">{language === 'ar' ? 'عدد المحطات' : 'Stations'}</p>
                    <p className="text-3xl font-bold text-white">{totalResults.stationCount}</p>
                    <p className="text-blue-300 text-sm">{language === 'ar' ? 'محطة' : 'stations'}</p>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="results" className="space-y-6">
            {stationResults.length > 0 ? (
              <>
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-white">
                    📊 {language === 'ar' ? 'نتائج كل محطة' : 'Station-by-Station Results'}
                  </h2>
                  <Button 
                    onClick={exportResults}
                    className="bg-gradient-to-r from-blue-500 to-indigo-600"
                    data-testid="button-export"
                  >
                    <Download className="w-5 h-5 ml-2" />
                    {language === 'ar' ? 'تصدير CSV' : 'Export CSV'}
                  </Button>
                </div>

                <Card className="bg-white/10 backdrop-blur-md border-white/20 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-amber-500/30 text-white">
                        <tr>
                          <th className="p-3 text-right">{language === 'ar' ? 'المحطة' : 'Station'}</th>
                          <th className="p-3 text-right">{language === 'ar' ? 'منسوب طبيعي' : 'Existing'}</th>
                          <th className="p-3 text-right">{language === 'ar' ? 'منسوب تصميمي' : 'Design'}</th>
                          <th className="p-3 text-right">{language === 'ar' ? 'الفرق' : 'Diff'}</th>
                          <th className="p-3 text-right">{language === 'ar' ? 'حفر (م³)' : 'Cut (m³)'}</th>
                          <th className="p-3 text-right">{language === 'ar' ? 'ردم (م³)' : 'Fill (m³)'}</th>
                          <th className="p-3 text-right">{language === 'ar' ? 'النوع' : 'Type'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {stationResults.map((r, idx) => (
                          <tr 
                            key={idx} 
                            className={`border-b border-white/10 ${
                              r.type === 'cut' ? 'bg-red-500/10' : 
                              r.type === 'fill' ? 'bg-green-500/10' : 'bg-gray-500/10'
                            }`}
                          >
                            <td className="p-3 text-white font-medium">{r.station}</td>
                            <td className="p-3 text-gray-300">{r.existingElev.toFixed(3)}</td>
                            <td className="p-3 text-gray-300">{r.designElev.toFixed(3)}</td>
                            <td className={`p-3 font-medium ${r.difference < 0 ? 'text-red-400' : r.difference > 0 ? 'text-green-400' : 'text-gray-400'}`}>
                              {r.difference.toFixed(3)}
                            </td>
                            <td className="p-3 text-red-400">{r.cutVolume > 0 ? r.cutVolume.toFixed(3) : '-'}</td>
                            <td className="p-3 text-green-400">{r.fillVolume > 0 ? r.fillVolume.toFixed(3) : '-'}</td>
                            <td className="p-3">
                              <span className={`px-2 py-1 rounded text-xs font-bold ${
                                r.type === 'cut' ? 'bg-red-500/30 text-red-300' : 
                                r.type === 'fill' ? 'bg-green-500/30 text-green-300' : 
                                'bg-gray-500/30 text-gray-300'
                              }`}>
                                {r.type === 'cut' ? (language === 'ar' ? 'حفر' : 'CUT') : 
                                 r.type === 'fill' ? (language === 'ar' ? 'ردم' : 'FILL') : 
                                 (language === 'ar' ? 'متوازن' : 'BAL')}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      {totalResults && (
                        <tfoot className="bg-amber-500/30 text-white font-bold">
                          <tr>
                            <td className="p-3" colSpan={4}>{language === 'ar' ? 'الإجمالي' : 'TOTAL'}</td>
                            <td className="p-3 text-red-300">{totalResults.totalCut.toFixed(3)}</td>
                            <td className="p-3 text-green-300">{totalResults.totalFill.toFixed(3)}</td>
                            <td className="p-3">
                              <span className={`px-2 py-1 rounded text-xs ${totalResults.netVolume >= 0 ? 'bg-green-500/30' : 'bg-red-500/30'}`}>
                                {language === 'ar' ? 'صافي: ' : 'Net: '}{totalResults.netVolume.toFixed(3)}
                              </span>
                            </td>
                          </tr>
                        </tfoot>
                      )}
                    </table>
                  </div>
                </Card>
              </>
            ) : (
              <Card className="bg-white/10 backdrop-blur-md border-white/20">
                <CardContent className="p-12 text-center">
                  <BarChart3 className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                  <p className="text-gray-400 text-lg">
                    {language === 'ar' 
                      ? 'لم يتم حساب أي نتائج بعد. قم برفع الملفات وابدأ الحساب.' 
                      : 'No results yet. Upload files and calculate.'}
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* جولة تعريفية */}
      <FeatureTour 
        steps={cutFillTourSteps}
        language={language}
        tourId="cutfill-tour"
      />
    </div>
  );
}
