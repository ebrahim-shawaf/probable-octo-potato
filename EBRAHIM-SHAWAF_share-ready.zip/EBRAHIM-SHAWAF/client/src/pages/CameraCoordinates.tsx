import { useState, useRef, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Camera, MapPin, Download, Copy, Loader, AlertCircle, CheckCircle, Eye } from "lucide-react";

interface CoordinateData {
  latitude: number;
  longitude: number;
  accuracy: number;
  altitude: number | null;
  timestamp: Date;
  imagePath: string | null;
}

interface CapturedPoint {
  id: number;
  coordinates: CoordinateData;
  description: string;
}

export default function CameraCoordinates() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [loading, setLoading] = useState(false);
  const [locationLoading, setLocationLoading] = useState(false);
  const [currentCoordinates, setCurrentCoordinates] = useState<CoordinateData | null>(null);
  const [capturedPoints, setCapturedPoints] = useState<CapturedPoint[]>([]);
  const [nextId, setNextId] = useState(1);
  const [pointDescription, setPointDescription] = useState("");
  const [coordinateFormat, setCoordinateFormat] = useState<"decimal" | "dms" | "both">("both");
  const [accuracyMode, setAccuracyMode] = useState<"normal" | "high">("normal");
  const [statusMessage, setStatusMessage] = useState("");
  const [attempts, setAttempts] = useState(0);
  const watchIdRef = useRef<number | null>(null);

  // تنظيف الموارد عند الخروج من الصفحة
  useEffect(() => {
    return () => {
      stopCamera();
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (cameraActive) {
      startCamera();
    } else {
      stopCamera();
    }
  }, [cameraActive]);

  const startCamera = async () => {
    try {
      // تنظيف الكاميرا السابقة إن وجدت
      if (videoRef.current?.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach((track) => track.stop());
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (error: any) {
      console.error("Error accessing camera:", error);
      let errorMessage = "لا يمكن الوصول للكاميرا";
      if (error.name === "NotAllowedError") {
        errorMessage = "تم رفض إذن الكاميرا. يرجى السماح بالوصول للكاميرا في إعدادات الجهاز.";
      } else if (error.name === "NotFoundError") {
        errorMessage = "لم يتم العثور على كاميرا على جهازك.";
      } else if (error.name === "NotSupportedError") {
        errorMessage = "المتصفح الحالي لا يدعم الوصول للكاميرا.";
      }
      alert(errorMessage);
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach((track) => track.stop());
    }
  };

  const getLocation = async () => {
    setLocationLoading(true);
    setStatusMessage("جاري البحث عن الموقع...");
    setAttempts(0);

    if (accuracyMode === "high") {
      // وضع الدقة العالية جداً - مراقبة حية مكثفة لتحقيق ±1 متر
      return new Promise<void>((resolve) => {
        let bestPosition: GeolocationPosition | null = null;
        let maxAttempts = 50; // محاولات متعددة كثيرة
        let currentAttempt = 0;
        const targetAccuracy = 1; // دقة مستهدفة 1 متر
        const goodAccuracy = 3; // دقة جيدة 3 متر
        const lastUpdates: number[] = []; // تتبع آخر التحديثات لحساب الاستقرار

        const handlePosition = (position: GeolocationPosition) => {
          currentAttempt++;
          setAttempts(currentAttempt);
          const accuracy = position.coords.accuracy;

          // تتبع آخر 5 قراءات للتحقق من استقرار الدقة
          lastUpdates.push(accuracy);
          if (lastUpdates.length > 5) lastUpdates.shift();

          // تحديث أفضل موقع
          if (!bestPosition || accuracy < bestPosition.coords.accuracy) {
            bestPosition = position;

            // تحديث الإحداثيات المعروضة
            setCurrentCoordinates({
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              accuracy: accuracy,
              altitude: position.coords.altitude,
              timestamp: new Date(),
              imagePath: null,
            });

            // تحديث الحالة مع رسائل مفصلة
            if (accuracy <= targetAccuracy) {
              setStatusMessage(`🎯 دقة عالية جداً: ±${accuracy.toFixed(2)} متر - يمكنك التقاط الآن!`);
            } else if (accuracy <= goodAccuracy) {
              setStatusMessage(`✅ دقة جيدة جداً: ±${accuracy.toFixed(2)} متر (جاري المحاولة...)`);
            } else if (accuracy < 10) {
              setStatusMessage(`✓ دقة معقولة: ±${accuracy.toFixed(1)} متر - محاولة ${currentAttempt}/50`);
            } else {
              setStatusMessage(`⏳ محاولة ${currentAttempt}/50 - الدقة: ±${accuracy.toFixed(1)} متر`);
            }
          }

          // حساب متوسط آخر قراءات للتحقق من الاستقرار
          const avgAccuracy = lastUpdates.length > 0 
            ? lastUpdates.reduce((a, b) => a + b, 0) / lastUpdates.length 
            : accuracy;
          
          const isStable = lastUpdates.length === 5 && 
            Math.max(...lastUpdates) - Math.min(...lastUpdates) < 1; // استقرار جيد

          // التوقف إذا حققنا الدقة المستهدفة أو كانت مستقرة أو وصلنا للمحاولات القصوى
          if (accuracy <= targetAccuracy || (isStable && accuracy <= goodAccuracy) || currentAttempt >= maxAttempts) {
            if (watchIdRef.current !== null) {
              navigator.geolocation.clearWatch(watchIdRef.current);
              watchIdRef.current = null;
            }
            
            let finalMessage = `✅ تم تأكيد الموقع`;
            if (accuracy <= targetAccuracy) {
              finalMessage = `🎯 دقة عالية جداً: ±${accuracy.toFixed(2)} متر`;
            } else if (accuracy <= goodAccuracy) {
              finalMessage = `✅ دقة جيدة جداً: ±${accuracy.toFixed(2)} متر`;
            } else {
              finalMessage = `ℹ️ الموقع: ±${accuracy.toFixed(1)} متر (محاولات: ${currentAttempt})`;
            }
            
            setStatusMessage(finalMessage);
            setLocationLoading(false);
            resolve();
          }
        };

        const handleError = (error: GeolocationPositionError) => {
          console.error("Geolocation error:", error);
          if (watchIdRef.current !== null) {
            navigator.geolocation.clearWatch(watchIdRef.current);
            watchIdRef.current = null;
          }

          let errorMessage = "⚠️ خطأ في الموقع: ";
          if (error.code === error.PERMISSION_DENIED) {
            errorMessage = "❌ تم رفض الإذن! يجب السماح بالوصول للموقع.\n\n📱 على الهاتف:\n1. اذهب للإعدادات\n2. ابحث عن أذونات التطبيق\n3. اسمح بالوصول للموقع\n\n🔄 ثم حاول مجدداً";
          } else if (error.code === error.POSITION_UNAVAILABLE) {
            errorMessage = "❌ الموقع غير متاح حالياً\nتأكد من تفعيل GPS";
          } else if (error.code === error.TIMEOUT) {
            errorMessage = "⏱️ انتهت المهلة الزمنية\nتأكد من وجود إشارة قوية";
          }

          setStatusMessage(errorMessage);
          setLocationLoading(false);

          // عرض تنبيه للمستخدم
          alert(errorMessage);
          resolve();
        };

        // بدء مراقبة الموقع الحية مع timeout أطول
        watchIdRef.current = navigator.geolocation.watchPosition(handlePosition, handleError, {
          enableHighAccuracy: true,
          timeout: 10000, // انتظر حتى 10 ثوان لكل قراءة
          maximumAge: 0, // لا تستخدم قراءات قديمة
        });
      });
    } else {
      // الوضع العادي - قراءة واحدة فقط
      try {
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: true,
            timeout: 15000,
          });
        });

        const coords = position.coords;
        setCurrentCoordinates({
          latitude: coords.latitude,
          longitude: coords.longitude,
          accuracy: coords.accuracy,
          altitude: coords.altitude,
          timestamp: new Date(),
          imagePath: null,
        });

        setStatusMessage(`الموقع: ±${coords.accuracy.toFixed(1)} متر`);
      } catch (error: any) {
        console.error("Error getting location:", error);

        let errorMessage = "⚠️ خطأ في الحصول على الموقع";
        if (error.code === error.PERMISSION_DENIED) {
          errorMessage = "❌ تم رفض الإذن!\n\nيجب السماح بالوصول للموقع:\n\n📱 على الهاتف:\n1. اذهب للإعدادات\n2. ابحث عن أذونات التطبيق\n3. اسمح بالوصول للموقع\n\n🔄 ثم حاول مجدداً";
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          errorMessage = "❌ الموقع غير متاح\nتأكد من:\n• تفعيل GPS\n• وجود إشارة قوية\n• الوقت الكافي للبحث";
        } else if (error.code === error.TIMEOUT) {
          errorMessage = "⏱️ انتهت المهلة الزمنية\nحاول مجدداً في منطقة مفتوحة";
        }

        setStatusMessage(errorMessage);
        alert(errorMessage);
      } finally {
        setLocationLoading(false);
      }
    }
  };

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current) return;

    try {
      const canvas = canvasRef.current;
      const context = canvas.getContext("2d");
      if (!context) return;

      // Set canvas size to video dimensions
      const video = videoRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      // Draw video frame to canvas
      context.drawImage(video, 0, 0, canvas.width, canvas.height);

      // Convert canvas to image data
      const imageData = canvas.toDataURL("image/jpeg");

      // Get location
      await getLocation();

      if (currentCoordinates) {
        setCurrentCoordinates({
          ...currentCoordinates,
          imagePath: imageData,
        });
      }
    } catch (error) {
      console.error("Error capturing photo:", error);
      alert("حدث خطأ في التقاط الصورة");
    }
  };

  const addPoint = () => {
    if (!currentCoordinates) {
      alert("الرجاء أخذ إحداثيات أولاً");
      return;
    }

    const newPoint: CapturedPoint = {
      id: nextId,
      coordinates: currentCoordinates,
      description: pointDescription || `نقطة ${nextId}`,
    };

    const updatedPoints = [...capturedPoints, newPoint];
    setCapturedPoints(updatedPoints);
    setNextId(nextId + 1);
    setPointDescription("");
    setCurrentCoordinates(null);

    // Reset canvas
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext("2d");
      if (ctx) ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    }

    // Save to localStorage for 3D visualization
    const surveyPoints = updatedPoints.map((p) => ({
      id: p.id,
      latitude: p.coordinates.latitude,
      longitude: p.coordinates.longitude,
      altitude: p.coordinates.altitude,
      accuracy: p.coordinates.accuracy,
      description: p.description,
      timestamp: p.coordinates.timestamp.toISOString(),
    }));
    localStorage.setItem("surveyPoints", JSON.stringify(surveyPoints));

    alert("تم إضافة النقطة بنجاح!");
  };

  const convertToDMS = (decimal: number, isLatitude: boolean) => {
    const abs = Math.abs(decimal);
    const degrees = Math.floor(abs);
    const minutes = Math.floor((abs - degrees) * 60);
    const seconds = ((abs - degrees - minutes / 60) * 3600).toFixed(2);

    const direction = isLatitude ? (decimal >= 0 ? "N" : "S") : decimal >= 0 ? "E" : "W";

    return `${degrees}° ${minutes}' ${seconds}" ${direction}`;
  };

  const formatCoordinates = (coords: CoordinateData) => {
    const decimal = `${coords.latitude.toFixed(6)}, ${coords.longitude.toFixed(6)}`;
    const dms = `${convertToDMS(coords.latitude, true)}, ${convertToDMS(coords.longitude, false)}`;

    if (coordinateFormat === "decimal") return decimal;
    if (coordinateFormat === "dms") return dms;
    return `${decimal}\n${dms}`;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert("تم النسخ إلى الحافظة");
  };

  // حساب الإحداثيات المصححة بناءً على الخطأ
  const calculateCorrectedCoordinates = (coords: CoordinateData) => {
    // تحويل الخطأ بالمتر إلى درجات
    // 1 درجة عرض = 111.32 كم
    // 1 درجة طول = 111.32 * cos(latitude) كم
    const earthRadiusMeters = 111320;
    const errorInDegrees = coords.accuracy / earthRadiusMeters;

    // حساب نطاق الثقة بناءً على الدقة
    const latVariation = errorInDegrees;
    const lonVariation = errorInDegrees / Math.cos((coords.latitude * Math.PI) / 180);

    // الحدود الدنيا والعليا
    const minLat = coords.latitude - latVariation;
    const maxLat = coords.latitude + latVariation;
    const minLon = coords.longitude - lonVariation;
    const maxLon = coords.longitude + lonVariation;

    // الإحداثيات المصححة (مركز المنطقة)
    const correctedLat = coords.latitude;
    const correctedLon = coords.longitude;

    // حساب نطاق الخطأ الفعلي
    const latErrorMeters = latVariation * earthRadiusMeters;
    const lonErrorMeters = lonVariation * earthRadiusMeters * Math.cos((coords.latitude * Math.PI) / 180);

    return {
      original: { lat: coords.latitude, lon: coords.longitude },
      corrected: { lat: correctedLat, lon: correctedLon },
      confidence: {
        minLat: Math.max(-90, minLat),
        maxLat: Math.min(90, maxLat),
        minLon: minLon,
        maxLon: maxLon,
      },
      errorRange: {
        latError: latErrorMeters.toFixed(2),
        lonError: lonErrorMeters.toFixed(2),
      },
      confidenceRadius: coords.accuracy,
    };
  };

  const downloadCSV = () => {
    if (capturedPoints.length === 0) {
      alert("لا توجد نقاط لتحميلها");
      return;
    }

    let csv = "الوصف,الخط,الطول,الدقة (متر),الارتفاع (متر),الوقت\n";

    capturedPoints.forEach((point) => {
      const time = point.coordinates.timestamp.toLocaleString("ar-EG");
      csv += `"${point.description}",${point.coordinates.latitude.toFixed(6)},${point.coordinates.longitude.toFixed(6)},${point.coordinates.accuracy.toFixed(2)},${point.coordinates.altitude?.toFixed(2) || "N/A"},${time}\n`;
    });

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `coordinates_${Date.now()}.csv`);
    link.click();
  };

  const deletePoint = (id: number) => {
    const updatedPoints = capturedPoints.filter((p) => p.id !== id);
    setCapturedPoints(updatedPoints);
    
    // تحديث localStorage
    const surveyPoints = updatedPoints.map((p) => ({
      id: p.id,
      latitude: p.coordinates.latitude,
      longitude: p.coordinates.longitude,
      altitude: p.coordinates.altitude,
      accuracy: p.coordinates.accuracy,
      description: p.description,
      timestamp: p.coordinates.timestamp.toISOString(),
    }));
    localStorage.setItem("surveyPoints", JSON.stringify(surveyPoints));
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 to-slate-800 text-white" data-testid="camera-coordinates-page">
      {/* Navigation */}
      <div className="sticky top-0 z-10 bg-black/30 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">الإحداثيات من الكاميرا</h1>
          <Link href="/">
            <Button variant="ghost" className="text-white hover:bg-white/10" data-testid="button-back-home">
              <ArrowRight className="w-4 h-4 ml-2" />
              العودة للرئيسية
            </Button>
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid md:grid-cols-3 gap-6">
          {/* Camera Section */}
          <div className="md:col-span-2">
            {/* Camera View */}
            <div className="bg-black rounded-xl overflow-hidden border-2 border-blue-400 mb-6">
              {!cameraActive ? (
                <div className="aspect-video flex items-center justify-center bg-gray-900">
                  <div className="text-center">
                    <Camera className="w-12 h-12 mx-auto mb-4 text-gray-500" />
                    <p className="text-gray-400 mb-4">اضغط لتشغيل الكاميرا</p>
                  </div>
                </div>
              ) : (
                <div className="aspect-video relative bg-black flex items-center justify-center">
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    className="w-full h-full object-cover"
                  />
                  
                  {/* Crosshair Overlay for Point Selection */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    {/* Outer Circle */}
                    <div className="absolute w-24 h-24 border-2 border-red-500 rounded-full opacity-70"></div>
                    
                    {/* Center Dot */}
                    <div className="absolute w-4 h-4 bg-red-500 rounded-full animate-pulse"></div>
                    
                    {/* Horizontal Line */}
                    <div className="absolute w-32 h-0.5 bg-gradient-to-r from-transparent via-red-500 to-transparent"></div>
                    
                    {/* Vertical Line */}
                    <div className="absolute h-32 w-0.5 bg-gradient-to-b from-transparent via-red-500 to-transparent"></div>
                    
                    {/* Corner Markers */}
                    <div className="absolute top-6 left-6 w-6 h-6 border-t-2 border-l-2 border-red-500 opacity-70"></div>
                    <div className="absolute top-6 right-6 w-6 h-6 border-t-2 border-r-2 border-red-500 opacity-70"></div>
                    <div className="absolute bottom-6 left-6 w-6 h-6 border-b-2 border-l-2 border-red-500 opacity-70"></div>
                    <div className="absolute bottom-6 right-6 w-6 h-6 border-b-2 border-r-2 border-red-500 opacity-70"></div>
                    
                    {/* Instruction Text */}
                    <div className="absolute top-4 left-4 right-4 bg-black/60 backdrop-blur-sm rounded-lg px-4 py-2 text-center text-yellow-300 text-sm font-bold">
                      🎯 وجه الكاميرا حتى تصل النقطة إلى المركز (النقطة الحمراء)
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Hidden Canvas for Photo Capture */}
            <canvas ref={canvasRef} className="hidden" />

            {/* Controls */}
            <div className="space-y-4 mb-6">
              <Button
                onClick={() => setCameraActive(!cameraActive)}
                size="lg"
                className="w-full"
                data-testid="button-toggle-camera"
              >
                <Camera className="w-4 h-4 ml-2" />
                {cameraActive ? "إيقاف الكاميرا" : "تشغيل الكاميرا"}
              </Button>

              {cameraActive && (
                <div className="space-y-4">
                  <Button
                    onClick={capturePhoto}
                    size="lg"
                    className="w-full bg-green-600 hover:bg-green-700"
                    disabled={locationLoading}
                    data-testid="button-capture-photo"
                  >
                    {locationLoading ? (
                      <>
                        <Loader className="w-4 h-4 ml-2 animate-spin" />
                        جاري الحصول على الموقع...
                      </>
                    ) : (
                      <>
                        <MapPin className="w-4 h-4 ml-2" />
                        التقاط الصورة والموقع
                      </>
                    )}
                  </Button>

                  {/* Description Input */}
                  <input
                    type="text"
                    value={pointDescription}
                    onChange={(e) => setPointDescription(e.target.value)}
                    placeholder="وصف النقطة (اختياري)"
                    className="w-full bg-black/30 border border-blue-400/30 rounded-lg px-4 py-2 text-white placeholder-gray-400"
                    data-testid="input-point-description"
                  />

                  <Button
                    onClick={addPoint}
                    size="lg"
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    disabled={!currentCoordinates}
                    data-testid="button-add-point"
                  >
                    <MapPin className="w-4 h-4 ml-2" />
                    إضافة النقطة
                  </Button>
                </div>
              )}
            </div>

            {/* Current Coordinates Display */}
            {currentCoordinates && (
              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-green-400/30 mb-6">
                <h3 className="text-lg font-bold text-green-400 mb-4">الإحداثيات الحالية</h3>
                <div className="space-y-4">
                  {/* Original Coordinates */}
                  <div className="bg-black/30 rounded-lg p-4 border border-blue-400/20">
                    <p className="text-sm text-blue-400 font-bold mb-2">📍 الإحداثيات الأصلية:</p>
                    <p className="text-white font-mono text-sm whitespace-pre-wrap break-words">
                      {formatCoordinates(currentCoordinates)}
                    </p>
                    <Button
                      onClick={() => copyToClipboard(formatCoordinates(currentCoordinates))}
                      variant="secondary"
                      size="sm"
                      className="mt-2"
                      data-testid="button-copy-coords"
                    >
                      <Copy className="w-4 h-4 ml-2" />
                      نسخ
                    </Button>
                  </div>

                  {/* Corrected Coordinates */}
                  {(() => {
                    const corrected = calculateCorrectedCoordinates(currentCoordinates);
                    return (
                      <div className="bg-black/30 rounded-lg p-4 border border-green-400/20">
                        <p className="text-sm text-green-400 font-bold mb-2">✅ الإحداثيات المصححة:</p>
                        <p className="text-white font-mono text-sm mb-2">
                          {corrected.corrected.lat.toFixed(8)}, {corrected.corrected.lon.toFixed(8)}
                        </p>
                        <p className="text-xs text-gray-400 mb-2">
                          (الفرق: ±{corrected.errorRange.latError}° عرض، ±{corrected.errorRange.lonError}° طول)
                        </p>
                        <Button
                          onClick={() => 
                            copyToClipboard(`${corrected.corrected.lat.toFixed(8)}, ${corrected.corrected.lon.toFixed(8)}`)
                          }
                          variant="secondary"
                          size="sm"
                          data-testid="button-copy-corrected"
                        >
                          <Copy className="w-4 h-4 ml-2" />
                          نسخ الإحداثيات المصححة
                        </Button>
                      </div>
                    );
                  })()}

                  {/* Accuracy & Confidence */}
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="bg-black/30 rounded-lg p-3">
                      <p className="text-gray-400 mb-1">🎯 الدقة (نطاق الخطأ)</p>
                      <p className="text-white font-semibold">±{currentCoordinates.accuracy.toFixed(2)}م</p>
                    </div>
                    {currentCoordinates.altitude && (
                      <div className="bg-black/30 rounded-lg p-3">
                        <p className="text-gray-400 mb-1">📈 الارتفاع</p>
                        <p className="text-white font-semibold">{currentCoordinates.altitude.toFixed(2)}م</p>
                      </div>
                    )}
                  </div>

                  {/* Confidence Circle Info */}
                  {(() => {
                    const corrected = calculateCorrectedCoordinates(currentCoordinates);
                    return (
                      <div className="bg-black/30 rounded-lg p-4 border border-yellow-400/20">
                        <p className="text-sm text-yellow-400 font-bold mb-3">⭕ منطقة الثقة (Confidence Circle):</p>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div>
                            <p className="text-gray-400">الحد الأدنى للعرض:</p>
                            <p className="text-cyan-400 font-mono">{corrected.confidence.minLat.toFixed(8)}°</p>
                          </div>
                          <div>
                            <p className="text-gray-400">الحد الأقصى للعرض:</p>
                            <p className="text-cyan-400 font-mono">{corrected.confidence.maxLat.toFixed(8)}°</p>
                          </div>
                          <div>
                            <p className="text-gray-400">الحد الأدنى للطول:</p>
                            <p className="text-cyan-400 font-mono">{corrected.confidence.minLon.toFixed(8)}°</p>
                          </div>
                          <div>
                            <p className="text-gray-400">الحد الأقصى للطول:</p>
                            <p className="text-cyan-400 font-mono">{corrected.confidence.maxLon.toFixed(8)}°</p>
                          </div>
                        </div>
                        <p className="text-xs text-gray-500 mt-3">
                          💡 هذا النطاق يمثل منطقة دائرية حول النقطة الأصلية بنصف قطر = الدقة المعطاة
                        </p>
                      </div>
                    );
                  })()}

                  {currentCoordinates.imagePath && (
                    <div className="bg-black/30 rounded-lg p-4">
                      <p className="text-gray-400 mb-2 text-sm">الصورة المأخوذة:</p>
                      <img
                        src={currentCoordinates.imagePath}
                        alt="Captured"
                        className="w-full rounded-lg max-h-48 object-cover"
                      />
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar - Settings and Points */}
          <div className="space-y-6">
            {/* Accuracy Mode Selection */}
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
              <h3 className="text-lg font-bold text-orange-400 mb-4">⚡ وضع الدقة</h3>
              <div className="space-y-2 mb-4">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="radio"
                    name="accuracy"
                    value="normal"
                    checked={accuracyMode === "normal"}
                    onChange={(e) => setAccuracyMode(e.target.value as "normal" | "high")}
                    className="w-4 h-4"
                  />
                  <span className="text-gray-300">وضع عادي (سريع)</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="radio"
                    name="accuracy"
                    value="high"
                    checked={accuracyMode === "high"}
                    onChange={(e) => setAccuracyMode(e.target.value as "normal" | "high")}
                    className="w-4 h-4"
                  />
                  <span className="text-gray-300">وضع دقة عالية جداً</span>
                </label>
              </div>
              
              {statusMessage && (
                <div className={`rounded-lg p-3 text-sm ${
                  statusMessage.includes("✅") || statusMessage.includes("تم")
                    ? "bg-green-500/20 text-green-300 border border-green-400/30"
                    : statusMessage.includes("✓")
                    ? "bg-blue-500/20 text-blue-300 border border-blue-400/30"
                    : "bg-yellow-500/20 text-yellow-300 border border-yellow-400/30"
                }`}>
                  {statusMessage}
                  {attempts > 0 && <span className="block mt-1 text-xs">محاولات: {attempts}</span>}
                </div>
              )}
            </div>

            {/* Format Selection */}
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
              <h3 className="text-lg font-bold text-blue-400 mb-4">صيغة الإحداثيات</h3>
              <div className="space-y-2">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="radio"
                    name="format"
                    value="decimal"
                    checked={coordinateFormat === "decimal"}
                    onChange={(e) => setCoordinateFormat(e.target.value as "decimal" | "dms" | "both")}
                    className="w-4 h-4"
                  />
                  <span className="text-gray-300">عشرية (Decimal)</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="radio"
                    name="format"
                    value="dms"
                    checked={coordinateFormat === "dms"}
                    onChange={(e) => setCoordinateFormat(e.target.value as "decimal" | "dms" | "both")}
                    className="w-4 h-4"
                  />
                  <span className="text-gray-300">درجات ودقائق وثواني (DMS)</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="radio"
                    name="format"
                    value="both"
                    checked={coordinateFormat === "both"}
                    onChange={(e) => setCoordinateFormat(e.target.value as "decimal" | "dms" | "both")}
                    className="w-4 h-4"
                  />
                  <span className="text-gray-300">كلا الصيغتين</span>
                </label>
              </div>
            </div>

            {/* Captured Points */}
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-green-400">النقاط المسجلة</h3>
                <span className="bg-green-500/20 px-3 py-1 rounded-full text-sm text-green-400">
                  {capturedPoints.length}
                </span>
              </div>

              {capturedPoints.length === 0 ? (
                <p className="text-sm text-gray-400 text-center py-4">لم يتم تسجيل نقاط بعد</p>
              ) : (
                <div className="space-y-3">
                  {capturedPoints.map((point) => (
                    <div
                      key={point.id}
                      className="bg-black/30 rounded-lg p-3 border border-green-400/20"
                      data-testid={`point-card-${point.id}`}
                    >
                      <p className="text-sm font-semibold text-white mb-1">{point.description}</p>
                      <p className="text-xs text-gray-400 font-mono break-all">
                        {point.coordinates.latitude.toFixed(6)}, {point.coordinates.longitude.toFixed(6)}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        ±{point.coordinates.accuracy.toFixed(0)}م
                      </p>
                      <Button
                        onClick={() => deletePoint(point.id)}
                        variant="secondary"
                        size="sm"
                        className="mt-2 w-full text-xs"
                        data-testid={`button-delete-point-${point.id}`}
                      >
                        حذف
                      </Button>
                    </div>
                  ))}

                  {capturedPoints.length > 0 && (
                    <div className="space-y-2">
                      <Button
                        onClick={downloadCSV}
                        size="sm"
                        className="w-full bg-blue-600 hover:bg-blue-700"
                        data-testid="button-download-csv"
                      >
                        <Download className="w-4 h-4 ml-2" />
                        تحميل CSV
                      </Button>
                      <Link href="/visualization">
                        <Button
                          size="sm"
                          className="w-full bg-purple-600 hover:bg-purple-700"
                          data-testid="button-view-3d"
                        >
                          <Eye className="w-4 h-4 ml-2" />
                          عرض ثلاثي الأبعاد
                        </Button>
                      </Link>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Accuracy Tips */}
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
              <h3 className="text-lg font-bold text-cyan-400 mb-4">💡 نصائح لدقة عالية</h3>
              <ul className="text-xs text-gray-300 space-y-2">
                <li className="flex gap-2">
                  <span className="text-cyan-400 min-w-fit">✓</span>
                  <span>استخدم وضع الدقة العالية</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-cyan-400 min-w-fit">✓</span>
                  <span>انتظر حتى تستقر الدقة</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-cyan-400 min-w-fit">✓</span>
                  <span>ابقَ في منطقة مفتوحة</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-cyan-400 min-w-fit">✓</span>
                  <span>تجنب المباني الطويلة</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-cyan-400 min-w-fit">✓</span>
                  <span>استخدم في الطقس الصافي</span>
                </li>
              </ul>
            </div>

            {/* Info */}
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
              <h3 className="text-lg font-bold text-green-400 mb-4">📋 المعلومات</h3>
              <ul className="text-xs text-gray-300 space-y-2">
                <li>✓ استخدم GPS الدقيق للموقع</li>
                <li>✓ التقاط صور مع الإحداثيات</li>
                <li>✓ حفظ البيانات في CSV</li>
                <li>✓ صيغ إحداثيات متعددة</li>
                <li>✓ محاولات متعددة للدقة العالية</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
