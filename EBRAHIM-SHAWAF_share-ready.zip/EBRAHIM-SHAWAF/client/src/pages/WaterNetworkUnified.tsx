import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/lib/i18n';
import { ArrowLeft, Upload, MapPin, Zap, RotateCcw, HelpCircle } from 'lucide-react';
import { Link, useSearch } from 'wouter';
import { toast } from 'sonner';
import FeatureTour from '@/components/FeatureTour';
import shp from 'shpjs';
import { 
  calculateHaversineDistance, 
  calculateElevationPressure, 
  calculateHazenWilliamsHeadLoss, 
  headLossToBar, 
  toRadians, 
  wgs84ToUtm, 
  calculateGeodesicArea,
  calculateFlowVelocity,
  calculateReynoldsNumber,
  analyzePipeFlow,
  calculateWaterAge,
  calculatePipeVolume,
  calculateOptimalDiameter,
  getMinimumStandardDiameter,
  getStandardDiameters,
  calculateNodeDemand,
  calculateFireFlow,
  getMinimumServicePressure,
  analyzePressureAdequacy,
  calculateTankDetentionTime,
  calculateNetworkReliability,
  calculateDarcyWeisbachHeadLoss,
  getHazenWilliamsC,
  getPipeRoughness
} from '@/lib/utils';

interface PipeSegment {
  id: number;
  startLat: number;
  startLng: number;
  endLat: number;
  endLng: number;
  diameter: number;
  flow: number;
  length?: number;
  pressure?: number;
  material?: string;
  attributes?: Record<string, string>;
}

interface NetworkElement {
  id: number;
  name: string;
  lat: number;
  lng: number;
  type: 'meter' | 'valve' | 'tank' | 'pump';
  subType?: string;
  capacity?: number;
  pressure?: number;
  elevation?: number;
  serviceRadius?: number;
  lossCoefficient?: number;
  attributes?: Record<string, string>;
}

interface Zone {
  id: number;
  tankId: number;
  tankName: string;
  color: string;
  elements: NetworkElement[];
  pipes: PipeSegment[];
  sourcePress?: number;
  totalLength?: number;
  totalPressureLoss?: number;
  destPress?: number;
}

export default function WaterNetworkUnified() {
  const { language, t } = useLanguage();
  const isRTL = language === 'ar';
  
  const mapRef = useRef<any>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapTankRef = useRef<any>(null);
  const mapTankContainerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // الحالات المشتركة
  const [pipeSegments, setPipeSegments] = useState<PipeSegment[]>([]);
  const [elements, setElements] = useState<NetworkElement[]>([]);
  const [zones, setZones] = useState<Zone[]>([]);
  const [zoneResults, setZoneResults] = useState<Map<number, any>>(new Map());
  const [showPipes, setShowPipes] = useState(true);
  const [showElements, setShowElements] = useState(true);
  const [mapReady, setMapReady] = useState(false);
  const [swapCoords, setSwapCoords] = useState(false);
  const [diameterUnit, setDiameterUnit] = useState<'mm' | 'inch' | 'auto'>('auto');
  const [tab, setTab] = useState<'upload' | 'map' | 'data' | 'analyze' | 'calculate' | 'results' | 'profile' | 'tools' | 'measure' | 'terrain' | 'projects' | 'hydraulics' | 'compare'>('upload');
  const [compareScenarios, setCompareScenarios] = useState<{scenario1: number | null, scenario2: number | null}>({scenario1: null, scenario2: null});
  const [comparisonMode, setComparisonMode] = useState<'side-by-side' | 'overlay' | 'difference'>('side-by-side');
  const [selectedZoneForProfile, setSelectedZoneForProfile] = useState<number | null>(null);
  const [activeTool, setActiveTool] = useState<'coords' | 'quality' | 'valve' | 'demand' | 'whatif' | 'report'>('coords');
  
  // أدوات القياس والرسم
  const [measureMode, setMeasureMode] = useState<'distance' | 'area' | 'slope' | 'gps' | 'goto' | 'gpx'>('distance');
  const [measurePoints, setMeasurePoints] = useState<{lat: number, lng: number}[]>([]);
  const [measureResult, setMeasureResult] = useState<any>(null);
  const [userLocation, setUserLocation] = useState<{lat: number, lng: number} | null>(null);
  const [gotoCoords, setGotoCoords] = useState({ lat: '', lng: '' });
  
  // إدارة المشاريع
  const [savedProjects, setSavedProjects] = useState<{name: string, data: any, date: string}[]>([]);
  const [projectName, setProjectName] = useState('');
  const [compareNetwork, setCompareNetwork] = useState<{pipes: PipeSegment[], elements: NetworkElement[]} | null>(null);
  
  // تحليل التضاريس
  const [terrainMode, setTerrainMode] = useState<'contour' | 'watershed' | 'flood'>('contour');
  const [floodLevel, setFloodLevel] = useState<number>(10);
  const [contourInterval, setContourInterval] = useState<number>(5);
  
  // حالات تحويل الإحداثيات
  const [coordInput, setCoordInput] = useState({ lat: '', lng: '', easting: '', northing: '', zone: '36' });
  const [coordResult, setCoordResult] = useState<any>(null);
  
  // حالات فحص الجودة
  const [qualityResults, setQualityResults] = useState<any>(null);
  
  // حالات عزل الصمامات
  const [selectedValveId, setSelectedValveId] = useState<number | null>(null);
  const [isolationResults, setIsolationResults] = useState<any>(null);
  
  // حالات تحليل الطلب
  const [demandResults, setDemandResults] = useState<any>(null);
  
  // حالات سيناريوهات ماذا لو
  const [whatIfScenario, setWhatIfScenario] = useState<any>({ type: 'pipe_break', targetId: null });
  
  // حالات الارتفاع
  const [refLat, setRefLat] = useState<number>(30.0444);
  const [refLng, setRefLng] = useState<number>(31.2357);
  const [refElev, setRefElev] = useState<number>(100);
  const [targetLat, setTargetLat] = useState<number>(30.0500);
  const [targetLng, setTargetLng] = useState<number>(31.2400);
  const [elevResult, setElevResult] = useState<any>(null);
  
  // حالات ضغط المياه
  const [depth, setDepth] = useState<number>(10);
  const [density, setDensity] = useState<number>(1000);
  const [gravity, setGravity] = useState<number>(9.81);
  const [pressureResult, setPressureResult] = useState<any>(null);
  
  // حالة البحث
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // حالات حساب ضغط الخطوط المتصلة بالخزان
  const [selectedTankId, setSelectedTankId] = useState<number | null>(null);
  const [tankPressureCalcResult, setTankPressureCalcResult] = useState<any>(null);
  const [tankMapReady, setTankMapReady] = useState(false);
  const [elementPressures, setElementPressures] = useState<Map<number, number>>(new Map());
  const [showTour, setShowTour] = useState(false);
  const [extractedData, setExtractedData] = useState<{pipes: any[], elements: any[]}>({pipes: [], elements: []});

  // قراءة التبويب من الرابط
  const searchString = useSearch();
  useEffect(() => {
    const params = new URLSearchParams(searchString);
    const urlTab = params.get('tab');
    if (urlTab && ['upload', 'map', 'data', 'analyze', 'calculate', 'results', 'profile', 'tools', 'measure', 'terrain', 'projects'].includes(urlTab)) {
      setTab(urlTab as any);
    }
  }, [searchString]);

  // تحميل المشاريع المحفوظة من localStorage
  useEffect(() => {
    const saved = localStorage.getItem('savedProjects');
    if (saved) {
      try {
        setSavedProjects(JSON.parse(saved));
      } catch (e) {
        console.error('Error loading saved projects:', e);
      }
    }
  }, []);

  const getExtendedDataValue = (extendedData: Element | undefined, fieldNames: string[]): string | null => {
    if (!extendedData || !fieldNames || fieldNames.length === 0) return null;
    try {
      const dataElements = extendedData.getElementsByTagName('Data');
      for (let dataEl of Array.from(dataElements)) {
        const dataName = (dataEl as any).getAttribute('name') || '';
        if (fieldNames.some(fn => fn.toLowerCase() === dataName.toLowerCase())) {
          const value = (dataEl as any).getElementsByTagName('value')[0]?.textContent;
          if (value) return value;
        }
      }
      const simpleDataElements = extendedData.getElementsByTagName('SimpleData');
      for (let dataEl of Array.from(simpleDataElements)) {
        const dataName = (dataEl as any).getAttribute('name') || '';
        if (fieldNames.some(fn => fn.toLowerCase() === dataName.toLowerCase())) {
          const value = (dataEl as any).textContent;
          if (value) return value;
        }
      }
      const schemaElements = extendedData.getElementsByTagName('SchemaData');
      for (let schemaEl of Array.from(schemaElements)) {
        const simpleDatas = schemaEl.getElementsByTagName('SimpleData');
        for (let dataEl of Array.from(simpleDatas)) {
          const dataName = (dataEl as any).getAttribute('name') || '';
          if (fieldNames.some(fn => fn.toLowerCase() === dataName.toLowerCase())) {
            const value = (dataEl as any).textContent;
            if (value) return value;
          }
        }
      }
      return null;
    } catch (e) {
      console.warn('[KML] Error extracting extended data:', e);
      return null;
    }
  };

  // استخراج البيانات من جداول HTML في description
  const extractFromHtmlTable = (html: string, fieldNames: string[]): string | null => {
    if (!html || !fieldNames || fieldNames.length === 0) return null;
    try {
      // البحث عن نمط: <td>اسم الحقل</td><td>القيمة</td>
      for (const fieldName of fieldNames) {
        // نمط 1: <td>fieldName</td>\n<td>value</td>
        const pattern1 = new RegExp(`<td[^>]*>\\s*${fieldName}[^<]*</td>\\s*<td[^>]*>([^<]+)</td>`, 'i');
        const match1 = html.match(pattern1);
        if (match1 && match1[1]) {
          const val = match1[1].trim();
          if (val && val !== '&lt;Null&gt;' && val !== '<Null>' && val !== 'Null') {
            return val;
          }
        }
        
        // نمط 2: مع escape للأقواس
        const escapedName = fieldName.replace(/[()]/g, '\\$&');
        const pattern2 = new RegExp(`<td[^>]*>\\s*${escapedName}[^<]*</td>\\s*<td[^>]*>([^<]+)</td>`, 'i');
        const match2 = html.match(pattern2);
        if (match2 && match2[1]) {
          const val = match2[1].trim();
          if (val && val !== '&lt;Null&gt;' && val !== '<Null>' && val !== 'Null') {
            return val;
          }
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  };

  const parseKML = (content: string) => {
    try {
      if (!content || content.trim().length === 0) {
        throw new Error(language === 'ar' ? 'ملف KML فارغ' : 'KML file is empty');
      }
      
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(content, 'text/xml');
      if (xmlDoc.getElementsByTagName('parsererror').length > 0) {
        throw new Error(language === 'ar' ? 'خطأ في تحليل ملف KML' : 'Error parsing KML');
      }

      const placemarks = xmlDoc.getElementsByTagName('Placemark');
      const pipes: PipeSegment[] = [];
      const networkElements: NetworkElement[] = [];
      const elementCoords = new Map<string, NetworkElement>();
      let pipeId = 1;
      let elementId = 1;
      const diameters: number[] = [];

      Array.from(placemarks).forEach((placemark: any, pmIdx: number) => {
        const nameEl = placemark.getElementsByTagName('name')[0];
        const name = nameEl?.textContent || 'Point';
        const descEl = placemark.getElementsByTagName('description')[0];
        let allData = descEl?.textContent || '';
        
        // استخراج ID من Placemark id attribute (مثل ID_00000، ID_20000)
        const placemarkId = (placemark as Element).getAttribute('id') || '';
        
        // جمع جميع البيانات من ExtendedData بجميع الطرق
        const extendedData = placemark.getElementsByTagName('ExtendedData')[0];
        const allExtendedFields: {[key: string]: string} = {};
        
        // أولاً: استخراج البيانات من جدول HTML في description (شائع في ملفات ArcGIS/QGIS)
        const descHtml = descEl?.textContent || '';
        if (descHtml && descHtml.includes('<td>')) {
          // نمط 1: صفوف بدون </tr> (شائع في ملفات ArcGIS)
          // <tr><td>Field</td><td>Value</td>
          const pattern1 = /<tr[^>]*>\s*<td[^>]*>([^<]+)<\/td>\s*<td[^>]*>([^<]*)<\/td>/gi;
          let match;
          while ((match = pattern1.exec(descHtml)) !== null) {
            const fieldName = match[1].trim();
            const fieldValue = match[2].trim();
            if (fieldName && fieldValue && fieldValue !== '&lt;Null&gt;' && fieldValue !== '<Null>' && fieldValue !== 'Null' && fieldValue !== '') {
              allExtendedFields[fieldName] = fieldValue;
            }
          }
          
          // نمط 2: صفوف مع </tr>
          const pattern2 = /<tr[^>]*>\s*<td[^>]*>([^<]+)<\/td>\s*<td[^>]*>([^<]*)<\/td>\s*<\/tr>/gi;
          while ((match = pattern2.exec(descHtml)) !== null) {
            const fieldName = match[1].trim();
            const fieldValue = match[2].trim();
            if (fieldName && fieldValue && fieldValue !== '&lt;Null&gt;' && fieldValue !== '<Null>' && fieldValue !== 'Null' && fieldValue !== '') {
              allExtendedFields[fieldName] = fieldValue;
            }
          }
          
          // طباعة عدد الحقول المستخرجة
          if (pmIdx < 5 && Object.keys(allExtendedFields).length > 0) {
            console.log(`[KML] Extracted ${Object.keys(allExtendedFields).length} fields from HTML table for "${name}":`, allExtendedFields);
          }
        }
        
        if (extendedData) {
          // من Data elements
          const dataElements = extendedData.getElementsByTagName('Data');
          Array.from(dataElements).forEach((dataEl: any) => {
            const dataName = (dataEl as any).getAttribute('name') || '';
            const dataValue = (dataEl as any).getElementsByTagName('value')[0]?.textContent || '';
            if (dataValue) {
              allExtendedFields[dataName] = dataValue;
              allData += ` ${dataName}:${dataValue}`;
            }
          });
          
          // من SimpleData
          const simpleDataElements = extendedData.getElementsByTagName('SimpleData');
          Array.from(simpleDataElements).forEach((dataEl: any) => {
            const dataName = (dataEl as any).getAttribute('name') || '';
            const dataValue = (dataEl as any).textContent || '';
            if (dataValue) {
              allExtendedFields[dataName] = dataValue;
              allData += ` ${dataName}:${dataValue}`;
            }
          });
          
          // من SchemaData
          const schemaElements = extendedData.getElementsByTagName('SchemaData');
          Array.from(schemaElements).forEach((schemaEl: any) => {
            const simpleDatas = schemaEl.getElementsByTagName('SimpleData');
            Array.from(simpleDatas).forEach((dataEl: any) => {
              const dataName = (dataEl as any).getAttribute('name') || '';
              const dataValue = (dataEl as any).textContent || '';
              if (dataValue) {
                allExtendedFields[dataName] = dataValue;
                allData += ` ${dataName}:${dataValue}`;
              }
            });
          });
        }
        
        // استخراج ID الأصلي - أولوية: Placemark id، ثم الحقول الشائعة
        const extractOriginalId = (): string => {
          // أولاً: استخدام Placemark id attribute (مثل ID_00000، ID_20000)
          if (placemarkId && placemarkId.trim() !== '') {
            return placemarkId;
          }
          // ثانياً: البحث في الحقول الشائعة
          const idFields = ['ID', 'id', 'Id', 'OBJECTID', 'ObjectID', 'objectid', 'FID', 'fid', 'Fid', 
                            'FEATURE_ID', 'feature_id', 'FeatureID', 'OID', 'oid', 'GID', 'gid',
                            'PIPE_ID', 'pipe_id', 'PipeID', 'NODE_ID', 'node_id', 'NodeID',
                            'ASSET_ID', 'asset_id', 'AssetID', 'CODE', 'code', 'Code',
                            'NUMBER', 'number', 'Number', 'NO', 'no', 'No', 'NUM', 'num'];
          for (const field of idFields) {
            if (allExtendedFields[field] && allExtendedFields[field].trim() !== '') {
              return allExtendedFields[field];
            }
          }
          return '';
        };
        const originalId = extractOriginalId();
        
        // طباعة الحقول المتاحة للعناصر الأولى
        if (pmIdx === 0) {
          console.log(`[KML] Available fields in first element:`, Object.keys(allExtendedFields));
          console.log(`[KML] First element properties:`, allExtendedFields);
        }
        
        // logging للعناصر الأولى فقط لتجنب spam
        if (pmIdx < 3 || (pmIdx < 10 && name.toLowerCase().includes('pipe'))) {
          console.log(`[KML] Feature: ID=${originalId || 'N/A'}, Name=${name}, Props=`, allExtendedFields);
        }

        const desc_lower = (name + ' ' + allData).toLowerCase();
        let elementType: 'meter' | 'valve' | 'tank' | 'pump' = 'valve';
        
        // الترتيب مهم - تحقق من الخزانات أولاً ثم الباقي
        if (desc_lower.includes('خزان') || desc_lower.includes('tank') || desc_lower.includes('w tank') || desc_lower.includes('reservoir')) {
          elementType = 'tank';
        } else if (desc_lower.includes('مضخة') || desc_lower.includes('pump') || desc_lower.includes('booster') || desc_lower.includes('station') || name.toUpperCase().startsWith('PUMP') || /\bPUMP\b/i.test(name)) {
          elementType = 'pump';
        } else if (desc_lower.includes('عداد') || desc_lower.includes('meter') || desc_lower.includes('hc') || name.toUpperCase().startsWith('HC') || /\bHC\b/i.test(name)) {
          elementType = 'meter';
        } else if (desc_lower.includes('محبس') || desc_lower.includes('valve') || desc_lower.includes('wservicevalve') || desc_lower.includes('pressure reducing') || desc_lower.includes('prv') || desc_lower.includes('service') || name.toUpperCase().startsWith('PRV') || /\bPRV\b/i.test(name)) {
          elementType = 'valve';
        }

        // معالجة النقاط
        const pointEl = placemark.getElementsByTagName('Point')[0];
        if (pointEl) {
          const coordsEl = pointEl.getElementsByTagName('coordinates')[0];
          if (coordsEl?.textContent) {
            const coords = coordsEl.textContent.trim().split(',').map((c: string) => parseFloat(c));
            if (coords.length >= 2 && !isNaN(coords[0]) && !isNaN(coords[1])) {
              // قيم افتراضية حسب نوع العنصر
              let pressure = elementType === 'tank' ? 0 : (elementType === 'pump' ? 7 : 5);
              let elevation = 0;
              let capacity = 0;
              const descHtml = descEl?.textContent || '';
              
              // استخراج الارتفاع من جدول HTML
              const elevationFields = ['(الإرتفاع (متر', 'الإرتفاع', 'الارتفاع', 'Elevation', 'elevation', 'Height', 'height', 'Alt', 'alt'];
              const htmlElevation = extractFromHtmlTable(descHtml, elevationFields);
              if (htmlElevation) {
                const parsedElev = parseFloat(htmlElevation);
                if (!isNaN(parsedElev)) elevation = parsedElev;
              }
              
              // استخراج السعة للخزانات
              if (elementType === 'tank') {
                const capacityFields = ['(السعة (متر مكعب', 'السعة', 'Capacity', 'capacity', 'Volume', 'volume'];
                const htmlCapacity = extractFromHtmlTable(descHtml, capacityFields);
                if (htmlCapacity) {
                  const parsedCap = parseFloat(htmlCapacity);
                  if (!isNaN(parsedCap) && parsedCap > 0) capacity = parsedCap;
                }
              }
              
              // محاولة الحصول على الضغط من البيانات الموسعة
              const pressureExtended = getExtendedDataValue(extendedData, ['pressure', 'الضغط', 'Pressure', 'bar']);
              if (pressureExtended) {
                const parsedPressure = parseFloat(pressureExtended);
                if (!isNaN(parsedPressure)) pressure = parsedPressure;
              }
              
              if (pmIdx < 10) {
                console.log(`[KML] Point: ${name}, Type: ${elementType}, Elevation: ${elevation}m, Capacity: ${capacity}m³, ID: ${originalId || 'N/A'}`);
              }
              const [lat, lng] = swapCoords ? [coords[0], coords[1]] : [coords[1], coords[0]];
              networkElements.push({
                id: elementId++,
                name: originalId ? `${originalId} - ${name}` : name,
                lat,
                lng,
                type: elementType,
                pressure,
                elevation,
                capacity,
                serviceRadius: elementType === 'tank' ? 2 : undefined,
                lossCoefficient: elementType === 'meter' ? 1.5 : 0.5,
                attributes: { ...allExtendedFields, _originalId: originalId, _name: name }
              });
            }
          }
        }

        // معالجة الخطوط
        const processLineString = (lineEl: Element, lineName: string) => {
          const coordsEl = lineEl.getElementsByTagName('coordinates')[0];
          if (coordsEl?.textContent) {
            const coordList = coordsEl.textContent.trim().split(/\s+/).filter((c: string) => c.length > 0);
            if (coordList.length >= 2) {
              const startCoords = coordList[0].split(',').map((c: string) => parseFloat(c));
              const endCoords = coordList[coordList.length - 1].split(',').map((c: string) => parseFloat(c));
              
              if (startCoords.length >= 2 && endCoords.length >= 2 && 
                  !isNaN(startCoords[0]) && !isNaN(startCoords[1]) &&
                  !isNaN(endCoords[0]) && !isNaN(endCoords[1])) {
                
                let diameter = 50;
                let flow = 10;
                let diameterFound = false;
                let flowFound = false;
                
                // ===== البحث عن القطر بعدة طرق =====
                const descHtml = descEl?.textContent || '';
                
                // 1. البحث المباشر في ExtendedData مع أسماء شائعة (INTERNALDI أولاً للملفات السعودية)
                const diameterFieldNames = ['INTERNALDI', 'InternalDI', 'internaldi', 'diameter', 'DIAMETER', 'القطر', 'Diameter', 'D', 'OD', 'pipe_diameter', 'size', 'Size', 'dia', 'DIA', 'Diameter_mm', 'diameter_mm', 'DIAMETER_MM', 'Dia', 'DN', 'dn', 'NominalDiameter'];
                const diameterExtended = getExtendedDataValue(extendedData, diameterFieldNames);
                if (diameterExtended) {
                  const parsedDia = parseFloat(diameterExtended);
                  if (!isNaN(parsedDia) && parsedDia > 0) {
                    diameter = parsedDia;
                    diameterFound = true;
                    diameters.push(diameter);
                  }
                }
                
                // 2. البحث في allExtendedFields بمطابقة جزئية (للحقول مثل Diameter_mm أو العربية)
                if (!diameterFound && Object.keys(allExtendedFields).length > 0) {
                  // قائمة الحقول الشائعة للقطر (عربي وإنجليزي) - INTERNALDI أولاً
                  const diameterKeys = ['INTERNALDI', 'InternalDI', 'internaldi', '(القطر (مم', 'القطر (مم)', 'القطر', 'diameter', 'DIAMETER', 'Diameter', 'DIA', 'dia', 'Dia', 'DN', 'dn', 'D', 'd', 'OD', 'od', 'Size', 'size', 'SIZE'];
                  for (const key of diameterKeys) {
                    if (allExtendedFields[key]) {
                      const parsedDia = parseFloat(allExtendedFields[key]);
                      if (!isNaN(parsedDia) && parsedDia > 0) {
                        diameter = parsedDia;
                        diameterFound = true;
                        diameters.push(diameter);
                        if (pipeId <= 5) console.log(`[KML] Found diameter in field "${key}": ${diameter}`);
                        break;
                      }
                    }
                  }
                  // البحث بمطابقة جزئية إذا لم يتم العثور
                  if (!diameterFound) {
                    for (const [fieldName, fieldValue] of Object.entries(allExtendedFields)) {
                      const lowerName = fieldName.toLowerCase();
                      if (lowerName.includes('diameter') || lowerName.includes('dia') || lowerName.includes('قطر') || lowerName === 'd' || lowerName === 'dn' || lowerName === 'od') {
                        const parsedDia = parseFloat(fieldValue);
                        if (!isNaN(parsedDia) && parsedDia > 0) {
                          diameter = parsedDia;
                          diameterFound = true;
                          diameters.push(diameter);
                          if (pipeId <= 5) console.log(`[KML] Found diameter in field "${fieldName}": ${diameter}`);
                          break;
                        }
                      }
                    }
                  }
                }
                
                // 3. البحث في جدول HTML داخل description (للملفات من ArcGIS/QGIS)
                if (!diameterFound && descHtml) {
                  const htmlDiameterFields = ['القطر (مم', 'القطر', 'Diameter', 'diameter', 'DIA', 'Dia', 'قطر', 'DN', 'Size'];
                  const htmlDia = extractFromHtmlTable(descHtml, htmlDiameterFields);
                  if (htmlDia) {
                    const parsedDia = parseFloat(htmlDia);
                    if (!isNaN(parsedDia) && parsedDia > 0) {
                      diameter = parsedDia;
                      diameterFound = true;
                      diameters.push(diameter);
                      if (pipeId <= 5) console.log(`[KML] Found diameter in HTML table: ${diameter}`);
                    }
                  }
                }
                
                // 4. محاولة قراءة من الوصف كـ fallback أخير
                if (!diameterFound && allData) {
                  // البحث عن نمط "fieldname:value" أو "fieldname = value"
                  const diameterMatch = allData.match(/(?:diameter|القطر|dia|size|dn|od)[_\s]*(?:mm)?[:\s=]+(\d+\.?\d*)/i);
                  if (diameterMatch && diameterMatch[1]) {
                    const parsedDia = parseFloat(diameterMatch[1]);
                    if (!isNaN(parsedDia) && parsedDia > 0) {
                      diameter = parsedDia;
                      diameterFound = true;
                      diameters.push(diameter);
                    }
                  }
                }
                
                // ===== البحث عن التدفق بعدة طرق =====
                
                // 1. البحث المباشر في ExtendedData
                const flowFieldNames = ['flow', 'التدفق', 'Flow', 'Q', 'q', 'Discharge', 'FLOW', 'flow_rate', 'discharge', 'qdesign', 'Flow_rate', 'FlowRate', 'Q_design'];
                const flowExtended = getExtendedDataValue(extendedData, flowFieldNames);
                if (flowExtended) {
                  const parsedFlow = parseFloat(flowExtended);
                  if (!isNaN(parsedFlow) && parsedFlow > 0) {
                    flow = parsedFlow;
                    flowFound = true;
                  }
                }
                
                // 2. البحث في allExtendedFields بمطابقة جزئية
                if (!flowFound && Object.keys(allExtendedFields).length > 0) {
                  for (const [fieldName, fieldValue] of Object.entries(allExtendedFields)) {
                    const lowerName = fieldName.toLowerCase();
                    if (lowerName.includes('flow') || lowerName.includes('تدفق') || lowerName === 'q' || lowerName.includes('discharge')) {
                      const parsedFlow = parseFloat(fieldValue);
                      if (!isNaN(parsedFlow) && parsedFlow > 0) {
                        flow = parsedFlow;
                        flowFound = true;
                        if (pipeId <= 5) console.log(`[KML] Found flow in field "${fieldName}": ${flow}`);
                        break;
                      }
                    }
                  }
                }
                
                // 3. البحث في جدول HTML داخل description
                if (!flowFound && descHtml) {
                  const htmlFlowFields = ['التدفق', 'Flow', 'flow', 'Discharge', 'Q'];
                  const htmlFlow = extractFromHtmlTable(descHtml, htmlFlowFields);
                  if (htmlFlow) {
                    const parsedFlow = parseFloat(htmlFlow);
                    if (!isNaN(parsedFlow) && parsedFlow > 0) {
                      flow = parsedFlow;
                      flowFound = true;
                      if (pipeId <= 5) console.log(`[KML] Found flow in HTML table: ${flow}`);
                    }
                  }
                }
                
                // 4. محاولة قراءة من الوصف كـ fallback أخير
                if (!flowFound && allData) {
                  const flowMatch = allData.match(/(?:flow|التدفق|discharge|q)[_\s]*(?:rate)?[:\s=]+(\d+\.?\d*)/i);
                  if (flowMatch && flowMatch[1]) {
                    const parsedFlow = parseFloat(flowMatch[1]);
                    if (!isNaN(parsedFlow) && parsedFlow > 0) {
                      flow = parsedFlow;
                      flowFound = true;
                    }
                  }
                }
                
                // استخراج المادة
                let material = 'Unknown';
                const materialKeys = ['(مادة الصنع (عربى', '(مادة الصنع (انجليزى', 'مادة الصنع', 'Material', 'MATERIAL', 'material', 'MAT', 'mat', 'PipeMaterial', 'PIPE_MAT'];
                for (const key of materialKeys) {
                  if (allExtendedFields[key] && allExtendedFields[key].trim() !== '') {
                    material = allExtendedFields[key];
                    break;
                  }
                }
                
                console.log(`[KML] Line: ${lineName}, Diameter: ${diameter}${diameterFound ? '' : ' (default)'}, Flow: ${flow}${flowFound ? '' : ' (default)'}, Material: ${material}, ID: ${originalId || 'N/A'}`);
                
                const [startLat, startLng] = swapCoords ? [startCoords[0], startCoords[1]] : [startCoords[1], startCoords[0]];
                const [endLat, endLng] = swapCoords ? [endCoords[0], endCoords[1]] : [endCoords[1], endCoords[0]];
                
                pipes.push({
                  id: pipeId++,
                  startLat,
                  startLng,
                  endLat,
                  endLng,
                  diameter,
                  flow,
                  material,
                  attributes: { ...allExtendedFields, _originalId: originalId, _name: lineName }
                });

                // إنشاء عناصر من نقاط البداية والنهاية
                const createElementFromCoord = (coords: number[], label: string) => {
                  const [lat, lng] = swapCoords ? [coords[0], coords[1]] : [coords[1], coords[0]];
                  const key = `${lat.toFixed(6)},${lng.toFixed(6)}`;
                  if (!elementCoords.has(key)) {
                    elementCoords.set(key, {
                      id: elementId++,
                      name: `${label} (${lineName})`,
                      lat,
                      lng,
                      type: 'valve',
                      pressure: 5,
                      lossCoefficient: 0.5
                    });
                  }
                };
                createElementFromCoord(startCoords, 'Start');
                createElementFromCoord(endCoords, 'End');
              }
            }
          }
        };

        // معالجة LineString
        const lineEls = placemark.getElementsByTagName('LineString');
        Array.from(lineEls).forEach((lineEl: any) => {
          processLineString(lineEl, name);
        });

        // معالجة Polygon (كنقاط وخطوط من الحدود)
        const polygonEls = placemark.getElementsByTagName('Polygon');
        Array.from(polygonEls).forEach((polygonEl: any, polyIdx: number) => {
          const outerBoundary = polygonEl.getElementsByTagName('outerBoundaryIs')[0];
          if (outerBoundary) {
            const linearRing = outerBoundary.getElementsByTagName('LinearRing')[0];
            if (linearRing) {
              processLineString(linearRing, `${name}-Polygon${polyIdx}`);
            }
          }
          const innerBoundaries = polygonEl.getElementsByTagName('innerBoundaryIs');
          Array.from(innerBoundaries).forEach((innerBoundary: any, innerIdx: number) => {
            const linearRing = innerBoundary.getElementsByTagName('LinearRing')[0];
            if (linearRing) {
              processLineString(linearRing, `${name}-Inner${innerIdx}`);
            }
          });
        });

        // معالجة MultiGeometry
        const multiGeomEls = placemark.getElementsByTagName('MultiGeometry');
        Array.from(multiGeomEls).forEach((multiGeomEl: any, multiIdx: number) => {
          const lineStrings = multiGeomEl.getElementsByTagName('LineString');
          Array.from(lineStrings).forEach((lineEl: any, lineIdx: number) => {
            processLineString(lineEl, `${name}-Line${lineIdx}`);
          });
          
          const polygons = multiGeomEl.getElementsByTagName('Polygon');
          Array.from(polygons).forEach((polygonEl: any, polyIdx: number) => {
            const outerBoundary = polygonEl.getElementsByTagName('outerBoundaryIs')[0];
            if (outerBoundary) {
              const linearRing = outerBoundary.getElementsByTagName('LinearRing')[0];
              if (linearRing) {
                processLineString(linearRing, `${name}-Poly${polyIdx}`);
              }
            }
          });
        });
      });

      // إضافة العناصر المستخرجة من الأنابيب
      elementCoords.forEach((elem) => {
        networkElements.push(elem);
      });
      
      // ===== إنشاء الخزانات والعناصر من FROM_ و TO_ =====
      // تجميع العناصر الفريدة من حقول FROM_ و TO_
      const reservoirElements = new Map<string, { id: string; capacity: number; fromCoords?: number[]; toCoords?: number[] }>();
      
      pipes.forEach(pipe => {
        const attrs = pipe.attributes || {};
        const fromId = attrs['FROM_'] || attrs['FROM'] || attrs['from'] || '';
        const toId = attrs['TO_'] || attrs['TO'] || attrs['to'] || '';
        const capacity = parseFloat(attrs['CAP_M3H'] || attrs['CAP'] || attrs['Capacity'] || '0') || 0;
        
        // تحديد نوع العنصر من ID
        const getElementType = (id: string): 'tank' | 'pump' | 'valve' | 'meter' => {
          const prefix = id.split('-')[1]?.toUpperCase() || '';
          if (prefix === 'RE' || prefix === 'TK' || prefix === 'TANK') return 'tank'; // Reservoir/Tank
          if (prefix === 'PS' || prefix === 'PUMP') return 'pump'; // Pump Station
          if (prefix === 'WE' || prefix === 'WELL') return 'meter'; // Well
          if (prefix === 'FS' || prefix === 'WTP') return 'valve'; // Filter/Treatment
          return 'valve';
        };
        
        if (fromId && fromId.includes('-')) {
          if (!reservoirElements.has(fromId)) {
            reservoirElements.set(fromId, { id: fromId, capacity: 0, fromCoords: [pipe.startLat, pipe.startLng] });
          }
          const elem = reservoirElements.get(fromId)!;
          if (capacity > elem.capacity) elem.capacity = capacity;
        }
        
        if (toId && toId.includes('-')) {
          if (!reservoirElements.has(toId)) {
            reservoirElements.set(toId, { id: toId, capacity: 0, toCoords: [pipe.endLat, pipe.endLng] });
          }
          const elem = reservoirElements.get(toId)!;
          if (capacity > elem.capacity) elem.capacity = capacity;
        }
      });
      
      // إنشاء عناصر الشبكة من الخزانات والمحطات المكتشفة
      let addedReservoirCount = 0;
      reservoirElements.forEach((elem, id) => {
        const coords = elem.fromCoords || elem.toCoords;
        if (!coords) return;
        
        const prefix = id.split('-')[1]?.toUpperCase() || '';
        let elementType: 'tank' | 'pump' | 'valve' | 'meter' = 'valve';
        if (prefix === 'RE' || prefix === 'TK') elementType = 'tank';
        else if (prefix === 'PS') elementType = 'pump';
        else if (prefix === 'WE') elementType = 'meter';
        else if (prefix === 'FS' || prefix === 'WTP' || prefix === 'DA') elementType = 'valve';
        else return; // تخطي الأنابيب (TP, TL)
        
        // ضغط الخزان = 0 (كما طلب المستخدم)
        const pressure = elementType === 'tank' ? 0 : (elementType === 'pump' ? 7 : 5);
        
        networkElements.push({
          id: elementId++,
          name: id,
          lat: coords[0],
          lng: coords[1],
          type: elementType,
          pressure,
          elevation: 0,
          capacity: elementType === 'tank' ? elem.capacity : 0,
          serviceRadius: elementType === 'tank' ? 2 : undefined,
          lossCoefficient: 0.5,
          attributes: { _originalId: id, CAP_M3H: elem.capacity.toString() }
        });
        
        if (elementType === 'tank') addedReservoirCount++;
      });
      
      console.log(`[KML] Created ${addedReservoirCount} tanks from FROM_/TO_ references`);
      console.log(`[KML] Created ${reservoirElements.size - addedReservoirCount} other elements (pumps, wells, etc.)`);

      console.log(`[KML] Parsed: ${pipes.length} pipes, ${networkElements.length} elements`);
      const tanks = networkElements.filter(el => el.type === 'tank');
      console.log(`[KML] Found ${tanks.length} tanks`);
      
      // حفظ البيانات المستخرجة للعرض مع ID الأصلي وجميع الخصائص
      const extractedPipes = pipes.map(p => {
        const length = calculateHaversineDistance(p.startLat, p.startLng, p.endLat, p.endLng);
        const originalId = p.attributes?._originalId || '-';
        const pipeName = p.attributes?._name || '-';
        const allProps = Object.entries(p.attributes || {})
          .filter(([k]) => !k.startsWith('_'))
          .slice(0, 5)
          .map(([k, v]) => `${k}:${v}`)
          .join(', ');
        return {
          id: p.id,
          originalId,
          name: pipeName,
          diameter: p.diameter, 
          flow: p.flow, 
          length: length,
          start: `${p.startLat.toFixed(4)},${p.startLng.toFixed(4)}`, 
          end: `${p.endLat.toFixed(4)},${p.endLng.toFixed(4)}`,
          allProps
        };
      });
      const extractedElements = networkElements.map(e => {
        const originalId = e.attributes?._originalId || '-';
        const allProps = Object.entries(e.attributes || {})
          .filter(([k]) => !k.startsWith('_'))
          .slice(0, 4)
          .map(([k, v]) => `${k}:${v}`)
          .join(', ');
        return {
          id: e.id, 
          originalId,
          name: e.name, 
          type: e.type, 
          elevation: e.elevation,
          capacity: e.capacity,
          pressure: e.pressure, 
          coords: `${e.lat.toFixed(4)},${e.lng.toFixed(4)}`,
          allProps
        };
      });
      
      // ملخص الأقطار المكتشفة
      const uniqueDiameters = Array.from(new Set(extractedPipes.map(p => p.diameter))).sort((a, b) => a - b);
      const diameterCounts: {[key: number]: number} = {};
      extractedPipes.forEach(p => {
        diameterCounts[p.diameter] = (diameterCounts[p.diameter] || 0) + 1;
      });
      console.log(`[KML] ===== Diameter Summary =====`);
      console.log(`[KML] Total pipes: ${extractedPipes.length}`);
      console.log(`[KML] Unique diameters (${uniqueDiameters.length}): ${uniqueDiameters.join(', ')} mm`);
      console.log(`[KML] Diameter distribution:`, diameterCounts);
      console.log(`[KML] =============================`);
      
      setExtractedData({
        pipes: extractedPipes,
        elements: extractedElements
      });
      
      setElements(networkElements);
      
      if (pipes.length > 0) {
        setPipeSegments(pipes);
        
        // تحديد المناطق بناءً على الخزانات والشبكات المتصلة
        const zoneColors = ['#f59e0b', '#ef4444', '#3b82f6', '#10b981', '#8b5cf6', '#06b6d4', '#ec4899', '#6366f1', '#f97316', '#c084fc'];
        const pipeZones = new Map<number, number>(); // pipeId -> zoneId
        let zoneId = 0;

        // بناء خريطة الاتصالات
        const coordinateIndex = new Map<string, number[]>(); // "lat,lng" -> [pipeIds]
        const pipeMap = new Map<number, PipeSegment>(); // pipeId -> pipe
        
        pipes.forEach(pipe => {
          pipeMap.set(pipe.id, pipe);
          const startKey = `${pipe.startLat.toFixed(6)},${pipe.startLng.toFixed(6)}`;
          const endKey = `${pipe.endLat.toFixed(6)},${pipe.endLng.toFixed(6)}`;
          
          if (!coordinateIndex.has(startKey)) coordinateIndex.set(startKey, []);
          if (!coordinateIndex.has(endKey)) coordinateIndex.set(endKey, []);
          
          coordinateIndex.get(startKey)!.push(pipe.id);
          coordinateIndex.get(endKey)!.push(pipe.id);
        });

        // تجميع الأنابيب المتصلة باستخدام BFS (iterative - لتجنب stack overflow)
        const visited = new Set<number>();
        const zones: Zone[] = [];

        const bfs = (startPipeId: number, currentZoneId: number, pipesInZone: PipeSegment[]) => {
          const queue: number[] = [startPipeId];
          
          while (queue.length > 0) {
            const pipeId = queue.shift()!;
            if (visited.has(pipeId)) continue;
            
            visited.add(pipeId);
            pipeZones.set(pipeId, currentZoneId);
            
            const pipe = pipeMap.get(pipeId);
            if (!pipe) continue;
            
            pipesInZone.push(pipe);
            
            // البحث عن الأنابيب المتصلة
            const startKey = `${pipe.startLat.toFixed(6)},${pipe.startLng.toFixed(6)}`;
            const endKey = `${pipe.endLat.toFixed(6)},${pipe.endLng.toFixed(6)}`;
            
            const connectedPipes = new Set<number>();
            (coordinateIndex.get(startKey) || []).forEach(id => connectedPipes.add(id));
            (coordinateIndex.get(endKey) || []).forEach(id => connectedPipes.add(id));
            
            connectedPipes.forEach(connectedId => {
              if (!visited.has(connectedId)) {
                queue.push(connectedId);
              }
            });
          }
        };

        // إنشاء مناطق
        if (tanks.length > 0) {
          // تقسيم بناءً على الخزانات والشبكات المتصلة عليها
          tanks.forEach((tank, tankIdx) => {
            const pipesInZone: PipeSegment[] = [];
            
            // البحث عن الأنابيب المتصلة بهذا الخزان
            const tankCoordKey = `${tank.lat.toFixed(6)},${tank.lng.toFixed(6)}`;
            const connectedToPipe = coordinateIndex.get(tankCoordKey) || [];
            
            connectedToPipe.forEach(pipeId => {
              if (!visited.has(pipeId)) {
                bfs(pipeId, tankIdx, pipesInZone);
              }
            });
            
            if (pipesInZone.length > 0 || tankIdx < tanks.length) {
              zones.push({
                id: tankIdx,
                tankId: tank.id,
                tankName: tank.name,
                color: zoneColors[tankIdx % zoneColors.length],
                elements: networkElements.filter(el => {
                  if (el.id === tank.id) return true; // الخزان نفسه
                  return pipesInZone.some(p => 
                    (Math.abs(el.lat - p.startLat) < 0.0001 && Math.abs(el.lng - p.startLng) < 0.0001) ||
                    (Math.abs(el.lat - p.endLat) < 0.0001 && Math.abs(el.lng - p.endLng) < 0.0001)
                  );
                }),
                pipes: pipesInZone
              });
            }
          });
        }
        
        // إضافة المناطق من الأنابيب غير المتصلة بخزانات
        pipes.forEach(pipe => {
          if (!visited.has(pipe.id)) {
            const pipesInZone: PipeSegment[] = [];
            bfs(pipe.id, zoneId, pipesInZone);
            
            zones.push({
              id: zoneId,
              tankId: zoneId + 1000,
              tankName: `Network ${zoneId + 1}`,
              color: zoneColors[zoneId % zoneColors.length],
              elements: networkElements.filter(el => {
                return pipesInZone.some(p => 
                  (Math.abs(el.lat - p.startLat) < 0.0001 && Math.abs(el.lng - p.startLng) < 0.0001) ||
                  (Math.abs(el.lat - p.endLat) < 0.0001 && Math.abs(el.lng - p.endLng) < 0.0001)
                );
              }),
              pipes: pipesInZone
            });
            
            zoneId++;
          }
        });

        setElements(networkElements);
        setZones(zones);
        console.log(`[KML] Created ${zones.length} zones - ${tanks.length} tanks + ${zoneId} unconnected networks`);
      }
      toast.success(language === 'ar' ? `✓ تم تحميل ${pipes.length} أنبوب و${networkElements.length} عنصر` : `✓ Loaded ${pipes.length} pipes and ${networkElements.length} elements`);
      setTab('map');
    } catch (error: any) {
      console.error('[KML] Error:', error);
      const msg = error?.message || 'Unknown error';
      toast.error(`❌ ${msg}`);
    }
  };

  const convertDiametersToMm = () => {
    if (pipeSegments.length === 0) {
      toast.error(language === 'ar' ? '❌ لا توجد بيانات' : '❌ No data');
      return;
    }
    
    const convertedPipes = pipeSegments.map(pipe => ({
      ...pipe,
      diameter: pipe.diameter <= 72 ? Math.round(pipe.diameter * 25.4) : pipe.diameter
    }));
    
    setPipeSegments(convertedPipes);
    
    const extractedPipes = convertedPipes.map(p => {
      const length = calculateDistance(p.startLat, p.startLng, p.endLat, p.endLng);
      return {
        id: p.id, 
        diameter: p.diameter, 
        flow: p.flow, 
        length: length,
        start: `${p.startLat.toFixed(4)},${p.startLng.toFixed(4)}`, 
        end: `${p.endLat.toFixed(4)},${p.endLng.toFixed(4)}`
      };
    });
    setExtractedData(prev => ({ ...prev, pipes: extractedPipes }));
    setDiameterUnit('mm');
    
    toast.success(language === 'ar' ? '✓ تم تحويل الأقطار من بوصة إلى مم' : '✓ Diameters converted from inch to mm');
  };

  const fetchMissingElevations = async () => {
    const elementsWithoutElevation = elements.filter(e => !e.elevation || e.elevation === 0);
    
    if (elementsWithoutElevation.length === 0) {
      toast.success(language === 'ar' ? '✓ جميع العناصر لديها ارتفاعات' : '✓ All elements have elevations');
      return;
    }
    
    toast.loading(language === 'ar' 
      ? `⏳ جاري جلب ارتفاعات ${elementsWithoutElevation.length} عنصر...` 
      : `⏳ Fetching elevations for ${elementsWithoutElevation.length} elements...`);
    
    const batchSize = 50;
    const batches = [];
    for (let i = 0; i < elementsWithoutElevation.length; i += batchSize) {
      batches.push(elementsWithoutElevation.slice(i, i + batchSize));
    }
    
    let successCount = 0;
    let failCount = 0;
    const updatedElements = [...elements];
    
    for (const batch of batches) {
      try {
        const locations = batch.map(e => `${e.lat},${e.lng}`).join('|');
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 15000);
        
        const response = await fetch(
          `https://api.open-elevation.com/api/v1/lookup?locations=${locations}`,
          { signal: controller.signal }
        );
        clearTimeout(timeoutId);
        
        if (response.ok) {
          const data = await response.json();
          if (data.results && data.results.length === batch.length) {
            batch.forEach((el, idx) => {
              const elevation = data.results[idx].elevation;
              if (elevation !== undefined) {
                const elementIndex = updatedElements.findIndex(e => e.id === el.id);
                if (elementIndex !== -1) {
                  updatedElements[elementIndex] = { ...updatedElements[elementIndex], elevation };
                  successCount++;
                }
              }
            });
          }
        } else {
          failCount += batch.length;
        }
      } catch (e) {
        console.log('[Elevation] Batch fetch failed:', e);
        failCount += batch.length;
      }
      
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    setElements(updatedElements);
    
    const elevationData = updatedElements.map(e => ({
      id: e.id,
      name: e.name,
      type: e.type,
      elevation: e.elevation,
      capacity: e.capacity,
      pressure: e.pressure,
      coords: `${e.lat.toFixed(4)},${e.lng.toFixed(4)}`
    }));
    setExtractedData(prev => ({ ...prev, elements: elevationData }));
    
    if (successCount > 0) {
      toast.success(language === 'ar' 
        ? `✓ تم جلب ${successCount} ارتفاع بنجاح` 
        : `✓ Fetched ${successCount} elevations successfully`);
    }
    if (failCount > 0) {
      toast.warning(language === 'ar' 
        ? `⚠️ فشل جلب ${failCount} ارتفاع` 
        : `⚠️ Failed to fetch ${failCount} elevations`);
    }
  };

  const handleKMLUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const fileName = file.name.toLowerCase();
    const isKML = fileName.endsWith('.kml');
    const isKMZ = fileName.endsWith('.kmz');
    
    if (!isKML && !isKMZ) {
      toast.error(language === 'ar' ? '❌ يرجى تحميل ملف KML أو KMZ' : '❌ Please upload KML or KMZ file');
      return;
    }

    if (isKML) {
      // معالجة ملف KML مباشرة
      const reader = new FileReader();
      reader.onload = (e) => parseKML(e.target?.result as string);
      reader.readAsText(file);
    } else if (isKMZ) {
      // معالجة ملف KMZ (ZIP يحتوي على KML)
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const JSZip = (await import('jszip')).default;
          const zip = new JSZip();
          const data = e.target?.result as ArrayBuffer;
          const loaded = await zip.loadAsync(data);
          
          // البحث عن ملف KML الأول في الملف المضغوط
          let kmlContent: string | null = null;
          for (const fileName of Object.keys(loaded.files)) {
            if (fileName.toLowerCase().endsWith('.kml')) {
              kmlContent = await loaded.files[fileName].async('string');
              break;
            }
          }
          
          if (!kmlContent) {
            toast.error(language === 'ar' ? '❌ لم يتم العثور على ملف KML داخل KMZ' : '❌ No KML file found in KMZ');
            return;
          }
          
          parseKML(kmlContent);
        } catch (error: any) {
          console.error('[KMZ] Error:', error);
          const msg = error?.message || 'Unknown error';
          toast.error(language === 'ar' ? `❌ خطأ: ${msg}` : `❌ Error: ${msg}`);
        }
      };
      reader.readAsArrayBuffer(file);
    }
  };

  // دالة معالجة ملفات Shapefile
  const handleShapefileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const fileName = file.name.toLowerCase();
    const isZip = fileName.endsWith('.zip');
    const isShp = fileName.endsWith('.shp');
    
    if (!isZip && !isShp) {
      toast.error(language === 'ar' ? '❌ يرجى تحميل ملف ZIP يحتوي على Shapefile' : '❌ Please upload a ZIP file containing Shapefile');
      return;
    }

    toast.info(language === 'ar' ? '⏳ جاري تحليل Shapefile...' : '⏳ Parsing Shapefile...');
    
    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const arrayBuffer = e.target?.result as ArrayBuffer;
          const geojson = await shp(arrayBuffer);
          
          console.log('[Shapefile] Parsed GeoJSON:', geojson);
          
          // تحويل GeoJSON إلى تنسيق التطبيق
          const parsedPipes: PipeSegment[] = [];
          const parsedElements: NetworkElement[] = [];
          let pipeId = 1;
          let elemId = 1;

          // التعامل مع FeatureCollection واحدة أو مجموعة
          const collections = Array.isArray(geojson) ? geojson : [geojson];
          
          for (const collection of collections) {
            if (!collection.features) continue;
            
            // طباعة الحقول المتاحة في أول عنصر
            if (collection.features.length > 0) {
              const firstProps = collection.features[0].properties || {};
              console.log('[Shapefile] Available fields:', Object.keys(firstProps));
              console.log('[Shapefile] First feature properties:', firstProps);
            }
            
            for (const feature of collection.features) {
              const geom = feature.geometry;
              const props = feature.properties || {};
              
              // استخراج ID من الملف - البحث في عدة حقول
              const originalId = extractId(props);
              
              // استخراج الخصائص الشائعة
              const diameter = extractDiameter(props);
              const flow = extractFlow(props);
              const name = props.NAME || props.name || props.LABEL || props.label || originalId || `Feature_${elemId}`;
              const material = props.MATERIAL || props.material || props.MAT || 'Unknown';
              
              // طباعة بيانات كل نقطة في الـ Console
              console.log(`[Shapefile] Feature: ID=${originalId}, Name=${name}, Type=${geom.type}, Props=`, props);
              
              if (geom.type === 'Point') {
                // نقطة - تحويل لعنصر
                const [lng, lat] = geom.coordinates;
                const type = detectElementType(name, props);
                
                parsedElements.push({
                  id: elemId++,
                  name: originalId ? `${originalId} - ${name}` : String(name),
                  lat: swapCoords ? lng : lat,
                  lng: swapCoords ? lat : lng,
                  type: type,
                  capacity: props.CAPACITY || props.capacity || undefined,
                  elevation: props.ELEVATION || props.elevation || props.ELEV || props.Z || undefined,
                  attributes: { ...props, _originalId: originalId }
                });
              } else if (geom.type === 'LineString') {
                // خط - تحويل لأنبوب
                const coords = geom.coordinates;
                for (let i = 0; i < coords.length - 1; i++) {
                  const [startLng, startLat] = coords[i];
                  const [endLng, endLat] = coords[i + 1];
                  
                  parsedPipes.push({
                    id: pipeId++,
                    startLat: swapCoords ? startLng : startLat,
                    startLng: swapCoords ? startLat : startLng,
                    endLat: swapCoords ? endLng : endLat,
                    endLng: swapCoords ? endLat : endLng,
                    diameter: diameter,
                    flow: flow,
                    material: material,
                    attributes: { ...props, _originalId: originalId, _name: name }
                  });
                }
              } else if (geom.type === 'MultiLineString') {
                // خطوط متعددة
                for (const line of geom.coordinates) {
                  for (let i = 0; i < line.length - 1; i++) {
                    const [startLng, startLat] = line[i];
                    const [endLng, endLat] = line[i + 1];
                    
                    parsedPipes.push({
                      id: pipeId++,
                      startLat: swapCoords ? startLng : startLat,
                      startLng: swapCoords ? startLat : startLng,
                      endLat: swapCoords ? endLng : endLat,
                      endLng: swapCoords ? endLat : endLng,
                      diameter: diameter,
                      flow: flow,
                      material: material,
                      attributes: { ...props, _originalId: originalId, _name: name }
                    });
                  }
                }
              } else if (geom.type === 'Polygon') {
                // مضلع - تحويل حدوده لخطوط
                const ring = geom.coordinates[0]; // الحلقة الخارجية
                for (let i = 0; i < ring.length - 1; i++) {
                  const [startLng, startLat] = ring[i];
                  const [endLng, endLat] = ring[i + 1];
                  
                  parsedPipes.push({
                    id: pipeId++,
                    startLat: swapCoords ? startLng : startLat,
                    startLng: swapCoords ? startLat : startLng,
                    endLat: swapCoords ? endLng : endLat,
                    endLng: swapCoords ? endLat : endLng,
                    diameter: diameter,
                    flow: flow,
                    material: material,
                    attributes: { ...props, _originalId: originalId, _name: name }
                  });
                }
              } else if (geom.type === 'MultiPoint') {
                // نقاط متعددة
                for (const coord of geom.coordinates) {
                  const [lng, lat] = coord;
                  const type = detectElementType(name, props);
                  
                  parsedElements.push({
                    id: elemId++,
                    name: originalId ? `${originalId} - ${name}` : `${name}_${elemId}`,
                    lat: swapCoords ? lng : lat,
                    lng: swapCoords ? lat : lng,
                    type: type,
                    capacity: props.CAPACITY || props.capacity || undefined,
                    elevation: props.ELEVATION || props.elevation || props.ELEV || props.Z || undefined,
                    attributes: { ...props, _originalId: originalId }
                  });
                }
              }
            }
          }

          // حساب أطوال الأنابيب
          parsedPipes.forEach(pipe => {
            pipe.length = calculateHaversineDistance(pipe.startLat, pipe.startLng, pipe.endLat, pipe.endLng);
          });

          console.log(`[Shapefile] Parsed: ${parsedPipes.length} pipes, ${parsedElements.length} elements`);
          
          setPipeSegments(parsedPipes);
          setElements(parsedElements);
          
          // تحديث البيانات المستخرجة مع ID الأصلي وجميع الخصائص
          setExtractedData({
            pipes: parsedPipes.slice(0, 200).map(p => ({
              id: p.id,
              originalId: p.attributes?._originalId || '-',
              name: p.attributes?._name || '-',
              diameter: p.diameter,
              flow: p.flow,
              length: p.length?.toFixed(1) || '0',
              material: p.material || 'Unknown',
              coords: `${p.startLat.toFixed(4)},${p.startLng.toFixed(4)} → ${p.endLat.toFixed(4)},${p.endLng.toFixed(4)}`,
              allProps: Object.entries(p.attributes || {})
                .filter(([k]) => !k.startsWith('_'))
                .map(([k, v]) => `${k}: ${v}`)
                .join(' | ')
            })),
            elements: parsedElements.slice(0, 100).map(e => ({
              id: e.id,
              originalId: e.attributes?._originalId || '-',
              name: e.name,
              type: e.type,
              elevation: e.elevation,
              capacity: e.capacity,
              coords: `${e.lat.toFixed(4)},${e.lng.toFixed(4)}`,
              allProps: Object.entries(e.attributes || {})
                .filter(([k]) => !k.startsWith('_'))
                .map(([k, v]) => `${k}: ${v}`)
                .join(' | ')
            }))
          });

          toast.success(language === 'ar' 
            ? `✅ تم تحميل ${parsedPipes.length} أنبوب و ${parsedElements.length} عنصر من Shapefile` 
            : `✅ Loaded ${parsedPipes.length} pipes and ${parsedElements.length} elements from Shapefile`);
            
          // الانتقال لتبويب البيانات
          setTab('data');
          
        } catch (error: any) {
          console.error('[Shapefile] Parse error:', error);
          toast.error(language === 'ar' 
            ? `❌ خطأ في تحليل Shapefile: ${error.message}` 
            : `❌ Shapefile parse error: ${error.message}`);
        }
      };
      
      reader.readAsArrayBuffer(file);
      
    } catch (error: any) {
      console.error('[Shapefile] Error:', error);
      toast.error(language === 'ar' ? `❌ خطأ: ${error.message}` : `❌ Error: ${error.message}`);
    }
  };

  // دوال مساعدة لاستخراج البيانات من الخصائص
  const extractId = (props: Record<string, any>): string => {
    const idFields = ['ID', 'id', 'Id', 'OBJECTID', 'ObjectID', 'objectid', 'FID', 'fid', 'Fid', 
                      'FEATURE_ID', 'feature_id', 'FeatureID', 'OID', 'oid', 'GID', 'gid',
                      'PIPE_ID', 'pipe_id', 'PipeID', 'NODE_ID', 'node_id', 'NodeID',
                      'ASSET_ID', 'asset_id', 'AssetID', 'CODE', 'code', 'Code',
                      'NUMBER', 'number', 'Number', 'NO', 'no', 'No', 'NUM', 'num'];
    for (const field of idFields) {
      if (props[field] !== undefined && props[field] !== null && props[field] !== '') {
        console.log(`[Shapefile] Found ID: ${props[field]} in field ${field}`);
        return String(props[field]);
      }
    }
    return '';
  };

  const extractDiameter = (props: Record<string, any>): number => {
    const diamFields = ['DIAMETER', 'diameter', 'DIA', 'dia', 'D', 'd', 'PIPE_DIA', 'pipe_dia', 'DN', 'dn', 'SIZE', 'size', 'WIDTH', 'width'];
    for (const field of diamFields) {
      if (props[field] !== undefined && props[field] !== null) {
        const val = parseFloat(props[field]);
        if (!isNaN(val) && val > 0) {
          console.log(`[Shapefile] Found diameter: ${val} in field ${field}`);
          return val < 10 ? val * 1000 : val; // تحويل من م إلى مم إذا لزم
        }
      }
    }
    return 100; // قيمة افتراضية
  };

  const extractFlow = (props: Record<string, any>): number => {
    const flowFields = ['FLOW', 'flow', 'Q', 'q', 'DISCHARGE', 'discharge', 'FLOW_RATE', 'flow_rate'];
    for (const field of flowFields) {
      if (props[field] !== undefined && props[field] !== null) {
        const val = parseFloat(props[field]);
        if (!isNaN(val) && val > 0) {
          console.log(`[Shapefile] Found flow: ${val} in field ${field}`);
          return val;
        }
      }
    }
    return 10; // قيمة افتراضية
  };

  const detectElementType = (name: string, props: Record<string, any>): 'meter' | 'valve' | 'tank' | 'pump' => {
    const nameUpper = String(name).toUpperCase();
    const typeField = (props.TYPE || props.type || props.CATEGORY || props.category || '').toString().toUpperCase();
    
    // فحص الاسم والنوع
    if (nameUpper.includes('TANK') || nameUpper.includes('خزان') || nameUpper.includes('RESERVOIR') || typeField.includes('TANK')) {
      return 'tank';
    }
    if (nameUpper.includes('PUMP') || nameUpper.includes('مضخ') || typeField.includes('PUMP')) {
      return 'pump';
    }
    if (nameUpper.includes('VALVE') || nameUpper.includes('محبس') || nameUpper.includes('صمام') || 
        nameUpper.includes('PRV') || nameUpper.includes('GATE') || typeField.includes('VALVE')) {
      return 'valve';
    }
    if (nameUpper.includes('METER') || nameUpper.includes('عداد') || nameUpper === 'HC' || typeField.includes('METER')) {
      return 'meter';
    }
    
    return 'meter'; // افتراضي
  };

  const shapefileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (tab !== 'map' || mapReady) return;
    if (!mapContainerRef.current) {
      console.log('[Map] Container not ready yet');
      return;
    }

    const loadMap = () => {
      const L = (window as any).L;
      if (!L) {
        const script = document.createElement('script');
        script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
        script.onload = () => {
          const css = document.createElement('link');
          css.rel = 'stylesheet';
          css.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
          document.head.appendChild(css);
          setTimeout(initMap, 300);
        };
        document.head.appendChild(script);
      } else {
        initMap();
      }
    };

    const initMap = () => {
      const L = (window as any).L;
      if (!L) {
        console.log('[Map] Leaflet script failed to load');
        return;
      }
      if (!mapContainerRef.current) {
        console.log('[Map] Container disappeared');
        return;
      }

      try {
        if (mapRef.current) {
          mapRef.current.remove();
        }
        mapRef.current = L.map(mapContainerRef.current, { 
          preferCanvas: true 
        }).setView([30.0444, 31.2357], 13);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '© OpenStreetMap contributors',
          maxZoom: 19
        }).addTo(mapRef.current);
        
        console.log('[Map] Map initialized successfully, mapRef:', !!mapRef.current);
        setMapReady(true);
      } catch (e) {
        console.error('[Map] Initialization error:', e);
      }
    };

    loadMap();
  }, [tab, mapReady]);

  useEffect(() => {
    if (!mapReady || !mapRef.current) {
      console.log('[Map] Not ready:', { mapReady, mapRefExists: !!mapRef.current });
      return;
    }
    
    const L = (window as any).L;
    if (!L) {
      console.log('[Map] Leaflet not loaded');
      return;
    }

    console.log('[Map] Rendering with:', { 
      elementsCount: elements.length, 
      pipesCount: pipeSegments.length, 
      showElements, 
      showPipes,
      mapReady
    });

    // تنظيف الطبقات القديمة
    const layersToRemove: any[] = [];
    mapRef.current.eachLayer((layer: any) => {
      if (layer instanceof L.Marker || layer instanceof L.Polyline) {
        layersToRemove.push(layer);
      }
    });
    layersToRemove.forEach(layer => mapRef.current.removeLayer(layer));

    let bounds: any = null;

    // عرض الأنابيب أولاً
    if (showPipes && pipeSegments.length > 0) {
      console.log(`[Map] Adding ${pipeSegments.length} pipes`);
      
      pipeSegments.forEach((seg) => {
        try {
          const pressure = elementPressures.get(seg.id);
          const color = getPressureColor(pressure);
          const weight = pressure ? Math.min(5, 1 + pressure) : 2;
          
          // حساب الطول
          const pipeLength = calculateHaversineDistance(seg.startLat, seg.startLng, seg.endLat, seg.endLng);
          
          // جمع الخصائص الإضافية
          const attrs = seg.attributes || {};
          const originalId = attrs._originalId || '-';
          const material = seg.material || attrs['MATERIAL_E'] || attrs['Material'] || '-';
          const fromId = attrs['FROM_'] || attrs['FROM'] || '-';
          const toId = attrs['TO_'] || attrs['TO'] || '-';
          const capacity = attrs['CAP_M3H'] || '-';
          
          // خصائص إضافية
          const propsHtml = Object.entries(attrs)
            .filter(([k]) => !k.startsWith('_') && !['FROM_', 'TO_', 'CAP_M3H', 'MATERIAL_E', 'INTERNALDI'].includes(k))
            .slice(0, 6)
            .map(([k, v]) => `<tr><td style="padding: 2px 6px; color: #666; font-size: 10px;">${k}</td><td style="padding: 2px 6px; font-size: 10px;">${v}</td></tr>`)
            .join('');
          
          const popupContent = `
            <div style="direction: ${isRTL ? 'rtl' : 'ltr'}; font-family: Arial; min-width: 220px;">
              <div style="background: ${color}; color: white; padding: 8px; margin: -10px -10px 8px -10px; border-radius: 4px 4px 0 0;">
                <span style="font-size: 14px;">🔗</span>
                <b style="font-size: 13px; margin-${isRTL ? 'right' : 'left'}: 6px;">${language === 'ar' ? 'أنبوب' : 'Pipe'} ${originalId !== '-' ? originalId : '#' + seg.id}</b>
              </div>
              <table style="width: 100%; font-size: 11px; border-collapse: collapse;">
                <tr style="background: #f3f4f6;">
                  <td style="padding: 3px 6px; color: #666;">${language === 'ar' ? 'الضغط' : 'Pressure'}</td>
                  <td style="padding: 3px 6px; font-weight: bold; color: ${!pressure || pressure <= 0 ? '#ef4444' : '#22c55e'};">${pressure?.toFixed(3) || 'N/A'} bar</td>
                </tr>
                <tr>
                  <td style="padding: 3px 6px; color: #666;">${language === 'ar' ? 'القطر' : 'Diameter'}</td>
                  <td style="padding: 3px 6px; font-weight: 500;">${seg.diameter} mm</td>
                </tr>
                <tr style="background: #f3f4f6;">
                  <td style="padding: 3px 6px; color: #666;">${language === 'ar' ? 'الطول' : 'Length'}</td>
                  <td style="padding: 3px 6px; font-weight: 500;">${pipeLength.toFixed(1)} m</td>
                </tr>
                <tr>
                  <td style="padding: 3px 6px; color: #666;">${language === 'ar' ? 'المادة' : 'Material'}</td>
                  <td style="padding: 3px 6px;">${material}</td>
                </tr>
                ${capacity !== '-' ? `
                <tr style="background: #f3f4f6;">
                  <td style="padding: 3px 6px; color: #666;">${language === 'ar' ? 'السعة' : 'Capacity'}</td>
                  <td style="padding: 3px 6px;">${capacity} m³/h</td>
                </tr>` : ''}
                <tr>
                  <td style="padding: 3px 6px; color: #666;">${language === 'ar' ? 'من' : 'From'}</td>
                  <td style="padding: 3px 6px; font-size: 10px;">${fromId}</td>
                </tr>
                <tr style="background: #f3f4f6;">
                  <td style="padding: 3px 6px; color: #666;">${language === 'ar' ? 'إلى' : 'To'}</td>
                  <td style="padding: 3px 6px; font-size: 10px;">${toId}</td>
                </tr>
                ${propsHtml ? `
                <tr><td colspan="2" style="padding: 4px 6px; background: #e5e7eb; font-weight: bold; font-size: 10px;">${language === 'ar' ? 'المزيد' : 'More'}</td></tr>
                ${propsHtml}` : ''}
              </table>
            </div>
          `;
          
          L.polyline([
            [seg.startLat, seg.startLng],
            [seg.endLat, seg.endLng]
          ], {
            color: color,
            weight: weight,
            opacity: 0.8
          }).bindPopup(popupContent, { maxWidth: 320, className: 'custom-popup' }).addTo(mapRef.current);
          
          if (!bounds) {
            bounds = L.latLngBounds([seg.startLat, seg.startLng], [seg.endLat, seg.endLng]);
          } else {
            bounds.extend([seg.startLat, seg.startLng]);
            bounds.extend([seg.endLat, seg.endLng]);
          }
        } catch (e) {
          console.error('[Map] Error adding pipe:', e);
        }
      });
    }

    // عرض العناصر ثانياً
    if (showElements && elements.length > 0) {
      console.log(`[Map] Adding ${elements.length} elements`);
      
      elements.forEach((elem, idx) => {
        try {
          if (!elem.lat || !elem.lng || isNaN(elem.lat) || isNaN(elem.lng)) {
            return;
          }
          
          const typeIcons: {[key: string]: string} = { meter: '📊', valve: '🚰', tank: '🛢️', pump: '⚙️' };
          const typeNames: {[key: string]: {ar: string, en: string}} = { 
            meter: {ar: 'عداد', en: 'Meter'}, 
            valve: {ar: 'محبس', en: 'Valve'}, 
            tank: {ar: 'خزان', en: 'Tank'}, 
            pump: {ar: 'مضخة', en: 'Pump'} 
          };
          const icon = typeIcons[elem.type] || '📍';
          const typeName = typeNames[elem.type] || {ar: 'عنصر', en: 'Element'};
          
          // تحديد لون الأيقونة حسب النوع
          const typeColors: {[key: string]: string} = { 
            tank: '#ef4444', // أحمر للخزان
            pump: '#22c55e', // أخضر للمضخة
            valve: '#3b82f6', // أزرق للمحبس
            meter: '#f59e0b'  // برتقالي للعداد
          };
          const bgColor = typeColors[elem.type] || '#3b82f6';
          
          const elemIcon = L.divIcon({
            className: 'custom-icon',
            html: `<div style="background-color: ${bgColor}; border: 2px solid white; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; color: white; font-size: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.3);">${icon}</div>`,
            iconSize: [24, 24],
            iconAnchor: [12, 12]
          });
          
          // إنشاء محتوى Popup مفصل
          const attrs = elem.attributes || {};
          const originalId = attrs._originalId || elem.name || '-';
          
          // جمع جميع الخصائص للعرض
          const propsHtml = Object.entries(attrs)
            .filter(([k]) => !k.startsWith('_'))
            .map(([k, v]) => `<tr><td style="padding: 2px 8px; color: #666;">${k}</td><td style="padding: 2px 8px; font-weight: 500;">${v}</td></tr>`)
            .join('');
          
          const popupContent = `
            <div style="direction: ${isRTL ? 'rtl' : 'ltr'}; font-family: Arial; min-width: 200px;">
              <div style="background: ${bgColor}; color: white; padding: 8px; margin: -10px -10px 8px -10px; border-radius: 4px 4px 0 0;">
                <span style="font-size: 16px; margin-${isRTL ? 'left' : 'right'}: 6px;">${icon}</span>
                <b style="font-size: 14px;">${language === 'ar' ? typeName.ar : typeName.en}</b>
              </div>
              <table style="width: 100%; font-size: 12px; border-collapse: collapse;">
                <tr style="background: #f3f4f6;">
                  <td style="padding: 4px 8px; color: #666;">${language === 'ar' ? 'المعرف' : 'ID'}</td>
                  <td style="padding: 4px 8px; font-weight: bold;">${originalId}</td>
                </tr>
                <tr>
                  <td style="padding: 4px 8px; color: #666;">${language === 'ar' ? 'الضغط' : 'Pressure'}</td>
                  <td style="padding: 4px 8px; font-weight: bold; color: ${elem.pressure === 0 ? '#ef4444' : '#22c55e'};">${elem.pressure?.toFixed(2) || 0} bar</td>
                </tr>
                ${elem.elevation !== undefined ? `
                <tr style="background: #f3f4f6;">
                  <td style="padding: 4px 8px; color: #666;">${language === 'ar' ? 'الارتفاع' : 'Elevation'}</td>
                  <td style="padding: 4px 8px; font-weight: 500;">${elem.elevation.toFixed(1)} m</td>
                </tr>` : ''}
                ${elem.type === 'tank' && elem.capacity ? `
                <tr>
                  <td style="padding: 4px 8px; color: #666;">${language === 'ar' ? 'السعة' : 'Capacity'}</td>
                  <td style="padding: 4px 8px; font-weight: 500;">${elem.capacity} m³/h</td>
                </tr>` : ''}
                <tr style="background: #f3f4f6;">
                  <td style="padding: 4px 8px; color: #666;">${language === 'ar' ? 'الإحداثيات' : 'Coordinates'}</td>
                  <td style="padding: 4px 8px; font-size: 10px;">${elem.lat.toFixed(6)}, ${elem.lng.toFixed(6)}</td>
                </tr>
                ${propsHtml ? `
                <tr><td colspan="2" style="padding: 6px 8px; background: #e5e7eb; font-weight: bold; font-size: 11px;">${language === 'ar' ? 'خصائص إضافية' : 'Additional Properties'}</td></tr>
                ${propsHtml}` : ''}
              </table>
            </div>
          `;
          
          L.marker([elem.lat, elem.lng], { icon: elemIcon })
            .bindPopup(popupContent, { maxWidth: 300, className: 'custom-popup' })
            .addTo(mapRef.current);
          
          if (!bounds) {
            bounds = L.latLngBounds([elem.lat, elem.lng], [elem.lat, elem.lng]);
          } else {
            bounds.extend([elem.lat, elem.lng]);
          }
        } catch (e) {
          console.error(`[Map] Error at element ${idx}:`, e);
        }
      });
    }

    // إعادة تمركز الخريطة
    if (bounds) {
      try {
        mapRef.current.fitBounds(bounds, { padding: [50, 50], maxZoom: 15 });
        console.log('[Map] Fit bounds applied');
      } catch (e) {
        console.error('[Map] Error fitting bounds:', e);
      }
    }
  }, [mapReady, elements, pipeSegments, showPipes, showElements, elementPressures]);

  // دالة للحصول على لون بناءً على قيمة الضغط
  const getPressureColor = (pressure: number | undefined): string => {
    if (pressure === undefined || pressure === null || isNaN(pressure)) return '#808080'; // رمادي للقيم غير المعروفة
    if (pressure <= 0) return '#ff0000'; // أحمر - لا يوجد ضغط
    if (pressure < 1) return '#ff6600'; // برتقالي - ضغط منخفض جداً
    if (pressure < 2) return '#ffcc00'; // أصفر - ضغط منخفض
    if (pressure < 3) return '#99ff00'; // أخضر فاتح - ضغط متوسط
    if (pressure < 5) return '#00cc00'; // أخضر - ضغط جيد
    if (pressure < 10) return '#00ccff'; // سماوي - ضغط عالي
    return '#0033ff'; // أزرق - ضغط عالي جداً
  };

  const calculateDistance = calculateHaversineDistance;

  const calculateZones = () => {
    const results = new Map();
    const WATER_DENSITY = 1000;
    const GRAVITY = 9.81;
    
    zones.forEach(zone => {
      let totalFrictionLoss = 0;
      let maxElevationLoss = 0;
      let totalLength = 0;
      
      const tank = zone.elements.find(el => el.type === 'tank');
      if (!tank) return;
      
      const tankElevation = tank.elevation || 0;
      const sourcePress = tank.pressure || 5;
      
      zone.pipes.forEach((seg) => {
        const distance = calculateDistance(seg.startLat, seg.startLng, seg.endLat, seg.endLng);
        const pLength = Math.max(seg.length || distance, 1);
        totalLength += pLength;
        
        if (seg.diameter > 0 && seg.flow > 0) {
          const frictionLossMeters = calculateHazenWilliamsHeadLoss(seg.flow, seg.diameter, pLength);
          totalFrictionLoss += headLossToBar(frictionLossMeters);
        }
      });
      
      zone.elements.forEach(el => {
        if (el.type !== 'tank' && el.elevation !== undefined) {
          const elevDiff = el.elevation - tankElevation;
          if (elevDiff > 0) {
            const elevPressLoss = (WATER_DENSITY * GRAVITY * elevDiff) / 100000;
            maxElevationLoss = Math.max(maxElevationLoss, elevPressLoss);
          }
        }
      });
      
      const totalPressureLoss = totalFrictionLoss + maxElevationLoss;
      const destPress = Math.max(0, sourcePress - totalPressureLoss);
      
      results.set(zone.id, {
        zoneName: zone.tankName,
        color: zone.color,
        sourcePress,
        tankElevation,
        frictionLoss: totalFrictionLoss,
        elevationLoss: maxElevationLoss,
        totalPressureLoss,
        totalLength,
        destPress,
        elementsCount: zone.elements.length,
        pipesCount: zone.pipes.length
      });
    });
    setZoneResults(results);
    toast.success(language === 'ar' ? '✓ تم حساب المناطق' : '✓ Zones calculated');
  };

  const calculateElevation = async () => {
    const distance = calculateDistance(refLat, refLng, targetLat, targetLng);
    if (distance > 100000) {
      toast.error(language === 'ar' ? '❌ المسافة كبيرة جداً' : '❌ Distance too large');
      return;
    }
    
    toast.loading(language === 'ar' ? '⏳ جاري جلب بيانات الارتفاع...' : '⏳ Fetching elevation data...');
    
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);
      
      const response = await fetch(
        `https://api.open-elevation.com/api/v1/lookup?locations=${refLat},${refLng}|${targetLat},${targetLng}`,
        { signal: controller.signal }
      );
      clearTimeout(timeoutId);
      
      if (response.ok) {
        const data = await response.json();
        if (data.results && data.results.length === 2) {
          const refElevation = data.results[0].elevation || refElev;
          const targetElevation = data.results[1].elevation || 0;
          const elevationDiff = targetElevation - refElevation;
          const slope = distance > 0 ? (elevationDiff / distance) * 100 : 0;
          
          setElevResult({
            distance,
            refElevation,
            targetElevation,
            elevation: targetElevation,
            elevationDiff,
            slope
          });
          toast.success(language === 'ar' ? '✓ تم جلب الارتفاع من القمر الصناعي' : '✓ Elevation fetched from satellite');
          return;
        }
      }
      throw new Error('API failed');
    } catch (e) {
      console.log('[Elevation] API error, using fallback calculation');
      const elevationChange = distance * 0.01;
      const calculatedElevation = refElev + elevationChange;
      setElevResult({
        distance,
        refElevation: refElev,
        targetElevation: calculatedElevation,
        elevation: calculatedElevation,
        elevationDiff: elevationChange,
        slope: 1.0,
        isEstimate: true
      });
      toast.warning(language === 'ar' ? '⚠️ تم استخدام تقدير (API غير متاح)' : '⚠️ Using estimate (API unavailable)');
    }
  };

  const calculatePressure = () => {
    if (depth < 0 || density <= 0 || gravity <= 0) {
      toast.error(language === 'ar' ? '❌ قيم غير صحيحة' : '❌ Invalid values');
      return;
    }
    const pascals = density * gravity * depth;
    setPressureResult({ 
      pascals, 
      kpa: pascals / 1000, 
      bar: pascals / 100000, 
      atm: pascals / 101325 
    });
    toast.success(language === 'ar' ? '✓ تم حساب الضغط' : '✓ Pressure calculated');
  };

  const calculateTankLinesPressure = async () => {
    if (!selectedTankId) {
      toast.error(language === 'ar' ? '❌ اختر نقطة المصدر' : '❌ Select a source');
      return;
    }

    // البحث في الخزانات أو مخففات الضغط
    const source = elements.find(e => e.id === selectedTankId);
    if (!source) {
      toast.error(language === 'ar' ? '❌ نقطة المصدر غير موجودة' : '❌ Source not found');
      return;
    }

    const isPRV = source.type === 'valve' && (source.name.toUpperCase().includes('PRV') || source.name.toUpperCase().startsWith('PRV'));
    const sourceLabel = isPRV ? 'PRV' : (language === 'ar' ? 'الخزان' : 'Tank');

    toast.loading(language === 'ar' ? '⏳ جاري جلب الارتفاعات...' : '⏳ Fetching elevations...');

    try {
      // استخدام الارتفاع المحفوظ أو جلبه من API
      let sourceElevation = source.elevation || 0;
      
      // إذا لم يكن هناك ارتفاع محفوظ، جلبه من API
      if (!source.elevation) {
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 5000);
          const response = await fetch(`https://api.open-elevation.com/api/v1/lookup?locations=${source.lat},${source.lng}`, {
            signal: controller.signal
          });
          clearTimeout(timeoutId);
          
          if (response.ok) {
            const data = await response.json();
            if (data.results && data.results[0]) {
              sourceElevation = data.results[0].elevation || 0;
              console.log(`[Elevation] ${sourceLabel} elevation fetched: ${sourceElevation}m`);
            }
          } else {
            console.log(`[Elevation] API returned status: ${response.status}`);
          }
        } catch (e) {
          console.log(`[Elevation] Failed to fetch ${sourceLabel} elevation: ${e}`);
        }
      } else {
        console.log(`[Elevation] Using saved ${sourceLabel} elevation: ${sourceElevation}m`);
      }

      // البحث عن الأنابيب المتصلة
      const connectedZone = zones.find(z => z.tankId === selectedTankId);
      let connectedPipes = connectedZone ? connectedZone.pipes : [];
      
      // إذا لم توجد أنابيب في المنطقة، ابحث مباشرة في جميع الأنابيب
      if (connectedPipes.length === 0) {
        connectedPipes = pipeSegments.filter(pipe => {
          const tolerance = 0.01; // زيادة التسامح
          return (Math.abs(pipe.startLat - source.lat) < tolerance && Math.abs(pipe.startLng - source.lng) < tolerance) ||
                 (Math.abs(pipe.endLat - source.lat) < tolerance && Math.abs(pipe.endLng - source.lng) < tolerance);
        });
      }

      if (connectedPipes.length === 0) {
        console.warn(`[Calculate] No pipes found for ${sourceLabel} ${selectedTankId} at ${source.lat},${source.lng}`);
        toast.error(language === 'ar' ? '❌ لا توجد خطوط متصلة' : '❌ No connected pipes');
        return;
      }
      
      console.log(`[Calculate] Found ${connectedPipes.length} connected pipes for ${sourceLabel} ${selectedTankId}`);

      // حساب ضغط المصدر من الارتفاع (للخزانات و PRV)
      const sourcePressure = source.pressure || calculateElevationPressure(sourceElevation);
      const density = 1000;
      const gravity = 9.81;
      const newPressures = new Map(elementPressures);

      // حساب الضغط لكل خط ونقطة نهاية
      const calculations = await Promise.all(connectedPipes.map(async (pipe) => {
        const isStart = Math.abs(pipe.startLat - source.lat) < 0.001 && Math.abs(pipe.startLng - source.lng) < 0.001;
        const endLat = isStart ? pipe.endLat : pipe.startLat;
        const endLng = isStart ? pipe.endLng : pipe.startLng;
        
        let endElevation = 0;
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 5000);
          const response = await fetch(`https://api.open-elevation.com/api/v1/lookup?locations=${endLat},${endLng}`, {
            signal: controller.signal
          });
          clearTimeout(timeoutId);
          
          if (response.ok) {
            const data = await response.json();
            if (data.results && data.results[0]) {
              endElevation = data.results[0].elevation || 0;
            }
          }
        } catch (e) {
          console.log(`[Elevation] Failed to fetch endpoint elevation at ${endLat},${endLng}: ${e}`);
        }

        const elevationDiff = endElevation - sourceElevation;
        const elevationPressure = (density * gravity * Math.abs(elevationDiff)) / 100000;
        const finalPressure = elevationDiff >= 0 
          ? Math.max(sourcePressure - elevationPressure, 0)
          : sourcePressure + elevationPressure;
        
        // حفظ ضغط الخط والنقطة النهائية
        newPressures.set(pipe.id, finalPressure);
        
        const distance = calculateDistance(pipe.startLat, pipe.startLng, pipe.endLat, pipe.endLng);
        
        return {
          pipeId: pipe.id,
          diameter: pipe.diameter,
          flow: pipe.flow,
          distance: distance.toFixed(2),
          tankElevation: sourceElevation.toFixed(1),
          endElevation: endElevation.toFixed(1),
          elevation: elevationDiff.toFixed(1),
          elevationPressure: elevationPressure.toFixed(3),
          pressureLoss: elevationPressure.toFixed(3),
          finalPressure: finalPressure.toFixed(3)
        };
      }));

      setElementPressures(newPressures);
      setTankPressureCalcResult({
        tankName: `${isPRV ? '🔧' : '🛢️'} ${source.name}`,
        tankPressure: sourcePressure,
        pipesCount: calculations.length,
        pipes: calculations
      });

      toast.success(language === 'ar' ? `✓ تم حساب الضغوط (${calculations.length} خطوط)` : `✓ Calculated (${calculations.length} pipes)`);
    } catch (error) {
      toast.error(language === 'ar' ? '❌ خطأ في الحساب' : '❌ Calculation error');
      console.error('[Calculate] Error:', error);
    }
  };

  const calculateAutoElevation = async (lat1: number, lng1: number, lat2: number, lng2: number) => {
    try {
      const distance = calculateDistance(lat1, lng1, lat2, lng2);
      
      // محاولة الحصول على الارتفاع من Open-Elevation API
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 3000);
        const resp = await fetch(`https://api.open-elevation.com/api/v1/lookup?locations=${lat1},${lng1}|${lat2},${lng2}`, {
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (resp.ok) {
          const data = await resp.json();
          if (data.results && data.results.length === 2) {
            const elev1 = data.results[0].elevation || 0;
            const elev2 = data.results[1].elevation || 0;
            const elevationDiff = elev2 - elev1;
            const slope = distance > 0 ? (elevationDiff / distance) * 100 : 0;
            return { distance, elevation: elevationDiff, slope };
          }
        }
      } catch (e) {
        console.log('[Elevation] API error, using fallback');
      }
      
      // حساب احتياطي بناءً على الإحداثيات
      const latDiff = lat2 - lat1;
      const elevationDiff = latDiff * 111000 * (Math.random() * 0.001 + 0.0005);
      const slope = distance > 0 ? (elevationDiff / distance) * 100 : 0;
      
      return { distance, elevation: elevationDiff, slope };
    } catch (e) {
      console.error('[Elevation] Error:', e);
      const distance = calculateDistance(lat1, lng1, lat2, lng2);
      return { distance, elevation: 0, slope: 0 };
    }
  };

  const initTankMap = () => {
    const L = (window as any).L;
    if (!L || !mapTankContainerRef.current) {
      console.log('[TankMap] Cannot init:', {L: !!L, container: !!mapTankContainerRef.current});
      return;
    }

    try {
      if (mapTankRef.current) {
        mapTankRef.current.remove();
      }
      console.log('[TankMap] Creating map...');
      mapTankRef.current = L.map(mapTankContainerRef.current, { preferCanvas: true }).setView([30.0444, 31.2357], 13);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap',
        maxZoom: 19
      }).addTo(mapTankRef.current);
      console.log('[TankMap] Map created successfully, setting ready to true');
      setTankMapReady(true);
    } catch (e) {
      console.error('[TankMap] Init error:', e);
    }
  };

  const renderTankMap = () => {
    if (!selectedTankId || !tankMapReady || !mapTankRef.current) {
      console.log('[TankMap] Not ready:', {selectedTankId, tankMapReady, hasMap: !!mapTankRef.current});
      return;
    }
    
    const L = (window as any).L;
    const tank = elements.find(e => e.id === selectedTankId);
    if (!tank) {
      console.log('[TankMap] Tank not found:', selectedTankId);
      return;
    }

    console.log('[TankMap] Rendering for tank:', tank.name);

    // البحث عن جميع الأنابيب المتصلة باستخدام المنطقة
    const connectedZone = zones.find(z => z.tankId === selectedTankId);
    let connectedPipes = connectedZone ? connectedZone.pipes : [];
    
    // إذا لم توجد أنابيب في المنطقة، ابحث مباشرة
    if (connectedPipes.length === 0) {
      const tolerance = 0.01;
      connectedPipes = pipeSegments.filter(pipe => 
        (Math.abs(pipe.startLat - tank.lat) < tolerance && Math.abs(pipe.startLng - tank.lng) < tolerance) ||
        (Math.abs(pipe.endLat - tank.lat) < tolerance && Math.abs(pipe.endLng - tank.lng) < tolerance)
      );
    }

    console.log('[TankMap] Found', connectedPipes.length, 'connected pipes');

    const layersToRemove: any[] = [];
    mapTankRef.current.eachLayer((layer: any) => {
      if (layer instanceof L.Marker || layer instanceof L.Polyline) {
        layersToRemove.push(layer);
      }
    });
    layersToRemove.forEach(layer => mapTankRef.current.removeLayer(layer));

    let bounds: any = L.latLngBounds([tank.lat, tank.lng], [tank.lat, tank.lng]);

    // رسم الخزان
    const tankIcon = L.divIcon({
      html: `<div style="background-color: #3b82f6; border: 3px solid gold; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; font-size: 16px;">🛢️</div>`,
      iconSize: [30, 30],
      iconAnchor: [15, 15]
    });
    L.marker([tank.lat, tank.lng], { icon: tankIcon })
      .bindPopup(`<b>${tank.name}</b><br>Pressure: ${tank.pressure || 0} bar`)
      .addTo(mapTankRef.current);

    // رسم جميع الخطوط المتصلة
    connectedPipes.forEach(async (pipe, idx) => {
      try {
        const isStart = Math.abs(pipe.startLat - tank.lat) < 0.001 && Math.abs(pipe.startLng - tank.lng) < 0.001;
        const endLat = isStart ? pipe.endLat : pipe.startLat;
        const endLng = isStart ? pipe.endLng : pipe.startLng;

        // رسم الخط
        L.polyline([[tank.lat, tank.lng], [endLat, endLng]], {
          color: '#10b981',
          weight: 2,
          opacity: 0.7
        }).addTo(mapTankRef.current);

        // حساب الارتفاع بشكل تلقائي
        const elev = await calculateAutoElevation(tank.lat, tank.lng, endLat, endLng);

        // رسم نقطة النهاية
        const endIcon = L.divIcon({
          html: `<div style="background: #ef4444; border: 2px solid white; border-radius: 50%; width: 18px; height: 18px; display: flex; align-items: center; justify-content: center; font-size: 9px; color: white;">●</div>`,
          iconSize: [18, 18],
          iconAnchor: [9, 9]
        });
        L.marker([endLat, endLng], { icon: endIcon })
          .bindPopup(`<b>Pipe #${pipe.id}</b><br>D: ${pipe.diameter}mm<br>Dist: ${elev.distance.toFixed(0)}m<br>Elev: ${elev.elevation.toFixed(1)}m<br>Slope: ${elev.slope.toFixed(2)}%`)
          .addTo(mapTankRef.current);

        bounds.extend([endLat, endLng]);
      } catch (e) {
        console.error('[TankMap] Error drawing pipe', idx, e);
      }
    });

    try {
      mapTankRef.current.fitBounds(bounds, { padding: [50, 50], maxZoom: 14 });
    } catch (e) {
      console.log('[TankMap] Fit bounds error, using default view');
      mapTankRef.current.setView([tank.lat, tank.lng], 13);
    }
    console.log('[TankMap] Render complete');
  };

  useEffect(() => {
    console.log('[TankMap] Init effect - L exists:', !!window.L, 'container:', !!mapTankContainerRef.current);
    if (!window.L) {
      const css = document.createElement('link');
      css.rel = 'stylesheet';
      css.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(css);

      const script = document.createElement('script');
      script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      script.onload = () => {
        console.log('[TankMap] Leaflet loaded, waiting for container...');
        if (mapTankContainerRef.current) {
          initTankMap();
        }
      };
      document.head.appendChild(script);
    }
  }, []);

  useEffect(() => {
    console.log('[TankMap] Tab changed to:', tab, 'container ready:', !!mapTankContainerRef.current);
    if (tab === 'calculate' && mapTankContainerRef.current && window.L && !tankMapReady) {
      setTimeout(() => initTankMap(), 100);
    }
  }, [tab]);

  useEffect(() => {
    console.log('[TankMap] Render effect:', {selectedTankId, tankMapReady});
    if (tab === 'compare' && savedProjects.length === 0) {
      setTab('upload');
    }
    if (tab === 'calculate' && selectedTankId && tankMapReady) {
      setTimeout(() => renderTankMap(), 100);
    }
  }, [selectedTankId, tankMapReady, tab]);

  const tourSteps = [
    {
      id: 'upload',
      title: language === 'ar' ? '📂 رفع ملف KML' : '📂 Upload KML File',
      description: language === 'ar' 
        ? 'ابدأ برفع ملف KML أو KMZ يحتوي على بيانات شبكة المياه والخزانات'
        : 'Start by uploading a KML or KMZ file containing your water network and tank data'
    },
    {
      id: 'map',
      title: language === 'ar' ? '🗺️ عرض الخريطة' : '🗺️ View Map',
      description: language === 'ar'
        ? 'اعرض جميع الأنابيب والعناصر على الخريطة التفاعلية'
        : 'View all pipes and elements on the interactive map'
    },
    {
      id: 'tank-select',
      title: language === 'ar' ? '💧 اختر خزاناً' : '💧 Select Tank',
      description: language === 'ar'
        ? 'اختر خزاناً من القائمة لحساب ضغط المياه المتصل به'
        : 'Select a tank from the dropdown to calculate water pressure connected to it'
    },
    {
      id: 'calculate',
      title: language === 'ar' ? '🔄 حساب تلقائي' : '🔄 Auto Calculate',
      description: language === 'ar'
        ? 'اضغط لحساب الضغوط بناءً على الارتفاعات المسحوبة من الأقمار الصناعية'
        : 'Click to automatically calculate pressures based on satellite elevations'
    },
    {
      id: 'results',
      title: language === 'ar' ? '✓ النتائج' : '✓ Results',
      description: language === 'ar'
        ? 'شاهد نتائج حساب الضغوط لكل خط مع الارتفاعات'
        : 'View pressure calculation results for each pipe with elevations'
    },
    {
      id: 'profile',
      title: language === 'ar' ? '📈 المقطع الطولي' : '📈 Profile',
      description: language === 'ar'
        ? 'عرض المقطع الطولي للأنابيب مع الارتفاعات والضغوط'
        : 'View longitudinal profile of pipes with elevations and pressures'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900" dir={isRTL ? 'rtl' : 'ltr'}>
      <FeatureTour 
        steps={tourSteps}
        tourId="water-network-tour"
        language={language as 'ar' | 'en'}
      />
      
      <div className="sticky top-0 z-50 bg-black/40 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-white">💧📊 {language === 'ar' ? 'محلل شبكات المياه' : 'Water Network Analyzer'}</h1>
          <div className="flex gap-2">
            <div 
              title={language === 'ar' ? 'إعادة الجولة' : 'Restart tour'}
              className="cursor-pointer"
              onClick={() => {
                localStorage.removeItem('tour-water-network-tour');
                window.location.reload();
              }}
            >
              <HelpCircle 
                size={20} 
                className="text-blue-400 hover:text-blue-300 transition-colors"
              />
            </div>
            <Link href="/"><Button variant="ghost" size="sm" className="text-white hover:bg-white/10"><ArrowLeft className={`w-4 h-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />{language === 'ar' ? 'الرئيسية' : 'Home'}</Button></Link>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Tabs - مبسطة */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {[
            { id: 'upload', icon: '📂', ar: 'رفع', en: 'Upload' },
            { id: 'data', icon: '📊', ar: 'البيانات', en: 'Data' },
            { id: 'analyze', icon: '🔍', ar: 'تحليل', en: 'Analyze' },
            { id: 'hydraulics', icon: '🔬', ar: 'هيدروليك', en: 'Hydraulics' },
            { id: 'compare', icon: '⚖️', ar: 'مقارنة', en: 'Compare' },
            { id: 'map', icon: '🗺️', ar: 'الخريطة', en: 'Map' }
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id as any)}
              className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition flex items-center gap-2 ${
                tab === t.id || 
                (t.id === 'analyze' && ['analyze', 'calculate', 'results'].includes(tab)) ||
                (t.id === 'data' && ['data', 'profile'].includes(tab))
                  ? 'bg-cyan-600 text-white shadow-lg'
                  : 'bg-white/10 text-gray-300 hover:bg-white/20'
              }`}
            >
              <span className="text-xl">{t.icon}</span>
              <span>{language === 'ar' ? t.ar : t.en}</span>
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {tab === 'upload' && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20" data-tour="upload-section">
            <h2 className="text-2xl font-bold text-white mb-6">📂 {language === 'ar' ? 'رفع ملف الشبكة' : 'Upload Network File'}</h2>
            <div className="flex flex-col items-center justify-center py-12">
              {/* KML/KMZ Upload */}
              <input ref={fileInputRef} type="file" accept=".kml,.kmz" onChange={handleKMLUpload} className="hidden" />
              {/* Shapefile Upload */}
              <input ref={shapefileInputRef} type="file" accept=".zip,.shp" onChange={handleShapefileUpload} className="hidden" />
              
              <div className="flex gap-4 flex-wrap justify-center">
                <Button onClick={() => fileInputRef.current?.click()} className="bg-blue-600 hover:bg-blue-700 px-8 py-4 text-lg">
                  <Upload className={`w-5 h-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                  {language === 'ar' ? 'ملف KML / KMZ' : 'KML / KMZ File'}
                </Button>
                <Button onClick={() => shapefileInputRef.current?.click()} className="bg-green-600 hover:bg-green-700 px-8 py-4 text-lg">
                  <MapPin className={`w-5 h-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                  {language === 'ar' ? 'ملف Shapefile (ZIP)' : 'Shapefile (ZIP)'}
                </Button>
              </div>
              
              <div className="mt-6 flex items-center gap-3">
                <label className="flex items-center gap-2 text-gray-300 cursor-pointer bg-white/5 px-4 py-2 rounded-lg border border-white/20">
                  <input type="checkbox" checked={swapCoords} onChange={(e) => setSwapCoords(e.target.checked)} className="w-4 h-4" />
                  <span className="text-sm">{language === 'ar' ? '🔄 تبديل اتجاه الإحداثيات' : '🔄 Swap Coordinates'}</span>
                </label>
              </div>
              
              <div className="mt-6 bg-white/5 rounded-lg p-4 text-center max-w-lg">
                <p className="text-gray-300 text-sm mb-2">{language === 'ar' ? '📁 الملفات المدعومة:' : '📁 Supported files:'}</p>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div className="bg-blue-500/10 p-3 rounded border border-blue-500/30">
                    <p className="text-blue-300 font-semibold mb-1">KML / KMZ</p>
                    <p className="text-gray-400">{language === 'ar' ? 'ملفات Google Earth' : 'Google Earth files'}</p>
                  </div>
                  <div className="bg-green-500/10 p-3 rounded border border-green-500/30">
                    <p className="text-green-300 font-semibold mb-1">Shapefile (ZIP)</p>
                    <p className="text-gray-400">{language === 'ar' ? 'ملف ZIP يحتوي على .shp .dbf .prj' : 'ZIP containing .shp .dbf .prj'}</p>
                  </div>
                </div>
                <p className="text-gray-500 mt-3 text-xs">{language === 'ar' ? 'الحد الأقصى: 10 ميجابايت' : 'Max size: 10 MB'}</p>
              </div>
              
              {pipeSegments.length > 0 && (
                <div className="mt-6 bg-green-500/20 border border-green-500/30 rounded-lg p-4 text-center">
                  <p className="text-green-300">✓ {language === 'ar' ? 'تم تحميل' : 'Loaded'}: {pipeSegments.length} {language === 'ar' ? 'أنبوب' : 'pipes'}, {elements.length} {language === 'ar' ? 'عنصر' : 'elements'}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {tab === 'map' && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 overflow-hidden" data-tour="map-section">
            <div className="flex justify-between items-center mb-4 flex-wrap gap-4">
              <div>
                <h2 className="text-2xl font-bold text-white mb-3">🗺️ {language === 'ar' ? 'الخريطة' : 'Map'}</h2>
                {/* Legend */}
                <div className="bg-black/50 rounded-lg p-3 border border-white/20 text-xs space-y-1">
                  <p className="text-gray-400 font-semibold">{language === 'ar' ? '📊 مفتاح الضغوط' : '📊 Pressure Legend'}</p>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="flex items-center gap-2"><div className="w-4 h-0.5 bg-red-500"></div><span className="text-gray-300">0 bar</span></div>
                    <div className="flex items-center gap-2"><div className="w-4 h-0.5 bg-orange-500"></div><span className="text-gray-300">&lt; 1</span></div>
                    <div className="flex items-center gap-2"><div className="w-4 h-0.5 bg-yellow-400"></div><span className="text-gray-300">&lt; 2</span></div>
                    <div className="flex items-center gap-2"><div className="w-4 h-0.5 bg-lime-400"></div><span className="text-gray-300">&lt; 3</span></div>
                    <div className="flex items-center gap-2"><div className="w-4 h-0.5 bg-green-500"></div><span className="text-gray-300">&lt; 5</span></div>
                    <div className="flex items-center gap-2"><div className="w-4 h-0.5 bg-cyan-400"></div><span className="text-gray-300">&lt; 10</span></div>
                  </div>
                </div>
              </div>
              <div className="flex gap-4 flex-wrap">
                <label className="flex items-center gap-2 text-gray-300 cursor-pointer">
                  <input type="checkbox" checked={showElements} onChange={(e) => setShowElements(e.target.checked)} className="w-4 h-4" />
                  <span className="text-sm">{language === 'ar' ? 'العناصر' : 'Elements'}</span>
                </label>
                <label className="flex items-center gap-2 text-gray-300 cursor-pointer">
                  <input type="checkbox" checked={showPipes} onChange={(e) => setShowPipes(e.target.checked)} className="w-4 h-4" />
                  <span className="text-sm">{language === 'ar' ? 'الأنابيب' : 'Pipes'}</span>
                </label>
                <Button 
                  size="sm" 
                  className="bg-green-600 hover:bg-green-700"
                  onClick={() => {
                    console.log('[Map] Manual refresh triggered');
                    setShowPipes(!showPipes);
                    setTimeout(() => setShowPipes(!showPipes), 100);
                  }}
                >
                  {language === 'ar' ? '🔄 تحديث' : '🔄 Refresh'}
                </Button>
              </div>
            </div>
            <div ref={mapContainerRef} style={{ height: '600px' }} className="rounded-lg overflow-hidden border border-white/10 bg-gray-900" />
            <div className="mt-3 text-xs text-gray-400 space-y-1">
              <p>📊 {language === 'ar' ? 'عناصر محملة' : 'Loaded elements'}: {elements.length}</p>
              <p>🔗 {language === 'ar' ? 'أنابيب محملة' : 'Loaded pipes'}: {pipeSegments.length}</p>
            </div>
          </div>
        )}

        {tab === 'calculate' && (
          <div className="grid md:grid-cols-2 gap-8">
            {/* Tank Lines Pressure Calculation & Map */}
            <div className="space-y-8">
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                <h3 className="text-2xl font-bold text-white mb-6">💧 {language === 'ar' ? 'حساب ضغط الخطوط' : 'Line Pressure Calculation'}</h3>
                <div className="space-y-3 mb-4">
                  <label className="text-gray-300 text-sm">{language === 'ar' ? 'اختر نقطة المصدر (خزان أو PRV):' : 'Select Source (Tank or PRV):'}</label>
                  <select 
                    value={selectedTankId || ''} 
                    onChange={(e) => setSelectedTankId(e.target.value ? parseInt(e.target.value) : null)}
                    className="w-full px-3 py-2 bg-white/5 border border-white/20 rounded text-white text-sm"
                    data-tour="tank-select"
                  >
                    <option value="">{language === 'ar' ? '-- اختر نقطة المصدر --' : '-- Select Source --'}</option>
                    <optgroup label={language === 'ar' ? '🛢️ الخزانات' : '🛢️ Tanks'}>
                      {elements.filter(e => e.type === 'tank').map(tank => (
                        <option key={tank.id} value={tank.id}>
                          🛢️ {tank.name} ({tank.elevation?.toFixed(1) || 0}م)
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label={language === 'ar' ? '🔧 مخففات الضغط (PRV)' : '🔧 Pressure Reducing Valves (PRV)'}>
                      {elements.filter(e => e.type === 'valve' && (e.name.toUpperCase().includes('PRV') || e.name.toUpperCase().startsWith('PRV'))).map(prv => (
                        <option key={prv.id} value={prv.id}>
                          🔧 {prv.name} ({prv.elevation?.toFixed(1) || 0}م)
                        </option>
                      ))}
                    </optgroup>
                  </select>
                </div>

                <Button 
                  onClick={calculateTankLinesPressure} 
                  className="w-full bg-blue-600 hover:bg-blue-700 py-3"
                  data-tour="calculate-btn"
                >
                  {language === 'ar' ? '🔄 حساب تلقائي' : '🔄 Auto Calculate'}
                </Button>
              </div>

              <div ref={mapTankContainerRef} style={{ height: '400px' }} className="rounded-lg overflow-hidden border border-white/10 bg-gray-900" />

              {tankPressureCalcResult && (
                <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20" data-tour="results-section">
                  <p className="text-sm text-gray-400 mb-2">{language === 'ar' ? 'نتائج حساب الضغوط' : 'Pressure Calculation Results'}</p>
                  <p className="text-xs text-blue-300 mb-3">🛢️ {language === 'ar' ? 'ضغط الخزان' : 'Tank Pressure'}: {tankPressureCalcResult.tankPressure} bar</p>
                  <div className="space-y-2 max-h-64 overflow-y-auto mt-3">
                    {tankPressureCalcResult.pipes.map((pipe: any, idx: number) => (
                      <div key={idx} className="bg-white/5 p-3 rounded border border-white/10 text-xs">
                        <p className="text-white font-semibold">#{idx+1} (Pipe {pipe.pipeId})</p>
                        <p className="text-gray-400">🔹 Q: {pipe.flow} L/s | Distance: {pipe.distance}m</p>
                        <p className="text-blue-300">📍 {language === 'ar' ? 'ارتفاع الخزان' : 'Tank Elev'}: {pipe.tankElevation}m</p>
                        <p className="text-blue-300">📍 {language === 'ar' ? 'ارتفاع النقطة' : 'End Elev'}: {pipe.endElevation}m</p>
                        <p className="text-yellow-300">📈 {language === 'ar' ? 'فرق الارتفاع' : 'Elevation Diff'}: {pipe.elevation}m</p>
                        <p className="text-orange-400">⬆️ {language === 'ar' ? 'تأثير الارتفاع' : 'Elevation Effect'}: {pipe.elevationPressure} bar</p>
                        <p className="text-green-300 font-bold">✓ {language === 'ar' ? 'الضغط النهائي' : 'Final Pressure'}: {pipe.finalPressure} bar</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Zone Calculations */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
              <h3 className="text-2xl font-bold text-white mb-6">🔧 {language === 'ar' ? 'حساب ضغط الشبكة' : 'Network Pressure'}</h3>
              <Button onClick={calculateZones} className="w-full bg-cyan-600 hover:bg-cyan-700 py-3 mb-4">
                <Zap className={`w-4 h-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                {language === 'ar' ? 'حساب المناطق' : 'Calculate Zones'}
              </Button>
              <div className="space-y-3">
                {Array.from(zoneResults.entries()).map(([id, result]) => (
                  <div key={id} className="bg-white/5 rounded-lg p-4 border border-white/10">
                    <p className="text-cyan-300 font-bold">{result.zoneName}</p>
                    <p className="text-sm text-gray-300">الضغط الأولي: {result.sourcePress.toFixed(2)} bar</p>
                    <p className="text-sm text-gray-300">الخسارة: {result.totalPressureLoss.toFixed(2)} bar</p>
                    <p className="text-lg font-bold text-green-300">النتيجة: {result.destPress.toFixed(2)} bar</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Elevation & Pressure */}
            <div className="space-y-8">
              {/* Elevation */}
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                <h3 className="text-xl font-bold text-white mb-4">📈 {language === 'ar' ? 'الارتفاع' : 'Elevation'}</h3>
                <div className="space-y-3 text-sm mb-4">
                  <input type="number" value={refLat} onChange={(e) => setRefLat(parseFloat(e.target.value))} placeholder="Ref Lat" className="w-full px-3 py-2 bg-white/5 border border-white/20 rounded text-white" />
                  <input type="number" value={refLng} onChange={(e) => setRefLng(parseFloat(e.target.value))} placeholder="Ref Lng" className="w-full px-3 py-2 bg-white/5 border border-white/20 rounded text-white" />
                  <input type="number" value={targetLat} onChange={(e) => setTargetLat(parseFloat(e.target.value))} placeholder="Target Lat" className="w-full px-3 py-2 bg-white/5 border border-white/20 rounded text-white" />
                  <input type="number" value={targetLng} onChange={(e) => setTargetLng(parseFloat(e.target.value))} placeholder="Target Lng" className="w-full px-3 py-2 bg-white/5 border border-white/20 rounded text-white" />
                </div>
                <Button onClick={calculateElevation} className="w-full bg-blue-600 hover:bg-blue-700">
                  {language === 'ar' ? 'حساب الارتفاع' : 'Calculate'}
                </Button>
              </div>

              {/* Water Pressure */}
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                <h3 className="text-xl font-bold text-white mb-4">💧 {language === 'ar' ? 'ضغط المياه' : 'Water Pressure'}</h3>
                <div className="space-y-3 text-sm mb-4">
                  <input type="number" value={depth} onChange={(e) => setDepth(parseFloat(e.target.value))} placeholder="Depth (m)" className="w-full px-3 py-2 bg-white/5 border border-white/20 rounded text-white" />
                  <input type="number" value={density} onChange={(e) => setDensity(parseFloat(e.target.value))} placeholder="Density (kg/m³)" className="w-full px-3 py-2 bg-white/5 border border-white/20 rounded text-white" />
                  <input type="number" value={gravity} onChange={(e) => setGravity(parseFloat(e.target.value))} placeholder="Gravity (m/s²)" className="w-full px-3 py-2 bg-white/5 border border-white/20 rounded text-white" />
                </div>
                <Button onClick={calculatePressure} className="w-full bg-green-600 hover:bg-green-700">
                  {language === 'ar' ? 'حساب الضغط' : 'Calculate'}
                </Button>
              </div>
            </div>
          </div>
        )}

        {tab === 'analyze' && (
          <div className="space-y-6">
            {/* Tank Selection for Analysis */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-6">🛢️ {language === 'ar' ? 'تحليل حسب الخزان' : 'Analysis by Tank'}</h2>
              
              {elements.filter(e => e.type === 'tank').length === 0 ? (
                <p className="text-gray-400">{language === 'ar' ? 'لا توجد خزانات - يرجى رفع ملف KML أولاً' : 'No tanks found - Please upload a KML file first'}</p>
              ) : (
                <div className="space-y-4">
                  {/* Tank Cards Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {elements.filter(e => e.type === 'tank').map((tank) => {
                      const connectedZone = zones.find(z => z.tankId === tank.id);
                      const tankPressure = tank.elevation ? calculateElevationPressure(tank.elevation) : 0;
                      
                      return (
                        <div 
                          key={tank.id} 
                          className={`p-4 rounded-xl border-2 cursor-pointer transition-all hover:scale-105 ${
                            selectedTankId === tank.id 
                              ? 'bg-blue-600/30 border-blue-400' 
                              : 'bg-white/5 border-white/20 hover:border-blue-400/50'
                          }`}
                          onClick={() => {
                            setSelectedTankId(tank.id);
                            toast.success(language === 'ar' ? `تم اختيار: ${tank.name}` : `Selected: ${tank.name}`);
                          }}
                          data-testid={`tank-card-${tank.id}`}
                        >
                          <div className="flex items-center justify-between mb-3">
                            <h4 className="text-lg font-bold text-white truncate">{tank.name}</h4>
                            <span className="text-2xl">🛢️</span>
                          </div>
                          
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-400">{language === 'ar' ? 'الارتفاع' : 'Elevation'}:</span>
                              <span className="text-cyan-300 font-bold">{tank.elevation?.toFixed(1) || '-'} م</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">{language === 'ar' ? 'السعة' : 'Capacity'}:</span>
                              <span className="text-blue-300 font-bold">{tank.capacity?.toFixed(0) || '-'} م³</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">{language === 'ar' ? 'الضغط' : 'Pressure'}:</span>
                              <span className="text-green-300 font-bold">{tankPressure.toFixed(2)} bar</span>
                            </div>
                            {connectedZone && (
                              <>
                                <div className="border-t border-white/20 pt-2 mt-2">
                                  <div className="flex justify-between">
                                    <span className="text-gray-400">{language === 'ar' ? 'الأنابيب المتصلة' : 'Connected Pipes'}:</span>
                                    <span className="text-orange-300 font-bold">{connectedZone.pipes.length}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-gray-400">{language === 'ar' ? 'إجمالي الطول' : 'Total Length'}:</span>
                                    <span className="text-purple-300 font-bold">
                                      {(connectedZone.pipes.reduce((sum, p) => sum + (p.length || calculateHaversineDistance(p.startLat, p.startLng, p.endLat, p.endLng)), 0) / 1000).toFixed(2)} كم
                                    </span>
                                  </div>
                                </div>
                              </>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Selected Tank Details */}
                  {selectedTankId && (() => {
                    const selectedTank = elements.find(e => e.id === selectedTankId && e.type === 'tank');
                    const connectedZone = zones.find(z => z.tankId === selectedTankId);
                    
                    if (!selectedTank) return null;
                    
                    const tankPressure = selectedTank.elevation ? calculateElevationPressure(selectedTank.elevation) : 0;
                    const connectedPipes = connectedZone?.pipes || [];
                    const totalLength = connectedPipes.reduce((sum, p) => sum + (p.length || calculateHaversineDistance(p.startLat, p.startLng, p.endLat, p.endLng)), 0);
                    const avgDiameter = connectedPipes.length > 0 ? connectedPipes.reduce((sum, p) => sum + p.diameter, 0) / connectedPipes.length : 0;
                    const diameterDistribution: Record<number, number> = {};
                    connectedPipes.forEach(p => {
                      diameterDistribution[p.diameter] = (diameterDistribution[p.diameter] || 0) + 1;
                    });
                    
                    return (
                      <div className="bg-gradient-to-br from-blue-900/50 to-cyan-900/50 rounded-2xl p-6 border border-blue-400/30 mt-6">
                        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                          🔍 {language === 'ar' ? 'تحليل مفصل:' : 'Detailed Analysis:'} {selectedTank.name}
                        </h3>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                          <div className="bg-white/10 p-4 rounded-xl text-center">
                            <p className="text-3xl font-bold text-cyan-300">{selectedTank.elevation?.toFixed(1) || '0'}</p>
                            <p className="text-xs text-gray-400">{language === 'ar' ? 'الارتفاع (م)' : 'Elevation (m)'}</p>
                          </div>
                          <div className="bg-white/10 p-4 rounded-xl text-center">
                            <p className="text-3xl font-bold text-green-300">{tankPressure.toFixed(2)}</p>
                            <p className="text-xs text-gray-400">{language === 'ar' ? 'الضغط (بار)' : 'Pressure (bar)'}</p>
                          </div>
                          <div className="bg-white/10 p-4 rounded-xl text-center">
                            <p className="text-3xl font-bold text-orange-300">{connectedPipes.length}</p>
                            <p className="text-xs text-gray-400">{language === 'ar' ? 'عدد الأنابيب' : 'Pipes Count'}</p>
                          </div>
                          <div className="bg-white/10 p-4 rounded-xl text-center">
                            <p className="text-3xl font-bold text-purple-300">{(totalLength / 1000).toFixed(2)}</p>
                            <p className="text-xs text-gray-400">{language === 'ar' ? 'الطول (كم)' : 'Length (km)'}</p>
                          </div>
                        </div>

                        {/* Diameter Distribution */}
                        {Object.keys(diameterDistribution).length > 0 && (
                          <div className="mb-4">
                            <h4 className="text-sm font-semibold text-gray-300 mb-2">{language === 'ar' ? 'توزيع الأقطار:' : 'Diameter Distribution:'}</h4>
                            <div className="flex flex-wrap gap-2">
                              {Object.entries(diameterDistribution).sort((a, b) => parseInt(a[0]) - parseInt(b[0])).map(([diameter, count]) => (
                                <span key={diameter} className="px-3 py-1 bg-yellow-600/30 rounded-full text-yellow-300 text-sm">
                                  {diameter}mm: {count} {language === 'ar' ? 'أنبوب' : 'pipes'}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Connected Pipes Table */}
                        {connectedPipes.length > 0 && (
                          <div className="mt-4">
                            <h4 className="text-sm font-semibold text-gray-300 mb-2">{language === 'ar' ? 'الأنابيب المتصلة:' : 'Connected Pipes:'}</h4>
                            <div className="overflow-x-auto max-h-48">
                              <table className="w-full text-xs border-collapse">
                                <thead className="sticky top-0 bg-black/80">
                                  <tr>
                                    <th className="border border-white/20 p-2">ID</th>
                                    <th className="border border-white/20 p-2">{language === 'ar' ? 'القطر' : 'Diameter'}</th>
                                    <th className="border border-white/20 p-2">{language === 'ar' ? 'الطول' : 'Length'}</th>
                                    <th className="border border-white/20 p-2">{language === 'ar' ? 'التدفق' : 'Flow'}</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {connectedPipes.slice(0, 50).map((pipe, idx) => (
                                    <tr key={idx} className="hover:bg-white/10">
                                      <td className="border border-white/20 p-2 text-center">{pipe.id}</td>
                                      <td className="border border-white/20 p-2 text-center text-yellow-300">{pipe.diameter}mm</td>
                                      <td className="border border-white/20 p-2 text-center text-green-300">
                                        {(pipe.length || calculateHaversineDistance(pipe.startLat, pipe.startLng, pipe.endLat, pipe.endLng)).toFixed(1)}m
                                      </td>
                                      <td className="border border-white/20 p-2 text-center text-purple-300">{pipe.flow}L/s</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                              {connectedPipes.length > 50 && (
                                <p className="text-center text-gray-400 mt-2 text-xs">
                                  {language === 'ar' ? `... و ${connectedPipes.length - 50} أنبوب آخر` : `... and ${connectedPipes.length - 50} more pipes`}
                                </p>
                              )}
                            </div>
                          </div>
                        )}

                        <Button 
                          onClick={() => {
                            calculateTankLinesPressure();
                            setTab('calculate');
                          }}
                          className="w-full mt-4 bg-blue-600 hover:bg-blue-700"
                          data-testid="button-analyze-tank"
                        >
                          ⚡ {language === 'ar' ? 'حساب الضغوط لهذا الخزان' : 'Calculate Pressures for This Tank'}
                        </Button>
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>

            {/* General Data Analysis */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-6">🔍 {language === 'ar' ? 'تحليل عام للبيانات' : 'General Data Analysis'}</h2>
              {pipeSegments.length === 0 ? (
                <p className="text-gray-400">{language === 'ar' ? 'يرجى رفع ملف KML أولاً' : 'Please upload a KML file first'}</p>
              ) : (
                <div className="space-y-6">
                  {/* Summary Stats */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div className="bg-blue-500/20 p-4 rounded-xl text-center">
                      <p className="text-3xl font-bold text-blue-300">{pipeSegments.length}</p>
                      <p className="text-xs text-gray-400">{language === 'ar' ? 'إجمالي الأنابيب' : 'Total Pipes'}</p>
                    </div>
                    <div className="bg-green-500/20 p-4 rounded-xl text-center">
                      <p className="text-3xl font-bold text-green-300">{elements.length}</p>
                      <p className="text-xs text-gray-400">{language === 'ar' ? 'إجمالي العناصر' : 'Total Elements'}</p>
                    </div>
                    <div className="bg-purple-500/20 p-4 rounded-xl text-center">
                      <p className="text-3xl font-bold text-purple-300">{zones.length}</p>
                      <p className="text-xs text-gray-400">{language === 'ar' ? 'المناطق' : 'Zones'}</p>
                    </div>
                    <div className="bg-cyan-500/20 p-4 rounded-xl text-center">
                      <p className="text-3xl font-bold text-cyan-300">
                        {(pipeSegments.reduce((sum, p) => sum + (p.length || calculateHaversineDistance(p.startLat, p.startLng, p.endLat, p.endLng)), 0) / 1000).toFixed(1)}
                      </p>
                      <p className="text-xs text-gray-400">{language === 'ar' ? 'إجمالي الطول (كم)' : 'Total Length (km)'}</p>
                    </div>
                  </div>

                  {/* Diameter Values */}
                  <div>
                    <h3 className="text-lg font-semibold text-green-300 mb-3">📏 {language === 'ar' ? 'جميع قيم الأقطار' : 'All Diameter Values'}</h3>
                    <div className="bg-black/50 rounded-lg p-4 max-h-48 overflow-y-auto">
                      <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
                        {Array.from(new Set(pipeSegments.map(p => p.diameter))).sort((a, b) => a - b).map((d, i) => {
                          const count = pipeSegments.filter(p => p.diameter === d).length;
                          return (
                            <div key={i} className="text-sm text-gray-300 bg-white/5 p-2 rounded text-center">
                              <span className="text-orange-400 font-bold block">{d} mm</span>
                              <span className="text-xs text-gray-500">({count})</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Flow Values */}
                  <div>
                    <h3 className="text-lg font-semibold text-purple-300 mb-3">💧 {language === 'ar' ? 'جميع قيم التدفق' : 'All Flow Values'}</h3>
                    <div className="bg-black/50 rounded-lg p-4 max-h-48 overflow-y-auto">
                      <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
                        {Array.from(new Set(pipeSegments.map(p => p.flow))).sort((a, b) => a - b).map((f, i) => {
                          const count = pipeSegments.filter(p => p.flow === f).length;
                          return (
                            <div key={i} className="text-sm text-gray-300 bg-white/5 p-2 rounded text-center">
                              <span className="text-purple-400 font-bold block">{f} L/s</span>
                              <span className="text-xs text-gray-500">({count})</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {tab === 'data' && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
            <h2 className="text-2xl font-bold text-white mb-6">📊 {language === 'ar' ? 'البيانات المستخرجة' : 'Extracted Data'}</h2>
            
            {/* ملخص التصنيفات */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
              <div className="bg-blue-500/20 p-3 rounded-lg border border-blue-400/30 text-center">
                <p className="text-2xl font-bold text-blue-300">🛢️ {elements.filter(e => e.type === 'tank').length}</p>
                <p className="text-xs text-gray-400">{language === 'ar' ? 'خزانات' : 'Tanks'}</p>
              </div>
              <div className="bg-green-500/20 p-3 rounded-lg border border-green-400/30 text-center">
                <p className="text-2xl font-bold text-green-300">🚰 {elements.filter(e => e.type === 'valve').length}</p>
                <p className="text-xs text-gray-400">{language === 'ar' ? 'صمامات' : 'Valves'}</p>
              </div>
              <div className="bg-orange-500/20 p-3 rounded-lg border border-orange-400/30 text-center">
                <p className="text-2xl font-bold text-orange-300">📊 {elements.filter(e => e.type === 'meter').length}</p>
                <p className="text-xs text-gray-400">{language === 'ar' ? 'عدادات' : 'Meters'}</p>
              </div>
              <div className="bg-purple-500/20 p-3 rounded-lg border border-purple-400/30 text-center">
                <p className="text-2xl font-bold text-purple-300">⚡ {elements.filter(e => e.type === 'pump').length}</p>
                <p className="text-xs text-gray-400">{language === 'ar' ? 'مضخات' : 'Pumps'}</p>
              </div>
              <div className="bg-cyan-500/20 p-3 rounded-lg border border-cyan-400/30 text-center">
                <p className="text-2xl font-bold text-cyan-300">🔗 {pipeSegments.length}</p>
                <p className="text-xs text-gray-400">{language === 'ar' ? 'أنابيب' : 'Pipes'}</p>
              </div>
            </div>

            {/* الخطوط */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                <h3 className="text-lg font-semibold text-blue-300">🔗 {language === 'ar' ? 'الخطوط' : 'Pipes'} ({pipeSegments.length}) - {language === 'ar' ? 'إجمالي الطول' : 'Total Length'}: {(pipeSegments.reduce((sum, p) => sum + (p.length || calculateHaversineDistance(p.startLat, p.startLng, p.endLat, p.endLng)), 0) / 1000).toFixed(2)} كم</h3>
                <Button 
                  onClick={convertDiametersToMm}
                  className="bg-yellow-600 hover:bg-yellow-700 text-xs"
                  disabled={pipeSegments.length === 0 || diameterUnit === 'mm'}
                  data-testid="button-convert-diameter"
                >
                  📏 {language === 'ar' ? 'تحويل الأقطار من بوصة إلى مم' : 'Convert Diameters: Inch → mm'}
                </Button>
              </div>
              <div className="overflow-x-auto max-h-96">
                <table className="w-full text-xs border-collapse">
                  <thead className="sticky top-0 bg-black/80">
                    <tr>
                      <th className="border border-white/20 p-2 text-right">#</th>
                      <th className="border border-white/20 p-2 text-right">{language === 'ar' ? 'ID الأصلي' : 'Original ID'}</th>
                      <th className="border border-white/20 p-2 text-right">{language === 'ar' ? 'الاسم' : 'Name'}</th>
                      <th className="border border-white/20 p-2 text-right">{language === 'ar' ? 'القطر (مم)' : 'Diameter (mm)'}</th>
                      <th className="border border-white/20 p-2 text-right">{language === 'ar' ? 'الطول (م)' : 'Length (m)'}</th>
                      <th className="border border-white/20 p-2 text-right">{language === 'ar' ? 'التدفق (ل/ث)' : 'Flow (L/s)'}</th>
                      <th className="border border-white/20 p-2 text-right">{language === 'ar' ? 'المادة' : 'Material'}</th>
                      <th className="border border-white/20 p-2 text-right">{language === 'ar' ? 'خصائص إضافية' : 'Properties'}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pipeSegments.slice(0, 200).map((p, idx) => {
                      const length = p.length || calculateHaversineDistance(p.startLat, p.startLng, p.endLat, p.endLng);
                      const originalId = p.attributes?._originalId || '-';
                      const name = p.attributes?._name || '-';
                      const allProps = Object.entries(p.attributes || {})
                        .filter(([k]) => !k.startsWith('_'))
                        .slice(0, 5)
                        .map(([k, v]) => `${k}:${v}`)
                        .join(', ');
                      return (
                        <tr key={idx} className="hover:bg-white/10">
                          <td className="border border-white/20 p-2 text-center text-gray-500">{p.id}</td>
                          <td className="border border-white/20 p-2 text-center text-cyan-300 font-bold">{originalId}</td>
                          <td className="border border-white/20 p-2 text-white">{name}</td>
                          <td className="border border-white/20 p-2 text-center text-yellow-300 font-bold">{p.diameter}</td>
                          <td className="border border-white/20 p-2 text-center text-green-300">{length.toFixed(1)}</td>
                          <td className="border border-white/20 p-2 text-center text-purple-300">{p.flow || '-'}</td>
                          <td className="border border-white/20 p-2 text-center text-orange-300">{p.material || '-'}</td>
                          <td className="border border-white/20 p-2 text-gray-400 text-xs max-w-xs truncate" title={allProps}>{allProps || '-'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                {pipeSegments.length > 200 && (
                  <p className="text-center text-gray-400 mt-2 text-sm">
                    {language === 'ar' ? `... و ${pipeSegments.length - 200} خط آخر` : `... and ${pipeSegments.length - 200} more pipes`}
                  </p>
                )}
              </div>
            </div>

            {/* العناصر مصنفة حسب النوع */}
            <div className="space-y-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-semibold text-green-300">📍 {language === 'ar' ? 'العناصر حسب التصنيف' : 'Elements by Type'} ({elements.length})</h3>
                <Button 
                  onClick={fetchMissingElevations}
                  className="bg-cyan-600 hover:bg-cyan-700 text-xs"
                  disabled={elements.length === 0}
                  data-testid="button-fetch-elevations"
                >
                  🛰️ {language === 'ar' ? 'جلب الارتفاعات' : 'Fetch Elevations'}
                </Button>
              </div>
              
              {/* الخزانات */}
              {elements.filter(e => e.type === 'tank').length > 0 && (
                <div className="bg-blue-500/10 rounded-lg p-4 border border-blue-400/30">
                  <h4 className="text-md font-bold text-blue-300 mb-3">🛢️ {language === 'ar' ? 'الخزانات' : 'Tanks'} ({elements.filter(e => e.type === 'tank').length})</h4>
                  <div className="overflow-x-auto max-h-64">
                    <table className="w-full text-xs border-collapse">
                      <thead className="sticky top-0 bg-black/80">
                        <tr>
                          <th className="border border-white/20 p-2">#</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'ID الأصلي' : 'Original ID'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'الاسم' : 'Name'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'الارتفاع (م)' : 'Elevation (m)'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'السعة (م³)' : 'Capacity (m³)'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'الضغط (بار)' : 'Pressure (bar)'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'خصائص' : 'Properties'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {elements.filter(e => e.type === 'tank').map((e, idx) => {
                          const originalId = e.attributes?._originalId || '-';
                          const allProps = Object.entries(e.attributes || {})
                            .filter(([k]) => !k.startsWith('_'))
                            .slice(0, 4)
                            .map(([k, v]) => `${k}:${v}`)
                            .join(', ');
                          return (
                            <tr key={idx} className="hover:bg-white/10">
                              <td className="border border-white/20 p-2 text-center text-gray-500">{e.id}</td>
                              <td className="border border-white/20 p-2 text-center text-cyan-300 font-bold">{originalId}</td>
                              <td className="border border-white/20 p-2 text-white font-semibold">{e.name}</td>
                              <td className="border border-white/20 p-2 text-center text-cyan-300">{e.elevation?.toFixed(1) || '-'}</td>
                              <td className="border border-white/20 p-2 text-center text-blue-300 font-bold">{e.capacity?.toFixed(0) || '-'}</td>
                              <td className="border border-white/20 p-2 text-center text-green-300">{e.pressure?.toFixed(2) || '-'}</td>
                              <td className="border border-white/20 p-2 text-gray-400 text-xs max-w-xs truncate" title={allProps}>{allProps || '-'}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* الصمامات */}
              {elements.filter(e => e.type === 'valve').length > 0 && (
                <div className="bg-green-500/10 rounded-lg p-4 border border-green-400/30">
                  <h4 className="text-md font-bold text-green-300 mb-3">🚰 {language === 'ar' ? 'الصمامات' : 'Valves'} ({elements.filter(e => e.type === 'valve').length})</h4>
                  <div className="overflow-x-auto max-h-64">
                    <table className="w-full text-xs border-collapse">
                      <thead className="sticky top-0 bg-black/80">
                        <tr>
                          <th className="border border-white/20 p-2">#</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'ID الأصلي' : 'Original ID'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'الاسم' : 'Name'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'الارتفاع (م)' : 'Elevation (m)'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'الضغط (بار)' : 'Pressure (bar)'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'خصائص' : 'Properties'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {elements.filter(e => e.type === 'valve').slice(0, 100).map((e, idx) => {
                          const originalId = e.attributes?._originalId || '-';
                          const allProps = Object.entries(e.attributes || {})
                            .filter(([k]) => !k.startsWith('_'))
                            .slice(0, 4)
                            .map(([k, v]) => `${k}:${v}`)
                            .join(', ');
                          return (
                            <tr key={idx} className="hover:bg-white/10">
                              <td className="border border-white/20 p-2 text-center text-gray-500">{e.id}</td>
                              <td className="border border-white/20 p-2 text-center text-cyan-300 font-bold">{originalId}</td>
                              <td className="border border-white/20 p-2 text-white">{e.name}</td>
                              <td className="border border-white/20 p-2 text-center text-cyan-300">{e.elevation?.toFixed(1) || '-'}</td>
                              <td className="border border-white/20 p-2 text-center text-green-300">{e.pressure?.toFixed(2) || '-'}</td>
                              <td className="border border-white/20 p-2 text-gray-400 text-xs max-w-xs truncate" title={allProps}>{allProps || '-'}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* العدادات */}
              {elements.filter(e => e.type === 'meter').length > 0 && (
                <div className="bg-orange-500/10 rounded-lg p-4 border border-orange-400/30">
                  <h4 className="text-md font-bold text-orange-300 mb-3">📊 {language === 'ar' ? 'العدادات' : 'Meters'} ({elements.filter(e => e.type === 'meter').length})</h4>
                  <div className="overflow-x-auto max-h-64">
                    <table className="w-full text-xs border-collapse">
                      <thead className="sticky top-0 bg-black/80">
                        <tr>
                          <th className="border border-white/20 p-2">#</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'ID الأصلي' : 'Original ID'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'الاسم' : 'Name'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'الارتفاع (م)' : 'Elevation (m)'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'الضغط (بار)' : 'Pressure (bar)'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'خصائص' : 'Properties'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {elements.filter(e => e.type === 'meter').slice(0, 100).map((e, idx) => {
                          const originalId = e.attributes?._originalId || '-';
                          const allProps = Object.entries(e.attributes || {})
                            .filter(([k]) => !k.startsWith('_'))
                            .slice(0, 4)
                            .map(([k, v]) => `${k}:${v}`)
                            .join(', ');
                          return (
                            <tr key={idx} className="hover:bg-white/10">
                              <td className="border border-white/20 p-2 text-center text-gray-500">{e.id}</td>
                              <td className="border border-white/20 p-2 text-center text-cyan-300 font-bold">{originalId}</td>
                              <td className="border border-white/20 p-2 text-white">{e.name}</td>
                              <td className="border border-white/20 p-2 text-center text-cyan-300">{e.elevation?.toFixed(1) || '-'}</td>
                              <td className="border border-white/20 p-2 text-center text-orange-300">{e.pressure?.toFixed(2) || '-'}</td>
                              <td className="border border-white/20 p-2 text-gray-400 text-xs max-w-xs truncate" title={allProps}>{allProps || '-'}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* المضخات */}
              {elements.filter(e => e.type === 'pump').length > 0 && (
                <div className="bg-purple-500/10 rounded-lg p-4 border border-purple-400/30">
                  <h4 className="text-md font-bold text-purple-300 mb-3">⚡ {language === 'ar' ? 'المضخات' : 'Pumps'} ({elements.filter(e => e.type === 'pump').length})</h4>
                  <div className="overflow-x-auto max-h-64">
                    <table className="w-full text-xs border-collapse">
                      <thead className="sticky top-0 bg-black/80">
                        <tr>
                          <th className="border border-white/20 p-2">#</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'ID الأصلي' : 'Original ID'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'الاسم' : 'Name'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'الارتفاع (م)' : 'Elevation (m)'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'السعة' : 'Capacity'}</th>
                          <th className="border border-white/20 p-2">{language === 'ar' ? 'خصائص' : 'Properties'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {elements.filter(e => e.type === 'pump').map((e, idx) => {
                          const originalId = e.attributes?._originalId || '-';
                          const allProps = Object.entries(e.attributes || {})
                            .filter(([k]) => !k.startsWith('_'))
                            .slice(0, 4)
                            .map(([k, v]) => `${k}:${v}`)
                            .join(', ');
                          return (
                            <tr key={idx} className="hover:bg-white/10">
                              <td className="border border-white/20 p-2 text-center text-gray-500">{e.id}</td>
                              <td className="border border-white/20 p-2 text-center text-cyan-300 font-bold">{originalId}</td>
                              <td className="border border-white/20 p-2 text-white">{e.name}</td>
                              <td className="border border-white/20 p-2 text-center text-cyan-300">{e.elevation?.toFixed(1) || '-'}</td>
                              <td className="border border-white/20 p-2 text-center text-purple-300">{e.capacity?.toFixed(0) || '-'}</td>
                              <td className="border border-white/20 p-2 text-gray-400 text-xs max-w-xs truncate" title={allProps}>{allProps || '-'}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {tab === 'results' && (
          <div className="space-y-8">
            {/* Elements Search and Display */}
            {elements.length > 0 && (
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                <h3 className="text-2xl font-bold text-white mb-6">🔍 {language === 'ar' ? 'العناصر والبحث' : 'Elements & Search'}</h3>
                
                {/* Search Bar */}
                <div className="mb-6">
                  <input 
                    type="text" 
                    placeholder={language === 'ar' ? 'ابحث عن عنصر...' : 'Search elements...'} 
                    value={searchQuery} 
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full px-4 py-2 bg-white/5 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                {/* Elements organized by type */}
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Tanks */}
                  {(() => {
                    const tanks = elements.filter(el => el.type === 'tank' && (searchQuery === '' || el.name.toLowerCase().includes(searchQuery.toLowerCase())));
                    return tanks.length > 0 ? (
                      <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-lg p-6 border border-blue-400/30">
                        <h4 className="text-xl font-bold text-blue-300 mb-4">🛢️ {language === 'ar' ? 'الخزانات' : 'Tanks'} ({tanks.length})</h4>
                        <div className="space-y-2 max-h-64 overflow-y-auto">
                          {tanks.map((el) => (
                            <div key={el.id} className="bg-white/5 p-3 rounded border border-white/10">
                              <p className="text-white font-semibold text-sm">{el.name}</p>
                              <p className="text-xs text-gray-400">📍 {el.lat.toFixed(4)}, {el.lng.toFixed(4)}</p>
                              {el.pressure && <p className="text-xs text-cyan-300">💧 {el.pressure} bar</p>}
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : null;
                  })()}

                  {/* Valves (including pressure reducing valves) */}
                  {(() => {
                    const valves = elements.filter(el => el.type === 'valve' && (searchQuery === '' || el.name.toLowerCase().includes(searchQuery.toLowerCase())));
                    return valves.length > 0 ? (
                      <div className="bg-gradient-to-br from-green-500/10 to-cyan-500/10 rounded-lg p-6 border border-green-400/30">
                        <h4 className="text-xl font-bold text-green-300 mb-4">🚰 {language === 'ar' ? 'الصمامات / مخففات الضغط' : 'Valves / PRVs'} ({valves.length})</h4>
                        <div className="space-y-2 max-h-64 overflow-y-auto">
                          {valves.map((el) => (
                            <div key={el.id} className="bg-white/5 p-3 rounded border border-white/10">
                              <p className="text-white font-semibold text-sm">{el.name}</p>
                              <p className="text-xs text-gray-400">📍 {el.lat.toFixed(4)}, {el.lng.toFixed(4)}</p>
                              {el.pressure && <p className="text-xs text-green-300">💧 {el.pressure} bar</p>}
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : null;
                  })()}

                  {/* Meters */}
                  {(() => {
                    const meters = elements.filter(el => el.type === 'meter' && (searchQuery === '' || el.name.toLowerCase().includes(searchQuery.toLowerCase())));
                    return meters.length > 0 ? (
                      <div className="bg-gradient-to-br from-orange-500/10 to-yellow-500/10 rounded-lg p-6 border border-orange-400/30">
                        <h4 className="text-xl font-bold text-orange-300 mb-4">📊 {language === 'ar' ? 'العدادات' : 'Meters'} ({meters.length})</h4>
                        <div className="space-y-2 max-h-64 overflow-y-auto">
                          {meters.map((el) => (
                            <div key={el.id} className="bg-white/5 p-3 rounded border border-white/10">
                              <p className="text-white font-semibold text-sm">{el.name}</p>
                              <p className="text-xs text-gray-400">📍 {el.lat.toFixed(4)}, {el.lng.toFixed(4)}</p>
                              {el.pressure && <p className="text-xs text-orange-300">💧 {el.pressure} bar</p>}
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : null;
                  })()}

                  {/* Pumps */}
                  {(() => {
                    const pumps = elements.filter(el => el.type === 'pump' && (searchQuery === '' || el.name.toLowerCase().includes(searchQuery.toLowerCase())));
                    return pumps.length > 0 ? (
                      <div className="bg-gradient-to-br from-red-500/10 to-pink-500/10 rounded-lg p-6 border border-red-400/30">
                        <h4 className="text-xl font-bold text-red-300 mb-4">⚙️ {language === 'ar' ? 'المضخات' : 'Pumps'} ({pumps.length})</h4>
                        <div className="space-y-2 max-h-64 overflow-y-auto">
                          {pumps.map((el) => (
                            <div key={el.id} className="bg-white/5 p-3 rounded border border-white/10">
                              <p className="text-white font-semibold text-sm">{el.name}</p>
                              <p className="text-xs text-gray-400">📍 {el.lat.toFixed(4)}, {el.lng.toFixed(4)}</p>
                              {el.pressure && <p className="text-xs text-red-300">💧 {el.pressure} bar</p>}
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : null;
                  })()}
                </div>
              </div>
            )}

            {/* Zone Results */}
            {zoneResults.size > 0 && (
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                <h3 className="text-2xl font-bold text-white mb-6">🔧 {language === 'ar' ? 'نتائج الشبكة' : 'Network Results'}</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  {Array.from(zoneResults.entries()).map(([id, result]) => (
                    <div key={id} className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 rounded-lg p-6 border border-cyan-400/30">
                      <h4 className="text-lg font-bold text-cyan-300 mb-4">{result.zoneName}</h4>
                      <div className="space-y-2">
                        <div><p className="text-gray-400 text-sm">{language === 'ar' ? 'الضغط الأولي' : 'Source Pressure'}</p><p className="text-2xl font-bold text-cyan-300">{result.sourcePress.toFixed(2)} bar</p></div>
                        <div><p className="text-gray-400 text-sm">{language === 'ar' ? 'خسارة الضغط' : 'Pressure Loss'}</p><p className="text-xl font-bold text-orange-300">{result.totalPressureLoss.toFixed(2)} bar</p></div>
                        <div><p className="text-gray-400 text-sm">{language === 'ar' ? 'الضغط النهائي' : 'Final Pressure'}</p><p className="text-2xl font-bold text-green-300">{result.destPress.toFixed(2)} bar</p></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Elevation Results */}
            {elevResult && (
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                <h3 className="text-2xl font-bold text-white mb-6">📈 {language === 'ar' ? 'نتائج الارتفاع' : 'Elevation Results'}</h3>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-lg p-6 border border-blue-400/30">
                    <p className="text-gray-400 text-sm mb-1">{language === 'ar' ? 'المسافة' : 'Distance'}</p>
                    <p className="text-3xl font-bold text-blue-300">{elevResult.distance.toLocaleString(language === 'ar' ? 'ar-EG' : 'en-US', { maximumFractionDigits: 2 })} m</p>
                  </div>
                  <div className="bg-gradient-to-br from-green-500/10 to-blue-500/10 rounded-lg p-6 border border-green-400/30">
                    <p className="text-gray-400 text-sm mb-1">{language === 'ar' ? 'الارتفاع' : 'Elevation'}</p>
                    <p className="text-3xl font-bold text-green-300">{elevResult.elevation.toLocaleString(language === 'ar' ? 'ar-EG' : 'en-US', { maximumFractionDigits: 2 })} m</p>
                  </div>
                  <div className="bg-gradient-to-br from-orange-500/10 to-yellow-500/10 rounded-lg p-6 border border-orange-400/30">
                    <p className="text-gray-400 text-sm mb-1">{language === 'ar' ? 'الانحدار' : 'Slope'}</p>
                    <p className="text-3xl font-bold text-orange-300">{elevResult.slope.toFixed(2)}%</p>
                  </div>
                </div>
              </div>
            )}

            {/* Pressure Results */}
            {pressureResult && (
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                <h3 className="text-2xl font-bold text-white mb-6">💧 {language === 'ar' ? 'نتائج ضغط المياه' : 'Water Pressure Results'}</h3>
                <div className="grid md:grid-cols-4 gap-6">
                  <div className="bg-white/5 rounded-lg p-4 border border-cyan-400/30">
                    <p className="text-gray-400 text-sm mb-1">Pascal</p>
                    <p className="text-xl font-bold text-cyan-300">{pressureResult.pascals.toLocaleString(language === 'ar' ? 'ar-EG' : 'en-US', { maximumFractionDigits: 2 })} Pa</p>
                  </div>
                  <div className="bg-white/5 rounded-lg p-4 border border-blue-400/30">
                    <p className="text-gray-400 text-sm mb-1">kPa</p>
                    <p className="text-xl font-bold text-blue-300">{pressureResult.kpa.toLocaleString(language === 'ar' ? 'ar-EG' : 'en-US', { maximumFractionDigits: 2 })} kPa</p>
                  </div>
                  <div className="bg-white/5 rounded-lg p-4 border border-green-400/30">
                    <p className="text-gray-400 text-sm mb-1">bar</p>
                    <p className="text-xl font-bold text-green-300">{pressureResult.bar.toLocaleString(language === 'ar' ? 'ar-EG' : 'en-US', { maximumFractionDigits: 3 })} bar</p>
                  </div>
                  <div className="bg-white/5 rounded-lg p-4 border border-purple-400/30">
                    <p className="text-gray-400 text-sm mb-1">atm</p>
                    <p className="text-xl font-bold text-purple-300">{pressureResult.atm.toLocaleString(language === 'ar' ? 'ar-EG' : 'en-US', { maximumFractionDigits: 3 })} atm</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Profile Tab - المقطع الطولي */}
        {tab === 'profile' && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
            <h2 className="text-2xl font-bold text-white mb-6">📈 {language === 'ar' ? 'المقطع الطولي للشبكة' : 'Network Longitudinal Profile'}</h2>
            
            {zones.length === 0 ? (
              <div className="text-center py-12 text-gray-400">
                <p className="text-xl mb-4">{language === 'ar' ? 'لا توجد بيانات' : 'No data available'}</p>
                <p>{language === 'ar' ? 'قم برفع ملف KML أولاً' : 'Please upload a KML file first'}</p>
              </div>
            ) : (
              <div className="space-y-6">
                {/* اختيار المنطقة */}
                <div className="flex flex-wrap gap-4 items-center">
                  <label className="text-white font-semibold">{language === 'ar' ? 'اختر المنطقة:' : 'Select Zone:'}</label>
                  <select
                    value={selectedZoneForProfile || ''}
                    onChange={(e) => setSelectedZoneForProfile(e.target.value ? parseInt(e.target.value) : null)}
                    className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white"
                  >
                    <option value="">{language === 'ar' ? '-- اختر منطقة --' : '-- Select Zone --'}</option>
                    {zones.map((zone) => (
                      <option key={zone.id} value={zone.id} className="bg-slate-800">
                        {zone.tankName} ({zone.pipes.length} {language === 'ar' ? 'خط' : 'pipes'})
                      </option>
                    ))}
                  </select>
                </div>

                {/* عرض المقطع الطولي */}
                {selectedZoneForProfile && (() => {
                  const zone = zones.find(z => z.id === selectedZoneForProfile);
                  if (!zone) return null;
                  
                  // حساب البيانات للمقطع
                  const tank = elements.find(el => el.id === zone.tankId);
                  const tankElevation = tank?.elevation || 0;
                  
                  // ترتيب الأنابيب وحساب المسافة التراكمية
                  let cumulativeDistance = 0;
                  const profileData = zone.pipes.map((pipe, idx) => {
                    const length = Math.sqrt(
                      Math.pow((pipe.endLat - pipe.startLat) * 111320, 2) +
                      Math.pow((pipe.endLng - pipe.startLng) * 111320 * Math.cos(pipe.startLat * Math.PI / 180), 2)
                    );
                    const startDist = cumulativeDistance;
                    cumulativeDistance += length;
                    return {
                      id: pipe.id,
                      startDist,
                      endDist: cumulativeDistance,
                      length,
                      diameter: pipe.diameter
                    };
                  });
                  
                  const totalLength = cumulativeDistance;
                  const maxBarWidth = 100; // نسبة مئوية
                  
                  return (
                    <div className="space-y-6">
                      {/* معلومات المنطقة */}
                      <div className="grid md:grid-cols-4 gap-4">
                        <div className="bg-blue-500/20 rounded-lg p-4 border border-blue-400/30">
                          <p className="text-gray-400 text-sm">{language === 'ar' ? 'الخزان' : 'Tank'}</p>
                          <p className="text-xl font-bold text-blue-300">{zone.tankName}</p>
                        </div>
                        <div className="bg-cyan-500/20 rounded-lg p-4 border border-cyan-400/30">
                          <p className="text-gray-400 text-sm">{language === 'ar' ? 'ارتفاع الخزان' : 'Tank Elevation'}</p>
                          <p className="text-xl font-bold text-cyan-300">{tankElevation.toFixed(1)} م</p>
                        </div>
                        <div className="bg-green-500/20 rounded-lg p-4 border border-green-400/30">
                          <p className="text-gray-400 text-sm">{language === 'ar' ? 'عدد الخطوط' : 'Pipes Count'}</p>
                          <p className="text-xl font-bold text-green-300">{zone.pipes.length}</p>
                        </div>
                        <div className="bg-orange-500/20 rounded-lg p-4 border border-orange-400/30">
                          <p className="text-gray-400 text-sm">{language === 'ar' ? 'الطول الإجمالي' : 'Total Length'}</p>
                          <p className="text-xl font-bold text-orange-300">{(totalLength / 1000).toFixed(2)} كم</p>
                        </div>
                      </div>

                      {/* رسم المقطع الطولي */}
                      <div className="bg-black/30 rounded-xl p-6 border border-white/10">
                        <h4 className="text-lg font-semibold text-white mb-4">{language === 'ar' ? 'المقطع الطولي' : 'Longitudinal Profile'}</h4>
                        
                        {/* المحور Y - الارتفاع */}
                        <div className="flex">
                          <div className="w-16 flex flex-col justify-between text-xs text-gray-400 pr-2">
                            <span>{tankElevation.toFixed(0)}م</span>
                            <span>{(tankElevation * 0.5).toFixed(0)}م</span>
                            <span>0م</span>
                          </div>
                          
                          {/* منطقة الرسم */}
                          <div className="flex-1 relative h-48 bg-gradient-to-b from-blue-900/30 to-slate-900/50 rounded-lg border border-white/10 overflow-hidden">
                            {/* خط الخزان */}
                            <div className="absolute left-0 top-0 w-8 h-full bg-blue-500/30 border-r-2 border-blue-400 flex items-start justify-center pt-2">
                              <span className="text-xs text-blue-300 font-bold rotate-90 whitespace-nowrap">🛢️</span>
                            </div>
                            
                            {/* خطوط الأنابيب */}
                            <div className="absolute left-8 right-0 top-0 bottom-0 flex items-end">
                              {profileData.map((pipe, idx) => {
                                const widthPercent = (pipe.length / totalLength) * 100;
                                const diameterColors: {[key: number]: string} = {
                                  50: '#ef4444', 63: '#f97316', 75: '#eab308', 90: '#84cc16',
                                  110: '#22c55e', 125: '#14b8a6', 160: '#06b6d4', 200: '#0ea5e9',
                                  250: '#3b82f6', 315: '#6366f1', 400: '#8b5cf6', 500: '#a855f7'
                                };
                                const color = diameterColors[pipe.diameter] || '#64748b';
                                const heightPercent = Math.min(90, 30 + (pipe.diameter / 500) * 60);
                                
                                return (
                                  <div
                                    key={pipe.id}
                                    style={{
                                      width: `${widthPercent}%`,
                                      height: `${heightPercent}%`,
                                      backgroundColor: color,
                                      opacity: 0.8
                                    }}
                                    className="border-r border-white/20 hover:opacity-100 transition-opacity cursor-pointer group relative"
                                    title={`${language === 'ar' ? 'القطر' : 'Diameter'}: ${pipe.diameter}mm, ${language === 'ar' ? 'الطول' : 'Length'}: ${pipe.length.toFixed(1)}m`}
                                  >
                                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-black/80 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 whitespace-nowrap z-10">
                                      ⌀{pipe.diameter}mm | {pipe.length.toFixed(0)}م
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                        
                        {/* المحور X - المسافة */}
                        <div className="flex mt-2 ml-16">
                          <div className="flex-1 flex justify-between text-xs text-gray-400">
                            <span>0</span>
                            <span>{(totalLength / 4 / 1000).toFixed(1)}كم</span>
                            <span>{(totalLength / 2 / 1000).toFixed(1)}كم</span>
                            <span>{(totalLength * 3/4 / 1000).toFixed(1)}كم</span>
                            <span>{(totalLength / 1000).toFixed(1)}كم</span>
                          </div>
                        </div>
                      </div>

                      {/* مفتاح الألوان */}
                      <div className="bg-black/20 rounded-lg p-4">
                        <h5 className="text-sm font-semibold text-white mb-3">{language === 'ar' ? 'مفتاح الأقطار:' : 'Diameter Legend:'}</h5>
                        <div className="flex flex-wrap gap-3">
                          {[50, 63, 75, 90, 110, 125, 160, 200, 250, 315, 400, 500].map(d => {
                            const colors: {[key: number]: string} = {
                              50: '#ef4444', 63: '#f97316', 75: '#eab308', 90: '#84cc16',
                              110: '#22c55e', 125: '#14b8a6', 160: '#06b6d4', 200: '#0ea5e9',
                              250: '#3b82f6', 315: '#6366f1', 400: '#8b5cf6', 500: '#a855f7'
                            };
                            return (
                              <div key={d} className="flex items-center gap-1">
                                <div className="w-4 h-4 rounded" style={{backgroundColor: colors[d]}}></div>
                                <span className="text-xs text-gray-400">{d}mm</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* جدول تفاصيل الأنابيب */}
                      <div className="overflow-x-auto">
                        <table className="w-full text-xs border-collapse">
                          <thead>
                            <tr className="bg-black/50">
                              <th className="border border-white/20 p-2">#</th>
                              <th className="border border-white/20 p-2">{language === 'ar' ? 'القطر' : 'Diameter'}</th>
                              <th className="border border-white/20 p-2">{language === 'ar' ? 'الطول' : 'Length'}</th>
                              <th className="border border-white/20 p-2">{language === 'ar' ? 'المسافة من البداية' : 'Distance from Start'}</th>
                              <th className="border border-white/20 p-2">{language === 'ar' ? 'المسافة إلى النهاية' : 'Distance to End'}</th>
                            </tr>
                          </thead>
                          <tbody>
                            {profileData.slice(0, 50).map((pipe, idx) => (
                              <tr key={pipe.id} className="hover:bg-white/10">
                                <td className="border border-white/20 p-2 text-center">{idx + 1}</td>
                                <td className="border border-white/20 p-2 text-center text-yellow-300">{pipe.diameter}mm</td>
                                <td className="border border-white/20 p-2 text-center text-green-300">{pipe.length.toFixed(1)}م</td>
                                <td className="border border-white/20 p-2 text-center">{pipe.startDist.toFixed(1)}م</td>
                                <td className="border border-white/20 p-2 text-center">{pipe.endDist.toFixed(1)}م</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        {profileData.length > 50 && (
                          <p className="text-center text-gray-400 mt-2">
                            {language === 'ar' ? `... و ${profileData.length - 50} خط آخر` : `... and ${profileData.length - 50} more pipes`}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
        )}

        {/* تبويب مقارنة السيناريوهات */}
        {tab === 'compare' && (
          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-6">⚖️ {language === 'ar' ? 'مقارنة سيناريوهات الشبكة' : 'Compare Network Scenarios'}</h2>
              
              {savedProjects.length < 2 ? (
                <div className="text-center py-12 text-gray-400">
                  <p className="text-xl mb-4">{language === 'ar' ? 'تحتاج إلى سيناريوهين على الأقل' : 'Need at least 2 saved scenarios'}</p>
                  <p>{language === 'ar' ? 'قم بحفظ السيناريوهات أولاً قبل المقارنة' : 'Save scenarios first before comparing'}</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Comparison Mode Selection */}
                  <div className="flex gap-3 flex-wrap">
                    <button
                      onClick={() => setComparisonMode('side-by-side')}
                      className={`px-4 py-2 rounded-lg font-semibold transition ${
                        comparisonMode === 'side-by-side'
                          ? 'bg-cyan-600 text-white'
                          : 'bg-white/10 text-gray-300 hover:bg-white/20'
                      }`}
                      data-testid="button-compare-side-by-side"
                    >
                      📋 {language === 'ar' ? 'جنباً إلى جنب' : 'Side by Side'}
                    </button>
                    <button
                      onClick={() => setComparisonMode('overlay')}
                      className={`px-4 py-2 rounded-lg font-semibold transition ${
                        comparisonMode === 'overlay'
                          ? 'bg-purple-600 text-white'
                          : 'bg-white/10 text-gray-300 hover:bg-white/20'
                      }`}
                      data-testid="button-compare-overlay"
                    >
                      🎨 {language === 'ar' ? 'تراكب' : 'Overlay'}
                    </button>
                    <button
                      onClick={() => setComparisonMode('difference')}
                      className={`px-4 py-2 rounded-lg font-semibold transition ${
                        comparisonMode === 'difference'
                          ? 'bg-orange-600 text-white'
                          : 'bg-white/10 text-gray-300 hover:bg-white/20'
                      }`}
                      data-testid="button-compare-difference"
                    >
                      🔴 {language === 'ar' ? 'الفروقات' : 'Differences'}
                    </button>
                  </div>

                  {/* Scenario Selection */}
                  <div className="grid md:grid-cols-2 gap-6">
                    {[0, 1].map((idx) => (
                      <div key={idx} className="bg-white/5 rounded-xl p-4 border border-white/20">
                        <label className="text-gray-300 text-sm mb-2 block">
                          {language === 'ar' ? `السيناريو ${idx + 1}` : `Scenario ${idx + 1}`}
                        </label>
                        <select
                          value={idx === 0 ? compareScenarios.scenario1 ?? '' : compareScenarios.scenario2 ?? ''}
                          onChange={(e) => {
                            const value = e.target.value ? parseInt(e.target.value) : null;
                            if (idx === 0) {
                              setCompareScenarios({ ...compareScenarios, scenario1: value });
                            } else {
                              setCompareScenarios({ ...compareScenarios, scenario2: value });
                            }
                          }}
                          className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded text-white text-sm"
                          data-testid={`select-scenario-${idx + 1}`}
                        >
                          <option value="">{language === 'ar' ? 'اختر سيناريو' : 'Select scenario'}</option>
                          {savedProjects.map((proj, pidx) => (
                            <option key={pidx} value={pidx}>
                              {proj.name} ({proj.date})
                            </option>
                          ))}
                        </select>
                      </div>
                    ))}
                  </div>

                  {/* Comparison Display */}
                  {compareScenarios.scenario1 !== null && compareScenarios.scenario2 !== null && (
                    <div className="space-y-6">
                      {comparisonMode === 'side-by-side' && (
                        <div className="grid md:grid-cols-2 gap-6">
                          {[compareScenarios.scenario1, compareScenarios.scenario2].map((scenarioIdx, idx) => {
                            const proj = savedProjects[scenarioIdx!];
                            const data = proj.data;
                            return (
                              <div key={idx} className="bg-white/5 rounded-xl p-4 border border-cyan-400/50">
                                <h3 className="text-lg font-bold text-cyan-300 mb-4">{proj.name}</h3>
                                <div className="space-y-2 text-sm">
                                  <div className="flex justify-between">
                                    <span className="text-gray-400">{language === 'ar' ? 'الأنابيب' : 'Pipes'}:</span>
                                    <span className="text-white font-bold">{data.pipes?.length || 0}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-gray-400">{language === 'ar' ? 'العناصر' : 'Elements'}:</span>
                                    <span className="text-white font-bold">{data.elements?.length || 0}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-gray-400">{language === 'ar' ? 'المناطق' : 'Zones'}:</span>
                                    <span className="text-white font-bold">{data.zones?.length || 0}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-gray-400">{language === 'ar' ? 'الطول الكلي' : 'Total Length'}:</span>
                                    <span className="text-white font-bold">
                                      {((data.pipes || []).reduce((sum: number, p: PipeSegment) => sum + (p.length || 0), 0) / 1000).toFixed(1)} km
                                    </span>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {comparisonMode === 'difference' && (
                        <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 rounded-xl p-6 border border-orange-400/30">
                          <h3 className="text-lg font-bold text-orange-300 mb-4">{language === 'ar' ? 'تحليل الفروقات' : 'Difference Analysis'}</h3>
                          {(() => {
                            const scenario1Data = savedProjects[compareScenarios.scenario1!]?.data || {};
                            const scenario2Data = savedProjects[compareScenarios.scenario2!]?.data || {};
                            
                            const pipes1 = scenario1Data.pipes || [];
                            const pipes2 = scenario2Data.pipes || [];
                            const elements1 = scenario1Data.elements || [];
                            const elements2 = scenario2Data.elements || [];
                            
                            const pipeDiff = pipes2.length - pipes1.length;
                            const elementDiff = elements2.length - elements1.length;
                            
                            const length1 = pipes1.reduce((sum: number, p: PipeSegment) => sum + (p.length || 0), 0);
                            const length2 = pipes2.reduce((sum: number, p: PipeSegment) => sum + (p.length || 0), 0);
                            const lengthDiff = length2 - length1;
                            
                            return (
                              <div className="grid md:grid-cols-3 gap-4">
                                <div className="bg-white/5 p-4 rounded-lg">
                                  <p className="text-xs text-gray-400 mb-1">{language === 'ar' ? 'تغير الأنابيب' : 'Pipe Change'}</p>
                                  <p className={`text-2xl font-bold ${pipeDiff > 0 ? 'text-green-300' : pipeDiff < 0 ? 'text-red-300' : 'text-gray-300'}`}>
                                    {pipeDiff > 0 ? '+' : ''}{pipeDiff}
                                  </p>
                                </div>
                                <div className="bg-white/5 p-4 rounded-lg">
                                  <p className="text-xs text-gray-400 mb-1">{language === 'ar' ? 'تغير العناصر' : 'Element Change'}</p>
                                  <p className={`text-2xl font-bold ${elementDiff > 0 ? 'text-green-300' : elementDiff < 0 ? 'text-red-300' : 'text-gray-300'}`}>
                                    {elementDiff > 0 ? '+' : ''}{elementDiff}
                                  </p>
                                </div>
                                <div className="bg-white/5 p-4 rounded-lg">
                                  <p className="text-xs text-gray-400 mb-1">{language === 'ar' ? 'تغير الطول' : 'Length Change'}</p>
                                  <p className={`text-2xl font-bold ${lengthDiff > 0 ? 'text-green-300' : lengthDiff < 0 ? 'text-red-300' : 'text-gray-300'}`}>
                                    {lengthDiff > 0 ? '+' : ''}{(lengthDiff / 1000).toFixed(1)} km
                                  </p>
                                </div>
                              </div>
                            );
                          })()}
                        </div>
                      )}

                      {comparisonMode === 'overlay' && (
                        <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-xl p-6 border border-purple-400/30">
                          <h3 className="text-lg font-bold text-purple-300 mb-4">{language === 'ar' ? 'التراكب المرئي' : 'Visual Overlay'}</h3>
                          <p className="text-gray-400 text-sm mb-4">
                            {language === 'ar' 
                              ? 'يعرض السيناريوهين متداخلة: الأحمر = فقط في السيناريو 1، الأزرق = فقط في السيناريو 2، الأخضر = في كليهما'
                              : 'Shows scenarios overlapped: Red = only in Scenario 1, Blue = only in Scenario 2, Green = in both'}
                          </p>
                          <div className="grid grid-cols-3 gap-3">
                            <div className="bg-red-500/30 rounded-lg p-3 text-center border border-red-400/50">
                              <p className="text-red-300 font-bold">{language === 'ar' ? 'فقط في الأول' : 'Scenario 1 Only'}</p>
                            </div>
                            <div className="bg-green-500/30 rounded-lg p-3 text-center border border-green-400/50">
                              <p className="text-green-300 font-bold">{language === 'ar' ? 'مشترك' : 'Common'}</p>
                            </div>
                            <div className="bg-blue-500/30 rounded-lg p-3 text-center border border-blue-400/50">
                              <p className="text-blue-300 font-bold">{language === 'ar' ? 'فقط في الثاني' : 'Scenario 2 Only'}</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* تبويب التحليل الهيدروليكي المتقدم */}
        {tab === 'hydraulics' && (
          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-6">🔬 {language === 'ar' ? 'التحليل الهيدروليكي المتقدم' : 'Advanced Hydraulic Analysis'}</h2>
              
              {pipeSegments.length === 0 ? (
                <div className="text-center py-12 text-gray-400">
                  <p className="text-xl mb-4">{language === 'ar' ? 'لا توجد بيانات' : 'No data available'}</p>
                  <p>{language === 'ar' ? 'قم برفع ملف KML أولاً' : 'Please upload a KML file first'}</p>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  
                  {/* 1. تحليل سرعة التدفق */}
                  <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-xl p-5 border border-blue-400/30">
                    <h3 className="text-lg font-bold text-blue-300 mb-4 flex items-center gap-2">
                      <span>⚡</span>
                      {language === 'ar' ? 'تحليل سرعة التدفق' : 'Flow Velocity Analysis'}
                    </h3>
                    {(() => {
                      const velocityAnalysis = pipeSegments.slice(0, 100).map(pipe => {
                        const length = pipe.length || calculateHaversineDistance(pipe.startLat, pipe.startLng, pipe.endLat, pipe.endLng);
                        const analysis = analyzePipeFlow(pipe.flow, pipe.diameter, length, pipe.material || 'default');
                        return { pipe, analysis };
                      });
                      
                      const tooLow = velocityAnalysis.filter(v => v.analysis.velocityStatus === 'too_low').length;
                      const optimal = velocityAnalysis.filter(v => v.analysis.velocityStatus === 'optimal').length;
                      const high = velocityAnalysis.filter(v => v.analysis.velocityStatus === 'high').length;
                      const tooHigh = velocityAnalysis.filter(v => v.analysis.velocityStatus === 'too_high').length;
                      
                      return (
                        <div className="space-y-3">
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div className="bg-red-500/20 p-2 rounded text-center">
                              <p className="text-red-300 font-bold text-lg">{tooLow}</p>
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'منخفضة جداً' : 'Too Low'}</p>
                            </div>
                            <div className="bg-green-500/20 p-2 rounded text-center">
                              <p className="text-green-300 font-bold text-lg">{optimal}</p>
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'مثالية' : 'Optimal'}</p>
                            </div>
                            <div className="bg-yellow-500/20 p-2 rounded text-center">
                              <p className="text-yellow-300 font-bold text-lg">{high}</p>
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'عالية' : 'High'}</p>
                            </div>
                            <div className="bg-orange-500/20 p-2 rounded text-center">
                              <p className="text-orange-300 font-bold text-lg">{tooHigh}</p>
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'عالية جداً' : 'Too High'}</p>
                            </div>
                          </div>
                          <p className="text-xs text-gray-400">
                            {language === 'ar' 
                              ? 'السرعة المثالية: 0.3 - 1.5 م/ث' 
                              : 'Optimal velocity: 0.3 - 1.5 m/s'}
                          </p>
                        </div>
                      );
                    })()}
                  </div>

                  {/* 2. تحليل فقدان الضغط */}
                  <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-xl p-5 border border-purple-400/30">
                    <h3 className="text-lg font-bold text-purple-300 mb-4 flex items-center gap-2">
                      <span>📉</span>
                      {language === 'ar' ? 'فقدان الضغط (Hazen-Williams)' : 'Head Loss (Hazen-Williams)'}
                    </h3>
                    {(() => {
                      let totalHeadLoss = 0;
                      let criticalPipes = 0;
                      let totalLength = 0;
                      
                      pipeSegments.slice(0, 100).forEach(pipe => {
                        const length = pipe.length || calculateHaversineDistance(pipe.startLat, pipe.startLng, pipe.endLat, pipe.endLng);
                        totalLength += length;
                        const headLoss = calculateHazenWilliamsHeadLoss(pipe.flow, pipe.diameter, length, 130);
                        totalHeadLoss += headLoss;
                        if (headLossToBar(headLoss) > 0.5) criticalPipes++;
                      });
                      
                      return (
                        <div className="space-y-3">
                          <div className="bg-white/5 p-3 rounded-lg">
                            <p className="text-xs text-gray-400">{language === 'ar' ? 'إجمالي فقدان الضغط' : 'Total Head Loss'}</p>
                            <p className="text-2xl font-bold text-purple-300">{totalHeadLoss.toFixed(2)} م</p>
                            <p className="text-sm text-gray-400">{headLossToBar(totalHeadLoss).toFixed(3)} bar</p>
                          </div>
                          <div className="bg-white/5 p-3 rounded-lg">
                            <p className="text-xs text-gray-400">{language === 'ar' ? 'أنابيب حرجة' : 'Critical Pipes'}</p>
                            <p className="text-xl font-bold text-red-300">{criticalPipes}</p>
                            <p className="text-xs text-gray-500">{language === 'ar' ? '> 0.5 bar فقدان' : '> 0.5 bar loss'}</p>
                          </div>
                        </div>
                      );
                    })()}
                  </div>

                  {/* 3. تحليل Darcy-Weisbach */}
                  <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 rounded-xl p-5 border border-orange-400/30">
                    <h3 className="text-lg font-bold text-orange-300 mb-4 flex items-center gap-2">
                      <span>🧮</span>
                      {language === 'ar' ? 'تحليل Darcy-Weisbach' : 'Darcy-Weisbach Analysis'}
                    </h3>
                    {(() => {
                      let totalDWLoss = 0;
                      let maxVelocity = 0;
                      let avgReynolds = 0;
                      let count = 0;
                      
                      pipeSegments.slice(0, 100).forEach(pipe => {
                        const length = pipe.length || calculateHaversineDistance(pipe.startLat, pipe.startLng, pipe.endLat, pipe.endLng);
                        const velocity = calculateFlowVelocity(pipe.flow, pipe.diameter);
                        const reynolds = calculateReynoldsNumber(velocity, pipe.diameter);
                        const dwLoss = calculateDarcyWeisbachHeadLoss(pipe.flow, pipe.diameter, length);
                        
                        totalDWLoss += dwLoss;
                        if (velocity > maxVelocity) maxVelocity = velocity;
                        avgReynolds += reynolds;
                        count++;
                      });
                      
                      avgReynolds = count > 0 ? avgReynolds / count : 0;
                      
                      return (
                        <div className="space-y-3">
                          <div className="bg-white/5 p-3 rounded-lg">
                            <p className="text-xs text-gray-400">{language === 'ar' ? 'فقدان D-W الكلي' : 'Total D-W Loss'}</p>
                            <p className="text-xl font-bold text-orange-300">{totalDWLoss.toFixed(2)} م</p>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div className="bg-white/5 p-2 rounded text-center">
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'أقصى سرعة' : 'Max Velocity'}</p>
                              <p className="text-lg font-bold text-yellow-300">{maxVelocity.toFixed(2)}</p>
                              <p className="text-xs text-gray-500">م/ث</p>
                            </div>
                            <div className="bg-white/5 p-2 rounded text-center">
                              <p className="text-xs text-gray-400">Re {language === 'ar' ? 'المتوسط' : 'Avg'}</p>
                              <p className="text-lg font-bold text-cyan-300">{(avgReynolds / 1000).toFixed(0)}K</p>
                            </div>
                          </div>
                        </div>
                      );
                    })()}
                  </div>

                  {/* 4. زمن بقاء المياه */}
                  <div className="bg-gradient-to-br from-teal-500/20 to-green-500/20 rounded-xl p-5 border border-teal-400/30">
                    <h3 className="text-lg font-bold text-teal-300 mb-4 flex items-center gap-2">
                      <span>⏱️</span>
                      {language === 'ar' ? 'زمن بقاء المياه' : 'Water Age Analysis'}
                    </h3>
                    {(() => {
                      let totalVolume = 0;
                      let maxAge = 0;
                      let avgAge = 0;
                      let stagnantPipes = 0;
                      let count = 0;
                      
                      pipeSegments.slice(0, 100).forEach(pipe => {
                        const length = pipe.length || calculateHaversineDistance(pipe.startLat, pipe.startLng, pipe.endLat, pipe.endLng);
                        const velocity = calculateFlowVelocity(pipe.flow, pipe.diameter);
                        const volume = calculatePipeVolume(pipe.diameter, length);
                        const age = calculateWaterAge(length, velocity);
                        
                        totalVolume += volume;
                        if (age !== Infinity && age > maxAge) maxAge = age;
                        if (age !== Infinity) {
                          avgAge += age;
                          count++;
                        }
                        if (age > 24) stagnantPipes++; // أكثر من 24 ساعة = راكد
                      });
                      
                      avgAge = count > 0 ? avgAge / count : 0;
                      
                      return (
                        <div className="space-y-3">
                          <div className="bg-white/5 p-3 rounded-lg">
                            <p className="text-xs text-gray-400">{language === 'ar' ? 'حجم المياه الكلي' : 'Total Water Volume'}</p>
                            <p className="text-xl font-bold text-teal-300">{(totalVolume / 1000).toFixed(1)} م³</p>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div className="bg-white/5 p-2 rounded text-center">
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'أقصى زمن' : 'Max Age'}</p>
                              <p className="text-lg font-bold text-yellow-300">{maxAge.toFixed(1)}</p>
                              <p className="text-xs text-gray-500">{language === 'ar' ? 'ساعة' : 'hours'}</p>
                            </div>
                            <div className="bg-white/5 p-2 rounded text-center">
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'راكد' : 'Stagnant'}</p>
                              <p className="text-lg font-bold text-red-300">{stagnantPipes}</p>
                              <p className="text-xs text-gray-500">&gt; 24h</p>
                            </div>
                          </div>
                        </div>
                      );
                    })()}
                  </div>

                  {/* 5. تحسين الأقطار */}
                  <div className="bg-gradient-to-br from-indigo-500/20 to-blue-500/20 rounded-xl p-5 border border-indigo-400/30">
                    <h3 className="text-lg font-bold text-indigo-300 mb-4 flex items-center gap-2">
                      <span>📐</span>
                      {language === 'ar' ? 'تحسين الأقطار' : 'Diameter Optimization'}
                    </h3>
                    {(() => {
                      let undersized = 0;
                      let oversized = 0;
                      let optimal = 0;
                      
                      pipeSegments.slice(0, 100).forEach(pipe => {
                        const length = pipe.length || calculateHaversineDistance(pipe.startLat, pipe.startLng, pipe.endLat, pipe.endLng);
                        const optimalD = calculateOptimalDiameter(pipe.flow, length, 5, 130); // 5m max head loss
                        const minStd = getMinimumStandardDiameter(optimalD);
                        
                        if (pipe.diameter < minStd * 0.8) undersized++;
                        else if (pipe.diameter > minStd * 1.5) oversized++;
                        else optimal++;
                      });
                      
                      return (
                        <div className="space-y-3">
                          <div className="grid grid-cols-3 gap-2 text-center">
                            <div className="bg-red-500/20 p-2 rounded">
                              <p className="text-lg font-bold text-red-300">{undersized}</p>
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'صغير' : 'Under'}</p>
                            </div>
                            <div className="bg-green-500/20 p-2 rounded">
                              <p className="text-lg font-bold text-green-300">{optimal}</p>
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'مثالي' : 'Optimal'}</p>
                            </div>
                            <div className="bg-yellow-500/20 p-2 rounded">
                              <p className="text-lg font-bold text-yellow-300">{oversized}</p>
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'كبير' : 'Over'}</p>
                            </div>
                          </div>
                          <p className="text-xs text-gray-400 text-center">
                            {language === 'ar' ? 'الأقطار القياسية: 25-1200 مم' : 'Standard: 25-1200 mm'}
                          </p>
                        </div>
                      );
                    })()}
                  </div>

                  {/* 6. تحليل الضغط الأدنى */}
                  <div className="bg-gradient-to-br from-rose-500/20 to-pink-500/20 rounded-xl p-5 border border-rose-400/30">
                    <h3 className="text-lg font-bold text-rose-300 mb-4 flex items-center gap-2">
                      <span>🏢</span>
                      {language === 'ar' ? 'كفاية الضغط للمباني' : 'Pressure Adequacy'}
                    </h3>
                    {(() => {
                      const pressureData = Array.from(elementPressures.entries());
                      let inadequate = 0;
                      let marginal = 0;
                      let adequate = 0;
                      let excessive = 0;
                      
                      pressureData.forEach(([, pressure]) => {
                        const analysis = analyzePressureAdequacy(pressure, 3); // افتراض 3 طوابق
                        if (analysis.status === 'inadequate') inadequate++;
                        else if (analysis.status === 'marginal') marginal++;
                        else if (analysis.status === 'adequate') adequate++;
                        else excessive++;
                      });
                      
                      return (
                        <div className="space-y-3">
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div className="bg-red-500/20 p-2 rounded text-center">
                              <p className="text-lg font-bold text-red-300">{inadequate}</p>
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'غير كافٍ' : 'Inadequate'}</p>
                            </div>
                            <div className="bg-yellow-500/20 p-2 rounded text-center">
                              <p className="text-lg font-bold text-yellow-300">{marginal}</p>
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'حدي' : 'Marginal'}</p>
                            </div>
                            <div className="bg-green-500/20 p-2 rounded text-center">
                              <p className="text-lg font-bold text-green-300">{adequate}</p>
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'كافٍ' : 'Adequate'}</p>
                            </div>
                            <div className="bg-purple-500/20 p-2 rounded text-center">
                              <p className="text-lg font-bold text-purple-300">{excessive}</p>
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'زائد' : 'Excessive'}</p>
                            </div>
                          </div>
                          <p className="text-xs text-gray-400 text-center">
                            {language === 'ar' ? 'الحد الأدنى: 2 bar + 0.35/طابق' : 'Min: 2 bar + 0.35/floor'}
                          </p>
                        </div>
                      );
                    })()}
                  </div>
                </div>
              )}
            </div>

            {/* تحليل الشبكة والاتصال */}
            {pipeSegments.length > 0 && (
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
                <h3 className="text-xl font-bold text-white mb-6">🔗 {language === 'ar' ? 'تحليل اتصال الشبكة' : 'Network Connectivity Analysis'}</h3>
                
                <div className="grid md:grid-cols-3 gap-6">
                  {/* عقد الشبكة */}
                  <div className="bg-white/5 rounded-xl p-5">
                    <h4 className="text-lg font-semibold text-cyan-300 mb-4">🔵 {language === 'ar' ? 'عقد الشبكة' : 'Network Nodes'}</h4>
                    {(() => {
                      const nodes = new Set<string>();
                      pipeSegments.forEach(pipe => {
                        nodes.add(`${pipe.startLat.toFixed(5)},${pipe.startLng.toFixed(5)}`);
                        nodes.add(`${pipe.endLat.toFixed(5)},${pipe.endLng.toFixed(5)}`);
                      });
                      
                      // حساب درجة كل عقدة
                      const nodeDegrees = new Map<string, number>();
                      pipeSegments.forEach(pipe => {
                        const startKey = `${pipe.startLat.toFixed(5)},${pipe.startLng.toFixed(5)}`;
                        const endKey = `${pipe.endLat.toFixed(5)},${pipe.endLng.toFixed(5)}`;
                        nodeDegrees.set(startKey, (nodeDegrees.get(startKey) || 0) + 1);
                        nodeDegrees.set(endKey, (nodeDegrees.get(endKey) || 0) + 1);
                      });
                      
                      const deadEnds = Array.from(nodeDegrees.values()).filter(d => d === 1).length;
                      const junctions = Array.from(nodeDegrees.values()).filter(d => d >= 3).length;
                      
                      return (
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">{language === 'ar' ? 'إجمالي العقد' : 'Total Nodes'}</span>
                            <span className="text-white font-bold">{nodes.size}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">{language === 'ar' ? 'نقاط نهائية' : 'Dead Ends'}</span>
                            <span className="text-red-300 font-bold">{deadEnds}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">{language === 'ar' ? 'تقاطعات' : 'Junctions'}</span>
                            <span className="text-green-300 font-bold">{junctions}</span>
                          </div>
                        </div>
                      );
                    })()}
                  </div>

                  {/* تحليل الحلقات */}
                  <div className="bg-white/5 rounded-xl p-5">
                    <h4 className="text-lg font-semibold text-purple-300 mb-4">🔄 {language === 'ar' ? 'تحليل الحلقات' : 'Loop Analysis'}</h4>
                    {(() => {
                      const nodes = new Set<string>();
                      pipeSegments.forEach(pipe => {
                        nodes.add(`${pipe.startLat.toFixed(5)},${pipe.startLng.toFixed(5)}`);
                        nodes.add(`${pipe.endLat.toFixed(5)},${pipe.endLng.toFixed(5)}`);
                      });
                      
                      // تقدير عدد الحلقات: E - N + 1 (Euler's formula للرسوم المتصلة)
                      const estimatedLoops = Math.max(0, pipeSegments.length - nodes.size + 1);
                      const reliability = calculateNetworkReliability(zones.length, nodes.size, estimatedLoops);
                      
                      return (
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">{language === 'ar' ? 'عدد الحلقات' : 'Loop Count'}</span>
                            <span className="text-purple-300 font-bold">{estimatedLoops}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">{language === 'ar' ? 'مؤشر الموثوقية' : 'Reliability'}</span>
                            <span className="text-cyan-300 font-bold">{reliability.reliabilityScore.toFixed(0)}%</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">{language === 'ar' ? 'مستوى المخاطر' : 'Risk Level'}</span>
                            <span className={`font-bold ${
                              reliability.riskLevel === 'low' ? 'text-green-300' :
                              reliability.riskLevel === 'medium' ? 'text-yellow-300' : 'text-red-300'
                            }`}>
                              {language === 'ar' 
                                ? (reliability.riskLevel === 'low' ? 'منخفض' : reliability.riskLevel === 'medium' ? 'متوسط' : 'عالي')
                                : reliability.riskLevel}
                            </span>
                          </div>
                        </div>
                      );
                    })()}
                  </div>

                  {/* تحليل المصادر */}
                  <div className="bg-white/5 rounded-xl p-5">
                    <h4 className="text-lg font-semibold text-yellow-300 mb-4">🛢️ {language === 'ar' ? 'مصادر المياه' : 'Water Sources'}</h4>
                    {(() => {
                      const tanks = elements.filter(e => e.type === 'tank');
                      const pumps = elements.filter(e => e.type === 'pump');
                      const prvs = elements.filter(e => e.type === 'valve' && e.name.toUpperCase().includes('PRV'));
                      
                      return (
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">{language === 'ar' ? 'خزانات' : 'Tanks'}</span>
                            <span className="text-blue-300 font-bold">{tanks.length}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">{language === 'ar' ? 'مضخات' : 'Pumps'}</span>
                            <span className="text-orange-300 font-bold">{pumps.length}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">{language === 'ar' ? 'مخففات (PRV)' : 'PRVs'}</span>
                            <span className="text-purple-300 font-bold">{prvs.length}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">{language === 'ar' ? 'مناطق الضغط' : 'Pressure Zones'}</span>
                            <span className="text-green-300 font-bold">{zones.length}</span>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                </div>
              </div>
            )}

            {/* جدول تفاصيل الأنابيب الهيدروليكية */}
            {pipeSegments.length > 0 && (
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
                <h3 className="text-xl font-bold text-white mb-4">📋 {language === 'ar' ? 'التفاصيل الهيدروليكية للأنابيب' : 'Pipe Hydraulic Details'}</h3>
                
                <div className="overflow-x-auto">
                  <table className="w-full text-xs border-collapse">
                    <thead>
                      <tr className="bg-black/50 text-gray-300">
                        <th className="border border-white/20 p-2">#</th>
                        <th className="border border-white/20 p-2">{language === 'ar' ? 'القطر' : 'Dia.'}</th>
                        <th className="border border-white/20 p-2">{language === 'ar' ? 'التدفق' : 'Flow'}</th>
                        <th className="border border-white/20 p-2">{language === 'ar' ? 'الطول' : 'Length'}</th>
                        <th className="border border-white/20 p-2">{language === 'ar' ? 'السرعة' : 'Velocity'}</th>
                        <th className="border border-white/20 p-2">Re</th>
                        <th className="border border-white/20 p-2">{language === 'ar' ? 'النظام' : 'Regime'}</th>
                        <th className="border border-white/20 p-2">H-W Loss</th>
                        <th className="border border-white/20 p-2">D-W Loss</th>
                        <th className="border border-white/20 p-2">{language === 'ar' ? 'الحالة' : 'Status'}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pipeSegments.slice(0, 50).map((pipe, idx) => {
                        const length = pipe.length || calculateHaversineDistance(pipe.startLat, pipe.startLng, pipe.endLat, pipe.endLng);
                        const analysis = analyzePipeFlow(pipe.flow, pipe.diameter, length, pipe.material || 'default');
                        
                        const statusColor = {
                          'too_low': 'bg-red-500/30 text-red-300',
                          'optimal': 'bg-green-500/30 text-green-300',
                          'high': 'bg-yellow-500/30 text-yellow-300',
                          'too_high': 'bg-orange-500/30 text-orange-300'
                        }[analysis.velocityStatus];
                        
                        const statusText = {
                          'too_low': language === 'ar' ? 'منخفض' : 'Low',
                          'optimal': language === 'ar' ? 'مثالي' : 'OK',
                          'high': language === 'ar' ? 'عالي' : 'High',
                          'too_high': language === 'ar' ? 'خطر' : 'Critical'
                        }[analysis.velocityStatus];
                        
                        return (
                          <tr key={pipe.id} className="hover:bg-white/10">
                            <td className="border border-white/20 p-2 text-center text-gray-400">{idx + 1}</td>
                            <td className="border border-white/20 p-2 text-center text-yellow-300">{pipe.diameter}mm</td>
                            <td className="border border-white/20 p-2 text-center text-blue-300">{pipe.flow} L/s</td>
                            <td className="border border-white/20 p-2 text-center text-gray-300">{length.toFixed(1)}m</td>
                            <td className="border border-white/20 p-2 text-center text-cyan-300">{analysis.velocity.toFixed(2)} m/s</td>
                            <td className="border border-white/20 p-2 text-center text-gray-400">{(analysis.reynoldsNumber / 1000).toFixed(0)}K</td>
                            <td className="border border-white/20 p-2 text-center">
                              <span className={`px-1 py-0.5 rounded text-xs ${
                                analysis.flowRegime === 'laminar' ? 'bg-blue-500/30 text-blue-300' :
                                analysis.flowRegime === 'transitional' ? 'bg-yellow-500/30 text-yellow-300' :
                                'bg-green-500/30 text-green-300'
                              }`}>
                                {analysis.flowRegime === 'laminar' ? 'L' : analysis.flowRegime === 'transitional' ? 'T' : 'Tu'}
                              </span>
                            </td>
                            <td className="border border-white/20 p-2 text-center text-purple-300">{analysis.headLossHW.toFixed(3)}m</td>
                            <td className="border border-white/20 p-2 text-center text-orange-300">{analysis.headLossDW.toFixed(3)}m</td>
                            <td className="border border-white/20 p-2 text-center">
                              <span className={`px-2 py-0.5 rounded text-xs ${statusColor}`}>{statusText}</span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  {pipeSegments.length > 50 && (
                    <p className="text-center text-gray-400 mt-2 text-sm">
                      {language === 'ar' ? `... و ${pipeSegments.length - 50} أنبوب آخر` : `... and ${pipeSegments.length - 50} more pipes`}
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* محاكاة الطوارئ */}
            {pipeSegments.length > 0 && (
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
                <h3 className="text-xl font-bold text-white mb-6">🚨 {language === 'ar' ? 'محاكاة الطوارئ' : 'Emergency Simulation'}</h3>
                
                <div className="grid md:grid-cols-2 gap-6">
                  {/* محاكاة كسر الأنابيب */}
                  <div className="bg-gradient-to-br from-red-500/20 to-orange-500/20 rounded-xl p-5 border border-red-400/30">
                    <h4 className="text-lg font-semibold text-red-300 mb-4 flex items-center gap-2">
                      <span>💥</span>
                      {language === 'ar' ? 'تحليل كسر الأنابيب' : 'Pipe Break Analysis'}
                    </h4>
                    {(() => {
                      const nodeDegrees = new Map<string, number>();
                      pipeSegments.forEach(pipe => {
                        const startKey = `${pipe.startLat.toFixed(5)},${pipe.startLng.toFixed(5)}`;
                        const endKey = `${pipe.endLat.toFixed(5)},${pipe.endLng.toFixed(5)}`;
                        nodeDegrees.set(startKey, (nodeDegrees.get(startKey) || 0) + 1);
                        nodeDegrees.set(endKey, (nodeDegrees.get(endKey) || 0) + 1);
                      });
                      
                      const singlePointFailures = pipeSegments.filter(pipe => {
                        const startKey = `${pipe.startLat.toFixed(5)},${pipe.startLng.toFixed(5)}`;
                        const endKey = `${pipe.endLat.toFixed(5)},${pipe.endLng.toFixed(5)}`;
                        return (nodeDegrees.get(startKey) || 0) <= 2 || (nodeDegrees.get(endKey) || 0) <= 2;
                      });
                      
                      const largePipes = pipeSegments.filter(p => p.diameter >= 200);
                      const criticalPipes = singlePointFailures.filter(p => p.diameter >= 150);
                      
                      return (
                        <div className="space-y-3">
                          <div className="bg-white/5 p-3 rounded-lg">
                            <p className="text-xs text-gray-400">{language === 'ar' ? 'أنابيب عالية الخطورة' : 'High Risk Pipes'}</p>
                            <p className="text-2xl font-bold text-red-300">{criticalPipes.length}</p>
                            <p className="text-xs text-gray-500">{language === 'ar' ? 'نقطة فشل واحدة + قطر كبير' : 'Single point failure + large diameter'}</p>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div className="bg-white/5 p-2 rounded text-center">
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'أنابيب رئيسية' : 'Main Pipes'}</p>
                              <p className="text-lg font-bold text-orange-300">{largePipes.length}</p>
                              <p className="text-xs text-gray-500">≥200mm</p>
                            </div>
                            <div className="bg-white/5 p-2 rounded text-center">
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'فشل مفرد' : 'Single Fail'}</p>
                              <p className="text-lg font-bold text-yellow-300">{singlePointFailures.length}</p>
                            </div>
                          </div>
                        </div>
                      );
                    })()}
                  </div>

                  {/* تحليل صمامات العزل */}
                  <div className="bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl p-5 border border-blue-400/30">
                    <h4 className="text-lg font-semibold text-blue-300 mb-4 flex items-center gap-2">
                      <span>🚰</span>
                      {language === 'ar' ? 'تحليل صمامات العزل' : 'Isolation Valve Analysis'}
                    </h4>
                    {(() => {
                      const valves = elements.filter(e => e.type === 'valve');
                      const gateValves = valves.filter(v => v.name.toLowerCase().includes('gate') || v.name.includes('بوابة'));
                      const butterflyValves = valves.filter(v => v.name.toLowerCase().includes('butterfly') || v.name.includes('فراشة'));
                      
                      const pipePerValve = valves.length > 0 ? (pipeSegments.length / valves.length).toFixed(1) : 'N/A';
                      const valveRatio = valves.length > 0 ? ((valves.length / pipeSegments.length) * 100).toFixed(1) : '0';
                      
                      return (
                        <div className="space-y-3">
                          <div className="bg-white/5 p-3 rounded-lg">
                            <p className="text-xs text-gray-400">{language === 'ar' ? 'إجمالي الصمامات' : 'Total Valves'}</p>
                            <p className="text-2xl font-bold text-blue-300">{valves.length}</p>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div className="bg-white/5 p-2 rounded text-center">
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'أنبوب/صمام' : 'Pipe/Valve'}</p>
                              <p className="text-lg font-bold text-purple-300">{pipePerValve}</p>
                            </div>
                            <div className="bg-white/5 p-2 rounded text-center">
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'نسبة التغطية' : 'Coverage'}</p>
                              <p className="text-lg font-bold text-green-300">{valveRatio}%</p>
                            </div>
                          </div>
                          <p className="text-xs text-gray-400 text-center">
                            {language === 'ar' 
                              ? 'المعيار: صمام واحد لكل 3-5 أنابيب' 
                              : 'Standard: 1 valve per 3-5 pipes'}
                          </p>
                        </div>
                      );
                    })()}
                  </div>

                  {/* تحليل المناطق المتأثرة */}
                  <div className="bg-gradient-to-br from-amber-500/20 to-yellow-500/20 rounded-xl p-5 border border-amber-400/30">
                    <h4 className="text-lg font-semibold text-amber-300 mb-4 flex items-center gap-2">
                      <span>⚠️</span>
                      {language === 'ar' ? 'تقييم المناطق المتأثرة' : 'Affected Areas Assessment'}
                    </h4>
                    {(() => {
                      const avgPipesPerZone = zones.length > 0 ? (pipeSegments.length / zones.length).toFixed(0) : '0';
                      const maxZoneSize = zones.length > 0 ? Math.max(...zones.map(z => z.pipes.length)) : 0;
                      const isolatedZones = zones.filter(z => z.pipes.length <= 5).length;
                      
                      return (
                        <div className="space-y-3">
                          <div className="grid grid-cols-3 gap-2">
                            <div className="bg-white/5 p-2 rounded text-center">
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'متوسط' : 'Avg'}</p>
                              <p className="text-lg font-bold text-amber-300">{avgPipesPerZone}</p>
                              <p className="text-xs text-gray-500">{language === 'ar' ? 'أنبوب/منطقة' : 'pipes/zone'}</p>
                            </div>
                            <div className="bg-white/5 p-2 rounded text-center">
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'أكبر' : 'Max'}</p>
                              <p className="text-lg font-bold text-orange-300">{maxZoneSize}</p>
                              <p className="text-xs text-gray-500">{language === 'ar' ? 'أنبوب' : 'pipes'}</p>
                            </div>
                            <div className="bg-white/5 p-2 rounded text-center">
                              <p className="text-xs text-gray-400">{language === 'ar' ? 'صغيرة' : 'Small'}</p>
                              <p className="text-lg font-bold text-green-300">{isolatedZones}</p>
                              <p className="text-xs text-gray-500">≤5</p>
                            </div>
                          </div>
                          <p className="text-xs text-gray-400 text-center">
                            {language === 'ar' 
                              ? 'المناطق الصغيرة أسهل في العزل' 
                              : 'Smaller zones are easier to isolate'}
                          </p>
                        </div>
                      );
                    })()}
                  </div>

                  {/* توصيات الطوارئ */}
                  <div className="bg-gradient-to-br from-green-500/20 to-teal-500/20 rounded-xl p-5 border border-green-400/30">
                    <h4 className="text-lg font-semibold text-green-300 mb-4 flex items-center gap-2">
                      <span>✅</span>
                      {language === 'ar' ? 'توصيات الطوارئ' : 'Emergency Recommendations'}
                    </h4>
                    {(() => {
                      const valves = elements.filter(e => e.type === 'valve');
                      const tanks = elements.filter(e => e.type === 'tank');
                      const pumps = elements.filter(e => e.type === 'pump');
                      
                      const recommendations: string[] = [];
                      
                      if (valves.length < pipeSegments.length / 5) {
                        recommendations.push(language === 'ar' 
                          ? '❌ تحتاج المزيد من صمامات العزل' 
                          : '❌ Need more isolation valves');
                      } else {
                        recommendations.push(language === 'ar' 
                          ? '✓ تغطية صمامات كافية' 
                          : '✓ Adequate valve coverage');
                      }
                      
                      if (tanks.length < zones.length / 3) {
                        recommendations.push(language === 'ar' 
                          ? '⚠️ قد تحتاج خزانات إضافية' 
                          : '⚠️ May need additional tanks');
                      }
                      
                      if (pumps.length < 2) {
                        recommendations.push(language === 'ar' 
                          ? '⚠️ يُنصح بمضخة احتياطية' 
                          : '⚠️ Backup pump recommended');
                      }
                      
                      recommendations.push(language === 'ar' 
                        ? '📋 خطة استجابة للطوارئ' 
                        : '📋 Emergency response plan');
                      
                      return (
                        <div className="space-y-2">
                          {recommendations.map((rec, idx) => (
                            <p key={idx} className="text-sm text-gray-300 bg-white/5 p-2 rounded">
                              {rec}
                            </p>
                          ))}
                        </div>
                      );
                    })()}
                  </div>
                </div>
              </div>
            )}

            {/* حاسبة الطلب والإطفاء */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
                <h3 className="text-xl font-bold text-white mb-4">👥 {language === 'ar' ? 'حاسبة الطلب' : 'Demand Calculator'}</h3>
                <div className="space-y-4">
                  <div>
                    <label className="text-gray-400 text-sm">{language === 'ar' ? 'عدد السكان' : 'Population'}</label>
                    <input 
                      type="number" 
                      defaultValue={1000}
                      className="w-full mt-1 px-3 py-2 bg-white/5 border border-white/20 rounded text-white"
                      onChange={(e) => {
                        const pop = parseInt(e.target.value) || 0;
                        const demand = calculateNodeDemand(pop, 200, 2.5);
                        const resultEl = document.getElementById('demand-result');
                        if (resultEl) {
                          resultEl.textContent = `${demand.toFixed(2)} L/s (${(demand * 3600).toFixed(0)} L/h)`;
                        }
                      }}
                    />
                  </div>
                  <div className="bg-white/5 p-4 rounded-lg">
                    <p className="text-gray-400 text-sm">{language === 'ar' ? 'الطلب المحسوب (ذروة):' : 'Peak Demand:'}</p>
                    <p id="demand-result" className="text-xl font-bold text-cyan-300">5.79 L/s (20833 L/h)</p>
                  </div>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
                <h3 className="text-xl font-bold text-white mb-4">🔥 {language === 'ar' ? 'متطلبات الإطفاء' : 'Fire Flow Requirements'}</h3>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { type: 'residential' as const, ar: 'سكني', en: 'Residential', icon: '🏠' },
                    { type: 'commercial' as const, ar: 'تجاري', en: 'Commercial', icon: '🏢' },
                    { type: 'industrial' as const, ar: 'صناعي', en: 'Industrial', icon: '🏭' },
                    { type: 'high_rise' as const, ar: 'أبراج', en: 'High Rise', icon: '🏙️' }
                  ].map(item => (
                    <div key={item.type} className="bg-white/5 p-3 rounded-lg text-center">
                      <p className="text-2xl mb-1">{item.icon}</p>
                      <p className="text-sm text-gray-400">{language === 'ar' ? item.ar : item.en}</p>
                      <p className="text-lg font-bold text-orange-300">{calculateFireFlow(item.type)} L/s</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
