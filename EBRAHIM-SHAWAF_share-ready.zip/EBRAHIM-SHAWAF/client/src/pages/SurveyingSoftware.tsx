import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Download, Star, Globe } from "lucide-react";
import { useLanguage } from "@/lib/i18n";

export default function SurveyingSoftware() {
  const software = [
    {
      name: "AutoCAD",
      category: "تصميم CAD",
      developer: "Autodesk",
      level: "احترافي",
      price: "مدفوع",
      icon: "📐",
      description: "برنامج رسم ونمذجة ثنائية وثلاثية الأبعاد عملاق",
      features: [
        "رسم دقيق جداً بدقة ميليمتر",
        "مكتبة ضخمة من الأدوات الهندسية",
        "دعم ملفات DXF و DWG",
        "إمكانية التعديل والتحديث السريع",
        "يدعم الإضافات والتوسعات",
        "نمذجة ثلاثية الأبعاد متقدمة"
      ],
      usage: [
        "رسم الخطط المعمارية والهندسية",
        "تصميم المشاريع الضخمة",
        "إنشاء نماذج ثلاثية الأبعاد",
        "استخراج الإحداثيات والأبعاد",
        "التعاون بين الفرق الهندسية"
      ],
      pros: "الأفضل والأكثر استخداماً عالمياً، دقة عالية جداً، توافقية عالية",
      cons: "سعر غالي جداً، منحنى تعلم حاد، يحتاج موارد حاسوب عالية"
    },
    {
      name: "ArcGIS",
      category: "نظم المعلومات الجغرافية (GIS)",
      developer: "Esri",
      level: "احترافي",
      price: "مدفوع",
      icon: "🗺️",
      description: "برنامج متخصص في معالجة البيانات الجغرافية والخرائط",
      features: [
        "إنشاء وتحليل الخرائط الرقمية",
        "معالجة البيانات الجغرافية الضخمة",
        "دمج صور الأقمار الصناعية والطائرات بدون طيار",
        "تحليل مكاني متقدم",
        "إنشاء خرائط ثلاثية الأبعاد",
        "مشاركة الخرائط عبر الإنترنت"
      ],
      usage: [
        "رسم الخرائط الجغرافية والحضرية",
        "تحليل الأراضي والموارد الطبيعية",
        "التخطيط العمراني والتطوير",
        "الدراسات البيئية والجيولوجية",
        "إدارة الكوارث والمشاريع"
      ],
      pros: "متخصص في البيانات الجغرافية، قوي في التحليل المكاني، واجهة حديثة",
      cons: "مكلف جداً، يحتاج تدريب متخصص، حجم البرنامج كبير"
    },
    {
      name: "Civil 3D",
      category: "الهندسة المدنية",
      developer: "Autodesk",
      level: "احترافي",
      price: "مدفوع",
      icon: "🏗️",
      description: "برنامج متخصص في تصميم المشاريع الهندسية المدنية",
      features: [
        "تصميم الطرق والجسور والأنفاق",
        "معالجة بيانات المساح والرفع الجيوديسي",
        "تحليل المنحدرات والقطاعات",
        "حساب الحجوم والمساحات تلقائياً",
        "رسم ملفات مفصلة للبناء",
        "دعم البيانات الحقيقية من أجهزة GPS والمساح"
      ],
      usage: [
        "تصميم الطرق والبنية التحتية",
        "مشاريع الجسور والأنفاق",
        "أعمال الصرف والتصريف",
        "التطوير العقاري الضخم",
        "المشاريع الحكومية الكبرى"
      ],
      pros: "متخصص تماماً للمدنيين، يتعامل مع الملفات الجيوديسية، دقة عالية",
      cons: "سعر غالي جداً، يحتاج خبرة مدنية، محصور في المشاريع المدنية"
    },
    {
      name: "QGIS",
      category: "نظم المعلومات الجغرافية (GIS)",
      developer: "Open Source",
      level: "متوسط",
      price: "مجاني",
      icon: "🆓",
      description: "برنامج GIS مجاني ومفتوح المصدر قوي وموثوق",
      features: [
        "إنشاء وتحليل الخرائط الجغرافية",
        "معالجة صور الأقمار الصناعية",
        "دعم جميع صيغ GIS الشهيرة",
        "أدوات تحليل مكاني قوية",
        "مشاركة المشاريع والبيانات",
        "توسعات وإضافات متاحة"
      ],
      usage: [
        "رسم الخرائط الجغرافية",
        "تحليل الأراضي والموارد",
        "الدراسات البيئية",
        "التخطيط المدني",
        "البحث الأكاديمي والتعليم"
      ],
      pros: "مجاني تماماً، مفتوح المصدر، قوي جداً، دعم مجتمع كبير",
      cons: "واجهة قد تكون معقدة قليلاً، قد يكون أبطأ من الخيارات المدفوعة"
    },
    {
      name: "Google Earth Pro",
      category: "الخرائط والتصوير الجوي",
      developer: "Google",
      level: "متوسط",
      price: "مجاني",
      icon: "🌍",
      description: "برنامج تصفح الأرض ثلاثية الأبعاد مع صور أقمار صناعية حقيقية",
      features: [
        "صور أقمار صناعية عالية الدقة",
        "عرض ثلاثي الأبعاد للمدن والمباني",
        "قياس المسافات والمساحات",
        "تحديد الإحداثيات الجغرافية",
        "عرض المشاريع التاريخية",
        "تحميل البيانات الجغرافية"
      ],
      usage: [
        "البحث عن المواقع والمناطق",
        "قياسات سريعة وتقريبية",
        "دراسة التضاريس والمنحدرات",
        "المشاريع والتخطيط الأولي",
        "الدراسات البيئية والجيولوجية"
      ],
      pros: "مجاني، سهل الاستخدام جداً، صور حديثة، يعمل على أي حاسب",
      cons: "دقة أقل من المتخصصة، ميزات محدودة للمحترفين، يحتاج إنترنت"
    },
    {
      name: "Global Mapper",
      category: "معالجة البيانات الجغرافية",
      developer: "Blue Marble Geographics",
      level: "احترافي",
      price: "مدفوع",
      icon: "🌐",
      description: "برنامج متخصص في معالجة وتحليل البيانات الجغرافية الكبيرة",
      features: [
        "معالجة بيانات الأقمار الصناعية والطائرات بدون طيار",
        "تحليل DEMs والارتفاعات",
        "معالجة صور البث الدرونز",
        "تصنيف البيانات واستخلاص الميزات",
        "دعم جميع صيغ البيانات الجغرافية",
        "تحليل مكاني متقدم"
      ],
      usage: [
        "معالجة بيانات الأقمار الصناعية",
        "تحليل صور الطائرات بدون طيار",
        "الدراسات البيئية والجيولوجية",
        "التصنيف والاستخلاص الآلي",
        "مشاريع البحث والتطوير"
      ],
      pros: "متخصص في معالجة البيانات الجغرافية، سريع وكفء، دعم متكامل",
      cons: "سعر مرتفع، يحتاج معرفة متقدمة بالبيانات الجغرافية"
    },
    {
      name: "Leica Infinity",
      category: "معالجة بيانات المساح",
      developer: "Leica Geosystems",
      level: "احترافي",
      price: "مدفوع",
      icon: "📊",
      description: "برنامج متخصص في معالجة بيانات أجهزة القياس والمساح المتقدمة",
      features: [
        "معالجة بيانات المحطات العاملة",
        "حساب الإحداثيات الدقيقة",
        "معالجة بيانات GNSS والمحطات الثابتة",
        "إنشاء نماذج ثلاثية الأبعاد دقيقة",
        "تحليل الشبكات الجيوديسية",
        "توليد التقارير الفنية"
      ],
      usage: [
        "معالجة بيانات المساح الهندسي",
        "المشاريع الجيوديسية الدقيقة",
        "البنية التحتية والطرق",
        "المشاريع الحكومية والكبرى",
        "الأعمال الجيولوجية والبحثية"
      ],
      pros: "متخصص تماماً للمساحين، دقة عالية جداً، دعم فني قوي",
      cons: "سعر غالي جداً، يحتاج تدريب متخصص، محصور في المتخصصين"
    },
    {
      name: "Trimble Survey",
      category: "معالجة بيانات المساح",
      developer: "Trimble",
      level: "احترافي",
      price: "مدفوع",
      icon: "🎯",
      description: "برنامج متكامل لمعالجة بيانات أجهزة Trimble ومشاريع المساح",
      features: [
        "معالجة بيانات GNSS الدقيقة",
        "معالجة بيانات المحطات العاملة",
        "حساب الإحداثيات والمناسيب",
        "معالجة شبكات GPS المتعددة",
        "إنشاء خرائط دقيقة",
        "توليد تقارير فنية متقدمة"
      ],
      usage: [
        "المشاريع الجيوديسية",
        "المساح الهندسي",
        "البنية التحتية",
        "الأعمال البنائية الدقيقة",
        "المشاريع الحكومية"
      ],
      pros: "متخصص لأجهزة Trimble، دقة عالية، دعم فني متميز",
      cons: "سعر غالي، يحتاج أجهزة Trimble، محصور في متخصصين"
    },
    {
      name: "DroneDeploy",
      category: "معالجة بيانات الطائرات بدون طيار",
      developer: "DroneDeploy",
      level: "متوسط",
      price: "مجاني + مدفوع",
      icon: "🚁",
      description: "منصة سحابية لمعالجة بيانات الطائرات بدون طيار وإنشاء خرائط",
      features: [
        "تحميل صور من الطائرات بدون طيار",
        "إنشاء خرائط أورثوفوتو",
        "إنشاء نماذج ثلاثية الأبعاد",
        "قياسات دقيقة من الصور",
        "تتبع المشاريع والمقارنة",
        "تصدير النتائج بصيغ متعددة"
      ],
      usage: [
        "معالجة بيانات الطائرات بدون طيار",
        "إنشاء خرائط المشاريع",
        "النمذجة ثلاثية الأبعاد",
        "مراقبة المشاريع والتطور",
        "الدراسات البيئية والزراعية"
      ],
      pros: "سهل الاستخدام، معالجة سحابية سريعة، نتائج عالية الجودة",
      cons: "يحتاج طائرة بدون طيار، قد يكون مكلفاً للحجوم الكبيرة"
    },
    {
      name: "Pix4D",
      category: "معالجة الصور الجوية",
      developer: "Pix4D",
      level: "احترافي",
      price: "مدفوع",
      icon: "📸",
      description: "برنامج متقدم لمعالجة الصور الجوية وإنشاء خرائط ونماذج",
      features: [
        "معالجة آلية للصور الجوية",
        "إنشاء أورثوفوتو عالية الدقة",
        "نمذجة ثلاثية الأبعاد دقيقة",
        "استخلاص الإحداثيات الدقيقة",
        "تحليل المحاصيل الزراعية",
        "إنشاء نماذج رقمية للارتفاع"
      ],
      usage: [
        "معالجة بيانات الطائرات بدون طيار",
        "الدراسات الزراعية والبيئية",
        "الخرائط الدقيقة للمشاريع",
        "النمذجة ثلاثية الأبعاد",
        "الأبحاث والدراسات الأكاديمية"
      ],
      pros: "دقة عالية جداً، معالجة متقدمة، دعم متكامل",
      cons: "سعر غالي جداً، يحتاج معرفة تقنية عالية"
    },
    {
      name: "Surfer",
      category: "نمذجة البيانات والرسم البياني",
      developer: "Golden Software",
      level: "متوسط",
      price: "مدفوع",
      icon: "📈",
      description: "برنامج متخصص في إنشاء نماذج سطحية وخرائط من البيانات الجغرافية",
      features: [
        "إنشاء نماذج سطحية من البيانات",
        "رسم خطوط الكنتور (Contour Maps)",
        "تحليل الارتفاعات والمنحدرات",
        "معالجة البيانات الجيولوجية",
        "إنشاء رسوم بيانية متقدمة",
        "تصدير النتائج بصيغ متعددة"
      ],
      usage: [
        "نمذجة البيانات الجيولوجية",
        "إنشاء خرائط الكنتور",
        "تحليل الارتفاعات",
        "الدراسات البيئية والجيوفيزيائية",
        "البحث الأكاديمي"
      ],
      pros: "متخصص في النمذجة، دقة عالية، سهل الاستخدام نسبياً",
      cons: "سعر مرتفع، محصور في نمذجة البيانات"
    }
  ];

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 to-slate-800 text-white" data-testid="surveying-software-page">
      {/* Navigation */}
      <div className="sticky top-0 z-10 bg-black/30 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">برامج المساحة</h1>
          <Link href="/">
            <Button variant="ghost" className="text-white hover:bg-white/10" data-testid="button-back-home">
              <ArrowRight className="w-4 h-4 ml-2" />
              العودة للرئيسية
            </Button>
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="mb-12">
          <h2 className="text-5xl font-bold mb-4 text-blue-400">أفضل برامج المساحة</h2>
          <p className="text-xl text-gray-300 max-w-3xl">
            دليل شامل لأفضل البرامج المستخدمة في مجال المساحة والهندسة بشرح مفصل لكل برنامج وميزاته واستخداماته.
          </p>
        </div>

        {/* Software Grid */}
        <div className="space-y-8">
          {software.map((app, index) => (
            <div
              key={index}
              className="bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10 hover:border-blue-400/50 transition"
              data-testid={`software-card-${index}`}
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-6">
                <div className="flex gap-4 flex-1">
                  <div className="text-5xl">{app.icon}</div>
                  <div>
                    <h3 className="text-3xl font-bold text-white mb-1">{app.name}</h3>
                    <p className="text-sm text-gray-400">
                      {app.category} • {app.developer}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className={`inline-block px-3 py-1 rounded-full text-sm font-bold mb-2 ${
                    app.price === "مجاني" 
                      ? "bg-green-500/20 text-green-400" 
                      : "bg-orange-500/20 text-orange-400"
                  }`}>
                    {app.price}
                  </span>
                  <span className={`block px-3 py-1 rounded-full text-sm font-bold ${
                    app.level === "احترافي"
                      ? "bg-red-500/20 text-red-400"
                      : app.level === "متوسط"
                      ? "bg-yellow-500/20 text-yellow-400"
                      : "bg-blue-500/20 text-blue-400"
                  }`}>
                    {app.level}
                  </span>
                </div>
              </div>

              {/* Description */}
              <p className="text-lg text-gray-300 mb-6 pb-6 border-b border-white/10">
                {app.description}
              </p>

              {/* Content Grid */}
              <div className="grid md:grid-cols-2 gap-8 mb-8">
                {/* Features */}
                <div>
                  <h4 className="text-xl font-bold text-blue-400 mb-4">✨ الميزات الرئيسية</h4>
                  <ul className="space-y-2">
                    {app.features.map((feature, i) => (
                      <li key={i} className="flex gap-3 text-gray-300">
                        <span className="text-blue-400 font-bold">✓</span>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Usage */}
                <div>
                  <h4 className="text-xl font-bold text-green-400 mb-4">🎯 الاستخدامات</h4>
                  <ul className="space-y-2">
                    {app.usage.map((use, i) => (
                      <li key={i} className="flex gap-3 text-gray-300">
                        <span className="text-green-400 font-bold">•</span>
                        <span>{use}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Pros and Cons */}
              <div className="grid md:grid-cols-2 gap-6 pt-6 border-t border-white/10">
                <div className="bg-green-500/10 border border-green-400/30 rounded-lg p-4">
                  <h5 className="text-lg font-bold text-green-400 mb-2">✅ المميزات</h5>
                  <p className="text-gray-300 text-sm">{app.pros}</p>
                </div>
                <div className="bg-red-500/10 border border-red-400/30 rounded-lg p-4">
                  <h5 className="text-lg font-bold text-red-400 mb-2">⚠️ العيوب</h5>
                  <p className="text-gray-300 text-sm">{app.cons}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Comparison Table */}
        <div className="mt-16 bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10">
          <h3 className="text-3xl font-bold text-blue-400 mb-8">📊 جدول المقارنة</h3>
          
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/20">
                  <th className="text-left py-4 px-4 font-bold text-white">البرنامج</th>
                  <th className="text-center py-4 px-4 font-bold text-white">السعر</th>
                  <th className="text-center py-4 px-4 font-bold text-white">المستوى</th>
                  <th className="text-center py-4 px-4 font-bold text-white">سهولة الاستخدام</th>
                  <th className="text-center py-4 px-4 font-bold text-white">الدقة</th>
                </tr>
              </thead>
              <tbody>
                {software.map((app, i) => (
                  <tr key={i} className="border-b border-white/10 hover:bg-white/5 transition">
                    <td className="py-4 px-4 text-white font-semibold">{app.name}</td>
                    <td className="py-4 px-4 text-center text-gray-300">{app.price}</td>
                    <td className="py-4 px-4 text-center text-gray-300">{app.level}</td>
                    <td className="py-4 px-4 text-center">
                      <span className={`${
                        app.level === "احترافي" ? "text-red-400" : "text-yellow-400"
                      }`}>
                        {"★".repeat(app.level === "متوسط" ? 3 : 2)}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-center text-blue-400 font-bold">
                      {"★".repeat(5)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recommendations */}
        <div className="mt-16 grid md:grid-cols-3 gap-6">
          <div className="bg-blue-500/20 border border-blue-400/50 rounded-xl p-8">
            <h4 className="text-xl font-bold text-blue-400 mb-4">🏆 للمبتدئين</h4>
            <ul className="space-y-2 text-gray-300">
              <li className="flex gap-2">
                <span className="text-blue-400">✓</span>
                <span>Google Earth Pro</span>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-400">✓</span>
                <span>QGIS</span>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-400">✓</span>
                <span>DroneDeploy</span>
              </li>
            </ul>
          </div>

          <div className="bg-yellow-500/20 border border-yellow-400/50 rounded-xl p-8">
            <h4 className="text-xl font-bold text-yellow-400 mb-4">⚡ للمتوسطين</h4>
            <ul className="space-y-2 text-gray-300">
              <li className="flex gap-2">
                <span className="text-yellow-400">✓</span>
                <span>ArcGIS</span>
              </li>
              <li className="flex gap-2">
                <span className="text-yellow-400">✓</span>
                <span>Surfer</span>
              </li>
              <li className="flex gap-2">
                <span className="text-yellow-400">✓</span>
                <span>Global Mapper</span>
              </li>
            </ul>
          </div>

          <div className="bg-red-500/20 border border-red-400/50 rounded-xl p-8">
            <h4 className="text-xl font-bold text-red-400 mb-4">🚀 للمحترفين</h4>
            <ul className="space-y-2 text-gray-300">
              <li className="flex gap-2">
                <span className="text-red-400">✓</span>
                <span>AutoCAD + Civil 3D</span>
              </li>
              <li className="flex gap-2">
                <span className="text-red-400">✓</span>
                <span>Leica Infinity</span>
              </li>
              <li className="flex gap-2">
                <span className="text-red-400">✓</span>
                <span>Pix4D</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Tips Section */}
        <div className="mt-16 bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10">
          <h3 className="text-3xl font-bold text-cyan-400 mb-8">💡 نصائح اختيار البرنامج</h3>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h4 className="text-lg font-bold text-white mb-3">للمبتدئين:</h4>
              <ul className="space-y-2 text-gray-300 text-sm">
                <li>✓ ابدأ ببرامج مجانية مثل QGIS و Google Earth</li>
                <li>✓ تعلم الأساسيات قبل الانتقال للبرامج الاحترافية</li>
                <li>✓ استخدم مصادر تعليمية مجانية على الإنترنت</li>
                <li>✓ مارس البرنامج على مشاريع بسيطة أولاً</li>
              </ul>
            </div>

            <div className="space-y-4">
              <h4 className="text-lg font-bold text-white mb-3">للمحترفين:</h4>
              <ul className="space-y-2 text-gray-300 text-sm">
                <li>✓ اختر البرنامج حسب نوع مشروعك</li>
                <li>✓ استثمر في التدريب المتقدم والشهادات</li>
                <li>✓ ابقَ محدثاً بأحدث الإصدارات والميزات</li>
                <li>✓ استخدم دمج عدة برامج حسب احتياجاتك</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
