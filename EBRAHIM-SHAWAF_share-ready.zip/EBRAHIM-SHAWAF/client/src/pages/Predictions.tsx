import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChart, TrendingUp } from "lucide-react";
import type { Vote, Prediction, Candidate, District } from "@shared/schema";

async function fetchPredictionData() {
  const [districtRes, candidateRes, voteRes, predRes] = await Promise.all([
    fetch("/api/districts"),
    fetch("/api/candidates"),
    fetch("/api/votes"),
    fetch("/api/predictions"),
  ]);

  return {
    districts: (await districtRes.json()) as District[],
    candidates: (await candidateRes.json()) as Candidate[],
    votes: (await voteRes.json()) as Vote[],
    predictions: (await predRes.json()) as (Prediction & { candidate?: Candidate })[],
  };
}

export default function Predictions() {
  const { data, isLoading, refetch } = useQuery({
    queryKey: ["predictions"],
    queryFn: fetchPredictionData,
    refetchInterval: 10000,
  });

  const [selectedDistrict, setSelectedDistrict] = useState<string | null>(null);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-card to-background p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-[500px]" />
        </div>
      </div>
    );
  }

  const { districts, candidates, votes, predictions } = data!;

  const filteredPredictions = selectedDistrict
    ? predictions.filter(p => p.districtId === selectedDistrict)
    : predictions;

  const selectedDistrictData = selectedDistrict 
    ? districts.find(d => d.id === selectedDistrict)
    : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card to-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground py-8 px-6 shadow-xl">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-4 mb-2">
            <TrendingUp className="w-10 h-10" />
            <h1 className="text-4xl font-bold" data-testid="predictions-title">
              التنبؤات الانتخابية
            </h1>
          </div>
          <p className="text-primary-foreground/80 text-lg">
            تحليل التوقعات المقارنة مع النتائج الفعلية
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6 space-y-6">
        {/* Summary Stats */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl font-bold flex items-center gap-2">
              <BarChart className="w-6 h-6" />
              ملخص المقارنة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-card rounded-lg border border-border">
                <div className="text-sm text-muted-foreground mb-1">المحافظات المحللة</div>
                <div className="text-3xl font-bold" data-testid="total-districts-pred">
                  {districts.length}
                </div>
              </div>
              <div className="p-4 bg-card rounded-lg border border-border">
                <div className="text-sm text-muted-foreground mb-1">التنبؤات</div>
                <div className="text-3xl font-bold text-accent" data-testid="total-predictions">
                  {predictions.length}
                </div>
              </div>
              <div className="p-4 bg-card rounded-lg border border-border">
                <div className="text-sm text-muted-foreground mb-1">متوسط الثقة</div>
                <div className="text-3xl font-bold text-chart-1">
                  {(predictions.reduce((sum, p) => sum + (p.confidence || 0.85), 0) / predictions.length * 100).toFixed(0)}%
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* District Selector and Details */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* District List */}
          <Card className="shadow-lg lg:col-span-1">
            <CardHeader>
              <CardTitle className="text-lg">المحافظات</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {districts.map((district) => (
                  <Button
                    key={district.id}
                    variant={selectedDistrict === district.id ? "default" : "outline"}
                    className="w-full justify-start text-right"
                    onClick={() => setSelectedDistrict(district.id)}
                    data-testid={`district-button-${district.id}`}
                  >
                    {district.name}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Detailed Comparison */}
          <Card className="lg:col-span-2 shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg">
                {selectedDistrictData ? `مقارنة: ${selectedDistrictData.name}` : "اختر محافظة للمقارنة"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedDistrictData ? (
                <div className="space-y-4">
                  {candidates.map((candidate) => {
                    const actualVote = votes.find(
                      v => v.districtId === selectedDistrict && v.candidateId === candidate.id
                    );
                    const prediction = filteredPredictions.find(
                      p => p.candidateId === candidate.id
                    );

                    const actual = actualVote?.voteCount || 0;
                    const predicted = Math.round(prediction?.predictedVotes || 0);
                    const difference = predicted - actual;
                    const percentDiff = actual > 0 ? ((difference / actual) * 100).toFixed(1) : "0";

                    return (
                      <div
                        key={candidate.id}
                        className="pb-4 border-b last:border-b-0 space-y-3"
                        data-testid={`comparison-${candidate.id}`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <Badge
                              style={{ backgroundColor: candidate.color }}
                              className="text-white"
                            >
                              {candidate.name}
                            </Badge>
                            <span className="text-sm text-muted-foreground">
                              {candidate.party}
                            </span>
                          </div>
                          {prediction && (
                            <Badge variant="secondary">
                              ثقة: {(prediction.confidence * 100).toFixed(0)}%
                            </Badge>
                          )}
                        </div>

                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div className="bg-secondary p-3 rounded-lg">
                            <div className="text-muted-foreground text-xs mb-1">
                              الأصوات الفعلية
                            </div>
                            <div className="text-xl font-bold">
                              {actual.toLocaleString("ar-EG")}
                            </div>
                          </div>
                          <div className="bg-accent/10 p-3 rounded-lg">
                            <div className="text-muted-foreground text-xs mb-1">
                              الأصوات المتوقعة
                            </div>
                            <div className="text-xl font-bold text-accent">
                              {predicted.toLocaleString("ar-EG")}
                            </div>
                          </div>
                          <div
                            className={`p-3 rounded-lg ${
                              difference >= 0 ? "bg-green-500/10" : "bg-red-500/10"
                            }`}
                          >
                            <div className="text-muted-foreground text-xs mb-1">
                              الفرق
                            </div>
                            <div
                              className={`text-xl font-bold ${
                                difference >= 0 ? "text-green-600" : "text-red-600"
                              }`}
                            >
                              {difference >= 0 ? "+" : ""}{difference.toLocaleString("ar-EG")}
                              ({percentDiff}%)
                            </div>
                          </div>
                        </div>

                        {/* Progress bar comparison */}
                        <div className="space-y-2">
                          <div className="flex justify-between text-xs">
                            <span>الفعلي</span>
                            <span>{actual.toLocaleString("ar-EG")}</span>
                          </div>
                          <div className="w-full bg-secondary rounded-full h-2 overflow-hidden">
                            <div
                              className="h-full bg-primary"
                              style={{
                                width: actual > predicted ? "100%" : `${(actual / Math.max(actual, predicted)) * 100}%`,
                              }}
                            />
                          </div>

                          <div className="flex justify-between text-xs mt-3">
                            <span>المتوقع</span>
                            <span>{predicted.toLocaleString("ar-EG")}</span>
                          </div>
                          <div className="w-full bg-secondary rounded-full h-2 overflow-hidden">
                            <div
                              className="h-full bg-accent"
                              style={{
                                width: predicted > actual ? "100%" : `${(predicted / Math.max(actual, predicted)) * 100}%`,
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12 text-muted-foreground">
                  اختر محافظة من القائمة لعرض المقارنة التفصيلية
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
