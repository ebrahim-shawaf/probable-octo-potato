import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import ElectionMap from "@/components/ElectionMap";
import { BarChart, Users, MapPin, TrendingUp } from "lucide-react";
import type { District, Candidate, Vote, Subarea } from "@shared/schema";

async function fetchResults() {
  const [districtsRes, candidatesRes, resultsRes, subareasRes] = await Promise.all([
    fetch("/api/districts"),
    fetch("/api/candidates"),
    fetch("/api/results"),
    fetch("/api/subareas"),
  ]);

  const districts: District[] = await districtsRes.json();
  const candidates: Candidate[] = await candidatesRes.json();
  const results: Array<{
    district: District;
    votes: Array<Vote & { candidate: Candidate }>;
  }> = await resultsRes.json();
  const subareas: Subarea[] = await subareasRes.json();

  return { districts, candidates, results, subareas };
}

export default function Dashboard() {
  const { data, isLoading } = useQuery({
    queryKey: ["election-results"],
    queryFn: fetchResults,
    refetchInterval: 5000, // Auto-refresh every 5 seconds
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-card to-background p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <Skeleton className="h-20 w-full" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
          </div>
          <Skeleton className="h-[600px]" />
        </div>
      </div>
    );
  }

  const { districts, candidates, results, subareas } = data!;

  const totalVotes = results.reduce(
    (sum, r) => sum + r.votes.reduce((s, v) => s + v.voteCount, 0),
    0
  );

  const candidateVotes = candidates.map(candidate => ({
    candidate,
    total: results.reduce(
      (sum, r) =>
        sum +
        (r.votes.find(v => v.candidateId === candidate.id)?.voteCount || 0),
      0
    ),
  }));

  candidateVotes.sort((a, b) => b.total - a.total);
  const leader = candidateVotes[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card to-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground py-8 px-6 shadow-xl">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-4 mb-2">
            <BarChart className="w-10 h-10" />
            <h1 className="text-4xl font-bold" data-testid="page-title">
              نتائج الانتخابات المصرية
            </h1>
          </div>
          <p className="text-primary-foreground/80 text-lg">
            متابعة حية للنتائج على مستوى المحافظات
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="border-2 border-primary/20 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-semibold">إجمالي الأصوات</CardTitle>
              <Users className="w-6 h-6 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary" data-testid="total-votes">
                {totalVotes.toLocaleString("ar-EG")}
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-accent/20 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-semibold">المحافظات</CardTitle>
              <MapPin className="w-6 h-6 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-accent" data-testid="total-districts">
                {districts.length}
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-chart-1/20 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-semibold">المتصدر</CardTitle>
              <TrendingUp className="w-6 h-6 text-chart-1" />
            </CardHeader>
            <CardContent>
              {leader && (
                <div>
                  <div className="text-2xl font-bold" data-testid="leader-name">
                    {leader.candidate.name}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {leader.total.toLocaleString("ar-EG")} صوت
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Map and Results */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Map */}
          <Card className="lg:col-span-2 shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl font-bold flex items-center gap-2">
                <MapPin className="w-6 h-6 text-primary" />
                الخريطة التفاعلية
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[600px]">
                <ElectionMap
                  districts={districts}
                  candidates={candidates}
                  results={results}
                  subareas={subareas}
                />
              </div>
            </CardContent>
          </Card>

          {/* Candidate Results */}
          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl font-bold">النتائج الإجمالية</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {candidateVotes.map((item, index) => {
                const percentage = totalVotes > 0 
                  ? ((item.total / totalVotes) * 100).toFixed(1)
                  : "0";
                
                return (
                  <div
                    key={item.candidate.id}
                    className="space-y-2 pb-4 border-b last:border-b-0"
                    data-testid={`candidate-result-${item.candidate.id}`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge
                          style={{ backgroundColor: item.candidate.color }}
                          className="text-white"
                        >
                          {index + 1}
                        </Badge>
                        <div>
                          <div className="font-bold text-lg">
                            {item.candidate.name}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {item.candidate.party}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="font-semibold">
                          {item.total.toLocaleString("ar-EG")} صوت
                        </span>
                        <span className="text-muted-foreground">
                          {percentage}%
                        </span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-3 overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{
                            width: `${percentage}%`,
                            backgroundColor: item.candidate.color,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
