import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Map, Calculator, Camera, Globe, Droplets, Ruler, FileText, Settings, Download, Smartphone, RefreshCw, MapPin, HelpCircle, Sun, Moon } from "lucide-react";
import { useLanguage, useTheme } from "@/lib/i18n";
import { QRCodeSVG } from "qrcode.react";
import { useState } from "react";
import { toast } from "sonner";
import FeatureTour from "@/components/FeatureTour";

export default function Home() {
  const { language, toggleLanguage } = useLanguage();
  const { isDark, toggleTheme } = useTheme();
  const isRTL = language === 'ar';
  const [showQR, setShowQR] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [cameraPermission, setCameraPermission] = useState<string>('');
  const [locationPermission, setLocationPermission] = useState<string>('');

  const handleUpdateApp = async () => {
    setIsUpdating(true);
    try {
      if ('serviceWorker' in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (const registration of registrations) {
          await registration.update();
          if (registration.waiting) {
            registration.waiting.postMessage({ type: 'SKIP_WAITING' });
          }
        }
      }
      if ('caches' in window) {
        const cacheNames = await caches.keys();
        await Promise.all(cacheNames.map(name => caches.delete(name)));
      }
      toast.success(language === 'ar' ? '✅ تم تحديث التطبيق بنجاح! جاري إعادة التحميل...' : '✅ App updated! Reloading...');
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    } catch (error) {
      toast.error(language === 'ar' ? '❌ فشل في التحديث' : '❌ Update failed');
    } finally {
      setIsUpdating(false);
    }
  };

  const requestCameraPermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      stream.getTracks().forEach(track => track.stop());
      setCameraPermission('granted');
      toast.success(language === 'ar' ? '✅ تم السماح بالوصول للكاميرا' : '✅ Camera access granted');
    } catch (error) {
      setCameraPermission('denied');
      toast.error(language === 'ar' ? '❌ تم رفض الوصول للكاميرا' : '❌ Camera access denied');
    }
  };

  const requestLocationPermission = async () => {
    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true });
      });
      setLocationPermission('granted');
      toast.success(language === 'ar' 
        ? `✅ تم تحديد موقعك: ${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}` 
        : `✅ Location: ${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}`);
    } catch (error) {
      setLocationPermission('denied');
      toast.error(language === 'ar' ? '❌ تم رفض الوصول للموقع' : '❌ Location access denied');
    }
  };
  
  const appUrl = typeof window !== 'undefined' ? window.location.origin : '';

  const mainTools = [
    {
      id: 'camera',
      icon: '📷',
      title: language === 'ar' ? 'أدوات الكاميرا والميدان' : 'Camera & Field Tools',
      desc: language === 'ar' ? 'قياس المسافات، تحديد GPS، التقاط الإحداثيات' : 'Distance measurement, GPS location, Coordinate capture',
      color: 'from-blue-600 to-blue-800',
      border: 'border-blue-400/30 hover:border-blue-400/60',
      href: '/camera'
    },
    {
      id: 'water',
      icon: '💧',
      title: language === 'ar' ? 'محلل شبكات المياه' : 'Water Network Analyzer',
      desc: language === 'ar' ? 'تحليل الشبكات، حساب الضغط، الخرائط التفاعلية' : 'Network analysis, Pressure calculation, Interactive maps',
      color: 'from-cyan-600 to-cyan-800',
      border: 'border-cyan-400/30 hover:border-cyan-400/60',
      href: '/water-network'
    },
    {
      id: 'calculator',
      icon: '📐',
      title: language === 'ar' ? 'حاسبات المساحة' : 'Survey Calculators',
      desc: language === 'ar' ? 'حساب المساحات، الأحجام، المسافات' : 'Area, Volume, Distance calculations',
      color: 'from-green-600 to-green-800',
      border: 'border-green-400/30 hover:border-green-400/60',
      href: '/calculator'
    },
    {
      id: 'coordinates',
      icon: '🗺️',
      title: language === 'ar' ? 'استخراج الإحداثيات' : 'Coordinates Extractor',
      desc: language === 'ar' ? 'استخراج من KML/KMZ/DXF، تحويل الإحداثيات' : 'Extract from KML/KMZ/DXF, Convert coordinates',
      color: 'from-orange-600 to-orange-800',
      border: 'border-orange-400/30 hover:border-orange-400/60',
      href: '/coordinates'
    }
  ];

  const quickTools = [
    { icon: '📚', label: language === 'ar' ? 'علم المساحة' : 'Science', href: '/science', large: true },
    { icon: '⛏️', label: language === 'ar' ? 'حفر وردم' : 'Cut & Fill', href: '/cut-fill', large: true },
    { icon: '🏗️', label: language === 'ar' ? 'الخرسانة والفولاذ' : 'Concrete & Steel', href: '/concrete-steel', large: true },
    { icon: '📋', label: language === 'ar' ? 'حصر البنود' : 'BOQ', href: '/structural-boq', large: true },
    { icon: '⚙️', label: language === 'ar' ? 'محول الوحدات' : 'Unit Converter', href: '/unit-converter', large: true },
    { icon: '📁', label: language === 'ar' ? 'حصر CAD' : 'CAD BOQ', href: '/calculator?tool=cad-boq', large: true },
    { icon: '📏', label: language === 'ar' ? 'قياس المسافة' : 'Distance', href: '/calculator?tool=measure' },
    { icon: '⬛', label: language === 'ar' ? 'حساب المساحة' : 'Area', href: '/calculator?tool=area' },
    { icon: '🛣️', label: language === 'ar' ? 'كميات الأسفلت' : 'Asphalt', href: '/calculator?tool=asphalt' },
    { icon: '💧', label: language === 'ar' ? 'تحليل الشبكة' : 'Network', href: '/water-network' },
  ];

  const [showTour, setShowTour] = useState(false);

  const homeTourSteps = [
    {
      id: 'welcome',
      title: language === 'ar' ? '🎉 مرحباً بك في إبراهيم شواف' : '🎉 Welcome to EBRAHIM SHAWAF',
      description: language === 'ar' 
        ? 'تطبيق احترافي للمساحة والهندسة. دعني أعرفك على الأدوات المتاحة!' 
        : 'Professional surveying & engineering app. Let me show you around!'
    },
    {
      id: 'main-tools',
      title: language === 'ar' ? '🛠️ الأدوات الرئيسية' : '🛠️ Main Tools',
      description: language === 'ar'
        ? 'هنا تجد الأدوات الأساسية: أدوات الكاميرا، محلل شبكات المياه، حاسبات المساحة، واستخراج الإحداثيات'
        : 'Here you find the main tools: Camera tools, Water network analyzer, Survey calculators, and Coordinates extractor',
      target: '[data-testid="main-tools-grid"]'
    },
    {
      id: 'quick-access',
      title: language === 'ar' ? '⚡ الوصول السريع' : '⚡ Quick Access',
      description: language === 'ar'
        ? 'أزرار سريعة للوصول المباشر للأدوات الأكثر استخداماً مثل علم المساحة وحاسبة الحفر والردم'
        : 'Quick buttons for direct access to most used tools like Surveying Science and Cut & Fill calculator',
      target: '[data-testid="quick-tools-section"]'
    },
    {
      id: 'download',
      title: language === 'ar' ? '📥 تحميل التطبيق' : '📥 Download App',
      description: language === 'ar'
        ? 'يمكنك تحميل التطبيق على هاتفك للعمل بدون إنترنت. اضغط على زر تحميل APK أو امسح QR Code'
        : 'You can download the app to your phone to work offline. Click Download APK or scan QR Code',
      target: '[data-testid="button-download-apk"]'
    },
    {
      id: 'update',
      title: language === 'ar' ? '🔄 تحديث التطبيق' : '🔄 Update App',
      description: language === 'ar'
        ? 'اضغط على زر التحديث للحصول على أحدث إصدار من التطبيق'
        : 'Click the update button to get the latest version of the app',
      target: '[data-testid="button-update-app"]'
    },
    {
      id: 'permissions',
      title: language === 'ar' ? '📍 الأذونات' : '📍 Permissions',
      description: language === 'ar'
        ? 'فعّل الكاميرا والموقع للاستفادة من جميع ميزات التطبيق في العمل الميداني'
        : 'Enable camera and location to use all app features in field work',
      target: '[data-testid="button-camera-permission"]'
    }
  ];

  const resetTour = () => {
    localStorage.removeItem('tour-home-tour');
    setShowTour(true);
    window.location.reload();
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* خلفية متحركة */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 right-10 w-72 h-72 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-10 left-10 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* شريط التنقل */}
      <div className="sticky top-0 z-50 bg-black/40 backdrop-blur-md border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <img src="/logo.png" alt="Logo" className="w-8 h-8 rounded-lg" />
            <h1 className="text-xl font-bold text-white">EBRAHIM SHAWAF</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button 
              variant="secondary" 
              size="sm" 
              onClick={resetTour}
              className="shadow-lg"
              data-testid="button-help-tour"
            >
              <HelpCircle className="w-4 h-4 ml-1" />
              {language === 'ar' ? '؟' : '?'}
            </Button>
            <Button 
              variant="secondary" 
              size="sm" 
              onClick={handleUpdateApp}
              disabled={isUpdating}
              className="shadow-lg"
              data-testid="button-update-app"
            >
              <RefreshCw className={`w-4 h-4 ml-1 ${isUpdating ? 'animate-spin' : ''}`} />
              {isUpdating ? (language === 'ar' ? 'جاري...' : 'Updating...') : (language === 'ar' ? 'تحديث' : 'Update')}
            </Button>
            <Button 
              variant="secondary" 
              size="sm" 
              onClick={toggleLanguage}
              className="shadow-lg"
              data-testid="button-toggle-language"
            >
              <Globe className="w-4 h-4 ml-2" />
              {language === 'ar' ? 'EN' : 'العربية'}
            </Button>
            <Button 
              variant="secondary" 
              size="sm" 
              onClick={toggleTheme}
              className="shadow-lg"
              data-testid="button-toggle-theme"
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      </div>

      {/* المحتوى الرئيسي */}
      <div className="relative z-10 max-w-6xl mx-auto px-4 py-8">
        
        {/* الترحيب */}
        <div className="text-center mb-10">
          <div className="flex justify-center mb-4">
            <img src="/logo.png" alt="EBRAHIM SHAWAF" className="w-24 h-24 rounded-2xl shadow-2xl" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-3">
            EBRAHIM SHAWAF
          </h1>
          <p className="text-xl text-cyan-300 mb-2">
            {language === 'ar' ? 'أدوات مساحة احترافية' : 'Professional Surveying Tools'}
          </p>
          <p className="text-gray-300 max-w-2xl mx-auto">
            {language === 'ar' 
              ? 'مجموعة شاملة من أدوات المساحة الرقمية للمهندسين والفنيين'
              : 'Comprehensive digital surveying tools for engineers and technicians'}
          </p>
        </div>

        {/* الملف الشخصي */}
        <div className="flex justify-center mb-6">
          <div className="flex items-center gap-4 bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20">
            <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-cyan-400">
              <img src="/profile.jpg" alt="إبراهيم شواف" className="w-full h-full object-cover" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">{language === 'ar' ? 'إبراهيم شواف' : 'Ibrahim Shawaf'}</h2>
              <p className="text-cyan-300 text-sm">{language === 'ar' ? 'مهندس مساحة' : 'Surveying Engineer'}</p>
            </div>
          </div>
        </div>

        {/* معلومات التواصل */}
        <div className="flex justify-center gap-4 mb-8 flex-wrap">
          <a 
            href="https://wa.me/966558898066"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white px-6 py-3 rounded-xl shadow-lg font-medium transition-transform hover:scale-105"
            data-testid="button-whatsapp"
          >
            <span className="text-xl ml-2">💬</span>
            {language === 'ar' ? 'واتسب' : 'WhatsApp'}
          </a>
          <a 
            href="mailto:hemo_sh2007@yahoo.com"
            className="inline-flex items-center bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white px-6 py-3 rounded-xl shadow-lg font-medium transition-transform hover:scale-105"
            data-testid="button-email"
          >
            <span className="text-xl ml-2">📧</span>
            {language === 'ar' ? 'البريد الإلكتروني' : 'Email'}
          </a>
        </div>

        {/* أزرار الأذونات */}
        <div className="flex justify-center gap-3 mb-10 flex-wrap">
          <Button
            onClick={requestCameraPermission}
            className={`px-5 py-2.5 rounded-xl shadow-lg transition-all ${
              cameraPermission === 'granted' 
                ? 'bg-green-600 hover:bg-green-700' 
                : cameraPermission === 'denied'
                ? 'bg-red-600 hover:bg-red-700'
                : 'bg-gradient-to-r from-purple-500 to-violet-600 hover:from-purple-600 hover:to-violet-700'
            }`}
            data-testid="button-camera-permission"
          >
            <Camera className="w-5 h-5 ml-2" />
            {cameraPermission === 'granted' 
              ? (language === 'ar' ? '✓ الكاميرا متاحة' : '✓ Camera Enabled')
              : cameraPermission === 'denied'
              ? (language === 'ar' ? '✗ الكاميرا مرفوضة' : '✗ Camera Denied')
              : (language === 'ar' ? '📷 تفعيل الكاميرا' : '📷 Enable Camera')}
          </Button>
          <Button
            onClick={requestLocationPermission}
            className={`px-5 py-2.5 rounded-xl shadow-lg transition-all ${
              locationPermission === 'granted' 
                ? 'bg-green-600 hover:bg-green-700' 
                : locationPermission === 'denied'
                ? 'bg-red-600 hover:bg-red-700'
                : 'bg-gradient-to-r from-teal-500 to-cyan-600 hover:from-teal-600 hover:to-cyan-700'
            }`}
            data-testid="button-location-permission"
          >
            <MapPin className="w-5 h-5 ml-2" />
            {locationPermission === 'granted' 
              ? (language === 'ar' ? '✓ الموقع متاح' : '✓ Location Enabled')
              : locationPermission === 'denied'
              ? (language === 'ar' ? '✗ الموقع مرفوض' : '✗ Location Denied')
              : (language === 'ar' ? '📍 تفعيل الموقع' : '📍 Enable Location')}
          </Button>
        </div>


        {/* الأدوات الرئيسية */}
        <div className="grid md:grid-cols-2 gap-6 mb-10" data-testid="main-tools-grid">
          {mainTools.map(tool => (
            <Link key={tool.id} href={tool.href}>
              <div className={`bg-gradient-to-br ${tool.color} backdrop-blur-md rounded-2xl p-6 border ${tool.border} transition cursor-pointer group hover:scale-[1.02] hover:shadow-2xl`}>
                <div className="flex items-start gap-4">
                  <div className="text-5xl">{tool.icon}</div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-white mb-2">{tool.title}</h3>
                    <p className="text-gray-200 text-sm">{tool.desc}</p>
                  </div>
                </div>
                <Button size="sm" className="w-full mt-4 bg-white/20 hover:bg-white/30 text-white">
                  {language === 'ar' ? 'فتح' : 'Open'} →
                </Button>
              </div>
            </Link>
          ))}
        </div>

        {/* أدوات سريعة */}
        <div className="mb-10" data-testid="quick-tools-section">
          <h2 className="text-xl font-bold text-white text-center mb-4">
            ⚡ {language === 'ar' ? 'وصول سريع' : 'Quick Access'}
          </h2>
          <div className="flex flex-wrap justify-center gap-3">
            {quickTools.map((tool, idx) => (
              <Link key={idx} href={tool.href}>
                <Button 
                  variant="outline" 
                  className={`bg-white/10 border-white/20 text-white hover:bg-white/20 ${
                    (tool as any).large ? 'text-lg py-3 px-5 bg-gradient-to-r from-amber-500/20 to-orange-500/20 border-amber-400/40 hover:border-amber-400/60' : ''
                  }`}
                >
                  <span className={(tool as any).large ? "text-2xl ml-2" : "text-lg ml-2"}>{tool.icon}</span>
                  {tool.label}
                </Button>
              </Link>
            ))}
          </div>
        </div>

        {/* معلومات عن التطبيق والمميزات */}
        <div className="grid md:grid-cols-3 gap-6 mb-10">
          {/* المميزات */}
          <div className="bg-gradient-to-br from-cyan-500/20 to-blue-500/20 backdrop-blur-md rounded-2xl p-6 border border-cyan-400/30 hover:border-cyan-400/60 transition">
            <h3 className="text-lg font-bold text-cyan-300 mb-4">✨ {language === 'ar' ? 'المميزات' : 'Features'}</h3>
            <ul className="text-gray-300 space-y-2 text-sm">
              <li className="flex gap-2"><span>🎯</span> {language === 'ar' ? 'قياس المسافات والمساحات' : 'Distance & Area'}</li>
              <li className="flex gap-2"><span>💧</span> {language === 'ar' ? 'تحليل شبكات المياه' : 'Water Networks'}</li>
              <li className="flex gap-2"><span>📁</span> {language === 'ar' ? 'استخراج الإحداثيات' : 'Extract Coordinates'}</li>
              <li className="flex gap-2"><span>🔄</span> {language === 'ar' ? 'تحويل الإحداثيات' : 'Convert Systems'}</li>
            </ul>
          </div>

          {/* حالات الاستخدام */}
          <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-md rounded-2xl p-6 border border-purple-400/30 hover:border-purple-400/60 transition">
            <h3 className="text-lg font-bold text-purple-300 mb-4">🎯 {language === 'ar' ? 'الاستخدامات' : 'Use Cases'}</h3>
            <ul className="text-gray-300 space-y-2 text-sm">
              <li className="flex gap-2"><span>🏗️</span> {language === 'ar' ? 'المساحة الميدانية' : 'Field Surveying'}</li>
              <li className="flex gap-2"><span>🌉</span> {language === 'ar' ? 'البنية التحتية' : 'Infrastructure'}</li>
              <li className="flex gap-2"><span>💼</span> {language === 'ar' ? 'إدارة المشاريع' : 'Project Mgmt'}</li>
              <li className="flex gap-2"><span>📐</span> {language === 'ar' ? 'التخطيط الهندسي' : 'Engineering'}</li>
            </ul>
          </div>

          {/* معلومات الاتصال المباشرة */}
          <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 backdrop-blur-md rounded-2xl p-6 border border-orange-400/30 hover:border-orange-400/60 transition">
            <h3 className="text-lg font-bold text-orange-300 mb-4">📞 {language === 'ar' ? 'التواصل' : 'Contact'}</h3>
            <div className="space-y-3 text-sm">
              <div className="flex gap-2 items-start">
                <span className="text-xl">💬</span>
                <div>
                  <p className="text-gray-400 text-xs">{language === 'ar' ? 'واتسب' : 'WhatsApp'}</p>
                  <a href="https://wa.me/966558898066" target="_blank" rel="noopener noreferrer" className="text-green-300 hover:text-green-200 font-mono text-xs">
                    +966558898066
                  </a>
                </div>
              </div>
              <div className="flex gap-2 items-start">
                <span className="text-xl">📧</span>
                <div>
                  <p className="text-gray-400 text-xs">{language === 'ar' ? 'البريد الإلكتروني' : 'Email'}</p>
                  <a href="mailto:hemo_sh2007@yahoo.com" className="text-blue-300 hover:text-blue-200 font-mono text-xs break-all">
                    hemo_sh2007@yahoo.com
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* حقوق النشر */}
        <div className="text-center mt-8 text-gray-400 text-sm">
          <p>© 2025 {language === 'ar' ? 'إبراهيم شواف للمساحة' : 'Ibrahim Shawaf Surveying'}</p>
        </div>
      </div>

      {/* جولة تعريفية */}
      <FeatureTour 
        steps={homeTourSteps}
        language={language}
        tourId="home-tour"
      />
    </div>
  );
}
