import React, { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowRight, Plus, Trash2, Download, Upload, Box, Map } from "lucide-react";
import { useLanguage } from "@/lib/i18n";
import { toast } from "sonner";
import DxfParser from "dxf-parser";
import ColumnViewer3D from "@/components/ColumnViewer3D";
import ColumnMapViewer from "@/components/ColumnMapViewer";
import RawGeometry3DViewer from "@/components/RawGeometry3DViewer";

type ElementType = "column" | "beam" | "wall" | "slab" | "footing" | "stairs" | "opening";

interface StructuralElement {
  id: number;
  type: ElementType;
  length: number;
  width: number;
  height: number;
  thickness?: number;
  qty: number;
}

interface ElementTypeConfig {
  label: { ar: string; en: string };
  icon: string;
  color: string;
  gradientFrom: string;
  gradientTo: string;
  borderColor: string;
}

const elementTypeConfigs: Record<ElementType, ElementTypeConfig> = {
  column: {
    label: { ar: "الأعمدة", en: "Columns" },
    icon: "🏛️",
    color: "purple",
    gradientFrom: "from-purple-500/20",
    gradientTo: "to-pink-600/20",
    borderColor: "border-purple-400/50",
  },
  beam: {
    label: { ar: "الكمرات", en: "Beams" },
    icon: "🔲",
    color: "blue",
    gradientFrom: "from-blue-500/20",
    gradientTo: "to-cyan-600/20",
    borderColor: "border-blue-400/50",
  },
  wall: {
    label: { ar: "الجدران", en: "Walls" },
    icon: "🧱",
    color: "orange",
    gradientFrom: "from-orange-500/20",
    gradientTo: "to-red-600/20",
    borderColor: "border-orange-400/50",
  },
  slab: {
    label: { ar: "الأرضيات", en: "Slabs" },
    icon: "📦",
    color: "green",
    gradientFrom: "from-green-500/20",
    gradientTo: "to-emerald-600/20",
    borderColor: "border-green-400/50",
  },
  footing: {
    label: { ar: "الأساسات", en: "Footings" },
    icon: "⚙️",
    color: "red",
    gradientFrom: "from-red-500/20",
    gradientTo: "to-rose-600/20",
    borderColor: "border-red-400/50",
  },
  stairs: {
    label: { ar: "السلالم", en: "Stairs" },
    icon: "🪜",
    color: "yellow",
    gradientFrom: "from-yellow-500/20",
    gradientTo: "to-amber-600/20",
    borderColor: "border-yellow-400/50",
  },
  opening: {
    label: { ar: "فتحات الأبواب", en: "Door Openings" },
    icon: "🚪",
    color: "pink",
    gradientFrom: "from-pink-500/20",
    gradientTo: "to-rose-600/20",
    borderColor: "border-pink-400/50",
  },
};

export default function ConcreteAndSteelCalculator() {
  const { language } = useLanguage();
  const isRTL = language === "ar";
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const [elements, setElements] = useState<StructuralElement[]>([
    { id: 1, type: "column", length: 0.5, width: 0.5, height: 3, qty: 1 },
  ]);
  const [steelRatio, setSteelRatio] = useState(1.5);
  const [nextId, setNextId] = useState(2);
  const [scale, setScale] = useState(1000);
  const [serverScale, setServerScale] = useState(1); // Scale for server-parsed files
  const [previewElements, setPreviewElements] = useState<StructuralElement[]>(
    []
  );
  const [showPreview, setShowPreview] = useState(false);
  const [viewMode, setViewMode] = useState<"none" | "3d" | "map" | "raw">("none");
  const [isLoadingCAD, setIsLoadingCAD] = useState(false);
  const [rawGeometry, setRawGeometry] = useState<any[]>([]);

  const parseCADFile = (content: string): StructuralElement[] => {
    const newElements: StructuralElement[] = [];
    try {
      const parser = new DxfParser();
      let dxf: any;
      try {
        dxf = parser.parse(content);
      } catch (parseError) {
        toast.error(
          language === "ar"
            ? "❌ صيغة ملف DXF غير صحيحة"
            : "❌ Invalid DXF format"
        );
        return [];
      }

      if (!dxf || !dxf.entities || dxf.entities.length === 0) {
        toast.warning(
          language === "ar"
            ? "⚠️ لم يتم العثور على عناصر في الملف"
            : "⚠️ No entities found in file"
        );
        return [];
      }

      let id = nextId;
      let elementCounts: Record<ElementType, number> = {
        column: 0,
        beam: 0,
        wall: 0,
        slab: 0,
        footing: 0,
        stairs: 0,
        opening: 0,
      };

      dxf.entities.forEach((entity: any) => {
        try {
          let width = 0,
            length = 0,
            height = 0,
            thickness = 0;
          let type: ElementType = "column";

          if (entity.type === "LWPOLYLINE" || entity.type === "POLYLINE") {
            let vertices = entity.vertices || [];
            if (Array.isArray(vertices) && vertices.length >= 3) {
              let xs: number[] = [],
                ys: number[] = [];
              vertices.forEach((v: any) => {
                if (v && typeof v === "object") {
                  const x =
                    v.x !== undefined ? v.x : Array.isArray(v) ? v[0] : 0;
                  const y =
                    v.y !== undefined ? v.y : Array.isArray(v) ? v[1] : 0;
                  if (typeof x === "number" && !isNaN(x)) xs.push(x);
                  if (typeof y === "number" && !isNaN(y)) ys.push(y);
                }
              });

              if (xs.length >= 2 && ys.length >= 2) {
                const maxX = Math.max(...xs);
                const minX = Math.min(...xs);
                const maxY = Math.max(...ys);
                const minY = Math.min(...ys);

                width = Math.abs(maxX - minX) / scale;
                length = Math.abs(maxY - minY) / scale;

                if (width > 0.01 && length > 0.01) {
                  // Determine element type based on aspect ratio
                  const ratio = Math.max(width, length) / Math.min(width, length);
                  if (ratio > 5) {
                    type = "beam";
                  } else if (width < 0.3 || length < 0.3) {
                    type = "column";
                  } else if (width > 2 || length > 2) {
                    type = "slab";
                  } else {
                    type = "column";
                  }
                  height = 3; // Default height
                }
              }
            }
          } else if (entity.type === "CIRCLE") {
            const radius = entity.radius;
            if (radius && typeof radius === "number" && !isNaN(radius)) {
              const diameter = (radius * 2) / scale;
              if (diameter > 0.01) {
                width = diameter;
                length = diameter;
                height = 3;
                type = "column";
              }
            }
          } else if (entity.type === "RECTANGLE") {
            if (entity.width && entity.height) {
              width = entity.width / scale;
              length = entity.height / scale;
              height = 3;
              type = "column";
            }
          }

          if (width > 0.01 && length > 0.01 && height > 0.01) {
            newElements.push({
              id: id++,
              type,
              length: Math.max(width, length),
              width: Math.min(width, length),
              height,
              thickness: thickness || undefined,
              qty: 1,
            });
            elementCounts[type]++;
          }
        } catch (e) {
          console.warn("Entity processing error:", e);
        }
      });

      if (newElements.length > 0) {
        const counts = newElements
          .map(
            (el) =>
              `${elementCounts[el.type]} ${elementTypeConfigs[el.type].label[language]}`
          )
          .filter((c, i, a) => a.indexOf(c) === i);
        toast.success(
          language === "ar"
            ? `✅ تم العثور على ${counts.join("، ")}`
            : `✅ Found ${counts.join(", ")}`
        );
      } else {
        toast.warning(
          language === "ar"
            ? "⚠️ لم يتم العثور على عناصر صحيحة"
            : "⚠️ No valid elements found"
        );
      }
      return newElements;
    } catch (error) {
      console.error("CAD Processing Error:", error);
      toast.error(
        language === "ar"
          ? "❌ خطأ في معالجة الملف"
          : "❌ Error processing file"
      );
      return [];
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) {
      toast.error(
        language === "ar" ? "❌ الرجاء اختيار ملف" : "❌ Please select a file"
      );
      return;
    }

    const fileExtension = file.name.split(".").pop()?.toLowerCase();
    
    // Reject DWG files - they cause parsing issues
    if (fileExtension === "dwg") {
      toast.error(
        language === "ar"
          ? "❌ ملفات DWG غير مدعومة.\n🔄 الحل: حول الملف من DWG → DXF على:\nhttps://cloudconvert.com/dwg-to-dxf"
          : "❌ DWG files not supported.\n🔄 Solution: Convert DWG → DXF at:\nhttps://cloudconvert.com/dwg-to-dxf"
      );
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }
    
    if (!["dxf", "txt"].includes(fileExtension || "")) {
      toast.error(
        language === "ar"
          ? "❌ صيغة ملف غير مدعومة (استخدم DXF فقط)"
          : "❌ Unsupported file format (use DXF only)"
      );
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }

    setIsLoadingCAD(true);

    if (fileExtension === "dxf" || fileExtension === "txt") {
      const reader = new FileReader();
      reader.onerror = () => {
        toast.error(
          language === "ar" ? "❌ خطأ في قراءة الملف" : "❌ Error reading file"
        );
        setIsLoadingCAD(false);
        if (fileInputRef.current) fileInputRef.current.value = "";
      };
      reader.onload = (event) => {
        try {
          const content = event.target?.result as string;
          if (!content) {
            toast.error(
              language === "ar" ? "❌ الملف فارغ" : "❌ File is empty"
            );
            setShowPreview(false);
            return;
          }
          const parsed = parseCADFile(content);
          if (parsed.length > 0) {
            setPreviewElements(parsed);
            setShowPreview(true);
          } else {
            setShowPreview(false);
          }
        } catch (error) {
          console.error("Parse Error:", error);
          toast.error(
            language === "ar"
              ? "❌ خطأ في معالجة الملف"
              : "❌ Error processing file"
          );
          setShowPreview(false);
        } finally {
          setIsLoadingCAD(false);
          if (fileInputRef.current) fileInputRef.current.value = "";
        }
      };
      reader.readAsText(file);
    }
  };

  const confirmImport = () => {
    setElements(previewElements);
    setNextId(previewElements.length + 1);
    setShowPreview(false);
    setPreviewElements([]);
    toast.success(
      language === "ar" ? "✅ تم استيراد العناصر" : "✅ Elements imported"
    );
  };

  const addElement = (type: ElementType) => {
    setElements([
      ...elements,
      {
        id: nextId,
        type,
        length: type === "stairs" ? 1.5 : type === "opening" ? 0.9 : 0.5,
        width: type === "stairs" ? 1.2 : type === "opening" ? 2.0 : 0.5,
        height: type === "column" ? 3 : type === "slab" ? 0.3 : type === "stairs" ? 3 : type === "opening" ? 2.1 : 0.5,
        thickness: type === "slab" ? 0.2 : type === "stairs" ? 0.15 : undefined,
        qty: 1,
      },
    ]);
    setNextId(nextId + 1);
  };

  const removeElement = (id: number) => {
    if (elements.length > 1) {
      setElements(elements.filter((e) => e.id !== id));
    }
  };

  const updateElement = (id: number, field: string, value: number) => {
    setElements(
      elements.map((e) =>
        e.id === id ? { ...e, [field]: value } : e
      )
    );
  };

  const calculateElementVolume = (el: StructuralElement): number => {
    if (el.type === "opening") {
      // Openings don't add volume - they reduce material
      return 0;
    } else if (el.type === "slab") {
      // Slabs use thickness instead of height
      return (el.length * el.width * (el.thickness || 0.2)) * el.qty;
    } else if (el.type === "stairs") {
      // Stairs: length x width x height with typical stair density
      return (el.length * el.width * el.height * 0.5) * el.qty; // 50% density for stepped structure
    }
    // All other elements: columns, beams, footings use full height
    return (el.length * el.width * el.height) * el.qty;
  };

  const calculateElementMaterials = (el: StructuralElement) => {
    // Door openings have zero material - they just reduce volume from walls
    if (el.type === "opening") {
      return { 
        volume: 0, 
        concreteWeight: 0, 
        steelWeight: 0, 
        steelBars: 0
      };
    }
    
    const volume = calculateElementVolume(el);
    
    // Precise concrete calculation
    // Concrete density: 2400 kg/m³ (standard for reinforced concrete C30)
    const concreteWeight = Math.round(volume * 2400 * 100) / 100; // kg, rounded to 2 decimals
    
    // Precise steel reinforcement calculation
    // Steel ratio varies by element type
    const elementSteelRatio = steelRatio; // User-defined ratio (%)
    const steelWeight = Math.round((concreteWeight * elementSteelRatio / 100) * 100) / 100; // kg
    
    // Precise steel bar calculation
    // 16mm deformed steel bar: 1.58 kg per linear meter (exact)
    // Calculate based on element dimensions and spacing
    const barWeightPerMeter = 1.58; // kg/m for 16mm diameter bar
    
    let steelBars = 0;
    
    // Calculate number of bars based on element type and dimensions
    if (el.type === 'column') {
      // Column: perimeter spacing + vertical spacing
      // Typical spacing: 200mm for main bars, 300mm for ties
      const perimeter = 2 * (el.width + el.length);
      const mainBars = Math.ceil(perimeter / 0.2); // bars every 200mm
      const ties = Math.ceil(el.height / 0.3); // ties every 300mm
      const avgBarLength = (el.height + el.width + el.length) / 3;
      steelBars = Math.ceil(steelWeight / (barWeightPerMeter * avgBarLength)) + mainBars;
    } else if (el.type === 'beam') {
      // Beam: main reinforcement at bottom + distribution bars + stirrups
      const mainBars = 4; // Typical 4 bars at bottom
      const distributionBars = 2; // Distribution bars
      const stirrups = Math.ceil(el.length / 0.15); // Stirrups every 150mm
      const avgBarLength = el.length;
      steelBars = mainBars + distributionBars + stirrups;
    } else if (el.type === 'slab') {
      // Slab: top and bottom reinforcement
      // Spacing: 150mm × 150mm grid in both directions
      const barsX = Math.ceil(el.length / 0.15);
      const barsY = Math.ceil(el.width / 0.15);
      steelBars = Math.ceil((barsX + barsY) * (el.length + el.width) / steelWeight * 10) || Math.ceil(steelWeight / 8);
    } else if (el.type === 'footing') {
      // Footing: main reinforcement grid
      // Spacing: 200mm × 200mm
      const barsX = Math.ceil(el.length / 0.2);
      const barsY = Math.ceil(el.width / 0.2);
      steelBars = Math.ceil((barsX + barsY) * 2);
    } else if (el.type === 'stairs') {
      // Stairs: main reinforcement along steps
      // Typical: horizontal bars at each step + vertical support bars
      const stepsCount = Math.ceil(el.height / 0.18); // ~18cm per step
      const mainBars = stepsCount * 3; // 3 bars per step
      const supportBars = Math.ceil(el.length / 0.2); // Support bars every 200mm
      steelBars = mainBars + supportBars;
    }
    
    // Fallback: calculate from total steel weight
    if (steelBars === 0) {
      const avgBarLength = Math.max(el.length, el.width, el.height || 1);
      steelBars = Math.ceil(steelWeight / (barWeightPerMeter * avgBarLength));
    }
    
    return { 
      volume: Math.round(volume * 1000) / 1000, // m³, 3 decimals
      concreteWeight, // kg
      steelWeight, // kg
      steelBars: Math.max(1, steelBars) // minimum 1 bar
    };
  };

  const getTotalsByType = (type: ElementType) => {
    const typeElements = elements.filter((e) => e.type === type);
    let totalVolume = 0,
      totalConcrete = 0,
      totalSteel = 0,
      totalBars = 0;

    typeElements.forEach((el) => {
      const mats = calculateElementMaterials(el);
      totalVolume += mats.volume;
      totalConcrete += mats.concreteWeight;
      totalSteel += mats.steelWeight;
      totalBars += mats.steelBars;
    });

    return { totalVolume, totalConcrete, totalSteel, totalBars };
  };

  const grandTotals = {
    volume: elements.reduce((sum, el) => sum + calculateElementVolume(el), 0),
    concrete: elements.reduce(
      (sum, el) => sum + calculateElementMaterials(el).concreteWeight,
      0
    ),
    steel: elements.reduce(
      (sum, el) => sum + calculateElementMaterials(el).steelWeight,
      0
    ),
    bars: elements.reduce(
      (sum, el) => sum + calculateElementMaterials(el).steelBars,
      0
    ),
  };

  const exportReport = () => {
    let csv = `تقرير المواد الإنشائية / Structural Materials Report\n`;
    csv += `التاريخ / Date: ${new Date().toLocaleDateString()}\n\n`;

    Object.entries(elementTypeConfigs).forEach(([type, config]) => {
      const typeElements = elements.filter(
        (e) => e.type === (type as ElementType)
      );
      if (typeElements.length > 0) {
        csv += `\n${config.icon} ${config.label.ar} / ${config.label.en}\n`;
        csv += `${"=".repeat(50)}\n`;

        typeElements.forEach((el, idx) => {
          const mats = calculateElementMaterials(el);
          csv += `${el.type} ${idx + 1}: ${el.length}m x ${el.width}m x ${el.height || el.thickness}m x ${el.qty}\n`;
          csv += `  Volume: ${mats.volume.toFixed(3)} m³\n`;
          csv += `  Concrete: ${mats.concreteWeight.toFixed(0)} kg\n`;
          csv += `  Steel: ${mats.steelWeight.toFixed(2)} kg (${mats.steelBars} bars)\n\n`;
        });
      }
    });

    csv += `\n${"=".repeat(50)}\n`;
    csv += `الإجمالي / TOTAL\n`;
    csv += `${"=".repeat(50)}\n`;
    csv += `Total Volume: ${grandTotals.volume.toFixed(3)} m³\n`;
    csv += `Total Concrete: ${grandTotals.concrete.toFixed(0)} kg\n`;
    csv += `Total Steel: ${grandTotals.steel.toFixed(2)} kg\n`;
    csv += `Total Steel Bars (16mm): ${grandTotals.bars}\n`;

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `structural-report-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(language === "ar" ? "✅ تم التصدير" : "✅ Exported");
  };

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-slate-900 via-amber-900/20 to-slate-900"
      dir={isRTL ? "rtl" : "ltr"}
    >
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 right-10 w-72 h-72 bg-amber-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-10 left-10 w-96 h-96 bg-orange-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="sticky top-0 z-50 bg-black/40 backdrop-blur-md border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
          <Link href="/">
            <Button
              variant="ghost"
              className="text-white hover:bg-white/10"
              data-testid="button-back-home"
            >
              <ArrowRight className="w-5 h-5 ml-2" />
              {language === "ar" ? "الرئيسية" : "Home"}
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-white">
            🏗️{" "}
            {language === "ar"
              ? "حاسبة المواد الإنشائية"
              : "Structural Materials Calculator"}
          </h1>
        </div>
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 py-6 space-y-6">
        {/* CAD Import */}
        <Card className="bg-white/10 border-white/20">
          <CardHeader>
            <CardTitle className="text-white">
              {language === "ar"
                ? "📁 استيراد ملف CAD"
                : "📁 Import CAD File"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-200">
                  {language === "ar" ? "وحدات DXF المحلية" : "DXF Units (Client)"}
                </Label>
                <select
                  value={scale}
                  onChange={(e) => setScale(parseFloat(e.target.value))}
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded text-white text-sm"
                >
                  <option value="1">
                    {language === "ar" ? "متر" : "Meters"}
                  </option>
                  <option value="1000">
                    {language === "ar" ? "ملليمتر" : "Millimeters"}
                  </option>
                  <option value="10">
                    {language === "ar" ? "سنتيمتر" : "Centimeters"}
                  </option>
                </select>
              </div>
              <div>
                <Label className="text-gray-200">
                  {language === "ar" ? "وحدات الملف" : "CAD File Units"}
                </Label>
                <select
                  value={serverScale}
                  onChange={(e) => setServerScale(parseFloat(e.target.value))}
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded text-white text-sm"
                >
                  <option value="1">
                    {language === "ar" ? "متر" : "Meters"}
                  </option>
                  <option value="1000">
                    {language === "ar" ? "ملليمتر" : "Millimeters"}
                  </option>
                  <option value="100">
                    {language === "ar" ? "سنتيمتر" : "Centimeters"}
                  </option>
                </select>
              </div>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept=".dxf,.dwg,.txt"
              onChange={handleFileUpload}
              disabled={isLoadingCAD}
              className="hidden"
              data-testid="input-cad-file"
            />
            <Button
              onClick={() => fileInputRef.current?.click()}
              disabled={isLoadingCAD}
              className="w-full bg-green-600 hover:bg-green-700"
              data-testid="button-upload-cad"
              type="button"
            >
              <Upload className="w-4 h-4 ml-2" />
              {isLoadingCAD
                ? language === "ar"
                  ? "جاري التحميل..."
                  : "Loading..."
                : language === "ar"
                ? "رفع ملف"
                : "Upload File"}
            </Button>
            <p className="text-xs text-gray-400">
              {language === "ar"
                ? "صيغ مدعومة: DXF, DWG, TXT - اختر وحدات الملف بشكل صحيح"
                : "Supported: DXF, DWG, TXT - Select correct file units"}
            </p>
          </CardContent>
        </Card>

        {/* Preview Section */}
        {showPreview && previewElements.length > 0 && (
          <Card className="bg-gradient-to-br from-blue-500/20 to-cyan-600/20 border-blue-400/50 animate-in slide-in-from-top">
            <CardHeader>
              <CardTitle className="text-white">
                {language === "ar" ? "👁️ معاينة" : "👁️ Preview"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {previewElements.map((el) => (
                  <div
                    key={el.id}
                    className="bg-white/10 p-3 rounded-lg border border-blue-400/30"
                  >
                    <p className="text-white font-semibold mb-2">
                      {elementTypeConfigs[el.type].icon}{" "}
                      {elementTypeConfigs[el.type].label[language]}
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <p className="text-gray-400 text-xs">
                          {language === "ar" ? "الطول" : "Length"}
                        </p>
                        <p className="text-white font-bold">
                          {el.length.toFixed(2)}m
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-xs">
                          {language === "ar" ? "العرض" : "Width"}
                        </p>
                        <p className="text-white font-bold">
                          {el.width.toFixed(2)}m
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-xs">
                          {language === "ar" ? "الارتفاع" : "Height"}
                        </p>
                        <p className="text-white font-bold">
                          {el.height.toFixed(2)}m
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-xs">
                          {language === "ar" ? "الحجم" : "Volume"}
                        </p>
                        <p className="text-cyan-300 font-bold">
                          {calculateElementVolume(el).toFixed(3)}m³
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex gap-2 pt-2">
                <Button
                  onClick={confirmImport}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  data-testid="button-confirm-import"
                >
                  {language === "ar"
                    ? "✓ تأكيد الاستيراد"
                    : "✓ Confirm"}
                </Button>
                <Button
                  onClick={() => setShowPreview(false)}
                  className="flex-1 bg-gray-600 hover:bg-gray-700"
                  data-testid="button-cancel-import"
                >
                  {language === "ar" ? "✗ إلغاء" : "✗ Cancel"}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quick Data Entry */}
        <Card className="bg-gradient-to-br from-amber-500/20 to-orange-600/20 border-amber-400/50">
          <CardHeader>
            <CardTitle className="text-white">
              {language === "ar" ? "📊 إدخال سريع للبيانات" : "📊 Quick Data Entry"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-gray-300">
              {language === "ar"
                ? "إدخل البيانات يدويًا أو عدّل البيانات المستخرجة من الملف:"
                : "Enter data manually or edit extracted data:"}
            </p>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-white/20">
                    <th className="text-left px-2 py-2 text-gray-300">{language === "ar" ? "النوع" : "Type"}</th>
                    <th className="text-left px-2 py-2 text-gray-300">{language === "ar" ? "الطول" : "L(m)"}</th>
                    <th className="text-left px-2 py-2 text-gray-300">{language === "ar" ? "العرض" : "W(m)"}</th>
                    <th className="text-left px-2 py-2 text-gray-300">{language === "ar" ? "الارتفاع" : "H(m)"}</th>
                    <th className="text-left px-2 py-2 text-gray-300">{language === "ar" ? "الكم" : "Qty"}</th>
                    <th className="text-left px-2 py-2 text-gray-300">{language === "ar" ? "الحجم" : "Vol(m³)"}</th>
                  </tr>
                </thead>
                <tbody>
                  {elements.map((el) => {
                    const vol = calculateElementVolume(el);
                    return (
                      <tr key={el.id} className="border-b border-white/10 hover:bg-white/5">
                        <td className="px-2 py-1 text-white">{elementTypeConfigs[el.type].icon}</td>
                        <td className="px-2 py-1">
                          <input
                            type="number"
                            min="0.01"
                            step="0.1"
                            value={el.length}
                            onChange={(e) =>
                              updateElement(el.id, "length", parseFloat(e.target.value) || el.length)
                            }
                            className="w-16 bg-white/10 border border-white/20 rounded px-1 text-white text-xs"
                          />
                        </td>
                        <td className="px-2 py-1">
                          <input
                            type="number"
                            min="0.01"
                            step="0.1"
                            value={el.width}
                            onChange={(e) =>
                              updateElement(el.id, "width", parseFloat(e.target.value) || el.width)
                            }
                            className="w-16 bg-white/10 border border-white/20 rounded px-1 text-white text-xs"
                          />
                        </td>
                        <td className="px-2 py-1">
                          <input
                            type="number"
                            min="0.01"
                            step="0.1"
                            value={el.height}
                            onChange={(e) =>
                              updateElement(el.id, "height", parseFloat(e.target.value) || el.height)
                            }
                            className="w-16 bg-white/10 border border-white/20 rounded px-1 text-white text-xs"
                          />
                        </td>
                        <td className="px-2 py-1">
                          <input
                            type="number"
                            min="1"
                            step="1"
                            value={el.qty}
                            onChange={(e) =>
                              updateElement(el.id, "qty", Math.max(1, parseInt(e.target.value) || 1))
                            }
                            className="w-12 bg-white/10 border border-white/20 rounded px-1 text-white text-xs"
                          />
                        </td>
                        <td className="px-2 py-1 text-cyan-300 font-bold">{vol.toFixed(2)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Settings */}
        <Card className="bg-white/10 border-white/20">
          <CardHeader>
            <CardTitle className="text-white">
              {language === "ar" ? "⚙️ الإعدادات" : "⚙️ Settings"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label className="text-gray-200">
                  {language === "ar" ? "نسبة التسليح %" : "Steel Ratio %"}
                </Label>
                <Input
                  type="number"
                  value={steelRatio}
                  onChange={(e) =>
                    setSteelRatio(parseFloat(e.target.value) || 1.5)
                  }
                  min="0.5"
                  step="0.1"
                  className="bg-white/10 border-white/20 text-white"
                  data-testid="input-steel-ratio"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Elements by Type */}
        {Object.entries(elementTypeConfigs).map(([typeKey, config]) => {
          const type = typeKey as ElementType;
          const typeElements = elements.filter((e) => e.type === type);
          const totals = getTotalsByType(type);

          return (
            <Card
              key={type}
              className={`bg-gradient-to-br ${config.gradientFrom} ${config.gradientTo} ${config.borderColor}`}
            >
              <CardHeader>
                <CardTitle className="text-white">
                  {config.icon} {config.label[language]}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {typeElements.length > 0 ? (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {/* Summary */}
                      <div className="bg-white/10 p-3 rounded-lg border border-white/20">
                        <p className="text-gray-300 text-xs mb-2">
                          {language === "ar" ? "الملخص" : "Summary"}
                        </p>
                        <div className="space-y-1 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-400">
                              {language === "ar" ? "الحجم الكلي" : "Total Vol."}
                            </span>
                            <span className="text-white font-bold">
                              {totals.totalVolume.toFixed(3)} m³
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">
                              {language === "ar"
                                ? "الخرسانة"
                                : "Concrete"}
                            </span>
                            <span className="text-white font-bold">
                              {totals.totalConcrete.toFixed(0)} kg
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">
                              {language === "ar" ? "الفولاذ" : "Steel"}
                            </span>
                            <span className="text-white font-bold">
                              {totals.totalSteel.toFixed(2)} kg
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">
                              {language === "ar" ? "الأسياخ" : "Bars"}
                            </span>
                            <span className="text-white font-bold">
                              {totals.totalBars}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Details */}
                      <div className="space-y-2">
                        {typeElements.map((el, idx) => {
                          const mats = calculateElementMaterials(el);
                          const showThickness = ["slab", "stairs"].includes(el.type);
                          return (
                            <div key={el.id} className="bg-white/5 p-2 rounded">
                              <p className="text-gray-300 text-xs mb-1">
                                {type} {idx + 1}
                              </p>
                              <div className="grid grid-cols-4 gap-1 text-xs">
                                <div>
                                  <span className="text-gray-400">
                                    {language === "ar" ? "L" : "L"}
                                  </span>
                                  <input
                                    type="number"
                                    min="0.01"
                                    step="0.05"
                                    value={el.length}
                                    onChange={(e) =>
                                      updateElement(
                                        el.id,
                                        "length",
                                        parseFloat(e.target.value) || el.length
                                      )
                                    }
                                    className="w-full bg-white/10 border border-white/20 rounded px-1 text-white text-xs"
                                    data-testid={`input-length-${el.id}`}
                                  />
                                </div>
                                <div>
                                  <span className="text-gray-400">
                                    {language === "ar" ? "W" : "W"}
                                  </span>
                                  <input
                                    type="number"
                                    min="0.01"
                                    step="0.05"
                                    value={el.width}
                                    onChange={(e) =>
                                      updateElement(
                                        el.id,
                                        "width",
                                        parseFloat(e.target.value) || el.width
                                      )
                                    }
                                    className="w-full bg-white/10 border border-white/20 rounded px-1 text-white text-xs"
                                    data-testid={`input-width-${el.id}`}
                                  />
                                </div>
                                <div>
                                  <span className="text-gray-400">
                                    {language === "ar" ? "H" : "H"}
                                  </span>
                                  <input
                                    type="number"
                                    min="0.01"
                                    step="0.05"
                                    value={el.height}
                                    onChange={(e) =>
                                      updateElement(
                                        el.id,
                                        "height",
                                        parseFloat(e.target.value) || el.height
                                      )
                                    }
                                    className="w-full bg-white/10 border border-white/20 rounded px-1 text-white text-xs"
                                    data-testid={`input-height-${el.id}`}
                                  />
                                </div>
                                <div>
                                  <span className="text-gray-400">
                                    {language === "ar" ? "Q" : "Q"}
                                  </span>
                                  <input
                                    type="number"
                                    min="1"
                                    step="1"
                                    value={el.qty}
                                    onChange={(e) =>
                                      updateElement(
                                        el.id,
                                        "qty",
                                        Math.max(1, parseInt(e.target.value) || 1)
                                      )
                                    }
                                    className="w-full bg-white/10 border border-white/20 rounded px-1 text-white text-xs"
                                    data-testid={`input-qty-${el.id}`}
                                  />
                                </div>
                              </div>
                              {showThickness && (
                                <div className="mt-1">
                                  <span className="text-gray-400 text-xs">
                                    {language === "ar" ? "السمك" : "Thickness"}
                                  </span>
                                  <input
                                    type="number"
                                    min="0.01"
                                    step="0.05"
                                    value={el.thickness || 0.2}
                                    onChange={(e) =>
                                      updateElement(
                                        el.id,
                                        "thickness",
                                        parseFloat(e.target.value) || el.thickness || 0.2
                                      )
                                    }
                                    className="w-full bg-white/10 border border-white/20 rounded px-1 text-white text-xs"
                                    data-testid={`input-thickness-${el.id}`}
                                  />
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        onClick={() => addElement(type)}
                        className={`flex-1 bg-${config.color}-600 hover:bg-${config.color}-700`}
                        size="sm"
                      >
                        <Plus className="w-3 h-3 ml-2" />
                        {language === "ar" ? "إضافة" : "Add"}
                      </Button>
                      {typeElements.length > 0 && (
                        <Button
                          onClick={() =>
                            removeElement(typeElements[typeElements.length - 1].id)
                          }
                          variant="destructive"
                          size="sm"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      )}
                    </div>
                  </>
                ) : (
                  <Button
                    onClick={() => addElement(type)}
                    className={`w-full bg-${config.color}-600 hover:bg-${config.color}-700`}
                  >
                    <Plus className="w-4 h-4 ml-2" />
                    {language === "ar" ? "إضافة" : "Add"} {config.label[language]}
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}

        {/* 3D Visualization */}
        {(elements.length > 0 || rawGeometry.length > 0) && (
          <div className="flex justify-center gap-2 flex-wrap">
            {rawGeometry.length > 0 && (
              <Button
                onClick={() =>
                  setViewMode(viewMode === "raw" ? "none" : "raw")
                }
                className={`${
                  viewMode === "raw"
                    ? "bg-indigo-600 hover:bg-indigo-700"
                    : "bg-gray-600 hover:bg-gray-700"
                }`}
                data-testid="button-toggle-raw"
              >
                <Box className="w-4 h-4 ml-2" />
                {language === "ar" ? "🏢 عرض المبنى كامل" : "🏢 Full Building"}
              </Button>
            )}
            {elements.length > 0 && (
              <>
                <Button
                  onClick={() =>
                    setViewMode(viewMode === "3d" ? "none" : "3d")
                  }
                  className={`${
                    viewMode === "3d"
                      ? "bg-purple-600 hover:bg-purple-700"
                      : "bg-gray-600 hover:bg-gray-700"
                  }`}
                  data-testid="button-toggle-3d"
                >
                  <Box className="w-4 h-4 ml-2" />
                  {language === "ar" ? "عرض 3D" : "View 3D"}
                </Button>
                <Button
                  onClick={() =>
                    setViewMode(viewMode === "map" ? "none" : "map")
                  }
                  className={`${
                    viewMode === "map"
                      ? "bg-green-600 hover:bg-green-700"
                      : "bg-gray-600 hover:bg-gray-700"
                  }`}
                  data-testid="button-toggle-map"
                >
                  <Map className="w-4 h-4 ml-2" />
                  {language === "ar" ? "الخريطة" : "Map"}
                </Button>
              </>
            )}
          </div>
        )}

        {viewMode === "raw" && rawGeometry.length > 0 && (
          <Card className="bg-white/10 border-white/20">
            <CardHeader>
              <CardTitle className="text-white">
                {language === "ar"
                  ? "🏢 عرض المبنى كاملاً"
                  : "🏢 Complete Building View"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <RawGeometry3DViewer geometry={rawGeometry} />
              <p className="text-xs text-gray-400 mt-3">
                {language === "ar"
                  ? `📊 إجمالي العناصر الهندسية: ${rawGeometry.length} (خطوط، دوائر، قوس، نصوص)`
                  : `📊 Total geometric entities: ${rawGeometry.length} (lines, circles, arcs, text)`}
              </p>
            </CardContent>
          </Card>
        )}

        {viewMode === "3d" && elements.length > 0 && (
          <Card className="bg-white/10 border-white/20">
            <CardHeader>
              <CardTitle className="text-white">
                {language === "ar"
                  ? "🎯 عرض ثلاثي الأبعاد"
                  : "🎯 3D View"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ColumnViewer3D elements={elements} />
            </CardContent>
          </Card>
        )}

        {viewMode === "map" && elements.length > 0 && (
          <Card className="bg-white/10 border-white/20">
            <CardHeader>
              <CardTitle className="text-white">
                {language === "ar" ? "🗺️ خريطة" : "🗺️ Map"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ColumnMapViewer columns={elements.filter((e) => e.type === "column")} />
            </CardContent>
          </Card>
        )}

        {/* Grand Totals */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border-cyan-400/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-white">
                {language === "ar" ? "الحجم الكلي" : "Total Volume"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p
                className="text-3xl font-bold text-white"
                data-testid="text-total-volume"
              >
                {grandTotals.volume.toFixed(2)}
              </p>
              <p className="text-xs text-gray-400">m³</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500/20 to-emerald-600/20 border-green-400/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-white">
                {language === "ar" ? "الخرسانة" : "Concrete"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p
                className="text-3xl font-bold text-white"
                data-testid="text-total-concrete"
              >
                {(grandTotals.concrete / 1000).toFixed(1)}
              </p>
              <p className="text-xs text-gray-400">Tons</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-500/20 to-indigo-600/20 border-blue-400/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-white">
                {language === "ar" ? "الفولاذ" : "Steel"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p
                className="text-3xl font-bold text-white"
                data-testid="text-total-steel"
              >
                {(grandTotals.steel / 1000).toFixed(1)}
              </p>
              <p className="text-xs text-gray-400">Tons</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-yellow-500/20 to-orange-600/20 border-yellow-400/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-white">
                {language === "ar" ? "الأسياخ" : "Steel Bars"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p
                className="text-3xl font-bold text-white"
                data-testid="text-total-bars"
              >
                {grandTotals.bars}
              </p>
              <p className="text-xs text-gray-400">
                {language === "ar" ? "سيخ" : "bars"}
              </p>
            </CardContent>
          </Card>
        </div>

        <Button
          onClick={exportReport}
          className="w-full bg-amber-600 hover:bg-amber-700"
          size="lg"
          data-testid="button-export"
        >
          <Download className="w-5 h-5 ml-2" />
          {language === "ar"
            ? "📥 تصدير التقرير"
            : "📥 Export Report"}
        </Button>
      </div>
    </div>
  );
}
