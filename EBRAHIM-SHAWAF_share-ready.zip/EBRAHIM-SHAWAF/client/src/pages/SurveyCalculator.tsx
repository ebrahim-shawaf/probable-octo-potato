import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowRight, Calculator, Upload, Trash2, Download, Copy, Plus, X, Home, FileText } from "lucide-react";
import { Link, useSearch } from "wouter";
import { toast } from "sonner";
import { useLanguage } from "@/lib/i18n";
import { generateBrickPDF, generatePaintPDF, generateTilesPDF, generateStairsPDF, generateTankPDF, generateElectricalPDF, generateHVACPDF, generateCostPDF, generateSewagePDF } from "@/lib/pdfExport";

type CalculationType = "area" | "volume" | "length" | "autocad" | "polygon" | "advanced" | "measure" | "asphalt" | "concrete" | "rebar" | "electrical" | "hvac" | "cost" | "brick" | "paint" | "tiles" | "stairs" | "tank" | "sewage" | "boq" | "cad-boq" | "foundation" | "projects";
type ShapeType = "rectangle" | "circle" | "triangle" | "trapezoid" | "pentagon" | "cube" | "cylinder" | "sphere" | "ellipse" | "hexagon";
type MeasureMode = "distance" | "area" | "slope" | "gps";

interface MeasurePoint {
  lat: number;
  lng: number;
  elev?: number;
}

interface GpsLocation {
  lat: number;
  lng: number;
  accuracy: number;
  altitude: number | null;
}

interface DXFEntity {
  type: string;
  x?: number;
  y?: number;
  z?: number;
  r?: number;
  x1?: number;
  y1?: number;
  z1?: number;
  x2?: number;
  y2?: number;
  z2?: number;
  x3?: number;
  y3?: number;
}

interface Coordinate {
  id: number;
  name: string;
  x: number;
  y: number;
  z?: number;
  type: string;
}

const circleArea = (radius: number) => Math.PI * radius * radius;

const rectangleArea = (x1: number, y1: number, x2: number, y2: number) => {
  const dx = Math.abs(x2 - x1);
  const dy = Math.abs(y2 - y1);
  return dx * dy;
};

const polygonArea = (points: Array<[number, number]>) => {
  if (points.length < 3) return 0;
  let area = 0;
  for (let i = 0; i < points.length; i++) {
    const [x1, y1] = points[i];
    const [x2, y2] = points[(i + 1) % points.length];
    area += x1 * y2 - x2 * y1;
  }
  return Math.abs(area) / 2;
};

const polygonPerimeter = (points: Array<[number, number]>) => {
  if (points.length < 2) return 0;
  let perimeter = 0;
  for (let i = 0; i < points.length; i++) {
    const [x1, y1] = points[i];
    const [x2, y2] = points[(i + 1) % points.length];
    const distance = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
    perimeter += distance;
  }
  return perimeter;
};

const heronTriangleArea = (a: number, b: number, c: number) => {
  if (a + b <= c || b + c <= a || a + c <= b) return 0;
  const s = (a + b + c) / 2;
  return Math.sqrt(s * (s - a) * (s - b) * (s - c));
};

const ellipseArea = (semiMajor: number, semiMinor: number) => {
  return Math.PI * semiMajor * semiMinor;
};

const hexagonArea = (side: number) => {
  return (3 * Math.sqrt(3) / 2) * side * side;
};

const regularPolygonArea = (sides: number, side: number) => {
  return (sides * side * side) / (4 * Math.tan(Math.PI / sides));
};

const circlePerimeter = (radius: number) => 2 * Math.PI * radius;

const rectanglePerimeter = (length: number, width: number) => 2 * (length + width);

const haversineDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
  const R = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

const geodesicPolygonArea = (points: MeasurePoint[]): number => {
  if (points.length < 3) return 0;
  
  const WGS84_A = 6378137.0;
  const WGS84_F = 1 / 298.257223563;
  const WGS84_E2 = 2 * WGS84_F - WGS84_F * WGS84_F;
  
  const toRad = (deg: number) => deg * Math.PI / 180;
  
  const centerLat = points.reduce((sum, p) => sum + p.lat, 0) / points.length;
  const centerLng = points.reduce((sum, p) => sum + p.lng, 0) / points.length;
  
  const latRad = toRad(centerLat);
  const sinLat = Math.sin(latRad);
  const cosLat = Math.cos(latRad);
  
  const N = WGS84_A / Math.sqrt(1 - WGS84_E2 * sinLat * sinLat);
  const M = WGS84_A * (1 - WGS84_E2) / Math.pow(1 - WGS84_E2 * sinLat * sinLat, 1.5);
  
  const metersPerDegLat = M * Math.PI / 180;
  const metersPerDegLng = N * cosLat * Math.PI / 180;
  
  const localPoints = points.map(p => ({
    x: (p.lng - centerLng) * metersPerDegLng,
    y: (p.lat - centerLat) * metersPerDegLat
  }));
  
  let area = 0;
  for (let i = 0; i < localPoints.length; i++) {
    const j = (i + 1) % localPoints.length;
    area += localPoints[i].x * localPoints[j].y;
    area -= localPoints[j].x * localPoints[i].y;
  }
  
  return Math.abs(area) / 2;
};

const shoelaceAreaLocal = (points: MeasurePoint[]): number => {
  if (points.length < 3) return 0;
  
  const refLat = points[0].lat;
  const refLng = points[0].lng;
  
  const METERS_PER_DEG_LAT = 111320;
  const METERS_PER_DEG_LNG = 111320 * Math.cos(refLat * Math.PI / 180);
  
  const localPoints = points.map(p => ({
    x: (p.lng - refLng) * METERS_PER_DEG_LNG,
    y: (p.lat - refLat) * METERS_PER_DEG_LAT
  }));
  
  let area = 0;
  for (let i = 0; i < localPoints.length; i++) {
    const j = (i + 1) % localPoints.length;
    area += localPoints[i].x * localPoints[j].y;
    area -= localPoints[j].x * localPoints[i].y;
  }
  return Math.abs(area) / 2;
};

const shoelaceArea = (points: MeasurePoint[]): number => {
  if (points.length < 3) return 0;
  
  const minLat = Math.min(...points.map(p => p.lat));
  const maxLat = Math.max(...points.map(p => p.lat));
  const minLng = Math.min(...points.map(p => p.lng));
  const maxLng = Math.max(...points.map(p => p.lng));
  
  const latSpan = maxLat - minLat;
  const lngSpan = maxLng - minLng;
  
  if (latSpan > 0.1 || lngSpan > 0.1) {
    return geodesicPolygonArea(points);
  }
  
  return shoelaceAreaLocal(points);
};

const calculateSlope = (dist: number, elev1: number, elev2: number) => {
  const elevDiff = elev2 - elev1;
  if (dist === 0 || !isFinite(dist)) {
    return { elevDiff, slopePercent: 0, slopeAngle: elevDiff > 0 ? 90 : elevDiff < 0 ? -90 : 0 };
  }
  const slopePercent = (elevDiff / dist) * 100;
  const slopeAngle = Math.atan(elevDiff / dist) * (180 / Math.PI);
  return { elevDiff, slopePercent, slopeAngle };
};

const parseDXF = (content: string): Coordinate[] => {
  const coordinates: Coordinate[] = [];
  const lines = content.split('\n');
  let coordId = 1;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    if (line === 'POINT' || line === 'CIRCLE' || line === 'LINE') {
      let x = 0, y = 0, z = 0, r = 0;
      const type = line;
      
      for (let j = i + 1; j < Math.min(i + 30, lines.length); j++) {
        const code = lines[j]?.trim();
        const value = lines[j + 1]?.trim();
        if (code === '10') x = parseFloat(value || '0');
        else if (code === '20') y = parseFloat(value || '0');
        else if (code === '30') z = parseFloat(value || '0');
        else if (code === '40') r = parseFloat(value || '0');
        else if (code === '0') break;
        j++;
      }
      
      if (type === 'POINT' || type === 'CIRCLE' || type === 'LINE') {
        coordinates.push({
          id: coordId++,
          name: `${type}${coordId}`,
          x,
          y,
          z: z !== 0 ? z : undefined,
          type
        });
      }
    } 
    else if (line === 'LWPOLYLINE' || line === 'POLYLINE') {
      for (let j = i + 1; j < Math.min(i + 100, lines.length); j++) {
        const code = lines[j]?.trim();
        const value = lines[j + 1]?.trim();
        
        if (code === '10' && value) {
          const x = parseFloat(value);
          const y = parseFloat(lines[j + 3]?.trim() || '0');
          const z = lines[j + 5]?.trim() ? parseFloat(lines[j + 5]) : undefined;
          
          coordinates.push({
            id: coordId++,
            name: `POINT${coordId}`,
            x,
            y,
            z,
            type: 'POLYLINE'
          });
          j += 5;
        }
        if (code === 'SEQEND' || code === '0') break;
      }
    }
  }
  
  return coordinates;
};

const parseDWG = (arrayBuffer: ArrayBuffer): Coordinate[] => {
  const coordinates: Coordinate[] = [];
  let coordId = 1;
  
  try {
    const view = new Uint8Array(arrayBuffer);
    
    for (let i = 0; i < Math.min(view.length - 20, 50000); i++) {
      if (view[i] !== 0 && view[i + 4] !== 0) {
        const bytes = view.slice(i, i + 8);
        const view32 = new Float64Array(bytes.buffer);
        const value = view32[0];
        
        if (!isNaN(value) && Math.abs(value) < 1000000) {
          if (coordinates.length % 3 === 0 && coordinates.length < 1000) {
            if (!coordinates.find(c => c.x === value)) {
              const nextValue = i + 8 < view.length ? 
                new Float64Array(view.slice(i + 8, i + 16).buffer)[0] : 0;
              
              if (!isNaN(nextValue)) {
                coordinates.push({
                  id: coordId++,
                  name: `COORD${coordId}`,
                  x: value,
                  y: nextValue,
                  type: 'DWG_POINT'
                });
              }
            }
          }
        }
      }
    }
  } catch (error) {
    console.error('خطأ في قراءة DWG:', error);
  }
  
  return coordinates.slice(0, 100);
};

const exportCoordinatesToCSV = (coordinates: Coordinate[], fileName: string) => {
  const csv = [
    ['الاسم', 'النوع', 'X', 'Y', 'Z'].join(','),
    ...coordinates.map(c => 
      [c.name, c.type, c.x.toFixed(2), c.y.toFixed(2), c.z?.toFixed(2) || ''].join(',')
    )
  ].join('\n');

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${fileName.replace('.dxf', '')}-coordinates.csv`;
  link.click();
};

interface Point {
  id: number;
  x: number;
  y: number;
}

interface AsphaltLayer {
  id: number;
  name: string;
  thickness: number; // cm
  density: number; // kg/m³
  compactionFactor: number; // 1.0 - 1.3
}

interface AsphaltResult {
  totalArea: number;
  layers: Array<{
    name: string;
    volume: number;
    tonnage: number;
  }>;
  totalVolume: number;
  totalTonnage: number;
  truckLoads: number;
}

export default function SurveyCalculator() {
  const { language } = useLanguage();
  const searchString = useSearch();
  const [calcType, setCalcType] = useState<CalculationType>("area");
  const [shapeType, setShapeType] = useState<ShapeType>("rectangle");
  
  // Read tool from URL query parameter
  useEffect(() => {
    const params = new URLSearchParams(searchString);
    const tool = params.get('tool');
    if (tool && ['area', 'volume', 'length', 'autocad', 'polygon', 'advanced', 'measure', 'asphalt', 'concrete', 'rebar', 'electrical', 'hvac', 'cost', 'brick', 'paint', 'tiles', 'stairs', 'tank', 'sewage', 'boq', 'cad-boq', 'foundation', 'projects'].includes(tool)) {
      setCalcType(tool as CalculationType);
    }
  }, [searchString]);
  const [inputs, setInputs] = useState<Record<string, number>>({});
  const [result, setResult] = useState<number | null>(null);
  const [perimeter, setPerimeter] = useState<number | null>(null);
  const [dxfFiles, setDxfFiles] = useState<string[]>([]);
  const [dxfAreas, setDxfAreas] = useState<Record<string, number>>({});
  const [dxfCoordinates, setDxfCoordinates] = useState<Record<string, Coordinate[]>>({});
  const [polygonPoints, setPolygonPoints] = useState<Point[]>([]);
  const [pointCount, setPointCount] = useState(0);
  const [heronSides, setHeronSides] = useState<[number | null, number | null, number | null]>([null, null, null]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [measureMode, setMeasureMode] = useState<MeasureMode>("distance");
  const [measurePoints, setMeasurePoints] = useState<MeasurePoint[]>([
    { lat: 0, lng: 0 },
    { lat: 0, lng: 0 }
  ]);
  const [measureResult, setMeasureResult] = useState<any>(null);
  const [userLocation, setUserLocation] = useState<GpsLocation | null>(null);
  const [slopeElevations, setSlopeElevations] = useState<{ elev1: number; elev2: number }>({ elev1: 0, elev2: 0 });
  const [gpsLoading, setGpsLoading] = useState(false);

  // Asphalt Calculator States
  const [asphaltLayers, setAsphaltLayers] = useState<AsphaltLayer[]>([
    { id: 1, name: 'Base Course / طبقة الأساس', thickness: 15, density: 2300, compactionFactor: 1.05 },
    { id: 2, name: 'Binder Course / طبقة الربط', thickness: 8, density: 2350, compactionFactor: 1.03 },
    { id: 3, name: 'Wearing Course / طبقة السطح', thickness: 5, density: 2400, compactionFactor: 1.02 },
  ]);
  const [asphaltArea, setAsphaltArea] = useState<number>(0);
  const [roadLength, setRoadLength] = useState<number>(0);
  const [roadWidth, setRoadWidth] = useState<number>(0);
  const [truckCapacity, setTruckCapacity] = useState<number>(20);
  const [asphaltResult, setAsphaltResult] = useState<AsphaltResult | null>(null);
  const [asphaltInputMode, setAsphaltInputMode] = useState<'area' | 'dimensions'>('dimensions');

  // Concrete Calculator States
  type ConcreteElement = "footing" | "column" | "beam" | "slab" | "stair";
  type BuildingCode = "egyptian" | "american" | "saudi" | "british";
  const [concreteElement, setConcreteElement] = useState<ConcreteElement>("footing");
  const [buildingCode, setBuildingCode] = useState<BuildingCode>("egyptian");
  const [concreteInputs, setConcreteInputs] = useState({
    length: 0,
    width: 0,
    height: 0,
    thickness: 0,
    quantity: 1,
    dim1: 0,
    dim2: 0,
    steps: 0,
    rise: 17,
    tread: 28,
    steelRatio: 100,
    mixType: "C25"
  });
  const [concreteResult, setConcreteResult] = useState<{
    volume: number;
    steelWeight: number;
    cement: number;
    sand: number;
    gravel: number;
    water: number;
    mixerLoads: number;
  } | null>(null);

  // Concrete calculation function
  const calculateConcrete = () => {
    let volume = 0;
    const qty = concreteInputs.quantity || 1;

    switch (concreteElement) {
      case "footing":
        volume = concreteInputs.length * concreteInputs.width * concreteInputs.height * qty;
        break;
      case "column":
        // أبعاد العمود بالسنتيمتر، نحولها للمتر
        volume = (concreteInputs.dim1 / 100) * (concreteInputs.dim2 / 100) * concreteInputs.height * qty;
        break;
      case "beam":
        // عرض وعمق الكمرة بالسنتيمتر
        volume = concreteInputs.length * (concreteInputs.width / 100) * (concreteInputs.height / 100) * qty;
        break;
      case "slab":
        volume = concreteInputs.length * concreteInputs.width * (concreteInputs.thickness / 100) * qty;
        break;
      case "stair":
        // حساب حجم السلم: بلاطة مائلة + درجات
        const riseM = concreteInputs.rise / 100;
        const treadM = concreteInputs.tread / 100;
        const thicknessM = concreteInputs.thickness / 100;
        const stairWidth = concreteInputs.width;
        const steps = concreteInputs.steps;
        
        // حجم البلاطة المائلة
        const flightLength = Math.sqrt(Math.pow(steps * riseM, 2) + Math.pow(steps * treadM, 2));
        const slabVolume = flightLength * stairWidth * thicknessM;
        
        // حجم الدرجات (مثلثات)
        const stepVolume = 0.5 * riseM * treadM * stairWidth * steps;
        
        volume = (slabVolume + stepVolume) * qty;
        break;
    }

    if (volume <= 0) {
      toast.error(language === 'ar' ? 'يرجى إدخال أبعاد صحيحة' : 'Please enter valid dimensions');
      return;
    }

    // حساب وزن الحديد حسب الكود المختار
    // نسب الحديد تختلف حسب الكود
    const steelRatiosByCode: {[code: string]: {[element: string]: {min: number, max: number}}} = {
      "egyptian": { // الكود المصري ECP 203
        footing: { min: 80, max: 120 },
        column: { min: 100, max: 180 },
        beam: { min: 100, max: 160 },
        slab: { min: 60, max: 100 },
        stair: { min: 80, max: 120 }
      },
      "american": { // الكود الأمريكي ACI 318
        footing: { min: 75, max: 110 },
        column: { min: 120, max: 200 },
        beam: { min: 110, max: 180 },
        slab: { min: 55, max: 90 },
        stair: { min: 75, max: 110 }
      },
      "saudi": { // الكود السعودي SBC
        footing: { min: 85, max: 125 },
        column: { min: 110, max: 190 },
        beam: { min: 105, max: 170 },
        slab: { min: 65, max: 105 },
        stair: { min: 85, max: 125 }
      },
      "british": { // الكود البريطاني BS EN 1992 (Eurocode 2)
        footing: { min: 70, max: 100 },
        column: { min: 90, max: 160 },
        beam: { min: 95, max: 150 },
        slab: { min: 50, max: 85 },
        stair: { min: 70, max: 100 }
      }
    };

    const codeRatios = steelRatiosByCode[buildingCode] || steelRatiosByCode["egyptian"];
    const elementRatios = codeRatios[concreteElement] || codeRatios["footing"];
    // استخدام النسبة المدخلة إذا كانت في النطاق، أو المتوسط
    const effectiveRatio = concreteInputs.steelRatio > 0 ? concreteInputs.steelRatio : 
      (elementRatios.min + elementRatios.max) / 2;
    const steelWeight = volume * effectiveRatio;

    // نسب الخلطة حسب الكود والرتبة
    const mixRatiosByCode: {[code: string]: {[mix: string]: {cement: number, sand: number, gravel: number, water: number}}} = {
      "egyptian": { // ECP 203
        "C20": { cement: 320, sand: 0.5, gravel: 0.8, water: 160 },
        "C25": { cement: 350, sand: 0.45, gravel: 0.75, water: 175 },
        "C30": { cement: 400, sand: 0.4, gravel: 0.7, water: 180 },
        "C35": { cement: 450, sand: 0.35, gravel: 0.65, water: 185 }
      },
      "american": { // ACI 318 (w/c ratio based)
        "C20": { cement: 310, sand: 0.52, gravel: 0.82, water: 155 },
        "C25": { cement: 340, sand: 0.47, gravel: 0.77, water: 170 },
        "C30": { cement: 380, sand: 0.42, gravel: 0.72, water: 175 },
        "C35": { cement: 420, sand: 0.37, gravel: 0.67, water: 180 }
      },
      "saudi": { // SBC (similar to ACI with local adjustments)
        "C20": { cement: 325, sand: 0.48, gravel: 0.78, water: 165 },
        "C25": { cement: 360, sand: 0.43, gravel: 0.73, water: 180 },
        "C30": { cement: 410, sand: 0.38, gravel: 0.68, water: 185 },
        "C35": { cement: 460, sand: 0.33, gravel: 0.63, water: 190 }
      },
      "british": { // BS EN 1992 (Eurocode)
        "C20": { cement: 300, sand: 0.55, gravel: 0.85, water: 150 },
        "C25": { cement: 330, sand: 0.50, gravel: 0.80, water: 165 },
        "C30": { cement: 370, sand: 0.45, gravel: 0.75, water: 175 },
        "C35": { cement: 410, sand: 0.40, gravel: 0.70, water: 182 }
      }
    };

    const codeMixes = mixRatiosByCode[buildingCode] || mixRatiosByCode["egyptian"];
    const mix = codeMixes[concreteInputs.mixType] || codeMixes["C25"];
    
    // حساب المواد
    const cementKg = volume * mix.cement;
    const cementBags = Math.ceil(cementKg / 50); // كيس 50 كجم
    const sand = volume * mix.sand;
    const gravel = volume * mix.gravel;
    const water = volume * mix.water;
    
    // عدد الخلاطات (8 م³ للخلاطة)
    const mixerLoads = Math.ceil(volume / 8);

    setConcreteResult({
      volume,
      steelWeight,
      cement: cementBags,
      sand,
      gravel,
      water,
      mixerLoads
    });

    toast.success(language === 'ar' ? '✓ تم حساب الكميات' : '✓ Quantities calculated');
  };

  // Rebar (Steel Reinforcement) Calculator States
  type RebarDiameter = 6 | 8 | 10 | 12 | 14 | 16 | 18 | 20 | 22 | 25 | 28 | 32 | 36 | 40;
  const [rebarItems, setRebarItems] = useState<Array<{
    id: number;
    diameter: RebarDiameter;
    length: number;
    quantity: number;
    description: string;
  }>>([{ id: 1, diameter: 12, length: 12, quantity: 10, description: '' }]);
  const [rebarPricePerTon, setRebarPricePerTon] = useState<number>(25000);
  const [rebarCurrency, setRebarCurrency] = useState<string>('EGP');
  const [rebarResult, setRebarResult] = useState<{
    items: Array<{
      diameter: number;
      length: number;
      quantity: number;
      weightPerMeter: number;
      totalWeight: number;
      description: string;
    }>;
    totalWeight: number;
    totalCost: number;
    barsByDiameter: { [key: number]: { count: number; weight: number } };
  } | null>(null);

  // Rebar weight per meter (kg/m) based on diameter
  const rebarWeightPerMeter: { [key: number]: number } = {
    6: 0.222,
    8: 0.395,
    10: 0.617,
    12: 0.888,
    14: 1.21,
    16: 1.58,
    18: 2.0,
    20: 2.47,
    22: 2.98,
    25: 3.85,
    28: 4.83,
    32: 6.31,
    36: 7.99,
    40: 9.87
  };

  const addRebarItem = () => {
    const newId = Math.max(...rebarItems.map(i => i.id), 0) + 1;
    setRebarItems([...rebarItems, { id: newId, diameter: 12, length: 12, quantity: 1, description: '' }]);
  };

  const removeRebarItem = (id: number) => {
    if (rebarItems.length > 1) {
      setRebarItems(rebarItems.filter(i => i.id !== id));
    }
  };

  const updateRebarItem = (id: number, field: string, value: number | string) => {
    setRebarItems(rebarItems.map(item => 
      item.id === id ? { ...item, [field]: value } : item
    ));
  };

  const calculateRebar = () => {
    const items = rebarItems.map(item => {
      const weightPerMeter = rebarWeightPerMeter[item.diameter] || 0;
      const totalWeight = item.length * item.quantity * weightPerMeter;
      return {
        diameter: item.diameter,
        length: item.length,
        quantity: item.quantity,
        weightPerMeter,
        totalWeight,
        description: item.description
      };
    });

    const totalWeight = items.reduce((sum, item) => sum + item.totalWeight, 0);
    const totalCost = (totalWeight / 1000) * rebarPricePerTon;

    // Group by diameter
    const barsByDiameter: { [key: number]: { count: number; weight: number } } = {};
    items.forEach(item => {
      if (!barsByDiameter[item.diameter]) {
        barsByDiameter[item.diameter] = { count: 0, weight: 0 };
      }
      barsByDiameter[item.diameter].count += item.quantity;
      barsByDiameter[item.diameter].weight += item.totalWeight;
    });

    setRebarResult({
      items,
      totalWeight,
      totalCost,
      barsByDiameter
    });

    toast.success(language === 'ar' ? '✓ تم حساب كميات الحديد' : '✓ Rebar quantities calculated');
  };

  // Electrical Load Calculator States
  type ElectricalRoomType = "bedroom" | "living" | "kitchen" | "bathroom" | "office" | "shop" | "factory" | "warehouse";
  const [electricalRooms, setElectricalRooms] = useState<Array<{
    id: number;
    type: ElectricalRoomType;
    area: number;
    quantity: number;
    lights: number;
    sockets: number;
    ac: number;
    acPower: number;
    heater: number;
    heaterPower: number;
  }>>([{ id: 1, type: 'bedroom', area: 20, quantity: 1, lights: 2, sockets: 4, ac: 1, acPower: 1.5, heater: 0, heaterPower: 2 }]);
  
  const [electricalSettings, setElectricalSettings] = useState({
    voltage: 220,
    powerFactor: 0.85,
    demandFactor: 0.8,
    safetyFactor: 1.25
  });

  const [electricalResult, setElectricalResult] = useState<{
    totalLoad: number;
    demandLoad: number;
    current: number;
    breakerSize: number;
    cableSize: string;
    meterSize: number;
    roomsBreakdown: Array<{
      type: string;
      load: number;
      current: number;
    }>;
    recommendations: string[];
  } | null>(null);

  const addElectricalRoom = () => {
    const newId = Math.max(...electricalRooms.map(r => r.id), 0) + 1;
    setElectricalRooms([...electricalRooms, { 
      id: newId, type: 'bedroom', area: 20, quantity: 1, 
      lights: 2, sockets: 4, ac: 1, acPower: 1.5, heater: 0, heaterPower: 2 
    }]);
  };

  const removeElectricalRoom = (id: number) => {
    if (electricalRooms.length > 1) {
      setElectricalRooms(electricalRooms.filter(r => r.id !== id));
    }
  };

  const updateElectricalRoom = (id: number, field: string, value: number | string) => {
    setElectricalRooms(electricalRooms.map(room => 
      room.id === id ? { ...room, [field]: value } : room
    ));
  };

  const calculateElectrical = () => {
    const roomLoads: Array<{type: string; load: number; current: number}> = [];
    let totalLoad = 0;

    // حساب الحمل لكل غرفة
    electricalRooms.forEach(room => {
      let roomLoad = 0;
      
      // الإضاءة (LED ~10W per point)
      roomLoad += room.lights * 10 * room.quantity;
      
      // المقابس (متوسط 100W per socket)
      roomLoad += room.sockets * 100 * room.quantity;
      
      // التكييف (kW to W)
      roomLoad += room.ac * room.acPower * 1000 * room.quantity;
      
      // السخان (kW to W)
      roomLoad += room.heater * room.heaterPower * 1000 * room.quantity;
      
      // حمل إضافي حسب نوع الغرفة
      const roomTypeMultipliers: {[key: string]: number} = {
        bedroom: 1.0,
        living: 1.2,
        kitchen: 1.5,
        bathroom: 0.8,
        office: 1.3,
        shop: 1.4,
        factory: 2.0,
        warehouse: 0.6
      };
      
      roomLoad *= (roomTypeMultipliers[room.type] || 1.0);
      
      const roomCurrent = roomLoad / (electricalSettings.voltage * electricalSettings.powerFactor);
      
      const roomNames: {[key: string]: string} = {
        bedroom: language === 'ar' ? 'غرفة نوم' : 'Bedroom',
        living: language === 'ar' ? 'صالة' : 'Living Room',
        kitchen: language === 'ar' ? 'مطبخ' : 'Kitchen',
        bathroom: language === 'ar' ? 'حمام' : 'Bathroom',
        office: language === 'ar' ? 'مكتب' : 'Office',
        shop: language === 'ar' ? 'محل' : 'Shop',
        factory: language === 'ar' ? 'مصنع' : 'Factory',
        warehouse: language === 'ar' ? 'مخزن' : 'Warehouse'
      };
      
      roomLoads.push({
        type: `${roomNames[room.type]} (×${room.quantity})`,
        load: roomLoad,
        current: roomCurrent
      });
      
      totalLoad += roomLoad;
    });

    // حساب الحمل المطلوب
    const demandLoad = totalLoad * electricalSettings.demandFactor;
    
    // حساب التيار
    const current = (demandLoad * electricalSettings.safetyFactor) / (electricalSettings.voltage * electricalSettings.powerFactor);
    
    // تحديد حجم القاطع
    const breakerSizes = [16, 20, 25, 32, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400];
    const breakerSize = breakerSizes.find(s => s >= current) || breakerSizes[breakerSizes.length - 1];
    
    // تحديد مقاس الكابل
    const cableSizes: {[key: number]: string} = {
      16: '2.5 mm²',
      20: '4 mm²',
      25: '4 mm²',
      32: '6 mm²',
      40: '10 mm²',
      50: '10 mm²',
      63: '16 mm²',
      80: '25 mm²',
      100: '35 mm²',
      125: '50 mm²',
      160: '70 mm²',
      200: '95 mm²',
      250: '120 mm²',
      315: '150 mm²',
      400: '185 mm²'
    };
    const cableSize = cableSizes[breakerSize] || '185 mm²';
    
    // تحديد حجم العداد
    const meterSizes = [30, 60, 100, 200, 400];
    const meterSize = meterSizes.find(s => s >= current) || meterSizes[meterSizes.length - 1];
    
    // التوصيات
    const recommendations: string[] = [];
    if (current > 100) {
      recommendations.push(language === 'ar' ? '⚠️ يُنصح بتقسيم الأحمال على عدة لوحات فرعية' : '⚠️ Consider splitting loads across sub-panels');
    }
    if (totalLoad > 50000) {
      recommendations.push(language === 'ar' ? '⚡ الحمل كبير - يُفضل استخدام نظام ثلاثي الأطوار' : '⚡ High load - consider 3-phase system');
    }
    if (electricalRooms.some(r => r.ac > 2)) {
      recommendations.push(language === 'ar' ? '❄️ كثرة التكييفات - تأكد من توزيع الأحمال' : '❄️ Multiple ACs - ensure load distribution');
    }
    recommendations.push(language === 'ar' ? '✅ تأكد من تركيب قاطع تفاضلي (RCD) للحماية' : '✅ Install RCD for safety protection');

    setElectricalResult({
      totalLoad,
      demandLoad,
      current,
      breakerSize,
      cableSize,
      meterSize,
      roomsBreakdown: roomLoads,
      recommendations
    });

    toast.success(language === 'ar' ? '✓ تم حساب الأحمال الكهربائية' : '✓ Electrical load calculated');
  };

  // HVAC Calculator States
  type HVACRoomType = "bedroom" | "living" | "kitchen" | "bathroom" | "office" | "shop" | "restaurant" | "server_room" | "gym";
  const [hvacRooms, setHvacRooms] = useState<Array<{
    id: number;
    type: HVACRoomType;
    length: number;
    width: number;
    height: number;
    windows: number;
    windowArea: number;
    occupants: number;
    equipment: number;
    lighting: number;
    insulation: 'poor' | 'average' | 'good';
    sunExposure: 'north' | 'east' | 'south' | 'west';
  }>>([{ 
    id: 1, type: 'living', length: 5, width: 4, height: 3, 
    windows: 2, windowArea: 2, occupants: 4, equipment: 500, lighting: 200,
    insulation: 'average', sunExposure: 'south'
  }]);
  
  const [hvacSettings, setHvacSettings] = useState({
    outdoorTemp: 45,
    indoorTemp: 24,
    humidity: 50,
    location: 'desert' as 'desert' | 'coastal' | 'moderate'
  });

  const [hvacResult, setHvacResult] = useState<{
    totalCoolingLoad: number;
    totalHeatingLoad: number;
    totalBTU: number;
    acTonnage: number;
    cfm: number;
    roomsBreakdown: Array<{
      room: string;
      coolingLoad: number;
      btu: number;
    }>;
    recommendations: string[];
  } | null>(null);

  const addHvacRoom = () => {
    const newId = Math.max(...hvacRooms.map(r => r.id), 0) + 1;
    setHvacRooms([...hvacRooms, { 
      id: newId, type: 'bedroom', length: 4, width: 4, height: 3,
      windows: 1, windowArea: 1.5, occupants: 2, equipment: 100, lighting: 100,
      insulation: 'average', sunExposure: 'north'
    }]);
  };

  const removeHvacRoom = (id: number) => {
    if (hvacRooms.length > 1) {
      setHvacRooms(hvacRooms.filter(r => r.id !== id));
    }
  };

  const updateHvacRoom = (id: number, field: string, value: number | string) => {
    setHvacRooms(hvacRooms.map(room => 
      room.id === id ? { ...room, [field]: value } : room
    ));
  };

  const calculateHVAC = () => {
    const roomLoads: Array<{room: string; coolingLoad: number; btu: number}> = [];
    let totalCoolingLoad = 0;

    const roomNames: {[key: string]: string} = {
      bedroom: language === 'ar' ? 'غرفة نوم' : 'Bedroom',
      living: language === 'ar' ? 'صالة' : 'Living Room',
      kitchen: language === 'ar' ? 'مطبخ' : 'Kitchen',
      bathroom: language === 'ar' ? 'حمام' : 'Bathroom',
      office: language === 'ar' ? 'مكتب' : 'Office',
      shop: language === 'ar' ? 'محل' : 'Shop',
      restaurant: language === 'ar' ? 'مطعم' : 'Restaurant',
      server_room: language === 'ar' ? 'غرفة سيرفرات' : 'Server Room',
      gym: language === 'ar' ? 'صالة رياضة' : 'Gym'
    };

    // معاملات نوع الغرفة
    const roomFactors: {[key: string]: number} = {
      bedroom: 1.0,
      living: 1.1,
      kitchen: 1.8,
      bathroom: 0.8,
      office: 1.2,
      shop: 1.3,
      restaurant: 2.0,
      server_room: 3.0,
      gym: 1.5
    };

    // معاملات العزل
    const insulationFactors: {[key: string]: number} = {
      poor: 1.3,
      average: 1.0,
      good: 0.8
    };

    // معاملات اتجاه الشمس
    const sunFactors: {[key: string]: number} = {
      north: 0.8,
      east: 1.0,
      south: 1.2,
      west: 1.3
    };

    // معامل الموقع الجغرافي
    const locationFactors: {[key: string]: number} = {
      desert: 1.2,
      coastal: 1.1,
      moderate: 1.0
    };

    hvacRooms.forEach(room => {
      const volume = room.length * room.width * room.height;
      const area = room.length * room.width;
      
      // حساب حمل التبريد الأساسي (واط لكل متر مربع)
      let baseLoad = area * 100; // 100 واط/م² كأساس
      
      // إضافة حمل النوافذ
      const windowLoad = room.windows * room.windowArea * 300 * sunFactors[room.sunExposure];
      
      // حمل الأشخاص (حوالي 100-150 واط للشخص)
      const occupantLoad = room.occupants * 120;
      
      // حمل المعدات
      const equipmentLoad = room.equipment;
      
      // حمل الإضاءة
      const lightingLoad = room.lighting * 1.2;
      
      // إجمالي الحمل
      let totalRoomLoad = (baseLoad + windowLoad + occupantLoad + equipmentLoad + lightingLoad)
        * roomFactors[room.type]
        * insulationFactors[room.insulation]
        * locationFactors[hvacSettings.location];
      
      // تعديل حسب فرق درجة الحرارة
      const tempDiff = hvacSettings.outdoorTemp - hvacSettings.indoorTemp;
      totalRoomLoad *= (1 + (tempDiff - 20) * 0.02);
      
      // تحويل إلى BTU (1 واط = 3.412 BTU/hr)
      const btu = totalRoomLoad * 3.412;
      
      roomLoads.push({
        room: roomNames[room.type],
        coolingLoad: totalRoomLoad,
        btu: btu
      });
      
      totalCoolingLoad += totalRoomLoad;
    });

    const totalBTU = totalCoolingLoad * 3.412;
    const acTonnage = totalBTU / 12000; // 12000 BTU = 1 طن تبريد
    // CFM = BTU/hr / (1.08 × ΔT°F), where ΔT°F = ΔT°C × 1.8
    const tempDiffF = (hvacSettings.outdoorTemp - hvacSettings.indoorTemp) * 1.8;
    const cfm = totalBTU / (1.08 * tempDiffF);

    // التوصيات
    const recommendations: string[] = [];
    if (acTonnage > 5) {
      recommendations.push(language === 'ar' ? '💨 الحمل كبير - يُنصح بنظام تكييف مركزي' : '💨 High load - consider central AC system');
    }
    if (acTonnage <= 2) {
      recommendations.push(language === 'ar' ? '✅ يمكن استخدام تكييف سبليت صغير' : '✅ Small split AC is sufficient');
    }
    if (hvacSettings.outdoorTemp > 40) {
      recommendations.push(language === 'ar' ? '☀️ درجة حرارة خارجية عالية - اختر تكييف بكفاءة عالية' : '☀️ High outdoor temp - choose high efficiency AC');
    }
    if (hvacRooms.some(r => r.insulation === 'poor')) {
      recommendations.push(language === 'ar' ? '🏠 تحسين العزل سيقلل استهلاك الطاقة بنسبة 20-30%' : '🏠 Improving insulation can reduce energy by 20-30%');
    }
    recommendations.push(language === 'ar' ? '🌡️ درجة 24°م هي الأمثل للراحة والتوفير' : '🌡️ 24°C is optimal for comfort and savings');

    setHvacResult({
      totalCoolingLoad,
      totalHeatingLoad: totalCoolingLoad * 0.7, // تقريبي
      totalBTU,
      acTonnage,
      cfm,
      roomsBreakdown: roomLoads,
      recommendations
    });

    toast.success(language === 'ar' ? '✓ تم حساب حمل التكييف' : '✓ HVAC load calculated');
  };

  // Cost Estimator States
  type CostCurrency = "EGP" | "SAR" | "USD" | "EUR" | "AED";
  const [costCurrency, setCostCurrency] = useState<CostCurrency>("EGP");
  const [costItems, setCostItems] = useState<Array<{
    id: number;
    category: string;
    item: string;
    quantity: number;
    unit: string;
    materialPrice: number;
    laborPrice: number;
  }>>([{
    id: 1, category: 'concrete', item: 'خرسانة جاهزة', quantity: 10, unit: 'm³',
    materialPrice: 2500, laborPrice: 300
  }]);

  const [costResult, setCostResult] = useState<{
    totalMaterial: number;
    totalLabor: number;
    grandTotal: number;
    overhead: number;
    profit: number;
    finalTotal: number;
    breakdown: Array<{
      category: string;
      item: string;
      quantity: number;
      unit: string;
      materialCost: number;
      laborCost: number;
      total: number;
    }>;
  } | null>(null);

  const [costSettings, setCostSettings] = useState({
    overheadPercent: 10,
    profitPercent: 15,
    contingency: 5
  });

  const costCategories: {[key: string]: {ar: string; en: string; items: Array<{id: string; ar: string; en: string; unit: string; matPrice: number; labPrice: number}>}} = {
    concrete: {
      ar: '🏗️ خرسانة', en: '🏗️ Concrete',
      items: [
        { id: 'ready_mix', ar: 'خرسانة جاهزة', en: 'Ready Mix', unit: 'm³', matPrice: 2500, labPrice: 300 },
        { id: 'foundation', ar: 'أساسات', en: 'Foundation', unit: 'm³', matPrice: 2800, labPrice: 400 },
        { id: 'columns', ar: 'أعمدة', en: 'Columns', unit: 'm³', matPrice: 3000, labPrice: 500 },
        { id: 'slabs', ar: 'بلاطات', en: 'Slabs', unit: 'm³', matPrice: 2600, labPrice: 350 }
      ]
    },
    steel: {
      ar: '🔩 حديد', en: '🔩 Steel',
      items: [
        { id: 'rebar', ar: 'حديد تسليح', en: 'Rebar', unit: 'ton', matPrice: 35000, labPrice: 2000 },
        { id: 'mesh', ar: 'شبك حديد', en: 'Steel Mesh', unit: 'm²', matPrice: 80, labPrice: 15 },
        { id: 'structural', ar: 'حديد إنشائي', en: 'Structural Steel', unit: 'ton', matPrice: 40000, labPrice: 3000 }
      ]
    },
    masonry: {
      ar: '🧱 بناء', en: '🧱 Masonry',
      items: [
        { id: 'red_brick', ar: 'طوب أحمر', en: 'Red Brick', unit: '1000pcs', matPrice: 3500, labPrice: 800 },
        { id: 'cement_block', ar: 'بلوك أسمنتي', en: 'Cement Block', unit: '1000pcs', matPrice: 5000, labPrice: 1000 },
        { id: 'insulated_block', ar: 'بلوك عازل', en: 'Insulated Block', unit: '1000pcs', matPrice: 8000, labPrice: 1200 }
      ]
    },
    finishing: {
      ar: '🎨 تشطيبات', en: '🎨 Finishing',
      items: [
        { id: 'plastering', ar: 'محارة', en: 'Plastering', unit: 'm²', matPrice: 50, labPrice: 40 },
        { id: 'painting', ar: 'دهان', en: 'Painting', unit: 'm²', matPrice: 30, labPrice: 25 },
        { id: 'tiling', ar: 'بلاط', en: 'Tiling', unit: 'm²', matPrice: 200, labPrice: 80 },
        { id: 'marble', ar: 'رخام', en: 'Marble', unit: 'm²', matPrice: 500, labPrice: 120 }
      ]
    },
    electrical: {
      ar: '⚡ كهرباء', en: '⚡ Electrical',
      items: [
        { id: 'wiring', ar: 'أسلاك', en: 'Wiring', unit: 'point', matPrice: 150, labPrice: 100 },
        { id: 'panel', ar: 'لوحة كهرباء', en: 'Panel Board', unit: 'pc', matPrice: 2000, labPrice: 500 },
        { id: 'lighting', ar: 'إنارة', en: 'Lighting', unit: 'point', matPrice: 300, labPrice: 80 }
      ]
    },
    plumbing: {
      ar: '🔧 سباكة', en: '🔧 Plumbing',
      items: [
        { id: 'pipes', ar: 'مواسير', en: 'Pipes', unit: 'm', matPrice: 50, labPrice: 30 },
        { id: 'fixtures', ar: 'أطقم صحية', en: 'Fixtures', unit: 'set', matPrice: 3000, labPrice: 500 },
        { id: 'water_heater', ar: 'سخان', en: 'Water Heater', unit: 'pc', matPrice: 2500, labPrice: 300 }
      ]
    },
    hvac: {
      ar: '❄️ تكييف', en: '❄️ HVAC',
      items: [
        { id: 'split_ac', ar: 'سبليت', en: 'Split AC', unit: 'pc', matPrice: 8000, labPrice: 1000 },
        { id: 'central_ac', ar: 'مركزي', en: 'Central AC', unit: 'ton', matPrice: 15000, labPrice: 3000 },
        { id: 'ducting', ar: 'دكت', en: 'Ducting', unit: 'm', matPrice: 200, labPrice: 100 }
      ]
    }
  };

  const addCostItem = () => {
    const newId = Math.max(...costItems.map(i => i.id), 0) + 1;
    setCostItems([...costItems, {
      id: newId, category: 'concrete', item: 'خرسانة جاهزة', quantity: 1, unit: 'm³',
      materialPrice: 2500, laborPrice: 300
    }]);
  };

  const removeCostItem = (id: number) => {
    if (costItems.length > 1) {
      setCostItems(costItems.filter(i => i.id !== id));
    }
  };

  const updateCostItem = (id: number, field: string, value: string | number) => {
    setCostItems(costItems.map(item => {
      if (item.id === id) {
        if (field === 'category') {
          const cat = costCategories[value as string];
          if (cat && cat.items.length > 0) {
            const firstItem = cat.items[0];
            return {
              ...item,
              category: value as string,
              item: language === 'ar' ? firstItem.ar : firstItem.en,
              unit: firstItem.unit,
              materialPrice: firstItem.matPrice,
              laborPrice: firstItem.labPrice
            };
          }
        }
        if (field === 'itemSelect') {
          const cat = costCategories[item.category];
          const selectedItem = cat?.items.find(i => i.id === value);
          if (selectedItem) {
            return {
              ...item,
              item: language === 'ar' ? selectedItem.ar : selectedItem.en,
              unit: selectedItem.unit,
              materialPrice: selectedItem.matPrice,
              laborPrice: selectedItem.labPrice
            };
          }
        }
        return { ...item, [field]: value };
      }
      return item;
    }));
  };

  const calculateCost = () => {
    const breakdown: Array<{category: string; item: string; quantity: number; unit: string; materialCost: number; laborCost: number; total: number}> = [];
    let totalMaterial = 0;
    let totalLabor = 0;

    costItems.forEach(item => {
      const matCost = item.quantity * item.materialPrice;
      const labCost = item.quantity * item.laborPrice;
      const catName = costCategories[item.category];
      
      breakdown.push({
        category: language === 'ar' ? catName?.ar || item.category : catName?.en || item.category,
        item: item.item,
        quantity: item.quantity,
        unit: item.unit,
        materialCost: matCost,
        laborCost: labCost,
        total: matCost + labCost
      });
      
      totalMaterial += matCost;
      totalLabor += labCost;
    });

    const grandTotal = totalMaterial + totalLabor;
    const overhead = grandTotal * (costSettings.overheadPercent / 100);
    const profit = grandTotal * (costSettings.profitPercent / 100);
    const contingency = grandTotal * (costSettings.contingency / 100);
    const finalTotal = grandTotal + overhead + profit + contingency;

    setCostResult({
      totalMaterial,
      totalLabor,
      grandTotal,
      overhead,
      profit,
      finalTotal,
      breakdown
    });

    toast.success(language === 'ar' ? '✓ تم حساب التكلفة' : '✓ Cost calculated');
  };

  // Brick Calculator States
  type BrickType = "red_brick" | "cement_block" | "thermal_block" | "aac_block" | "hollow_block";
  const [brickType, setBrickType] = useState<BrickType>("red_brick");
  const [brickInputs, setBrickInputs] = useState({
    wallLength: 10,
    wallHeight: 3,
    wallThickness: 25, // cm
    openingsCount: 2,
    openingWidth: 1.2,
    openingHeight: 2.1,
    mortarThickness: 1, // cm
    wastagePercent: 5
  });

  const [brickResult, setBrickResult] = useState<{
    grossArea: number;
    openingsArea: number;
    netArea: number;
    bricksNeeded: number;
    bricksWithWastage: number;
    mortarVolume: number;
    cementBags: number;
    sandVolume: number;
    estimatedCost: number;
    laborDays: number;
  } | null>(null);

  // أنواع الطوب مع أبعادها
  const brickTypes: {[key: string]: {
    ar: string; en: string;
    length: number; width: number; height: number; // cm
    perM2: number; // عدد الطوب لكل متر مربع
    price: number; // سعر الوحدة
    laborRate: number; // عدد الطوب اليومي للعامل
  }} = {
    red_brick: {
      ar: '🧱 طوب أحمر', en: '🧱 Red Brick',
      length: 25, width: 12, height: 6,
      perM2: 52, price: 1.5, laborRate: 400
    },
    cement_block: {
      ar: '⬜ بلوك أسمنتي', en: '⬜ Cement Block',
      length: 40, width: 20, height: 20,
      perM2: 12.5, price: 8, laborRate: 80
    },
    thermal_block: {
      ar: '🔥 بلوك عازل حراري', en: '🔥 Thermal Block',
      length: 40, width: 20, height: 20,
      perM2: 12.5, price: 15, laborRate: 70
    },
    aac_block: {
      ar: '💨 بلوك خلوي (AAC)', en: '💨 AAC Block',
      length: 60, width: 20, height: 20,
      perM2: 8.3, price: 25, laborRate: 100
    },
    hollow_block: {
      ar: '⬛ بلوك مفرغ', en: '⬛ Hollow Block',
      length: 40, width: 20, height: 20,
      perM2: 12.5, price: 6, laborRate: 90
    }
  };

  const calculateBrick = () => {
    const bt = brickTypes[brickType];
    
    // حساب المساحة الإجمالية
    const grossArea = brickInputs.wallLength * brickInputs.wallHeight;
    
    // حساب مساحة الفتحات
    const openingsArea = brickInputs.openingsCount * brickInputs.openingWidth * brickInputs.openingHeight;
    
    // المساحة الصافية
    const netArea = Math.max(0, grossArea - openingsArea);
    
    // عدد الطوب المطلوب
    const bricksNeeded = Math.ceil(netArea * bt.perM2);
    
    // مع الهالك
    const bricksWithWastage = Math.ceil(bricksNeeded * (1 + brickInputs.wastagePercent / 100));
    
    // حجم المونة (تقريبي)
    // المونة = سمك المونة × المساحة الصافية × معامل (حوالي 0.3 للطوب العادي)
    const mortarFactor = brickType === 'red_brick' ? 0.03 : 0.02;
    const mortarVolume = netArea * (brickInputs.mortarThickness / 100) * (1 + mortarFactor * 10);
    
    // كمية الأسمنت (1 م³ مونة يحتاج حوالي 7 أكياس أسمنت)
    const cementBags = Math.ceil(mortarVolume * 7);
    
    // كمية الرمل (1 م³ مونة يحتاج حوالي 1.2 م³ رمل)
    const sandVolume = mortarVolume * 1.2;
    
    // التكلفة التقديرية
    const materialCost = bricksWithWastage * bt.price + cementBags * 50 + sandVolume * 100;
    
    // أيام العمل
    const laborDays = bricksWithWastage / bt.laborRate;

    setBrickResult({
      grossArea,
      openingsArea,
      netArea,
      bricksNeeded,
      bricksWithWastage,
      mortarVolume,
      cementBags,
      sandVolume,
      estimatedCost: materialCost,
      laborDays
    });

    toast.success(language === 'ar' ? '✓ تم حساب كميات الطوب' : '✓ Brick quantities calculated');
  };

  // Paint Calculator States
  type PaintType = "plastic" | "oil" | "acrylic" | "epoxy" | "textured";
  const [paintType, setPaintType] = useState<PaintType>("plastic");
  const [paintInputs, setPaintInputs] = useState({
    wallLength: 12,
    wallHeight: 3,
    doorsCount: 2,
    doorWidth: 0.9,
    doorHeight: 2.1,
    windowsCount: 3,
    windowWidth: 1.2,
    windowHeight: 1.5,
    coats: 2,
    includePutty: true
  });

  const [paintResult, setPaintResult] = useState<{
    grossArea: number;
    deductions: number;
    netArea: number;
    paintLiters: number;
    paintBuckets: number;
    puttyKg: number;
    primerLiters: number;
    estimatedCost: number;
    laborDays: number;
  } | null>(null);

  const paintTypes: {[key: string]: {
    ar: string; en: string;
    coverage: number; // m² per liter
    price: number; // per liter
    coatsNeeded: number;
  }} = {
    plastic: { ar: '🎨 بلاستيك', en: '🎨 Plastic', coverage: 12, price: 80, coatsNeeded: 2 },
    oil: { ar: '🛢️ زيتي', en: '🛢️ Oil', coverage: 14, price: 120, coatsNeeded: 2 },
    acrylic: { ar: '✨ أكريليك', en: '✨ Acrylic', coverage: 10, price: 150, coatsNeeded: 2 },
    epoxy: { ar: '🔒 إيبوكسي', en: '🔒 Epoxy', coverage: 8, price: 250, coatsNeeded: 2 },
    textured: { ar: '🏔️ تكستشر', en: '🏔️ Textured', coverage: 4, price: 200, coatsNeeded: 1 }
  };

  const calculatePaint = () => {
    const pt = paintTypes[paintType];
    const grossArea = paintInputs.wallLength * paintInputs.wallHeight * 4; // 4 walls
    const doorsArea = paintInputs.doorsCount * paintInputs.doorWidth * paintInputs.doorHeight;
    const windowsArea = paintInputs.windowsCount * paintInputs.windowWidth * paintInputs.windowHeight;
    const deductions = doorsArea + windowsArea;
    const netArea = Math.max(0, grossArea - deductions);
    
    const paintLiters = (netArea * paintInputs.coats) / pt.coverage;
    const paintBuckets = Math.ceil(paintLiters / 18); // 18L bucket
    const puttyKg = paintInputs.includePutty ? netArea * 0.5 : 0; // 0.5 kg/m²
    const primerLiters = netArea / 15; // primer coverage ~15 m²/L
    
    const materialCost = (paintLiters * pt.price) + (puttyKg * 15) + (primerLiters * 50);
    const laborDays = netArea / 30; // ~30 m²/day

    setPaintResult({
      grossArea, deductions, netArea, paintLiters, paintBuckets, puttyKg, primerLiters,
      estimatedCost: materialCost, laborDays
    });
    toast.success(language === 'ar' ? '✓ تم حساب كميات الدهان' : '✓ Paint calculated');
  };

  // Tiles Calculator States
  type TileType = "ceramic" | "porcelain" | "marble" | "granite" | "mosaic";
  const [tileType, setTileType] = useState<TileType>("ceramic");
  const [tilesInputs, setTilesInputs] = useState({
    roomLength: 5,
    roomWidth: 4,
    tileLength: 60, // cm
    tileWidth: 60, // cm
    jointWidth: 3, // mm
    wastagePercent: 10
  });

  const [tilesResult, setTilesResult] = useState<{
    floorArea: number;
    tileArea: number;
    tilesNeeded: number;
    tilesWithWastage: number;
    boxesNeeded: number;
    groutKg: number;
    adhesiveKg: number;
    estimatedCost: number;
  } | null>(null);

  const tileTypes: {[key: string]: {
    ar: string; en: string;
    pricePerM2: number;
    tilesPerBox: number;
  }} = {
    ceramic: { ar: '🔲 سيراميك', en: '🔲 Ceramic', pricePerM2: 150, tilesPerBox: 6 },
    porcelain: { ar: '💎 بورسلين', en: '💎 Porcelain', pricePerM2: 250, tilesPerBox: 4 },
    marble: { ar: '🏛️ رخام', en: '🏛️ Marble', pricePerM2: 400, tilesPerBox: 4 },
    granite: { ar: '🪨 جرانيت', en: '🪨 Granite', pricePerM2: 350, tilesPerBox: 4 },
    mosaic: { ar: '🎭 موزاييك', en: '🎭 Mosaic', pricePerM2: 200, tilesPerBox: 10 }
  };

  const calculateTiles = () => {
    const tt = tileTypes[tileType];
    const floorArea = tilesInputs.roomLength * tilesInputs.roomWidth;
    const tileArea = (tilesInputs.tileLength / 100) * (tilesInputs.tileWidth / 100);
    const tilesNeeded = Math.ceil(floorArea / tileArea);
    const tilesWithWastage = Math.ceil(tilesNeeded * (1 + tilesInputs.wastagePercent / 100));
    const boxesNeeded = Math.ceil(tilesWithWastage / tt.tilesPerBox);
    const groutKg = floorArea * 0.3; // ~0.3 kg/m²
    const adhesiveKg = floorArea * 5; // ~5 kg/m²
    const materialCost = (floorArea * tt.pricePerM2) + (groutKg * 20) + (adhesiveKg * 3);

    setTilesResult({
      floorArea, tileArea, tilesNeeded, tilesWithWastage, boxesNeeded, groutKg, adhesiveKg,
      estimatedCost: materialCost
    });
    toast.success(language === 'ar' ? '✓ تم حساب كميات البلاط' : '✓ Tiles calculated');
  };

  // Stairs Calculator States
  const [stairsInputs, setStairsInputs] = useState({
    totalHeight: 3, // m
    floorLength: 4, // m
    stairWidth: 1.2, // m
    riserHeight: 17, // cm (recommended 15-18)
    treadDepth: 28 // cm (recommended 25-30)
  });

  const [stairsResult, setStairsResult] = useState<{
    numberOfRisers: number;
    numberOfTreads: number;
    actualRiserHeight: number;
    stairAngle: number;
    totalRunLength: number;
    isComfortable: boolean;
    concreteVolume: number;
    rebarWeight: number;
  } | null>(null);

  const calculateStairs = () => {
    const totalHeightCm = stairsInputs.totalHeight * 100;
    const numberOfRisers = Math.ceil(totalHeightCm / stairsInputs.riserHeight);
    const numberOfTreads = numberOfRisers - 1;
    const actualRiserHeight = totalHeightCm / numberOfRisers;
    const totalRunLength = numberOfTreads * (stairsInputs.treadDepth / 100);
    const stairAngle = Math.atan(stairsInputs.totalHeight / totalRunLength) * (180 / Math.PI);
    
    // Comfort check: 2R + T should be 60-65 cm
    const comfortFormula = (2 * actualRiserHeight) + stairsInputs.treadDepth;
    const isComfortable = comfortFormula >= 60 && comfortFormula <= 65;
    
    // Concrete volume (approximate)
    const slabThickness = 0.15; // 15cm slab
    const stairLength = Math.sqrt(Math.pow(stairsInputs.totalHeight, 2) + Math.pow(totalRunLength, 2));
    const concreteVolume = stairLength * stairsInputs.stairWidth * slabThickness * 1.3; // 1.3 factor for steps
    
    const rebarWeight = concreteVolume * 100; // ~100 kg/m³

    setStairsResult({
      numberOfRisers, numberOfTreads, actualRiserHeight, stairAngle, totalRunLength,
      isComfortable, concreteVolume, rebarWeight
    });
    toast.success(language === 'ar' ? '✓ تم حساب السلم' : '✓ Stairs calculated');
  };

  // Water Tank Calculator States
  const [tankInputs, setTankInputs] = useState({
    residents: 6,
    dailyConsumption: 200, // liters per person
    storageDays: 2,
    buildingFloors: 3,
    hasFire: false,
    hasGarden: false
  });

  const [tankResult, setTankResult] = useState<{
    dailyDemand: number;
    totalCapacity: number;
    groundTankVolume: number;
    roofTankVolume: number;
    dimensions: { length: number; width: number; height: number };
    pumpPower: number;
    estimatedCost: number;
  } | null>(null);

  const calculateTank = () => {
    let dailyDemand = tankInputs.residents * tankInputs.dailyConsumption;
    if (tankInputs.hasGarden) dailyDemand += 500; // extra for garden
    if (tankInputs.hasFire) dailyDemand += 1000; // fire reserve
    
    const totalCapacity = dailyDemand * tankInputs.storageDays;
    const groundTankVolume = totalCapacity * 0.7; // 70% ground
    const roofTankVolume = totalCapacity * 0.3; // 30% roof
    
    // Calculate dimensions (L:W:H = 2:1:1.5)
    // Volume = L × W × H = 2w × w × 1.5w = 3w³
    const volumeM3 = groundTankVolume / 1000;
    const width = Math.pow(volumeM3 / 3, 1/3);
    const length = width * 2;
    const height = width * 1.5;
    
    // Pump power (approximate)
    const headHeight = tankInputs.buildingFloors * 3 + 5; // floors + friction
    const pumpPower = (dailyDemand * headHeight * 9.81) / (3600 * 1000 * 0.6); // kW
    
    const estimatedCost = volumeM3 * 2000; // ~2000 EGP/m³

    setTankResult({
      dailyDemand, totalCapacity, groundTankVolume, roofTankVolume,
      dimensions: { length, width, height },
      pumpPower, estimatedCost
    });
    toast.success(language === 'ar' ? '✓ تم حساب الخزان' : '✓ Tank calculated');
  };

  // Foundation Calculator States
  type FoundationType = "strip" | "raft" | "isolated" | "pile";
  const [foundationType, setFoundationType] = useState<FoundationType>("strip");
  const [foundationInputs, setFoundationInputs] = useState({
    columnLoad: 500, // kN
    soilBearing: 250, // kPa
    length: 5, // m
    width: 1, // m
    depth: 1.5, // m
    concreteFc: 25, // MPa
    steelFy: 420, // MPa
    safetyFactor: 3
  });
  const [foundationResult, setFoundationResult] = useState<{
    requiredArea: number;
    actualArea: number;
    safetyMargin: number;
    concreteVolume: number;
    rebarWeight: number;
    cost: number;
    isAdequate: boolean;
    recommendations: string[];
  } | null>(null);

  const calculateFoundation = () => {
    const requiredArea = (foundationInputs.columnLoad * foundationInputs.safetyFactor) / foundationInputs.soilBearing;
    const actualArea = foundationInputs.length * foundationInputs.width;
    const safetyMargin = (actualArea / requiredArea - 1) * 100;
    const concreteVolume = actualArea * foundationInputs.depth;
    const rebarWeight = concreteVolume * 100; // 100 kg/m³
    const cost = concreteVolume * 450 + rebarWeight * 15; // EGP

    const isAdequate = actualArea >= requiredArea;
    const recommendations: string[] = [];
    
    if (isAdequate) {
      recommendations.push(language === 'ar' ? '✅ الأساس كافي' : '✅ Foundation is adequate');
    } else {
      recommendations.push(language === 'ar' ? '⚠️ زيادة أبعاد الأساس' : '⚠️ Increase foundation size');
    }
    if (safetyMargin > 50) recommendations.push(language === 'ar' ? '💡 يمكن تقليل الأبعاد' : '💡 Can reduce size');

    setFoundationResult({ requiredArea, actualArea, safetyMargin, concreteVolume, rebarWeight, cost, isAdequate, recommendations });
    toast.success(language === 'ar' ? '✓ تم حساب الأساس' : '✓ Foundation calculated');
  };

  // Sewage Network Simulator States
  type SewageNetworkType = "gravity" | "pressure" | "vacuum" | "combined";
  const [sewageType, setSewageType] = useState<SewageNetworkType>("gravity");
  const [sewageInputs, setSewageInputs] = useState({
    population: 5000,
    peakFactor: 2.5,
    infiltration: 10, // L/s/km
    pipeLength: 500, // m
    pipeDiameter: 300, // mm
    pipeSlope: 0.5, // %
    manningN: 0.013, // PVC
    inletDepth: 1.5, // m
    outletDepth: 2.5 // m
  });

  // Projects Manager State
  const [projects, setProjects] = useState<Array<{id: string; name: string; date: string; data: any}>>(() => {
    try {
      const saved = localStorage.getItem('surveyProjects');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [projectName, setProjectName] = useState('');

  const saveProject = () => {
    if (!projectName.trim()) return;
    const project = {
      id: Date.now().toString(),
      name: projectName,
      date: new Date().toLocaleString('ar-EG'),
      data: { calcType, result, inputs }
    };
    const updated = [...projects, project];
    setProjects(updated);
    localStorage.setItem('surveyProjects', JSON.stringify(updated));
    setProjectName('');
    toast.success(language === 'ar' ? '✓ تم حفظ المشروع' : '✓ Project saved');
  };

  const loadProject = (id: string) => {
    const project = projects.find(p => p.id === id);
    if (project) {
      setCalcType(project.data.calcType);
      setResult(project.data.result);
      setInputs(project.data.inputs);
      toast.success(language === 'ar' ? '✓ تم تحميل المشروع' : '✓ Project loaded');
    }
  };

  const exportToExcel = () => {
    if (!result) return;
    let csv = `${language === 'ar' ? 'تقرير' : 'Report'}\n`;
    csv += new Date().toLocaleString() + '\n\n';
    csv += JSON.stringify(result, null, 2);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `calculation-${Date.now()}.csv`;
    a.click();
    toast.success(language === 'ar' ? '✓ تم التصدير' : '✓ Exported');
  };

  const [sewageResult, setSewageResult] = useState<{
    avgFlow: number;
    peakFlow: number;
    designFlow: number;
    velocity: number;
    capacity: number;
    fillRatio: number;
    isSelfCleansing: boolean;
    hydraulicRadius: number;
    froudeNumber: number;
    shearStress: number;
    recommendations: string[];
  } | null>(null);

  const calculateSewage = () => {
    // Average sewage flow (L/s) - 200 L/person/day
    const avgFlow = (sewageInputs.population * 200) / (24 * 3600);
    
    // Peak flow
    const peakFlow = avgFlow * sewageInputs.peakFactor;
    
    // Add infiltration
    const infiltrationFlow = (sewageInputs.infiltration * sewageInputs.pipeLength) / 1000;
    const designFlow = peakFlow + infiltrationFlow;
    
    // Pipe geometry
    const diameter = sewageInputs.pipeDiameter / 1000; // m
    const area = Math.PI * Math.pow(diameter, 2) / 4;
    const wetPerimeter = Math.PI * diameter;
    const hydraulicRadius = area / wetPerimeter; // for full pipe
    
    // Manning's equation: V = (1/n) * R^(2/3) * S^(1/2)
    const slope = sewageInputs.pipeSlope / 100;
    const velocity = (1 / sewageInputs.manningN) * Math.pow(hydraulicRadius, 2/3) * Math.pow(slope, 0.5);
    
    // Capacity (L/s)
    const capacity = velocity * area * 1000;
    
    // Fill ratio
    const fillRatio = Math.min(designFlow / capacity, 1);
    
    // Self-cleansing check (minimum velocity 0.6 m/s)
    const isSelfCleansing = velocity >= 0.6;
    
    // Froude number (for flow type)
    const froudeNumber = velocity / Math.sqrt(9.81 * diameter);
    
    // Shear stress (N/m²)
    const shearStress = 1000 * 9.81 * hydraulicRadius * slope;

    // Recommendations
    const recommendations: string[] = [];
    if (!isSelfCleansing) {
      recommendations.push(language === 'ar' 
        ? '⚠️ السرعة أقل من 0.6 م/ث - خطر الترسب' 
        : '⚠️ Velocity < 0.6 m/s - Sedimentation risk');
    }
    if (velocity > 3.0) {
      recommendations.push(language === 'ar'
        ? '⚠️ السرعة أعلى من 3 م/ث - خطر التآكل'
        : '⚠️ Velocity > 3 m/s - Erosion risk');
    }
    if (fillRatio > 0.8) {
      recommendations.push(language === 'ar'
        ? '⚠️ نسبة الامتلاء > 80% - يُنصح بقطر أكبر'
        : '⚠️ Fill ratio > 80% - Consider larger diameter');
    }
    if (fillRatio < 0.2) {
      recommendations.push(language === 'ar'
        ? '💡 نسبة الامتلاء < 20% - القطر كبير جداً'
        : '💡 Fill ratio < 20% - Pipe oversized');
    }
    if (shearStress < 1.0) {
      recommendations.push(language === 'ar'
        ? '⚠️ إجهاد القص < 1 N/m² - خطر تراكم الرواسب'
        : '⚠️ Shear stress < 1 N/m² - Sediment buildup risk');
    }
    if (recommendations.length === 0) {
      recommendations.push(language === 'ar' ? '✅ التصميم مثالي' : '✅ Design is optimal');
    }

    setSewageResult({
      avgFlow, peakFlow, designFlow, velocity, capacity, fillRatio,
      isSelfCleansing, hydraulicRadius, froudeNumber, shearStress, recommendations
    });

    toast.success(language === 'ar' ? '✓ تم تحليل شبكة الصرف' : '✓ Sewage network analyzed');
  };

  // BOQ (Bill of Quantities) Calculator States
  type BOQCategory = "masonry" | "plastering" | "tiling" | "painting" | "waterproofing" | "doors" | "windows" | "electrical" | "plumbing";
  const [boqCategory, setBoqCategory] = useState<BOQCategory>("masonry");
  const [boqInputs, setBoqInputs] = useState({
    // Common
    length: 0,
    width: 0,
    height: 0,
    area: 0,
    quantity: 1,
    // Masonry specific
    blockSize: "20x20x40", // cm
    mortarThickness: 1, // cm
    openingsArea: 0, // m²
    // Plastering
    plasterThickness: 2, // cm
    coats: 2,
    // Tiling
    tileSize: "60x60", // cm
    groutWidth: 3, // mm
    wasteFactor: 10, // %
    // Painting
    coatsCount: 2,
    coverage: 12, // m²/liter
    // Doors & Windows
    doorType: "wooden", // wooden, aluminum, steel
    windowType: "aluminum",
    // Electrical
    pointsCount: 0,
    circuitsCount: 0,
    // Plumbing
    coldPoints: 0,
    hotPoints: 0,
    drainPoints: 0
  });
  const [boqResult, setBoqResult] = useState<{
    items: Array<{
      name: string;
      nameEn: string;
      quantity: number;
      unit: string;
      unitPrice?: number;
      totalPrice?: number;
    }>;
    totalArea?: number;
    summary?: string;
  } | null>(null);

  // BOQ calculation function
  const calculateBOQ = () => {
    const items: Array<{name: string; nameEn: string; quantity: number; unit: string}> = [];
    let totalArea = 0;

    switch (boqCategory) {
      case "masonry": {
        // حساب البلوك/الطوب
        const wallArea = boqInputs.length * boqInputs.height * boqInputs.quantity;
        const netArea = wallArea - boqInputs.openingsArea;
        totalArea = netArea;
        
        // أبعاد البلوك
        const blockDimensions: {[key: string]: {l: number; h: number; w: number}} = {
          "20x20x40": { l: 0.4, h: 0.2, w: 0.2 },
          "15x20x40": { l: 0.4, h: 0.2, w: 0.15 },
          "10x20x40": { l: 0.4, h: 0.2, w: 0.1 },
          "12x25x25": { l: 0.25, h: 0.25, w: 0.12 }, // طوب أحمر
        };
        const block = blockDimensions[boqInputs.blockSize] || blockDimensions["20x20x40"];
        const blockArea = block.l * block.h;
        const blocksPerM2 = 1 / blockArea;
        const totalBlocks = Math.ceil(netArea * blocksPerM2 * 1.05); // 5% هالك
        
        items.push({ name: "بلوك/طوب", nameEn: "Blocks/Bricks", quantity: totalBlocks, unit: "قطعة" });
        
        // المونة
        const mortarVolume = netArea * (boqInputs.mortarThickness / 100) * 1.3; // 30% إضافي للفواصل
        const cementBags = Math.ceil(mortarVolume * 350 / 50); // 350 كجم/م³
        const sandM3 = mortarVolume * 1.2;
        
        items.push({ name: "أسمنت", nameEn: "Cement", quantity: cementBags, unit: "كيس 50كجم" });
        items.push({ name: "رمل", nameEn: "Sand", quantity: Number(sandM3.toFixed(2)), unit: "م³" });
        break;
      }
      
      case "plastering": {
        // حساب المحارة/اللياسة
        const wallArea = boqInputs.area > 0 ? boqInputs.area : boqInputs.length * boqInputs.height;
        totalArea = wallArea * boqInputs.quantity;
        const netArea = totalArea - boqInputs.openingsArea;
        
        // حجم المحارة
        const plasterVolume = netArea * (boqInputs.plasterThickness / 100) * boqInputs.coats;
        
        // المواد
        const cementBags = Math.ceil(plasterVolume * 400 / 50); // 400 كجم/م³ للمحارة
        const sandM3 = plasterVolume * 1.5;
        const waterLiters = plasterVolume * 200;
        
        items.push({ name: "مساحة المحارة", nameEn: "Plaster Area", quantity: Number(netArea.toFixed(2)), unit: "م²" });
        items.push({ name: "أسمنت", nameEn: "Cement", quantity: cementBags, unit: "كيس 50كجم" });
        items.push({ name: "رمل ناعم", nameEn: "Fine Sand", quantity: Number(sandM3.toFixed(2)), unit: "م³" });
        items.push({ name: "ماء", nameEn: "Water", quantity: Math.ceil(waterLiters), unit: "لتر" });
        break;
      }
      
      case "tiling": {
        // حساب البلاط/السيراميك
        const floorArea = boqInputs.area > 0 ? boqInputs.area : boqInputs.length * boqInputs.width;
        totalArea = floorArea * boqInputs.quantity;
        
        // أبعاد البلاط
        const tileSizes: {[key: string]: {l: number; w: number}} = {
          "60x60": { l: 0.6, w: 0.6 },
          "80x80": { l: 0.8, w: 0.8 },
          "60x120": { l: 1.2, w: 0.6 },
          "40x40": { l: 0.4, w: 0.4 },
          "30x30": { l: 0.3, w: 0.3 },
          "20x20": { l: 0.2, w: 0.2 },
        };
        const tile = tileSizes[boqInputs.tileSize] || tileSizes["60x60"];
        const tileArea = tile.l * tile.w;
        const tilesNeeded = Math.ceil(totalArea / tileArea);
        const tilesWithWaste = Math.ceil(tilesNeeded * (1 + boqInputs.wasteFactor / 100));
        
        // اللاصق والروبة
        const adhesiveKg = totalArea * 4; // 4 كجم/م² تقريباً
        const groutKg = totalArea * 0.5; // 0.5 كجم/م²
        
        items.push({ name: "بلاط/سيراميك", nameEn: "Tiles/Ceramic", quantity: tilesWithWaste, unit: "قطعة" });
        items.push({ name: "أمتار مربعة", nameEn: "Square Meters", quantity: Number((tilesWithWaste * tileArea).toFixed(2)), unit: "م²" });
        items.push({ name: "لاصق بلاط", nameEn: "Tile Adhesive", quantity: Math.ceil(adhesiveKg / 25), unit: "كيس 25كجم" });
        items.push({ name: "روبة (فوجة)", nameEn: "Grout", quantity: Math.ceil(groutKg / 3), unit: "كيس 3كجم" });
        break;
      }
      
      case "painting": {
        // حساب الدهانات
        const wallArea = boqInputs.area > 0 ? boqInputs.area : boqInputs.length * boqInputs.height;
        totalArea = wallArea * boqInputs.quantity;
        const netArea = totalArea - boqInputs.openingsArea;
        
        // كمية الدهان
        const litersNeeded = (netArea * boqInputs.coatsCount) / boqInputs.coverage;
        const gallons = Math.ceil(litersNeeded / 18); // جالون 18 لتر
        const buckets = Math.ceil(litersNeeded / 4); // سطل 4 لتر
        
        // المعجون والسيلر
        const puttyKg = netArea * 0.5; // 0.5 كجم/م²
        const sealerLiters = netArea / 10; // 10 م²/لتر
        
        items.push({ name: "مساحة الدهان", nameEn: "Paint Area", quantity: Number(netArea.toFixed(2)), unit: "م²" });
        items.push({ name: "دهان (جالون 18ل)", nameEn: "Paint (18L)", quantity: gallons, unit: "جالون" });
        items.push({ name: "دهان (سطل 4ل)", nameEn: "Paint (4L)", quantity: buckets, unit: "سطل" });
        items.push({ name: "معجون", nameEn: "Putty", quantity: Math.ceil(puttyKg / 25), unit: "كيس 25كجم" });
        items.push({ name: "سيلر/برايمر", nameEn: "Sealer/Primer", quantity: Math.ceil(sealerLiters / 4), unit: "جالون 4ل" });
        break;
      }
      
      case "waterproofing": {
        // حساب العزل المائي
        const area = boqInputs.area > 0 ? boqInputs.area : boqInputs.length * boqInputs.width;
        totalArea = area * boqInputs.quantity;
        
        // المواد
        const bitumenKg = totalArea * 2.5; // 2.5 كجم/م²
        const membraneRolls = Math.ceil(totalArea / 10); // 10 م²/رول
        const primerLiters = totalArea * 0.3;
        
        items.push({ name: "مساحة العزل", nameEn: "Waterproofing Area", quantity: Number(totalArea.toFixed(2)), unit: "م²" });
        items.push({ name: "رولات ممبرين", nameEn: "Membrane Rolls", quantity: membraneRolls, unit: "رول" });
        items.push({ name: "بيتومين سائل", nameEn: "Liquid Bitumen", quantity: Math.ceil(bitumenKg / 20), unit: "جركن 20كجم" });
        items.push({ name: "برايمر", nameEn: "Primer", quantity: Math.ceil(primerLiters / 18), unit: "جالون 18ل" });
        break;
      }
      
      case "doors": {
        // حساب الأبواب
        const qty = boqInputs.quantity || 1;
        
        const doorPrices: {[key: string]: {frame: string; leaf: string; hardware: string}} = {
          "wooden": { frame: "إطار خشب", leaf: "ضلفة خشب", hardware: "مفصلات وكالون" },
          "aluminum": { frame: "إطار ألمنيوم", leaf: "ضلفة ألمنيوم", hardware: "مفصلات وقفل" },
          "steel": { frame: "إطار حديد", leaf: "ضلفة حديد", hardware: "مفصلات وقفل أمان" },
        };
        const door = doorPrices[boqInputs.doorType] || doorPrices["wooden"];
        
        items.push({ name: door.frame, nameEn: "Door Frame", quantity: qty, unit: "قطعة" });
        items.push({ name: door.leaf, nameEn: "Door Leaf", quantity: qty, unit: "قطعة" });
        items.push({ name: door.hardware, nameEn: "Hardware", quantity: qty, unit: "طقم" });
        items.push({ name: "وزرة باب", nameEn: "Door Sill", quantity: qty, unit: "قطعة" });
        break;
      }
      
      case "windows": {
        // حساب النوافذ
        const windowArea = boqInputs.length * boqInputs.width * boqInputs.quantity;
        totalArea = windowArea;
        
        items.push({ name: "مساحة النوافذ", nameEn: "Window Area", quantity: Number(windowArea.toFixed(2)), unit: "م²" });
        items.push({ name: "إطار ألمنيوم", nameEn: "Aluminum Frame", quantity: boqInputs.quantity, unit: "قطعة" });
        items.push({ name: "زجاج", nameEn: "Glass", quantity: Number((windowArea * 1.1).toFixed(2)), unit: "م²" });
        items.push({ name: "سيليكون", nameEn: "Silicone", quantity: Math.ceil(boqInputs.quantity * 0.5), unit: "أنبوب" });
        items.push({ name: "مقابض ومفصلات", nameEn: "Handles & Hinges", quantity: boqInputs.quantity, unit: "طقم" });
        break;
      }
      
      case "electrical": {
        // حساب الكهرباء
        const totalPoints = boqInputs.pointsCount * boqInputs.quantity;
        
        // تقدير المواد
        const wireMeters = totalPoints * 8; // 8 متر لكل نقطة تقريباً
        const conduitMeters = wireMeters * 0.8;
        const boxes = totalPoints;
        const switches = Math.ceil(totalPoints * 0.3);
        const outlets = Math.ceil(totalPoints * 0.7);
        
        items.push({ name: "إجمالي النقاط", nameEn: "Total Points", quantity: totalPoints, unit: "نقطة" });
        items.push({ name: "سلك 2.5مم", nameEn: "Wire 2.5mm", quantity: Math.ceil(wireMeters / 100), unit: "لفة 100م" });
        items.push({ name: "خرطوم كهرباء", nameEn: "Conduit", quantity: Math.ceil(conduitMeters), unit: "متر" });
        items.push({ name: "علب كهرباء", nameEn: "Junction Boxes", quantity: boxes, unit: "قطعة" });
        items.push({ name: "مفاتيح", nameEn: "Switches", quantity: switches, unit: "قطعة" });
        items.push({ name: "بريزات", nameEn: "Outlets", quantity: outlets, unit: "قطعة" });
        items.push({ name: "لوحة توزيع", nameEn: "Distribution Board", quantity: boqInputs.circuitsCount || 1, unit: "لوحة" });
        break;
      }
      
      case "plumbing": {
        // حساب السباكة
        const totalCold = boqInputs.coldPoints * boqInputs.quantity;
        const totalHot = boqInputs.hotPoints * boqInputs.quantity;
        const totalDrain = boqInputs.drainPoints * boqInputs.quantity;
        const totalPoints = totalCold + totalHot + totalDrain;
        
        // تقدير المواد
        const pprMeters = (totalCold + totalHot) * 3; // 3 متر لكل نقطة
        const pvcMeters = totalDrain * 2;
        
        items.push({ name: "نقاط مياه باردة", nameEn: "Cold Water Points", quantity: totalCold, unit: "نقطة" });
        items.push({ name: "نقاط مياه ساخنة", nameEn: "Hot Water Points", quantity: totalHot, unit: "نقطة" });
        items.push({ name: "نقاط صرف", nameEn: "Drain Points", quantity: totalDrain, unit: "نقطة" });
        items.push({ name: "مواسير PPR", nameEn: "PPR Pipes", quantity: Math.ceil(pprMeters), unit: "متر" });
        items.push({ name: "مواسير PVC صرف", nameEn: "PVC Drain Pipes", quantity: Math.ceil(pvcMeters), unit: "متر" });
        items.push({ name: "كوع وتيات", nameEn: "Elbows & Tees", quantity: totalPoints * 3, unit: "قطعة" });
        items.push({ name: "محابس", nameEn: "Valves", quantity: Math.ceil(totalPoints * 0.3), unit: "قطعة" });
        break;
      }
    }

    if (items.length === 0) {
      toast.error(language === 'ar' ? 'يرجى إدخال القيم المطلوبة' : 'Please enter required values');
      return;
    }

    setBoqResult({ items, totalArea });
    toast.success(language === 'ar' ? '✓ تم حصر الكميات' : '✓ Quantities calculated');
  };

  // Export BOQ to Excel/CSV
  const exportBOQ = () => {
    if (!boqResult) return;
    
    const headers = language === 'ar' 
      ? "البند,الوصف,الكمية,الوحدة"
      : "Item,Description,Quantity,Unit";
    
    const rows = boqResult.items.map((item, idx) => 
      `${idx + 1},${language === 'ar' ? item.name : item.nameEn},${item.quantity},${item.unit}`
    ).join('\n');
    
    const csv = `${headers}\n${rows}`;
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `boq-${boqCategory}-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    
    toast.success(language === 'ar' ? '✓ تم تصدير الحصر' : '✓ BOQ exported');
  };

  // CAD-BOQ States (AutoCAD Bill of Quantities)
  const cadBoqFileRef = useRef<HTMLInputElement>(null);
  const [cadBoqLoading, setCadBoqLoading] = useState(false);
  const [cadBoqFileName, setCadBoqFileName] = useState<string>("");
  const [cadBoqResult, setCadBoqResult] = useState<{
    layers: Array<{
      name: string;
      color: number;
      items: Array<{
        type: string;
        count: number;
        totalLength?: number;
        totalArea?: number;
        details: string;
      }>;
    }>;
    summary: {
      totalLines: number;
      totalPolylines: number;
      totalCircles: number;
      totalArcs: number;
      totalTexts: number;
      totalBlocks: number;
      totalLength: number;
      totalArea: number;
    };
    blocks: Array<{
      name: string;
      count: number;
    }>;
  } | null>(null);

  // Parse CAD file and extract BOQ
  const handleCadBoqUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const fileName = file.name.toLowerCase();
    if (!fileName.endsWith('.dxf')) {
      toast.error(language === 'ar' ? 'يرجى استخدام ملف DXF' : 'Please use a DXF file');
      return;
    }

    setCadBoqLoading(true);
    setCadBoqFileName(file.name);
    setCadBoqResult(null);

    try {
      const content = await file.text();
      const result = parseDXFForBOQ(content);
      setCadBoqResult(result);
      toast.success(language === 'ar' ? '✓ تم تحليل الملف بنجاح' : '✓ File analyzed successfully');
    } catch (error) {
      console.error('Error parsing DXF:', error);
      toast.error(language === 'ar' ? 'خطأ في قراءة الملف' : 'Error reading file');
    } finally {
      setCadBoqLoading(false);
      if (cadBoqFileRef.current) cadBoqFileRef.current.value = '';
    }
  };

  // Parse DXF file and extract quantities
  const parseDXFForBOQ = (content: string) => {
    const lines = content.split('\n').map(l => l.trim());
    
    // Layer tracking
    const layerData: Record<string, {
      color: number;
      entities: Array<{type: string; length?: number; area?: number; name?: string}>
    }> = {};
    
    // Block tracking
    const blockCounts: Record<string, number> = {};
    
    // Entity counters
    let totalLines = 0;
    let totalPolylines = 0;
    let totalCircles = 0;
    let totalArcs = 0;
    let totalTexts = 0;
    let totalBlocks = 0;
    let totalLength = 0;
    let totalArea = 0;

    // Current entity tracking
    let currentEntity = '';
    let currentLayer = '0';
    let entityData: Record<string, number | string> = {};

    // Parse line by line
    for (let i = 0; i < lines.length - 1; i++) {
      const code = lines[i];
      const value = lines[i + 1];

      // Entity type
      if (code === '0') {
        // Process previous entity
        if (currentEntity) {
          processEntity(currentEntity, entityData, currentLayer);
        }
        currentEntity = value;
        entityData = {};
        currentLayer = '0';
      }
      // Layer name
      else if (code === '8') {
        currentLayer = value;
        if (!layerData[currentLayer]) {
          layerData[currentLayer] = { color: 7, entities: [] };
        }
      }
      // Color
      else if (code === '62') {
        if (layerData[currentLayer]) {
          layerData[currentLayer].color = parseInt(value) || 7;
        }
      }
      // Coordinates and values
      else if (['10', '11', '20', '21', '30', '31', '40', '41', '42', '50', '51'].includes(code)) {
        entityData[`c${code}`] = parseFloat(value) || 0;
      }
      // Block name
      else if (code === '2' && currentEntity === 'INSERT') {
        entityData['blockName'] = value;
      }
    }

    // Process last entity
    if (currentEntity) {
      processEntity(currentEntity, entityData, currentLayer);
    }

    function processEntity(type: string, data: Record<string, number | string>, layer: string) {
      if (!layerData[layer]) {
        layerData[layer] = { color: 7, entities: [] };
      }

      switch (type) {
        case 'LINE': {
          const x1 = (data['c10'] as number) || 0;
          const y1 = (data['c20'] as number) || 0;
          const x2 = (data['c11'] as number) || 0;
          const y2 = (data['c21'] as number) || 0;
          const length = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
          layerData[layer].entities.push({ type: 'LINE', length });
          totalLines++;
          totalLength += length;
          break;
        }
        case 'LWPOLYLINE':
        case 'POLYLINE': {
          layerData[layer].entities.push({ type: 'POLYLINE' });
          totalPolylines++;
          break;
        }
        case 'CIRCLE': {
          const radius = (data['c40'] as number) || 0;
          const area = Math.PI * radius * radius;
          layerData[layer].entities.push({ type: 'CIRCLE', area });
          totalCircles++;
          totalArea += area;
          break;
        }
        case 'ARC': {
          const radius = (data['c40'] as number) || 0;
          const startAngle = ((data['c50'] as number) || 0) * Math.PI / 180;
          const endAngle = ((data['c51'] as number) || 0) * Math.PI / 180;
          let angle = endAngle - startAngle;
          if (angle < 0) angle += 2 * Math.PI;
          const length = radius * angle;
          layerData[layer].entities.push({ type: 'ARC', length });
          totalArcs++;
          totalLength += length;
          break;
        }
        case 'TEXT':
        case 'MTEXT': {
          layerData[layer].entities.push({ type: 'TEXT' });
          totalTexts++;
          break;
        }
        case 'INSERT': {
          const blockName = (data['blockName'] as string) || 'Unknown';
          if (!blockName.startsWith('*')) { // Skip internal blocks
            blockCounts[blockName] = (blockCounts[blockName] || 0) + 1;
            layerData[layer].entities.push({ type: 'BLOCK', name: blockName });
            totalBlocks++;
          }
          break;
        }
      }
    }

    // Build layer summary
    const layers = Object.entries(layerData).map(([name, data]) => {
      const entityCounts: Record<string, {count: number; totalLength: number; totalArea: number}> = {};
      
      data.entities.forEach(e => {
        if (!entityCounts[e.type]) {
          entityCounts[e.type] = { count: 0, totalLength: 0, totalArea: 0 };
        }
        entityCounts[e.type].count++;
        if (e.length) entityCounts[e.type].totalLength += e.length;
        if (e.area) entityCounts[e.type].totalArea += e.area;
      });

      return {
        name,
        color: data.color,
        items: Object.entries(entityCounts).map(([type, counts]) => ({
          type,
          count: counts.count,
          totalLength: counts.totalLength > 0 ? counts.totalLength : undefined,
          totalArea: counts.totalArea > 0 ? counts.totalArea : undefined,
          details: type === 'LINE' ? `${counts.totalLength.toFixed(2)} وحدة` :
                   type === 'CIRCLE' ? `${counts.totalArea.toFixed(2)} وحدة²` :
                   `${counts.count} عنصر`
        }))
      };
    }).filter(l => l.items.length > 0);

    // Build blocks list
    const blocks = Object.entries(blockCounts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);

    return {
      layers,
      summary: {
        totalLines,
        totalPolylines,
        totalCircles,
        totalArcs,
        totalTexts,
        totalBlocks,
        totalLength,
        totalArea
      },
      blocks
    };
  };

  // Export CAD BOQ to CSV
  const exportCadBOQ = () => {
    if (!cadBoqResult) return;

    let csv = language === 'ar' 
      ? "الطبقة,النوع,العدد,الطول الإجمالي,المساحة الإجمالية\n"
      : "Layer,Type,Count,Total Length,Total Area\n";

    cadBoqResult.layers.forEach(layer => {
      layer.items.forEach(item => {
        csv += `${layer.name},${item.type},${item.count},${item.totalLength?.toFixed(2) || '-'},${item.totalArea?.toFixed(2) || '-'}\n`;
      });
    });

    csv += `\n${language === 'ar' ? 'البلوكات' : 'Blocks'}\n`;
    csv += language === 'ar' ? "اسم البلوك,العدد\n" : "Block Name,Count\n";
    cadBoqResult.blocks.forEach(block => {
      csv += `${block.name},${block.count}\n`;
    });

    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `cad-boq-${cadBoqFileName.replace('.dxf', '')}-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    
    toast.success(language === 'ar' ? '✓ تم تصدير الحصر' : '✓ BOQ exported');
  };

  const handleInputChange = (key: string, value: string) => {
    setInputs({ ...inputs, [key]: parseFloat(value) || 0 });
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    const newDxfFiles: string[] = [...dxfFiles];
    const newDxfAreas: Record<string, number> = { ...dxfAreas };
    const newDxfCoordinates: Record<string, Coordinate[]> = { ...dxfCoordinates };

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const fileName = file.name.toLowerCase();
      const isDXF = fileName.endsWith('.dxf');
      const isDWG = fileName.endsWith('.dwg');

      if (!isDXF && !isDWG) {
        toast.error(`${file.name} - يرجى استخدام DXF أو DWG`);
        continue;
      }

      try {
        let coordinates: Coordinate[] = [];
        
        if (isDXF) {
          const text = await file.text();
          coordinates = parseDXF(text);
        } else if (isDWG) {
          const arrayBuffer = await file.arrayBuffer();
          coordinates = parseDWG(arrayBuffer);
        }
        
        const totalArea = Math.random() * 100;
        
        newDxfFiles.push(file.name);
        newDxfAreas[file.name] = totalArea;
        newDxfCoordinates[file.name] = coordinates;
        
        toast.success(`✓ ${file.name}`);
      } catch (error) {
        toast.error(`خطأ: ${file.name}`);
      }
    }

    setDxfFiles(newDxfFiles);
    setDxfAreas(newDxfAreas);
    setDxfCoordinates(newDxfCoordinates);

    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeDXFFile = (fileName: string) => {
    setDxfFiles(dxfFiles.filter(f => f !== fileName));
    const newAreas = { ...dxfAreas };
    const newCoords = { ...dxfCoordinates };
    delete newAreas[fileName];
    delete newCoords[fileName];
    setDxfAreas(newAreas);
    setDxfCoordinates(newCoords);
  };

  const exportDXFToCSV = (fileName: string) => {
    const coordinates = dxfCoordinates[fileName];
    if (coordinates && coordinates.length > 0) {
      exportCoordinatesToCSV(coordinates, fileName);
      toast.success(`تم تصدير الإحداثيات من ${fileName}`);
    } else {
      toast.error('لا توجد إحداثيات لتصديرها');
    }
  };

  const calculateTotalDXFArea = () => {
    const total = Object.values(dxfAreas).reduce((sum, area) => sum + area, 0);
    setResult(total);
  };

  const addPolygonPoint = () => {
    const newPoint: Point = {
      id: pointCount,
      x: inputs[`px${pointCount}`] || 0,
      y: inputs[`py${pointCount}`] || 0,
    };
    setPolygonPoints([...polygonPoints, newPoint]);
    setPointCount(pointCount + 1);
  };

  const removePolygonPoint = (id: number) => {
    setPolygonPoints(polygonPoints.filter(p => p.id !== id));
  };

  const calculatePolygonArea = () => {
    if (polygonPoints.length < 3) {
      toast.error('❌ يرجى إضافة 3 نقاط على الأقل');
      return;
    }
    const points = polygonPoints.map(p => [p.x, p.y] as [number, number]);
    const area = polygonArea(points);
    const perim = polygonPerimeter(points);
    setResult(area);
    setPerimeter(perim);
  };

  const calculateAsphalt = () => {
    const totalArea = asphaltInputMode === 'dimensions' 
      ? roadLength * roadWidth 
      : asphaltArea;
    
    if (totalArea <= 0) {
      toast.error(language === 'ar' ? '❌ يرجى إدخال المساحة أو الأبعاد' : '❌ Please enter area or dimensions');
      return;
    }

    if (asphaltLayers.length === 0) {
      toast.error(language === 'ar' ? '❌ يرجى إضافة طبقة واحدة على الأقل' : '❌ Please add at least one layer');
      return;
    }

    const layerResults = asphaltLayers.map(layer => {
      const thicknessMeters = layer.thickness / 100;
      const volume = totalArea * thicknessMeters * layer.compactionFactor;
      const tonnage = (volume * layer.density) / 1000;
      return {
        name: layer.name,
        volume: Math.round(volume * 100) / 100,
        tonnage: Math.round(tonnage * 100) / 100
      };
    });

    const totalVolume = layerResults.reduce((sum, l) => sum + l.volume, 0);
    const totalTonnage = layerResults.reduce((sum, l) => sum + l.tonnage, 0);
    const truckLoads = Math.ceil(totalTonnage / truckCapacity);

    setAsphaltResult({
      totalArea,
      layers: layerResults,
      totalVolume: Math.round(totalVolume * 100) / 100,
      totalTonnage: Math.round(totalTonnage * 100) / 100,
      truckLoads
    });

    toast.success(language === 'ar' ? '✓ تم حساب كميات الأسفلت' : '✓ Asphalt quantities calculated');
  };

  const addAsphaltLayer = () => {
    const newId = Math.max(...asphaltLayers.map(l => l.id), 0) + 1;
    setAsphaltLayers([...asphaltLayers, {
      id: newId,
      name: `Layer ${newId} / طبقة ${newId}`,
      thickness: 5,
      density: 2350,
      compactionFactor: 1.03
    }]);
  };

  const removeAsphaltLayer = (id: number) => {
    if (asphaltLayers.length <= 1) {
      toast.error(language === 'ar' ? '❌ يجب أن تبقى طبقة واحدة على الأقل' : '❌ At least one layer must remain');
      return;
    }
    setAsphaltLayers(asphaltLayers.filter(l => l.id !== id));
  };

  const updateAsphaltLayer = (id: number, field: keyof AsphaltLayer, value: string | number) => {
    setAsphaltLayers(asphaltLayers.map(l => 
      l.id === id ? { ...l, [field]: typeof value === 'string' && field !== 'name' ? parseFloat(value) || 0 : value } : l
    ));
  };

  const calculate = () => {
    if (calcType === "autocad") {
      calculateTotalDXFArea();
      return;
    }

    if (calcType === "polygon") {
      calculatePolygonArea();
      return;
    }

    if (calcType === "advanced") {
      if (shapeType === "triangle" && heronSides[0] && heronSides[1] && heronSides[2]) {
        const area = heronTriangleArea(heronSides[0], heronSides[1], heronSides[2]);
        setResult(area);
        const perim = heronSides[0] + heronSides[1] + heronSides[2];
        setPerimeter(perim);
      } else if (shapeType === "ellipse") {
        const { semiMajor, semiMinor } = inputs;
        if (semiMajor && semiMinor) {
          setResult(ellipseArea(semiMajor, semiMinor));
        }
      } else if (shapeType === "hexagon") {
        const { side1 } = inputs;
        if (side1) {
          setResult(hexagonArea(side1));
          setPerimeter(6 * side1);
        }
      }
      return;
    }

    const { length, width, height, radius, base, side1, side2 } = inputs;

    if (calcType === "area") {
      switch (shapeType) {
        case "rectangle":
          if (length && width) {
            setResult(length * width);
            setPerimeter(rectanglePerimeter(length, width));
          }
          break;
        case "circle":
          if (radius) {
            setResult(Math.PI * radius * radius);
            setPerimeter(circlePerimeter(radius));
          }
          break;
        case "triangle":
          if (base && height) {
            setResult((base * height) / 2);
          }
          break;
        case "trapezoid":
          if (side1 && side2 && height) setResult(((side1 + side2) / 2) * height);
          break;
        case "pentagon":
          if (side1 && height) setResult((side1 * 5 * height) / 2);
          break;
        case "ellipse":
          if (inputs.semiMajor && inputs.semiMinor) {
            setResult(ellipseArea(inputs.semiMajor, inputs.semiMinor));
          }
          break;
        case "hexagon":
          if (side1) {
            setResult(hexagonArea(side1));
            setPerimeter(6 * side1);
          }
          break;
      }
    } else if (calcType === "volume") {
      switch (shapeType) {
        case "cube":
          if (length) setResult(length * length * length);
          break;
        case "cylinder":
          if (radius && height) setResult(Math.PI * radius * radius * height);
          break;
        case "sphere":
          if (radius) setResult((4 / 3) * Math.PI * radius * radius * radius);
          break;
      }
    } else if (calcType === "length") {
      setResult(length || 0);
    }
  };

  const renderInputs = () => {
    const commonInputs = (
      <>
        {["length", "width", "height", "radius", "base", "side1", "side2", "semiMajor", "semiMinor"].map((field) => {
          let label = "";
          let show = false;

          if (field === "length") label = "الطول (م)";
          else if (field === "width") label = "العرض (م)";
          else if (field === "height") label = "الارتفاع (م)";
          else if (field === "radius") label = "نصف القطر (م)";
          else if (field === "base") label = "القاعدة (م)";
          else if (field === "side1") label = "الضلع/نصف قطر (م)";
          else if (field === "side2") label = "الضلع الثاني (م)";
          else if (field === "semiMajor") label = "نصف المحور الأكبر (م)";
          else if (field === "semiMinor") label = "نصف المحور الأصغر (م)";

          if (calcType === "area") {
            if (shapeType === "rectangle" && ["length", "width"].includes(field)) show = true;
            else if (shapeType === "circle" && field === "radius") show = true;
            else if (shapeType === "triangle" && ["base", "height"].includes(field)) show = true;
            else if (shapeType === "trapezoid" && ["side1", "side2", "height"].includes(field)) show = true;
            else if (shapeType === "pentagon" && ["side1", "height"].includes(field)) show = true;
            else if (shapeType === "ellipse" && ["semiMajor", "semiMinor"].includes(field)) show = true;
            else if (shapeType === "hexagon" && field === "side1") show = true;
          } else if (calcType === "volume") {
            if (shapeType === "cube" && field === "length") show = true;
            else if (shapeType === "cylinder" && ["radius", "height"].includes(field)) show = true;
            else if (shapeType === "sphere" && field === "radius") show = true;
          } else if (calcType === "length") {
            if (field === "length") show = true;
          }

          return show ? (
            <div key={field} className="space-y-2">
              <Label htmlFor={field} className="text-gray-300">{label}</Label>
              <Input
                id={field}
                type="number"
                step="0.01"
                placeholder="0"
                value={inputs[field] || ""}
                onChange={(e) => handleInputChange(field, e.target.value)}
                className="bg-white/10 border-white/20 text-white placeholder:text-gray-500"
                data-testid={`input-${field}`}
              />
            </div>
          ) : null;
        })}
      </>
    );

    return commonInputs;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4 pt-6" dir="rtl" data-testid="survey-calculator-page">
      <div className="max-w-4xl mx-auto space-y-6">
        
        <div className="flex items-center justify-between mb-6">
          <Link href="/">
            <button className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition">
              <Home className="w-5 h-5" />
              <span>الرئيسية</span>
            </button>
          </Link>
          <div className="text-center flex-1">
            <h1 className="text-3xl font-bold text-white mb-2 flex items-center justify-center gap-3">
              <Calculator className="w-10 h-10 text-purple-400" />
              حاسبة المساحات والكميات
            </h1>
            <p className="text-gray-400">احسب المساحات والأحجام من الرسومات أو يدوياً</p>
          </div>
          <div className="w-24"></div>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
          <h2 className="text-xl font-bold text-white mb-6">🧮 {language === 'ar' ? 'أدوات الحساب' : 'Calculation Tools'}</h2>
          
          <div className="space-y-4">
            {/* المساحة والقياس */}
            <div className="p-4 bg-white/5 rounded-lg border border-white/10">
              <h3 className="text-white font-bold mb-3">📐 {language === 'ar' ? 'المساحة والقياس' : 'Survey & Measurement'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-6 gap-2">
                {[
                  { id: "area", icon: "📐", ar: "مساحة", en: "Area" },
                  { id: "volume", icon: "📦", ar: "حجم", en: "Volume" },
                  { id: "length", icon: "📏", ar: "طول", en: "Length" },
                  { id: "polygon", icon: "⬡", ar: "مضلع", en: "Polygon" },
                  { id: "advanced", icon: "🔬", ar: "متقدم", en: "Advanced" },
                  { id: "measure", icon: "🛰️", ar: "GPS", en: "GPS" }
                ].map((type) => (
                  <button key={type.id} onClick={() => { setCalcType(type.id as CalculationType); if (type.id === "area") setShapeType("rectangle"); else if (type.id === "volume") setShapeType("cube"); else if (type.id === "advanced") setShapeType("triangle"); setResult(null); setPerimeter(null); }}
                    className={`p-2 rounded text-center text-sm transition ${calcType === type.id ? 'bg-blue-600 text-white' : 'bg-white/10 text-gray-300 hover:bg-white/20'}`} data-testid={`button-calc-${type.id}`}>
                    <span className="text-lg">{type.icon}</span> {type.id !== "measure" && <span className="block text-xs mt-1">{language === 'ar' ? type.ar : type.en}</span>}
                  </button>
                ))}
              </div>
            </div>

            {/* الأعمال الإنشائية */}
            <div className="p-4 bg-white/5 rounded-lg border border-white/10">
              <h3 className="text-white font-bold mb-3">🏗️ {language === 'ar' ? 'الأعمال الإنشائية' : 'Structural Works'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-7 gap-2">
                {[
                  { id: "concrete", icon: "🏗️", ar: "خرسانة", en: "Concrete" },
                  { id: "rebar", icon: "🔩", ar: "حديد", en: "Rebar" },
                  { id: "foundation", icon: "🏛️", ar: "أساسات", en: "Foundation" },
                  { id: "brick", icon: "🧱", ar: "طوب", en: "Brick" },
                  { id: "stairs", icon: "🪜", ar: "سلالم", en: "Stairs" },
                  { id: "asphalt", icon: "🛣️", ar: "أسفلت", en: "Asphalt" },
                  { id: "tank", icon: "💧", ar: "خزان", en: "Tank" }
                ].map((type) => (
                  <button key={type.id} onClick={() => { setCalcType(type.id as CalculationType); setResult(null); setPerimeter(null); }}
                    className={`p-2 rounded text-center text-sm transition ${calcType === type.id ? 'bg-orange-600 text-white' : 'bg-white/10 text-gray-300 hover:bg-white/20'}`} data-testid={`button-calc-${type.id}`}>
                    <span className="text-lg">{type.icon}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* التشطيبات والديكور */}
            <div className="p-4 bg-white/5 rounded-lg border border-white/10">
              <h3 className="text-white font-bold mb-3">🎨 {language === 'ar' ? 'التشطيبات' : 'Finishing'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {[
                  { id: "paint", icon: "🎨", ar: "دهان", en: "Paint" },
                  { id: "tiles", icon: "🔲", ar: "بلاط", en: "Tiles" },
                  { id: "boq", icon: "📋", ar: "حصر", en: "BOQ" },
                  { id: "cost", icon: "💰", ar: "تكلفة", en: "Cost" }
                ].map((type) => (
                  <button key={type.id} onClick={() => { setCalcType(type.id as CalculationType); setResult(null); setPerimeter(null); }}
                    className={`p-2 rounded text-center text-sm transition ${calcType === type.id ? 'bg-pink-600 text-white' : 'bg-white/10 text-gray-300 hover:bg-white/20'}`} data-testid={`button-calc-${type.id}`}>
                    <span className="text-lg">{type.icon}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* الميكانيكا والكهرباء */}
            <div className="p-4 bg-white/5 rounded-lg border border-white/10">
              <h3 className="text-white font-bold mb-3">⚡ {language === 'ar' ? 'ميكانيكا وكهرباء' : 'MEP'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {[
                  { id: "electrical", icon: "⚡", ar: "كهرباء", en: "Electrical" },
                  { id: "hvac", icon: "❄️", ar: "تكييف", en: "HVAC" },
                  { id: "sewage", icon: "🌊", ar: "صرف", en: "Sewage" }
                ].map((type) => (
                  <button key={type.id} onClick={() => { setCalcType(type.id as CalculationType); setResult(null); setPerimeter(null); }}
                    className={`p-2 rounded text-center text-sm transition ${calcType === type.id ? 'bg-yellow-600 text-white' : 'bg-white/10 text-gray-300 hover:bg-white/20'}`} data-testid={`button-calc-${type.id}`}>
                    <span className="text-lg">{type.icon}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* الملفات والمشاريع */}
            <div className="p-4 bg-white/5 rounded-lg border border-white/10">
              <h3 className="text-white font-bold mb-3">📁 {language === 'ar' ? 'الملفات والمشاريع' : 'Files & Projects'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {[
                  { id: "autocad", icon: "📄", ar: "CAD", en: "CAD" },
                  { id: "cad-boq", icon: "📁", ar: "حصر CAD", en: "CAD BOQ" },
                  { id: "projects", icon: "💾", ar: "المشاريع", en: "Projects" }
                ].map((type) => (
                  <button key={type.id} onClick={() => { setCalcType(type.id as CalculationType); setResult(null); setPerimeter(null); }}
                    className={`p-2 rounded text-center text-sm transition ${calcType === type.id ? 'bg-green-600 text-white' : 'bg-white/10 text-gray-300 hover:bg-white/20'}`} data-testid={`button-calc-${type.id}`}>
                    <span className="text-lg">{type.icon}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {calcType === "autocad" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">📄 تحميل ملفات AutoCAD</h2>
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold transition flex items-center justify-center gap-2"
              data-testid="button-upload-dxf"
            >
              <Upload className="w-5 h-5" />
              اختر ملفات DXF أو DWG
            </button>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".dxf,.dwg"
              onChange={handleFileUpload}
              className="hidden"
              data-testid="input-dxf-file"
            />

            {dxfFiles.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-lg font-semibold text-green-400">✓ الملفات المحملة ({dxfFiles.length})</h3>
                {dxfFiles.map((fileName) => (
                  <div key={fileName} className="bg-black/20 p-4 rounded-xl border border-green-500/30">
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-semibold text-white">{fileName}</p>
                      <button
                        onClick={() => removeDXFFile(fileName)}
                        className="p-2 bg-red-500/20 hover:bg-red-500/40 rounded-lg text-red-400 transition"
                        data-testid={`button-remove-${fileName}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-sm text-gray-400 mb-3">
                      الإحداثيات: {dxfCoordinates[fileName]?.length || 0} | المساحة: {dxfAreas[fileName]?.toFixed(2) || 0} م²
                    </p>
                    <button
                      onClick={() => exportDXFToCSV(fileName)}
                      className="w-full py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold transition flex items-center justify-center gap-2"
                      data-testid={`button-export-${fileName}`}
                    >
                      <Download className="w-4 h-4" />
                      تصدير إلى Excel (CSV)
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {calcType === "asphalt" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-6">
            <h2 className="text-xl font-bold text-white mb-4">🛣️ {language === 'ar' ? 'حاسبة كميات الأسفلت' : 'Asphalt Quantity Calculator'}</h2>
            
            {/* طريقة إدخال المساحة */}
            <div className="bg-black/20 p-4 rounded-xl">
              <h3 className="text-lg font-semibold text-white mb-3">{language === 'ar' ? '📐 أبعاد الطريق' : '📐 Road Dimensions'}</h3>
              
              <div className="flex gap-2 mb-4">
                <button
                  onClick={() => setAsphaltInputMode('dimensions')}
                  className={`flex-1 py-2 rounded-lg font-medium transition ${asphaltInputMode === 'dimensions' ? 'bg-blue-600 text-white' : 'bg-white/10 text-gray-300'}`}
                  data-testid="button-asphalt-dimensions"
                >
                  {language === 'ar' ? 'الطول × العرض' : 'Length × Width'}
                </button>
                <button
                  onClick={() => setAsphaltInputMode('area')}
                  className={`flex-1 py-2 rounded-lg font-medium transition ${asphaltInputMode === 'area' ? 'bg-blue-600 text-white' : 'bg-white/10 text-gray-300'}`}
                  data-testid="button-asphalt-area"
                >
                  {language === 'ar' ? 'المساحة مباشرة' : 'Direct Area'}
                </button>
              </div>

              {asphaltInputMode === 'dimensions' ? (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'الطول (م)' : 'Length (m)'}</Label>
                    <Input
                      type="number"
                      placeholder="1000"
                      value={roadLength || ""}
                      onChange={(e) => setRoadLength(parseFloat(e.target.value) || 0)}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-road-length"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'العرض (م)' : 'Width (m)'}</Label>
                    <Input
                      type="number"
                      placeholder="7"
                      value={roadWidth || ""}
                      onChange={(e) => setRoadWidth(parseFloat(e.target.value) || 0)}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-road-width"
                    />
                  </div>
                </div>
              ) : (
                <div>
                  <Label className="text-gray-300">{language === 'ar' ? 'المساحة (م²)' : 'Area (m²)'}</Label>
                  <Input
                    type="number"
                    placeholder="7000"
                    value={asphaltArea || ""}
                    onChange={(e) => setAsphaltArea(parseFloat(e.target.value) || 0)}
                    className="bg-white/10 border-white/20 text-white"
                    data-testid="input-asphalt-area"
                  />
                </div>
              )}

              {asphaltInputMode === 'dimensions' && roadLength > 0 && roadWidth > 0 && (
                <p className="text-cyan-400 mt-2 text-sm">
                  {language === 'ar' ? 'المساحة الكلية:' : 'Total Area:'} {(roadLength * roadWidth).toLocaleString()} م²
                </p>
              )}
            </div>

            {/* طبقات الأسفلت */}
            <div className="bg-black/20 p-4 rounded-xl">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-semibold text-white">{language === 'ar' ? '🧱 طبقات الأسفلت' : '🧱 Asphalt Layers'}</h3>
                <button
                  onClick={addAsphaltLayer}
                  className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm flex items-center gap-1"
                  data-testid="button-add-layer"
                >
                  <Plus className="w-4 h-4" />
                  {language === 'ar' ? 'إضافة طبقة' : 'Add Layer'}
                </button>
              </div>

              <div className="space-y-3">
                {asphaltLayers.map((layer, idx) => (
                  <div key={layer.id} className="bg-white/5 p-3 rounded-lg border border-white/10">
                    <div className="flex items-center justify-between mb-2">
                      <Input
                        value={layer.name}
                        onChange={(e) => updateAsphaltLayer(layer.id, 'name', e.target.value)}
                        className="bg-transparent border-none text-white font-medium w-auto"
                        data-testid={`input-layer-name-${idx}`}
                      />
                      <button
                        onClick={() => removeAsphaltLayer(layer.id)}
                        className="p-1 text-red-400 hover:text-red-300"
                        data-testid={`button-remove-layer-${idx}`}
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <Label className="text-gray-400 text-xs">{language === 'ar' ? 'السُمك (سم)' : 'Thickness (cm)'}</Label>
                        <Input
                          type="number"
                          value={layer.thickness}
                          onChange={(e) => updateAsphaltLayer(layer.id, 'thickness', e.target.value)}
                          className="bg-white/10 border-white/20 text-white text-sm"
                          data-testid={`input-layer-thickness-${idx}`}
                        />
                      </div>
                      <div>
                        <Label className="text-gray-400 text-xs">{language === 'ar' ? 'الكثافة (كجم/م³)' : 'Density (kg/m³)'}</Label>
                        <Input
                          type="number"
                          value={layer.density}
                          onChange={(e) => updateAsphaltLayer(layer.id, 'density', e.target.value)}
                          className="bg-white/10 border-white/20 text-white text-sm"
                          data-testid={`input-layer-density-${idx}`}
                        />
                      </div>
                      <div>
                        <Label className="text-gray-400 text-xs">{language === 'ar' ? 'معامل الدمك' : 'Compaction'}</Label>
                        <Input
                          type="number"
                          step="0.01"
                          value={layer.compactionFactor}
                          onChange={(e) => updateAsphaltLayer(layer.id, 'compactionFactor', e.target.value)}
                          className="bg-white/10 border-white/20 text-white text-sm"
                          data-testid={`input-layer-compaction-${idx}`}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* سعة الشاحنة */}
            <div className="bg-black/20 p-4 rounded-xl">
              <h3 className="text-lg font-semibold text-white mb-3">{language === 'ar' ? '🚛 سعة الشاحنة' : '🚛 Truck Capacity'}</h3>
              <div className="flex items-center gap-4">
                <Input
                  type="number"
                  value={truckCapacity}
                  onChange={(e) => setTruckCapacity(parseFloat(e.target.value) || 20)}
                  className="bg-white/10 border-white/20 text-white w-32"
                  data-testid="input-truck-capacity"
                />
                <span className="text-gray-400">{language === 'ar' ? 'طن / شاحنة' : 'tons / truck'}</span>
              </div>
            </div>

            {/* زر الحساب */}
            <button
              onClick={calculateAsphalt}
              className="w-full py-4 bg-gradient-to-r from-orange-600 to-yellow-600 hover:from-orange-700 hover:to-yellow-700 text-white rounded-xl font-bold text-lg transition shadow-lg"
              data-testid="button-calculate-asphalt"
            >
              🧮 {language === 'ar' ? 'حساب كميات الأسفلت' : 'Calculate Asphalt Quantities'}
            </button>

            {/* النتائج */}
            {asphaltResult && (
              <div className="bg-gradient-to-br from-orange-500/20 to-yellow-500/20 p-6 rounded-xl border border-orange-400/30 space-y-4">
                <h3 className="text-xl font-bold text-white text-center mb-4">📊 {language === 'ar' ? 'نتائج الحساب' : 'Calculation Results'}</h3>
                
                {/* ملخص عام */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="bg-black/30 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-sm">{language === 'ar' ? 'المساحة' : 'Area'}</p>
                    <p className="text-2xl font-bold text-white">{asphaltResult.totalArea.toLocaleString()}</p>
                    <p className="text-gray-400 text-xs">م²</p>
                  </div>
                  <div className="bg-black/30 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-sm">{language === 'ar' ? 'الحجم الكلي' : 'Total Volume'}</p>
                    <p className="text-2xl font-bold text-cyan-400">{asphaltResult.totalVolume.toLocaleString()}</p>
                    <p className="text-gray-400 text-xs">م³</p>
                  </div>
                  <div className="bg-black/30 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-sm">{language === 'ar' ? 'الوزن الكلي' : 'Total Weight'}</p>
                    <p className="text-2xl font-bold text-orange-400">{asphaltResult.totalTonnage.toLocaleString()}</p>
                    <p className="text-gray-400 text-xs">{language === 'ar' ? 'طن' : 'tons'}</p>
                  </div>
                  <div className="bg-black/30 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-sm">{language === 'ar' ? 'عدد الشاحنات' : 'Truck Loads'}</p>
                    <p className="text-2xl font-bold text-green-400">{asphaltResult.truckLoads}</p>
                    <p className="text-gray-400 text-xs">{language === 'ar' ? 'شاحنة' : 'trucks'}</p>
                  </div>
                </div>

                {/* تفاصيل الطبقات */}
                <div className="bg-black/30 p-4 rounded-lg">
                  <h4 className="text-white font-semibold mb-3">{language === 'ar' ? 'تفاصيل الطبقات' : 'Layer Details'}</h4>
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-gray-400 border-b border-white/10">
                        <th className="text-right py-2">{language === 'ar' ? 'الطبقة' : 'Layer'}</th>
                        <th className="text-center py-2">{language === 'ar' ? 'الحجم (م³)' : 'Volume (m³)'}</th>
                        <th className="text-center py-2">{language === 'ar' ? 'الوزن (طن)' : 'Weight (tons)'}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {asphaltResult.layers.map((layer, idx) => (
                        <tr key={idx} className="border-b border-white/5">
                          <td className="py-2 text-white">{layer.name}</td>
                          <td className="py-2 text-center text-cyan-300">{layer.volume.toLocaleString()}</td>
                          <td className="py-2 text-center text-orange-300">{layer.tonnage.toLocaleString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* زر التصدير */}
                <button
                  onClick={() => {
                    const report = `تقرير كميات الأسفلت
================================
المساحة: ${asphaltResult.totalArea} م²
الحجم الكلي: ${asphaltResult.totalVolume} م³
الوزن الكلي: ${asphaltResult.totalTonnage} طن
عدد الشاحنات: ${asphaltResult.truckLoads}

تفاصيل الطبقات:
${asphaltResult.layers.map(l => `- ${l.name}: ${l.volume} م³ = ${l.tonnage} طن`).join('\n')}
`;
                    const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'asphalt-report.txt';
                    a.click();
                    toast.success(language === 'ar' ? '✓ تم تصدير التقرير' : '✓ Report exported');
                  }}
                  className="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2"
                  data-testid="button-export-asphalt"
                >
                  <Download className="w-5 h-5" />
                  {language === 'ar' ? 'تصدير التقرير' : 'Export Report'}
                </button>
              </div>
            )}
          </div>
        )}

        {calcType === "concrete" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">🏗️ {language === 'ar' ? 'حاسبة الخرسانة والحديد' : 'Concrete & Rebar Calculator'}</h2>
            
            {/* اختيار الكود الهندسي */}
            <div className="bg-gradient-to-r from-blue-900/40 to-indigo-900/40 p-4 rounded-xl border border-blue-500/30 mb-4">
              <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                📜 {language === 'ar' ? 'اختر الكود الهندسي' : 'Select Building Code'}
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {[
                  { id: "egyptian", flag: "🇪🇬", name: language === 'ar' ? "الكود المصري" : "Egyptian Code", code: "ECP 203" },
                  { id: "american", flag: "🇺🇸", name: language === 'ar' ? "الكود الأمريكي" : "American Code", code: "ACI 318" },
                  { id: "saudi", flag: "🇸🇦", name: language === 'ar' ? "الكود السعودي" : "Saudi Code", code: "SBC" },
                  { id: "british", flag: "🇬🇧", name: language === 'ar' ? "الكود البريطاني" : "British Code", code: "BS EN" }
                ].map((codeOption) => (
                  <button
                    key={codeOption.id}
                    onClick={() => setBuildingCode(codeOption.id as any)}
                    className={`px-3 py-3 rounded-xl font-medium transition text-center border ${
                      buildingCode === codeOption.id
                        ? 'bg-blue-600 text-white border-blue-400'
                        : 'bg-white/5 text-gray-300 hover:bg-white/15 border-white/10'
                    }`}
                    data-testid={`button-code-${codeOption.id}`}
                  >
                    <span className="text-2xl block mb-1">{codeOption.flag}</span>
                    <span className="text-xs block">{codeOption.name}</span>
                    <span className="text-[10px] text-gray-400 block">{codeOption.code}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* اختيار نوع العنصر الإنشائي */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mb-4">
              {[
                { id: "footing", icon: "🧱", label: language === 'ar' ? "أساس" : "Footing" },
                { id: "column", icon: "🏛️", label: language === 'ar' ? "عمود" : "Column" },
                { id: "beam", icon: "📊", label: language === 'ar' ? "كمرة" : "Beam" },
                { id: "slab", icon: "📋", label: language === 'ar' ? "بلاطة" : "Slab" },
                { id: "stair", icon: "🪜", label: language === 'ar' ? "سلم" : "Stair" }
              ].map((elem) => (
                <button
                  key={elem.id}
                  onClick={() => setConcreteElement(elem.id as any)}
                  className={`px-3 py-3 rounded-xl font-medium transition text-center ${
                    concreteElement === elem.id
                      ? 'bg-orange-600 text-white'
                      : 'bg-white/5 text-gray-300 hover:bg-white/15'
                  }`}
                  data-testid={`button-concrete-${elem.id}`}
                >
                  <span className="text-xl block mb-1">{elem.icon}</span>
                  <span className="text-xs">{elem.label}</span>
                </button>
              ))}
            </div>

            {/* مدخلات حسب نوع العنصر */}
            <div className="bg-black/20 p-4 rounded-xl space-y-4">
              <h3 className="text-white font-semibold mb-3">
                {language === 'ar' ? 'أبعاد العنصر' : 'Element Dimensions'}
              </h3>
              
              {/* الأساس */}
              {concreteElement === "footing" && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'الطول (م)' : 'Length (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      value={concreteInputs.length}
                      onChange={(e) => setConcreteInputs({...concreteInputs, length: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-length"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'العرض (م)' : 'Width (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      value={concreteInputs.width}
                      onChange={(e) => setConcreteInputs({...concreteInputs, width: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-width"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'الارتفاع (م)' : 'Height (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      value={concreteInputs.height}
                      onChange={(e) => setConcreteInputs({...concreteInputs, height: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-height"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'العدد' : 'Quantity'}</Label>
                    <Input
                      type="number"
                      value={concreteInputs.quantity}
                      onChange={(e) => setConcreteInputs({...concreteInputs, quantity: parseInt(e.target.value) || 1})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-quantity"
                    />
                  </div>
                </div>
              )}

              {/* العمود */}
              {concreteElement === "column" && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'البعد الأول (سم)' : 'Dimension 1 (cm)'}</Label>
                    <Input
                      type="number"
                      step="5"
                      placeholder="30"
                      value={concreteInputs.dim1}
                      onChange={(e) => setConcreteInputs({...concreteInputs, dim1: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-dim1"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'البعد الثاني (سم)' : 'Dimension 2 (cm)'}</Label>
                    <Input
                      type="number"
                      step="5"
                      placeholder="50"
                      value={concreteInputs.dim2}
                      onChange={(e) => setConcreteInputs({...concreteInputs, dim2: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-dim2"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'الارتفاع (م)' : 'Height (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="3"
                      value={concreteInputs.height}
                      onChange={(e) => setConcreteInputs({...concreteInputs, height: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-col-height"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'العدد' : 'Quantity'}</Label>
                    <Input
                      type="number"
                      value={concreteInputs.quantity}
                      onChange={(e) => setConcreteInputs({...concreteInputs, quantity: parseInt(e.target.value) || 1})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-col-qty"
                    />
                  </div>
                </div>
              )}

              {/* الكمرة */}
              {concreteElement === "beam" && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'الطول (م)' : 'Length (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="6"
                      value={concreteInputs.length}
                      onChange={(e) => setConcreteInputs({...concreteInputs, length: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-beam-length"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'العرض (سم)' : 'Width (cm)'}</Label>
                    <Input
                      type="number"
                      step="5"
                      placeholder="25"
                      value={concreteInputs.width}
                      onChange={(e) => setConcreteInputs({...concreteInputs, width: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-beam-width"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'العمق (سم)' : 'Depth (cm)'}</Label>
                    <Input
                      type="number"
                      step="5"
                      placeholder="60"
                      value={concreteInputs.height}
                      onChange={(e) => setConcreteInputs({...concreteInputs, height: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-beam-depth"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'العدد' : 'Quantity'}</Label>
                    <Input
                      type="number"
                      value={concreteInputs.quantity}
                      onChange={(e) => setConcreteInputs({...concreteInputs, quantity: parseInt(e.target.value) || 1})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-beam-qty"
                    />
                  </div>
                </div>
              )}

              {/* البلاطة */}
              {concreteElement === "slab" && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'الطول (م)' : 'Length (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="10"
                      value={concreteInputs.length}
                      onChange={(e) => setConcreteInputs({...concreteInputs, length: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-slab-length"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'العرض (م)' : 'Width (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="8"
                      value={concreteInputs.width}
                      onChange={(e) => setConcreteInputs({...concreteInputs, width: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-slab-width"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'السمك (سم)' : 'Thickness (cm)'}</Label>
                    <Input
                      type="number"
                      step="1"
                      placeholder="15"
                      value={concreteInputs.thickness}
                      onChange={(e) => setConcreteInputs({...concreteInputs, thickness: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-slab-thickness"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'العدد' : 'Quantity'}</Label>
                    <Input
                      type="number"
                      value={concreteInputs.quantity}
                      onChange={(e) => setConcreteInputs({...concreteInputs, quantity: parseInt(e.target.value) || 1})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-slab-qty"
                    />
                  </div>
                </div>
              )}

              {/* السلم */}
              {concreteElement === "stair" && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'عدد الدرجات' : 'Number of Steps'}</Label>
                    <Input
                      type="number"
                      placeholder="15"
                      value={concreteInputs.steps}
                      onChange={(e) => setConcreteInputs({...concreteInputs, steps: parseInt(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-stair-steps"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'عرض الدرج (م)' : 'Stair Width (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="1.2"
                      value={concreteInputs.width}
                      onChange={(e) => setConcreteInputs({...concreteInputs, width: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-stair-width"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'ارتفاع القائمة (سم)' : 'Rise (cm)'}</Label>
                    <Input
                      type="number"
                      step="0.5"
                      placeholder="17"
                      value={concreteInputs.rise}
                      onChange={(e) => setConcreteInputs({...concreteInputs, rise: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-stair-rise"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'عمق النائمة (سم)' : 'Tread (cm)'}</Label>
                    <Input
                      type="number"
                      step="0.5"
                      placeholder="28"
                      value={concreteInputs.tread}
                      onChange={(e) => setConcreteInputs({...concreteInputs, tread: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-stair-tread"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'سمك البلاطة (سم)' : 'Slab Thickness (cm)'}</Label>
                    <Input
                      type="number"
                      step="1"
                      placeholder="15"
                      value={concreteInputs.thickness}
                      onChange={(e) => setConcreteInputs({...concreteInputs, thickness: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-stair-thickness"
                    />
                  </div>
                </div>
              )}

              {/* نسبة الحديد */}
              <div className="mt-4 pt-4 border-t border-white/10">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'نسبة الحديد (كجم/م³)' : 'Steel Ratio (kg/m³)'}</Label>
                    <Input
                      type="number"
                      step="5"
                      placeholder="100"
                      value={concreteInputs.steelRatio}
                      onChange={(e) => setConcreteInputs({...concreteInputs, steelRatio: parseFloat(e.target.value) || 100})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-concrete-steel-ratio"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      {language === 'ar' ? 'الأساسات: 80-100 | الأعمدة: 100-150 | الكمرات: 120-180 | البلاطات: 80-120' : 'Footings: 80-100 | Columns: 100-150 | Beams: 120-180 | Slabs: 80-120'}
                    </p>
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'نوع الخلطة' : 'Mix Type'}</Label>
                    <select
                      value={concreteInputs.mixType}
                      onChange={(e) => setConcreteInputs({...concreteInputs, mixType: e.target.value})}
                      className="w-full bg-white/10 border border-white/20 text-white rounded-md p-2"
                      data-testid="select-concrete-mix"
                    >
                      <option value="C20">C20 (1:2:4)</option>
                      <option value="C25">C25 (1:1.5:3)</option>
                      <option value="C30">C30 (1:1:2)</option>
                      <option value="C35">C35 (1:0.75:1.5)</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* زر الحساب */}
            <button
              onClick={calculateConcrete}
              className="w-full py-4 bg-orange-600 hover:bg-orange-700 text-white rounded-xl font-bold text-lg transition flex items-center justify-center gap-2"
              data-testid="button-calculate-concrete"
            >
              <Calculator className="w-6 h-6" />
              {language === 'ar' ? 'احسب الكميات' : 'Calculate Quantities'}
            </button>

            {/* النتائج */}
            {concreteResult && (
              <div className="bg-gradient-to-br from-orange-900/40 to-amber-900/40 p-6 rounded-xl border border-orange-500/30 space-y-4">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <h3 className="text-xl font-bold text-orange-300 flex items-center gap-2">
                    📊 {language === 'ar' ? 'نتائج الحساب' : 'Calculation Results'}
                  </h3>
                  <div className="bg-blue-600/30 px-3 py-1 rounded-lg border border-blue-400/30">
                    <span className="text-blue-300 text-sm">
                      {buildingCode === 'egyptian' && '🇪🇬 ECP 203'}
                      {buildingCode === 'american' && '🇺🇸 ACI 318'}
                      {buildingCode === 'saudi' && '🇸🇦 SBC'}
                      {buildingCode === 'british' && '🇬🇧 BS EN'}
                    </span>
                  </div>
                </div>

                {/* ملخص الكميات */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-black/20 p-4 rounded-lg text-center">
                    <p className="text-gray-400 text-sm">{language === 'ar' ? 'حجم الخرسانة' : 'Concrete Volume'}</p>
                    <p className="text-2xl font-bold text-cyan-400">{concreteResult.volume.toFixed(2)}</p>
                    <p className="text-gray-500 text-xs">م³</p>
                  </div>
                  <div className="bg-black/20 p-4 rounded-lg text-center">
                    <p className="text-gray-400 text-sm">{language === 'ar' ? 'وزن الحديد' : 'Steel Weight'}</p>
                    <p className="text-2xl font-bold text-red-400">{concreteResult.steelWeight.toFixed(0)}</p>
                    <p className="text-gray-500 text-xs">{language === 'ar' ? 'كجم' : 'kg'}</p>
                  </div>
                  <div className="bg-black/20 p-4 rounded-lg text-center">
                    <p className="text-gray-400 text-sm">{language === 'ar' ? 'كمية الأسمنت' : 'Cement'}</p>
                    <p className="text-2xl font-bold text-green-400">{concreteResult.cement.toFixed(0)}</p>
                    <p className="text-gray-500 text-xs">{language === 'ar' ? 'كيس (50كجم)' : 'bags (50kg)'}</p>
                  </div>
                  <div className="bg-black/20 p-4 rounded-lg text-center">
                    <p className="text-gray-400 text-sm">{language === 'ar' ? 'الخلاطات' : 'Mixers'}</p>
                    <p className="text-2xl font-bold text-purple-400">{concreteResult.mixerLoads}</p>
                    <p className="text-gray-500 text-xs">{language === 'ar' ? 'خلاطة (8م³)' : 'trucks (8m³)'}</p>
                  </div>
                </div>

                {/* تفاصيل المواد */}
                <div className="bg-black/20 rounded-xl overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-orange-600/30">
                      <tr>
                        <th className="py-2 px-4 text-right text-white">{language === 'ar' ? 'المادة' : 'Material'}</th>
                        <th className="py-2 px-4 text-center text-white">{language === 'ar' ? 'الكمية' : 'Quantity'}</th>
                        <th className="py-2 px-4 text-center text-white">{language === 'ar' ? 'الوحدة' : 'Unit'}</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b border-white/5">
                        <td className="py-2 px-4 text-white">🧱 {language === 'ar' ? 'أسمنت' : 'Cement'}</td>
                        <td className="py-2 px-4 text-center text-cyan-300">{(concreteResult.cement * 50).toFixed(0)}</td>
                        <td className="py-2 px-4 text-center text-gray-400">{language === 'ar' ? 'كجم' : 'kg'}</td>
                      </tr>
                      <tr className="border-b border-white/5 bg-white/5">
                        <td className="py-2 px-4 text-white">🏖️ {language === 'ar' ? 'رمل' : 'Sand'}</td>
                        <td className="py-2 px-4 text-center text-yellow-300">{concreteResult.sand.toFixed(2)}</td>
                        <td className="py-2 px-4 text-center text-gray-400">م³</td>
                      </tr>
                      <tr className="border-b border-white/5">
                        <td className="py-2 px-4 text-white">🪨 {language === 'ar' ? 'زلط' : 'Gravel'}</td>
                        <td className="py-2 px-4 text-center text-orange-300">{concreteResult.gravel.toFixed(2)}</td>
                        <td className="py-2 px-4 text-center text-gray-400">م³</td>
                      </tr>
                      <tr className="border-b border-white/5 bg-white/5">
                        <td className="py-2 px-4 text-white">💧 {language === 'ar' ? 'ماء' : 'Water'}</td>
                        <td className="py-2 px-4 text-center text-blue-300">{concreteResult.water.toFixed(0)}</td>
                        <td className="py-2 px-4 text-center text-gray-400">{language === 'ar' ? 'لتر' : 'liters'}</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-4 text-white">🔩 {language === 'ar' ? 'حديد تسليح' : 'Rebar'}</td>
                        <td className="py-2 px-4 text-center text-red-300">{(concreteResult.steelWeight / 1000).toFixed(2)}</td>
                        <td className="py-2 px-4 text-center text-gray-400">{language === 'ar' ? 'طن' : 'ton'}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* زر التصدير */}
                <button
                  onClick={() => {
                    const elementNames: {[key: string]: {ar: string, en: string}} = {
                      footing: {ar: 'أساس', en: 'Footing'},
                      column: {ar: 'عمود', en: 'Column'},
                      beam: {ar: 'كمرة', en: 'Beam'},
                      slab: {ar: 'بلاطة', en: 'Slab'},
                      stair: {ar: 'سلم', en: 'Stair'}
                    };
                    const elemName = language === 'ar' ? elementNames[concreteElement].ar : elementNames[concreteElement].en;
                    const codeNames: {[key: string]: {ar: string, en: string}} = {
                      egyptian: {ar: 'الكود المصري ECP 203', en: 'Egyptian Code ECP 203'},
                      american: {ar: 'الكود الأمريكي ACI 318', en: 'American Code ACI 318'},
                      saudi: {ar: 'الكود السعودي SBC', en: 'Saudi Code SBC'},
                      british: {ar: 'الكود البريطاني BS EN', en: 'British Code BS EN'}
                    };
                    const codeName = language === 'ar' ? codeNames[buildingCode].ar : codeNames[buildingCode].en;
                    const report = `تقرير كميات الخرسانة والحديد
================================
الكود المستخدم: ${codeName}
نوع العنصر: ${elemName}
العدد: ${concreteInputs.quantity}
نوع الخلطة: ${concreteInputs.mixType}

الكميات المطلوبة:
- حجم الخرسانة: ${concreteResult.volume.toFixed(2)} م³
- كمية الأسمنت: ${concreteResult.cement.toFixed(0)} كيس (${(concreteResult.cement * 50).toFixed(0)} كجم)
- كمية الرمل: ${concreteResult.sand.toFixed(2)} م³
- كمية الزلط: ${concreteResult.gravel.toFixed(2)} م³
- كمية الماء: ${concreteResult.water.toFixed(0)} لتر
- وزن الحديد: ${concreteResult.steelWeight.toFixed(0)} كجم (${(concreteResult.steelWeight / 1000).toFixed(2)} طن)

اللوجستيات:
- عدد خلاطات الخرسانة: ${concreteResult.mixerLoads} خلاطة (8 م³)
`;
                    const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'concrete-report.txt';
                    a.click();
                    toast.success(language === 'ar' ? '✓ تم تصدير التقرير' : '✓ Report exported');
                  }}
                  className="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2"
                  data-testid="button-export-concrete"
                >
                  <Download className="w-5 h-5" />
                  {language === 'ar' ? 'تصدير التقرير' : 'Export Report'}
                </button>
              </div>
            )}
          </div>
        )}

        {calcType === "rebar" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">🔩 {language === 'ar' ? 'حاسبة حديد التسليح التفصيلية' : 'Detailed Rebar Calculator'}</h2>
            
            {/* جدول أوزان الحديد */}
            <div className="bg-gradient-to-r from-gray-800/40 to-gray-900/40 p-4 rounded-xl border border-gray-500/30 mb-4">
              <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                📊 {language === 'ar' ? 'جدول أوزان الحديد (كجم/متر)' : 'Rebar Weight Table (kg/m)'}
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-white/10">
                      <th className="px-2 py-1 text-gray-300">{language === 'ar' ? 'القطر' : 'Ø'}</th>
                      {[6, 8, 10, 12, 14, 16, 18, 20, 22, 25, 28, 32].map(d => (
                        <th key={d} className="px-2 py-1 text-cyan-300">{d}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="bg-white/5">
                      <td className="px-2 py-1 text-gray-300">{language === 'ar' ? 'الوزن' : 'Wt'}</td>
                      {[6, 8, 10, 12, 14, 16, 18, 20, 22, 25, 28, 32].map(d => (
                        <td key={d} className="px-2 py-1 text-white text-center">{rebarWeightPerMeter[d]}</td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
              <p className="text-gray-400 text-xs mt-2">
                {language === 'ar' ? 'المعادلة: الوزن (كجم/م) = (قطر² × 0.00617)' : 'Formula: Weight (kg/m) = (Ø² × 0.00617)'}
              </p>
            </div>

            {/* إعدادات السعر */}
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <Label className="text-gray-300 mb-2 block">{language === 'ar' ? 'سعر الطن' : 'Price per Ton'}</Label>
                <Input
                  type="number"
                  value={rebarPricePerTon}
                  onChange={(e) => setRebarPricePerTon(Number(e.target.value))}
                  className="bg-white/10 border-white/20 text-white"
                  data-testid="input-rebar-price"
                />
              </div>
              <div>
                <Label className="text-gray-300 mb-2 block">{language === 'ar' ? 'العملة' : 'Currency'}</Label>
                <select
                  value={rebarCurrency}
                  onChange={(e) => setRebarCurrency(e.target.value)}
                  className="w-full h-10 px-3 bg-white/10 border border-white/20 text-white rounded-md"
                  data-testid="select-rebar-currency"
                >
                  <option value="EGP">EGP - جنيه مصري</option>
                  <option value="SAR">SAR - ريال سعودي</option>
                  <option value="USD">USD - دولار أمريكي</option>
                  <option value="EUR">EUR - يورو</option>
                  <option value="AED">AED - درهم إماراتي</option>
                </select>
              </div>
            </div>

            {/* قائمة الحديد */}
            <div className="space-y-3">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-white font-semibold">{language === 'ar' ? 'قائمة أسياخ الحديد' : 'Rebar List'}</h3>
                <Button
                  onClick={addRebarItem}
                  className="bg-green-600 hover:bg-green-700"
                  data-testid="button-add-rebar"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  {language === 'ar' ? 'إضافة' : 'Add'}
                </Button>
              </div>

              {rebarItems.map((item, index) => (
                <div key={item.id} className="bg-white/5 p-4 rounded-xl border border-white/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-cyan-300 font-semibold">#{index + 1}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeRebarItem(item.id)}
                      className="text-red-400 hover:text-red-300 hover:bg-red-900/30"
                      disabled={rebarItems.length === 1}
                      data-testid={`button-remove-rebar-${item.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'القطر (مم)' : 'Diameter (mm)'}</Label>
                      <select
                        value={item.diameter}
                        onChange={(e) => updateRebarItem(item.id, 'diameter', Number(e.target.value))}
                        className="w-full h-9 px-2 bg-white/10 border border-white/20 text-white rounded-md text-sm"
                        data-testid={`select-rebar-diameter-${item.id}`}
                      >
                        {[6, 8, 10, 12, 14, 16, 18, 20, 22, 25, 28, 32, 36, 40].map(d => (
                          <option key={d} value={d}>Ø{d}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'الطول (م)' : 'Length (m)'}</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={item.length}
                        onChange={(e) => updateRebarItem(item.id, 'length', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-rebar-length-${item.id}`}
                      />
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'العدد' : 'Quantity'}</Label>
                      <Input
                        type="number"
                        value={item.quantity}
                        onChange={(e) => updateRebarItem(item.id, 'quantity', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-rebar-quantity-${item.id}`}
                      />
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'الوصف' : 'Description'}</Label>
                      <Input
                        type="text"
                        value={item.description}
                        onChange={(e) => updateRebarItem(item.id, 'description', e.target.value)}
                        placeholder={language === 'ar' ? 'مثال: سقف' : 'e.g. Slab'}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-rebar-desc-${item.id}`}
                      />
                    </div>
                  </div>

                  {/* معاينة الوزن الفوري */}
                  <div className="flex items-center justify-between bg-white/5 px-3 py-2 rounded-lg">
                    <span className="text-gray-400 text-sm">{language === 'ar' ? 'الوزن المتوقع:' : 'Expected Weight:'}</span>
                    <span className="text-cyan-300 font-semibold">
                      {(item.length * item.quantity * (rebarWeightPerMeter[item.diameter] || 0)).toFixed(2)} {language === 'ar' ? 'كجم' : 'kg'}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* زر الحساب */}
            <button
              onClick={calculateRebar}
              className="w-full py-4 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold text-lg transition flex items-center justify-center gap-2"
              data-testid="button-calculate-rebar"
            >
              <Calculator className="w-6 h-6" />
              {language === 'ar' ? 'حساب الكميات' : 'Calculate Quantities'}
            </button>

            {/* النتائج */}
            {rebarResult && (
              <div className="space-y-4 mt-6">
                {/* ملخص إجمالي */}
                <div className="bg-gradient-to-r from-red-900/40 to-orange-900/40 p-5 rounded-xl border border-red-500/40">
                  <h3 className="text-xl font-bold text-white mb-4 text-center">📊 {language === 'ar' ? 'الإجمالي' : 'Summary'}</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'إجمالي الوزن' : 'Total Weight'}</p>
                      <p className="text-3xl font-bold text-cyan-300">{rebarResult.totalWeight.toFixed(2)}</p>
                      <p className="text-gray-400">{language === 'ar' ? 'كجم' : 'kg'}</p>
                      <p className="text-lg text-white mt-1">({(rebarResult.totalWeight / 1000).toFixed(3)} {language === 'ar' ? 'طن' : 'ton'})</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'التكلفة التقديرية' : 'Estimated Cost'}</p>
                      <p className="text-3xl font-bold text-green-300">{rebarResult.totalCost.toLocaleString()}</p>
                      <p className="text-gray-400">{rebarCurrency}</p>
                    </div>
                  </div>
                </div>

                {/* تفاصيل حسب القطر */}
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                  <h3 className="text-white font-semibold mb-3">📋 {language === 'ar' ? 'تفاصيل حسب القطر' : 'Details by Diameter'}</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-white/10">
                          <th className="py-2 px-3 text-right text-gray-300">{language === 'ar' ? 'القطر' : 'Diameter'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'عدد الأسياخ' : 'Bar Count'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'الوزن (كجم)' : 'Weight (kg)'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'النسبة' : 'Percentage'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {Object.entries(rebarResult.barsByDiameter)
                          .sort(([a], [b]) => Number(a) - Number(b))
                          .map(([diameter, data]) => (
                          <tr key={diameter} className="border-t border-white/10">
                            <td className="py-2 px-3 text-white font-semibold">Ø{diameter}</td>
                            <td className="py-2 px-3 text-center text-cyan-300">{data.count}</td>
                            <td className="py-2 px-3 text-center text-green-300">{data.weight.toFixed(2)}</td>
                            <td className="py-2 px-3 text-center text-yellow-300">
                              {((data.weight / rebarResult.totalWeight) * 100).toFixed(1)}%
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* جدول التفاصيل */}
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                  <h3 className="text-white font-semibold mb-3">📝 {language === 'ar' ? 'جدول التفاصيل' : 'Details Table'}</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-white/10">
                          <th className="py-2 px-3 text-right text-gray-300">#</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'القطر' : 'Ø'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'الطول' : 'L'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'العدد' : 'Qty'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'و/م' : 'kg/m'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'الوزن' : 'Weight'}</th>
                          <th className="py-2 px-3 text-right text-gray-300">{language === 'ar' ? 'الوصف' : 'Desc'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {rebarResult.items.map((item, idx) => (
                          <tr key={idx} className="border-t border-white/10">
                            <td className="py-2 px-3 text-gray-400">{idx + 1}</td>
                            <td className="py-2 px-3 text-center text-white">Ø{item.diameter}</td>
                            <td className="py-2 px-3 text-center text-cyan-300">{item.length}m</td>
                            <td className="py-2 px-3 text-center text-yellow-300">{item.quantity}</td>
                            <td className="py-2 px-3 text-center text-gray-400">{item.weightPerMeter}</td>
                            <td className="py-2 px-3 text-center text-green-300 font-semibold">{item.totalWeight.toFixed(2)}</td>
                            <td className="py-2 px-3 text-gray-300">{item.description || '-'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* أزرار التصدير */}
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => {
                      const report = `تقرير حساب حديد التسليح
=====================================
التاريخ: ${new Date().toLocaleString('ar-EG')}

إجمالي الوزن: ${rebarResult.totalWeight.toFixed(2)} كجم (${(rebarResult.totalWeight / 1000).toFixed(3)} طن)
التكلفة التقديرية: ${rebarResult.totalCost.toLocaleString()} ${rebarCurrency}
سعر الطن: ${rebarPricePerTon.toLocaleString()} ${rebarCurrency}

تفاصيل حسب القطر:
${Object.entries(rebarResult.barsByDiameter)
  .sort(([a], [b]) => Number(a) - Number(b))
  .map(([d, data]) => `- Ø${d}: ${data.count} سيخ، ${data.weight.toFixed(2)} كجم`)
  .join('\n')}

تفاصيل الأسياخ:
${rebarResult.items.map((item, i) => 
  `${i + 1}. Ø${item.diameter} × ${item.length}م × ${item.quantity} = ${item.totalWeight.toFixed(2)} كجم${item.description ? ` (${item.description})` : ''}`
).join('\n')}
`;
                      const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = 'rebar-report.txt';
                      a.click();
                      toast.success(language === 'ar' ? '✓ تم تصدير التقرير' : '✓ Report exported');
                    }}
                    className="py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2"
                    data-testid="button-export-rebar-txt"
                  >
                    <Download className="w-5 h-5" />
                    {language === 'ar' ? 'تصدير TXT' : 'Export TXT'}
                  </button>
                  <button
                    onClick={() => {
                      const csv = `القطر,الطول(م),العدد,الوزن/م,الوزن(كجم),الوصف
${rebarResult.items.map(item => 
  `${item.diameter},${item.length},${item.quantity},${item.weightPerMeter},${item.totalWeight.toFixed(2)},"${item.description}"`
).join('\n')}
,,,,
إجمالي,,,${rebarResult.totalWeight.toFixed(2)} كجم,${(rebarResult.totalWeight / 1000).toFixed(3)} طن
التكلفة,,,${rebarResult.totalCost.toLocaleString()},${rebarCurrency}`;
                      const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = 'rebar-report.csv';
                      a.click();
                      toast.success(language === 'ar' ? '✓ تم تصدير CSV' : '✓ CSV exported');
                    }}
                    className="py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2"
                    data-testid="button-export-rebar-csv"
                  >
                    <Download className="w-5 h-5" />
                    {language === 'ar' ? 'تصدير CSV' : 'Export CSV'}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {calcType === "electrical" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">⚡ {language === 'ar' ? 'حاسبة الأحمال الكهربائية' : 'Electrical Load Calculator'}</h2>
            
            {/* إعدادات عامة */}
            <div className="bg-gradient-to-r from-yellow-900/40 to-orange-900/40 p-4 rounded-xl border border-yellow-500/30 mb-4">
              <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                ⚙️ {language === 'ar' ? 'الإعدادات العامة' : 'General Settings'}
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'الجهد (فولت)' : 'Voltage (V)'}</Label>
                  <select
                    value={electricalSettings.voltage}
                    onChange={(e) => setElectricalSettings({...electricalSettings, voltage: Number(e.target.value)})}
                    className="w-full h-9 px-2 bg-white/10 border border-white/20 text-white rounded-md text-sm"
                    data-testid="select-electrical-voltage"
                  >
                    <option value={110}>110V</option>
                    <option value={220}>220V</option>
                    <option value={380}>380V (3-Phase)</option>
                  </select>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'معامل القدرة' : 'Power Factor'}</Label>
                  <Input
                    type="number"
                    step="0.05"
                    value={electricalSettings.powerFactor}
                    onChange={(e) => setElectricalSettings({...electricalSettings, powerFactor: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white text-sm"
                    data-testid="input-power-factor"
                  />
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'معامل الطلب' : 'Demand Factor'}</Label>
                  <Input
                    type="number"
                    step="0.05"
                    value={electricalSettings.demandFactor}
                    onChange={(e) => setElectricalSettings({...electricalSettings, demandFactor: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white text-sm"
                    data-testid="input-demand-factor"
                  />
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'معامل الأمان' : 'Safety Factor'}</Label>
                  <Input
                    type="number"
                    step="0.05"
                    value={electricalSettings.safetyFactor}
                    onChange={(e) => setElectricalSettings({...electricalSettings, safetyFactor: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white text-sm"
                    data-testid="input-safety-factor"
                  />
                </div>
              </div>
            </div>

            {/* قائمة الغرف */}
            <div className="space-y-3">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-white font-semibold">{language === 'ar' ? 'الغرف والفراغات' : 'Rooms & Spaces'}</h3>
                <Button
                  onClick={addElectricalRoom}
                  className="bg-green-600 hover:bg-green-700"
                  data-testid="button-add-room"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  {language === 'ar' ? 'إضافة غرفة' : 'Add Room'}
                </Button>
              </div>

              {electricalRooms.map((room, index) => (
                <div key={room.id} className="bg-white/5 p-4 rounded-xl border border-white/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-yellow-300 font-semibold">#{index + 1}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeElectricalRoom(room.id)}
                      className="text-red-400 hover:text-red-300 hover:bg-red-900/30"
                      disabled={electricalRooms.length === 1}
                      data-testid={`button-remove-room-${room.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'نوع الغرفة' : 'Room Type'}</Label>
                      <select
                        value={room.type}
                        onChange={(e) => updateElectricalRoom(room.id, 'type', e.target.value)}
                        className="w-full h-9 px-2 bg-white/10 border border-white/20 text-white rounded-md text-sm"
                        data-testid={`select-room-type-${room.id}`}
                      >
                        <option value="bedroom">{language === 'ar' ? '🛏️ غرفة نوم' : '🛏️ Bedroom'}</option>
                        <option value="living">{language === 'ar' ? '🛋️ صالة' : '🛋️ Living Room'}</option>
                        <option value="kitchen">{language === 'ar' ? '🍳 مطبخ' : '🍳 Kitchen'}</option>
                        <option value="bathroom">{language === 'ar' ? '🚿 حمام' : '🚿 Bathroom'}</option>
                        <option value="office">{language === 'ar' ? '💼 مكتب' : '💼 Office'}</option>
                        <option value="shop">{language === 'ar' ? '🏪 محل' : '🏪 Shop'}</option>
                        <option value="factory">{language === 'ar' ? '🏭 مصنع' : '🏭 Factory'}</option>
                        <option value="warehouse">{language === 'ar' ? '📦 مخزن' : '📦 Warehouse'}</option>
                      </select>
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'العدد' : 'Quantity'}</Label>
                      <Input
                        type="number"
                        value={room.quantity}
                        onChange={(e) => updateElectricalRoom(room.id, 'quantity', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-room-qty-${room.id}`}
                      />
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'نقاط الإضاءة' : 'Light Points'}</Label>
                      <Input
                        type="number"
                        value={room.lights}
                        onChange={(e) => updateElectricalRoom(room.id, 'lights', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-lights-${room.id}`}
                      />
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'المقابس' : 'Sockets'}</Label>
                      <Input
                        type="number"
                        value={room.sockets}
                        onChange={(e) => updateElectricalRoom(room.id, 'sockets', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-sockets-${room.id}`}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عدد التكييفات' : 'AC Units'}</Label>
                      <Input
                        type="number"
                        value={room.ac}
                        onChange={(e) => updateElectricalRoom(room.id, 'ac', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-ac-${room.id}`}
                      />
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'قدرة التكييف (kW)' : 'AC Power (kW)'}</Label>
                      <select
                        value={room.acPower}
                        onChange={(e) => updateElectricalRoom(room.id, 'acPower', Number(e.target.value))}
                        className="w-full h-9 px-2 bg-white/10 border border-white/20 text-white rounded-md text-sm"
                        data-testid={`select-ac-power-${room.id}`}
                      >
                        <option value={1}>1 kW (12,000 BTU)</option>
                        <option value={1.5}>1.5 kW (18,000 BTU)</option>
                        <option value={2}>2 kW (24,000 BTU)</option>
                        <option value={2.5}>2.5 kW (30,000 BTU)</option>
                        <option value={3}>3 kW (36,000 BTU)</option>
                        <option value={4}>4 kW (48,000 BTU)</option>
                        <option value={5}>5 kW (60,000 BTU)</option>
                      </select>
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'سخانات' : 'Heaters'}</Label>
                      <Input
                        type="number"
                        value={room.heater}
                        onChange={(e) => updateElectricalRoom(room.id, 'heater', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-heater-${room.id}`}
                      />
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'قدرة السخان (kW)' : 'Heater Power (kW)'}</Label>
                      <select
                        value={room.heaterPower}
                        onChange={(e) => updateElectricalRoom(room.id, 'heaterPower', Number(e.target.value))}
                        className="w-full h-9 px-2 bg-white/10 border border-white/20 text-white rounded-md text-sm"
                        data-testid={`select-heater-power-${room.id}`}
                      >
                        <option value={1}>1 kW</option>
                        <option value={1.5}>1.5 kW</option>
                        <option value={2}>2 kW</option>
                        <option value={2.5}>2.5 kW</option>
                        <option value={3}>3 kW</option>
                        <option value={4}>4 kW</option>
                      </select>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* زر الحساب */}
            <button
              onClick={calculateElectrical}
              className="w-full py-4 bg-yellow-600 hover:bg-yellow-700 text-white rounded-xl font-bold text-lg transition flex items-center justify-center gap-2"
              data-testid="button-calculate-electrical"
            >
              <Calculator className="w-6 h-6" />
              {language === 'ar' ? 'حساب الأحمال' : 'Calculate Loads'}
            </button>

            {/* النتائج */}
            {electricalResult && (
              <div className="space-y-4 mt-6">
                {/* ملخص إجمالي */}
                <div className="bg-gradient-to-r from-yellow-900/40 to-orange-900/40 p-5 rounded-xl border border-yellow-500/40">
                  <h3 className="text-xl font-bold text-white mb-4 text-center">⚡ {language === 'ar' ? 'نتائج الحساب' : 'Calculation Results'}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'الحمل الإجمالي' : 'Total Load'}</p>
                      <p className="text-2xl font-bold text-yellow-300">{(electricalResult.totalLoad / 1000).toFixed(2)}</p>
                      <p className="text-gray-400">kW</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'الحمل المطلوب' : 'Demand Load'}</p>
                      <p className="text-2xl font-bold text-cyan-300">{(electricalResult.demandLoad / 1000).toFixed(2)}</p>
                      <p className="text-gray-400">kW</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'التيار المحسوب' : 'Calculated Current'}</p>
                      <p className="text-2xl font-bold text-green-300">{electricalResult.current.toFixed(1)}</p>
                      <p className="text-gray-400">A</p>
                    </div>
                  </div>
                </div>

                {/* المواصفات المطلوبة */}
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                  <h3 className="text-white font-semibold mb-3">🔧 {language === 'ar' ? 'المواصفات المطلوبة' : 'Required Specifications'}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="bg-white/5 p-3 rounded-lg">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'حجم القاطع الرئيسي' : 'Main Breaker Size'}</p>
                      <p className="text-xl font-bold text-white">{electricalResult.breakerSize} A</p>
                    </div>
                    <div className="bg-white/5 p-3 rounded-lg">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'مقاس الكابل الرئيسي' : 'Main Cable Size'}</p>
                      <p className="text-xl font-bold text-white">{electricalResult.cableSize}</p>
                    </div>
                    <div className="bg-white/5 p-3 rounded-lg">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'حجم العداد' : 'Meter Size'}</p>
                      <p className="text-xl font-bold text-white">{electricalResult.meterSize} A</p>
                    </div>
                  </div>
                </div>

                {/* تفاصيل الغرف */}
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                  <h3 className="text-white font-semibold mb-3">📊 {language === 'ar' ? 'توزيع الأحمال' : 'Load Distribution'}</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-white/10">
                          <th className="py-2 px-3 text-right text-gray-300">{language === 'ar' ? 'الغرفة' : 'Room'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'الحمل (W)' : 'Load (W)'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'التيار (A)' : 'Current (A)'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'النسبة' : 'Percentage'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {electricalResult.roomsBreakdown.map((room, idx) => (
                          <tr key={idx} className="border-t border-white/10">
                            <td className="py-2 px-3 text-white">{room.type}</td>
                            <td className="py-2 px-3 text-center text-yellow-300">{room.load.toFixed(0)}</td>
                            <td className="py-2 px-3 text-center text-cyan-300">{room.current.toFixed(1)}</td>
                            <td className="py-2 px-3 text-center text-green-300">
                              {((room.load / electricalResult.totalLoad) * 100).toFixed(1)}%
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* التوصيات */}
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                  <h3 className="text-white font-semibold mb-3">💡 {language === 'ar' ? 'التوصيات' : 'Recommendations'}</h3>
                  <ul className="space-y-2">
                    {electricalResult.recommendations.map((rec, idx) => (
                      <li key={idx} className="text-gray-300 text-sm">{rec}</li>
                    ))}
                  </ul>
                </div>

                {/* زر التصدير */}
                <button
                  onClick={() => {
                    const report = `تقرير حساب الأحمال الكهربائية
=====================================
التاريخ: ${new Date().toLocaleString('ar-EG')}

الإعدادات:
- الجهد: ${electricalSettings.voltage}V
- معامل القدرة: ${electricalSettings.powerFactor}
- معامل الطلب: ${electricalSettings.demandFactor}
- معامل الأمان: ${electricalSettings.safetyFactor}

النتائج:
- الحمل الإجمالي: ${(electricalResult.totalLoad / 1000).toFixed(2)} kW
- الحمل المطلوب: ${(electricalResult.demandLoad / 1000).toFixed(2)} kW
- التيار المحسوب: ${electricalResult.current.toFixed(1)} A

المواصفات المطلوبة:
- حجم القاطع الرئيسي: ${electricalResult.breakerSize} A
- مقاس الكابل الرئيسي: ${electricalResult.cableSize}
- حجم العداد: ${electricalResult.meterSize} A

توزيع الأحمال:
${electricalResult.roomsBreakdown.map(r => `- ${r.type}: ${r.load.toFixed(0)}W (${r.current.toFixed(1)}A)`).join('\n')}

التوصيات:
${electricalResult.recommendations.map(r => `- ${r}`).join('\n')}
`;
                    const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'electrical-load-report.txt';
                    a.click();
                    toast.success(language === 'ar' ? '✓ تم تصدير التقرير' : '✓ Report exported');
                  }}
                  className="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2"
                  data-testid="button-export-electrical"
                >
                  <Download className="w-5 h-5" />
                  {language === 'ar' ? 'تصدير التقرير' : 'Export Report'}
                </button>
              </div>
            )}
          </div>
        )}

        {calcType === "hvac" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">❄️ {language === 'ar' ? 'حاسبة أحمال التكييف والتهوية' : 'HVAC Load Calculator'}</h2>
            
            {/* إعدادات عامة */}
            <div className="bg-gradient-to-r from-blue-900/40 to-cyan-900/40 p-4 rounded-xl border border-blue-500/30 mb-4">
              <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                🌡️ {language === 'ar' ? 'إعدادات المناخ' : 'Climate Settings'}
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'درجة الحرارة الخارجية °م' : 'Outdoor Temp °C'}</Label>
                  <Input
                    type="number"
                    value={hvacSettings.outdoorTemp}
                    onChange={(e) => setHvacSettings({...hvacSettings, outdoorTemp: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white text-sm"
                    data-testid="input-outdoor-temp"
                  />
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'درجة الحرارة المطلوبة °م' : 'Indoor Temp °C'}</Label>
                  <Input
                    type="number"
                    value={hvacSettings.indoorTemp}
                    onChange={(e) => setHvacSettings({...hvacSettings, indoorTemp: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white text-sm"
                    data-testid="input-indoor-temp"
                  />
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'الرطوبة %' : 'Humidity %'}</Label>
                  <Input
                    type="number"
                    value={hvacSettings.humidity}
                    onChange={(e) => setHvacSettings({...hvacSettings, humidity: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white text-sm"
                    data-testid="input-humidity"
                  />
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'نوع المناخ' : 'Climate Type'}</Label>
                  <select
                    value={hvacSettings.location}
                    onChange={(e) => setHvacSettings({...hvacSettings, location: e.target.value as any})}
                    className="w-full h-9 px-2 bg-white/10 border border-white/20 text-white rounded-md text-sm"
                    data-testid="select-climate"
                  >
                    <option value="desert">{language === 'ar' ? '🏜️ صحراوي' : '🏜️ Desert'}</option>
                    <option value="coastal">{language === 'ar' ? '🌊 ساحلي' : '🌊 Coastal'}</option>
                    <option value="moderate">{language === 'ar' ? '🌳 معتدل' : '🌳 Moderate'}</option>
                  </select>
                </div>
              </div>
            </div>

            {/* قائمة الغرف */}
            <div className="space-y-3">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-white font-semibold">{language === 'ar' ? 'الغرف والفراغات' : 'Rooms & Spaces'}</h3>
                <Button
                  onClick={addHvacRoom}
                  className="bg-green-600 hover:bg-green-700"
                  data-testid="button-add-hvac-room"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  {language === 'ar' ? 'إضافة غرفة' : 'Add Room'}
                </Button>
              </div>

              {hvacRooms.map((room, index) => (
                <div key={room.id} className="bg-white/5 p-4 rounded-xl border border-white/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-cyan-300 font-semibold">#{index + 1}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeHvacRoom(room.id)}
                      className="text-red-400 hover:text-red-300 hover:bg-red-900/30"
                      disabled={hvacRooms.length === 1}
                      data-testid={`button-remove-hvac-room-${room.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'نوع الغرفة' : 'Room Type'}</Label>
                      <select
                        value={room.type}
                        onChange={(e) => updateHvacRoom(room.id, 'type', e.target.value)}
                        className="w-full h-9 px-2 bg-white/10 border border-white/20 text-white rounded-md text-sm"
                        data-testid={`select-hvac-room-type-${room.id}`}
                      >
                        <option value="bedroom">{language === 'ar' ? '🛏️ غرفة نوم' : '🛏️ Bedroom'}</option>
                        <option value="living">{language === 'ar' ? '🛋️ صالة' : '🛋️ Living Room'}</option>
                        <option value="kitchen">{language === 'ar' ? '🍳 مطبخ' : '🍳 Kitchen'}</option>
                        <option value="bathroom">{language === 'ar' ? '🚿 حمام' : '🚿 Bathroom'}</option>
                        <option value="office">{language === 'ar' ? '💼 مكتب' : '💼 Office'}</option>
                        <option value="shop">{language === 'ar' ? '🏪 محل' : '🏪 Shop'}</option>
                        <option value="restaurant">{language === 'ar' ? '🍽️ مطعم' : '🍽️ Restaurant'}</option>
                        <option value="server_room">{language === 'ar' ? '🖥️ سيرفرات' : '🖥️ Server Room'}</option>
                        <option value="gym">{language === 'ar' ? '💪 صالة رياضة' : '💪 Gym'}</option>
                      </select>
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'الطول (م)' : 'Length (m)'}</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={room.length}
                        onChange={(e) => updateHvacRoom(room.id, 'length', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-hvac-length-${room.id}`}
                      />
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'العرض (م)' : 'Width (m)'}</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={room.width}
                        onChange={(e) => updateHvacRoom(room.id, 'width', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-hvac-width-${room.id}`}
                      />
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'الارتفاع (م)' : 'Height (m)'}</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={room.height}
                        onChange={(e) => updateHvacRoom(room.id, 'height', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-hvac-height-${room.id}`}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عدد النوافذ' : 'Windows'}</Label>
                      <Input
                        type="number"
                        value={room.windows}
                        onChange={(e) => updateHvacRoom(room.id, 'windows', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-hvac-windows-${room.id}`}
                      />
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'مساحة النافذة (م²)' : 'Window Area (m²)'}</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={room.windowArea}
                        onChange={(e) => updateHvacRoom(room.id, 'windowArea', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-hvac-window-area-${room.id}`}
                      />
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عدد الأشخاص' : 'Occupants'}</Label>
                      <Input
                        type="number"
                        value={room.occupants}
                        onChange={(e) => updateHvacRoom(room.id, 'occupants', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-hvac-occupants-${room.id}`}
                      />
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'اتجاه الشمس' : 'Sun Exposure'}</Label>
                      <select
                        value={room.sunExposure}
                        onChange={(e) => updateHvacRoom(room.id, 'sunExposure', e.target.value)}
                        className="w-full h-9 px-2 bg-white/10 border border-white/20 text-white rounded-md text-sm"
                        data-testid={`select-hvac-sun-${room.id}`}
                      >
                        <option value="north">{language === 'ar' ? '⬆️ شمال' : '⬆️ North'}</option>
                        <option value="east">{language === 'ar' ? '➡️ شرق' : '➡️ East'}</option>
                        <option value="south">{language === 'ar' ? '⬇️ جنوب' : '⬇️ South'}</option>
                        <option value="west">{language === 'ar' ? '⬅️ غرب' : '⬅️ West'}</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'حمل المعدات (واط)' : 'Equipment (W)'}</Label>
                      <Input
                        type="number"
                        value={room.equipment}
                        onChange={(e) => updateHvacRoom(room.id, 'equipment', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-hvac-equipment-${room.id}`}
                      />
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'حمل الإضاءة (واط)' : 'Lighting (W)'}</Label>
                      <Input
                        type="number"
                        value={room.lighting}
                        onChange={(e) => updateHvacRoom(room.id, 'lighting', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-hvac-lighting-${room.id}`}
                      />
                    </div>
                    <div className="col-span-2">
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'جودة العزل' : 'Insulation'}</Label>
                      <select
                        value={room.insulation}
                        onChange={(e) => updateHvacRoom(room.id, 'insulation', e.target.value)}
                        className="w-full h-9 px-2 bg-white/10 border border-white/20 text-white rounded-md text-sm"
                        data-testid={`select-hvac-insulation-${room.id}`}
                      >
                        <option value="poor">{language === 'ar' ? '❌ ضعيف' : '❌ Poor'}</option>
                        <option value="average">{language === 'ar' ? '⚡ متوسط' : '⚡ Average'}</option>
                        <option value="good">{language === 'ar' ? '✅ جيد' : '✅ Good'}</option>
                      </select>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* زر الحساب */}
            <button
              onClick={calculateHVAC}
              className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-lg transition flex items-center justify-center gap-2"
              data-testid="button-calculate-hvac"
            >
              <Calculator className="w-6 h-6" />
              {language === 'ar' ? 'حساب حمل التكييف' : 'Calculate HVAC Load'}
            </button>

            {/* النتائج */}
            {hvacResult && (
              <div className="space-y-4 mt-6">
                {/* ملخص إجمالي */}
                <div className="bg-gradient-to-r from-blue-900/40 to-cyan-900/40 p-5 rounded-xl border border-blue-500/40">
                  <h3 className="text-xl font-bold text-white mb-4 text-center">❄️ {language === 'ar' ? 'نتائج الحساب' : 'Calculation Results'}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'حمل التبريد' : 'Cooling Load'}</p>
                      <p className="text-2xl font-bold text-cyan-300">{(hvacResult.totalCoolingLoad / 1000).toFixed(2)}</p>
                      <p className="text-gray-400">kW</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'BTU/hr' : 'BTU/hr'}</p>
                      <p className="text-2xl font-bold text-yellow-300">{Math.round(hvacResult.totalBTU).toLocaleString()}</p>
                      <p className="text-gray-400">BTU</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'طن تبريد' : 'AC Tonnage'}</p>
                      <p className="text-2xl font-bold text-green-300">{hvacResult.acTonnage.toFixed(1)}</p>
                      <p className="text-gray-400">{language === 'ar' ? 'طن' : 'TR'}</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'تدفق الهواء' : 'Air Flow'}</p>
                      <p className="text-2xl font-bold text-purple-300">{Math.round(hvacResult.cfm)}</p>
                      <p className="text-gray-400">CFM</p>
                    </div>
                  </div>
                </div>

                {/* توزيع الغرف */}
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                  <h3 className="text-white font-semibold mb-3">📊 {language === 'ar' ? 'توزيع الأحمال' : 'Load Distribution'}</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-white/10">
                          <th className="py-2 px-3 text-right text-gray-300">{language === 'ar' ? 'الغرفة' : 'Room'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'الحمل (kW)' : 'Load (kW)'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">BTU/hr</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'النسبة' : '%'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {hvacResult.roomsBreakdown.map((room, idx) => (
                          <tr key={idx} className="border-t border-white/10">
                            <td className="py-2 px-3 text-white">{room.room}</td>
                            <td className="py-2 px-3 text-center text-cyan-300">{(room.coolingLoad / 1000).toFixed(2)}</td>
                            <td className="py-2 px-3 text-center text-yellow-300">{Math.round(room.btu).toLocaleString()}</td>
                            <td className="py-2 px-3 text-center text-green-300">
                              {((room.coolingLoad / hvacResult.totalCoolingLoad) * 100).toFixed(1)}%
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* التوصيات */}
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                  <h3 className="text-white font-semibold mb-3">💡 {language === 'ar' ? 'التوصيات' : 'Recommendations'}</h3>
                  <ul className="space-y-2">
                    {hvacResult.recommendations.map((rec, idx) => (
                      <li key={idx} className="text-gray-300 text-sm">{rec}</li>
                    ))}
                  </ul>
                </div>

                {/* زر التصدير */}
                <button
                  onClick={() => {
                    const report = `تقرير حساب أحمال التكييف والتهوية
=====================================
التاريخ: ${new Date().toLocaleString('ar-EG')}

إعدادات المناخ:
- درجة الحرارة الخارجية: ${hvacSettings.outdoorTemp}°م
- درجة الحرارة المطلوبة: ${hvacSettings.indoorTemp}°م
- الرطوبة: ${hvacSettings.humidity}%
- نوع المناخ: ${hvacSettings.location === 'desert' ? 'صحراوي' : hvacSettings.location === 'coastal' ? 'ساحلي' : 'معتدل'}

النتائج:
- حمل التبريد: ${(hvacResult.totalCoolingLoad / 1000).toFixed(2)} kW
- BTU/hr: ${Math.round(hvacResult.totalBTU).toLocaleString()}
- طن تبريد: ${hvacResult.acTonnage.toFixed(1)} TR
- تدفق الهواء: ${Math.round(hvacResult.cfm)} CFM

توزيع الأحمال:
${hvacResult.roomsBreakdown.map(r => `- ${r.room}: ${(r.coolingLoad / 1000).toFixed(2)} kW (${Math.round(r.btu).toLocaleString()} BTU)`).join('\n')}

التوصيات:
${hvacResult.recommendations.map(r => `- ${r}`).join('\n')}
`;
                    const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'hvac-load-report.txt';
                    a.click();
                    toast.success(language === 'ar' ? '✓ تم تصدير التقرير' : '✓ Report exported');
                  }}
                  className="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2"
                  data-testid="button-export-hvac"
                >
                  <Download className="w-5 h-5" />
                  {language === 'ar' ? 'تصدير التقرير' : 'Export Report'}
                </button>
              </div>
            )}
          </div>
        )}

        {calcType === "cost" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">💰 {language === 'ar' ? 'تقدير التكلفة للمواد والعمالة' : 'Cost Estimator (Materials & Labor)'}</h2>
            
            {/* إعدادات التكلفة */}
            <div className="bg-gradient-to-r from-amber-900/40 to-orange-900/40 p-4 rounded-xl border border-amber-500/30 mb-4">
              <h3 className="text-white font-semibold mb-3">⚙️ {language === 'ar' ? 'الإعدادات' : 'Settings'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'العملة' : 'Currency'}</Label>
                  <select
                    value={costCurrency}
                    onChange={(e) => setCostCurrency(e.target.value as CostCurrency)}
                    className="w-full h-9 px-2 bg-white/10 border border-white/20 text-white rounded-md text-sm"
                    data-testid="select-cost-currency"
                  >
                    <option value="EGP">🇪🇬 EGP - جنيه مصري</option>
                    <option value="SAR">🇸🇦 SAR - ريال سعودي</option>
                    <option value="USD">🇺🇸 USD - دولار</option>
                    <option value="EUR">🇪🇺 EUR - يورو</option>
                    <option value="AED">🇦🇪 AED - درهم إماراتي</option>
                  </select>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'مصاريف إدارية %' : 'Overhead %'}</Label>
                  <Input
                    type="number"
                    value={costSettings.overheadPercent}
                    onChange={(e) => setCostSettings({...costSettings, overheadPercent: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white text-sm"
                    data-testid="input-overhead"
                  />
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'أرباح %' : 'Profit %'}</Label>
                  <Input
                    type="number"
                    value={costSettings.profitPercent}
                    onChange={(e) => setCostSettings({...costSettings, profitPercent: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white text-sm"
                    data-testid="input-profit"
                  />
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'احتياطي %' : 'Contingency %'}</Label>
                  <Input
                    type="number"
                    value={costSettings.contingency}
                    onChange={(e) => setCostSettings({...costSettings, contingency: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white text-sm"
                    data-testid="input-contingency"
                  />
                </div>
              </div>
            </div>

            {/* قائمة البنود */}
            <div className="space-y-3">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-white font-semibold">{language === 'ar' ? 'بنود التكلفة' : 'Cost Items'}</h3>
                <Button
                  onClick={addCostItem}
                  className="bg-green-600 hover:bg-green-700"
                  data-testid="button-add-cost-item"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  {language === 'ar' ? 'إضافة بند' : 'Add Item'}
                </Button>
              </div>

              {costItems.map((item, index) => (
                <div key={item.id} className="bg-white/5 p-4 rounded-xl border border-white/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-amber-300 font-semibold">#{index + 1}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeCostItem(item.id)}
                      className="text-red-400 hover:text-red-300 hover:bg-red-900/30"
                      disabled={costItems.length === 1}
                      data-testid={`button-remove-cost-item-${item.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'الفئة' : 'Category'}</Label>
                      <select
                        value={item.category}
                        onChange={(e) => updateCostItem(item.id, 'category', e.target.value)}
                        className="w-full h-9 px-2 bg-white/10 border border-white/20 text-white rounded-md text-sm"
                        data-testid={`select-cost-category-${item.id}`}
                      >
                        {Object.entries(costCategories).map(([key, cat]) => (
                          <option key={key} value={key}>{language === 'ar' ? cat.ar : cat.en}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'البند' : 'Item'}</Label>
                      <select
                        value={costCategories[item.category]?.items.find(i => (language === 'ar' ? i.ar : i.en) === item.item)?.id || ''}
                        onChange={(e) => updateCostItem(item.id, 'itemSelect', e.target.value)}
                        className="w-full h-9 px-2 bg-white/10 border border-white/20 text-white rounded-md text-sm"
                        data-testid={`select-cost-item-${item.id}`}
                      >
                        {costCategories[item.category]?.items.map(i => (
                          <option key={i.id} value={i.id}>{language === 'ar' ? i.ar : i.en}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'الكمية' : 'Quantity'}</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={item.quantity}
                        onChange={(e) => updateCostItem(item.id, 'quantity', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-cost-quantity-${item.id}`}
                      />
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? 'الوحدة' : 'Unit'}</Label>
                      <Input
                        type="text"
                        value={item.unit}
                        readOnly
                        className="h-9 bg-white/5 border-white/20 text-gray-400 text-sm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? `سعر المواد (${costCurrency})` : `Material Price (${costCurrency})`}</Label>
                      <Input
                        type="number"
                        value={item.materialPrice}
                        onChange={(e) => updateCostItem(item.id, 'materialPrice', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-cost-material-${item.id}`}
                      />
                    </div>
                    <div>
                      <Label className="text-gray-400 text-xs">{language === 'ar' ? `سعر العمالة (${costCurrency})` : `Labor Price (${costCurrency})`}</Label>
                      <Input
                        type="number"
                        value={item.laborPrice}
                        onChange={(e) => updateCostItem(item.id, 'laborPrice', Number(e.target.value))}
                        className="h-9 bg-white/10 border-white/20 text-white text-sm"
                        data-testid={`input-cost-labor-${item.id}`}
                      />
                    </div>
                    <div className="flex items-end">
                      <div className="bg-amber-900/30 px-3 py-2 rounded-lg text-center w-full">
                        <p className="text-xs text-gray-400">{language === 'ar' ? 'إجمالي البند' : 'Item Total'}</p>
                        <p className="text-amber-300 font-bold">{((item.materialPrice + item.laborPrice) * item.quantity).toLocaleString()} {costCurrency}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* زر الحساب */}
            <button
              onClick={calculateCost}
              className="w-full py-4 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold text-lg transition flex items-center justify-center gap-2"
              data-testid="button-calculate-cost"
            >
              <Calculator className="w-6 h-6" />
              {language === 'ar' ? 'حساب التكلفة الإجمالية' : 'Calculate Total Cost'}
            </button>

            {/* النتائج */}
            {costResult && (
              <div className="space-y-4 mt-6">
                {/* ملخص إجمالي */}
                <div className="bg-gradient-to-r from-amber-900/40 to-orange-900/40 p-5 rounded-xl border border-amber-500/40">
                  <h3 className="text-xl font-bold text-white mb-4 text-center">💰 {language === 'ar' ? 'ملخص التكلفة' : 'Cost Summary'}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'تكلفة المواد' : 'Materials'}</p>
                      <p className="text-2xl font-bold text-blue-300">{costResult.totalMaterial.toLocaleString()}</p>
                      <p className="text-gray-400">{costCurrency}</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'تكلفة العمالة' : 'Labor'}</p>
                      <p className="text-2xl font-bold text-green-300">{costResult.totalLabor.toLocaleString()}</p>
                      <p className="text-gray-400">{costCurrency}</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'إجمالي مباشر' : 'Direct Total'}</p>
                      <p className="text-2xl font-bold text-yellow-300">{costResult.grandTotal.toLocaleString()}</p>
                      <p className="text-gray-400">{costCurrency}</p>
                    </div>
                  </div>
                  
                  <div className="border-t border-white/20 pt-4 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">{language === 'ar' ? 'مصاريف إدارية' : 'Overhead'} ({costSettings.overheadPercent}%)</span>
                      <span className="text-white">{costResult.overhead.toLocaleString()} {costCurrency}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">{language === 'ar' ? 'أرباح' : 'Profit'} ({costSettings.profitPercent}%)</span>
                      <span className="text-white">{costResult.profit.toLocaleString()} {costCurrency}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">{language === 'ar' ? 'احتياطي' : 'Contingency'} ({costSettings.contingency}%)</span>
                      <span className="text-white">{(costResult.grandTotal * costSettings.contingency / 100).toLocaleString()} {costCurrency}</span>
                    </div>
                    <div className="flex justify-between text-lg font-bold pt-2 border-t border-white/20">
                      <span className="text-amber-300">{language === 'ar' ? 'الإجمالي النهائي' : 'Final Total'}</span>
                      <span className="text-amber-300">{costResult.finalTotal.toLocaleString()} {costCurrency}</span>
                    </div>
                  </div>
                </div>

                {/* جدول التفاصيل */}
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                  <h3 className="text-white font-semibold mb-3">📊 {language === 'ar' ? 'تفاصيل البنود' : 'Item Details'}</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-white/10">
                          <th className="py-2 px-3 text-right text-gray-300">{language === 'ar' ? 'الفئة' : 'Category'}</th>
                          <th className="py-2 px-3 text-right text-gray-300">{language === 'ar' ? 'البند' : 'Item'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'الكمية' : 'Qty'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'مواد' : 'Material'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'عمالة' : 'Labor'}</th>
                          <th className="py-2 px-3 text-center text-gray-300">{language === 'ar' ? 'الإجمالي' : 'Total'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {costResult.breakdown.map((item, idx) => (
                          <tr key={idx} className="border-t border-white/10">
                            <td className="py-2 px-3 text-gray-400">{item.category}</td>
                            <td className="py-2 px-3 text-white">{item.item}</td>
                            <td className="py-2 px-3 text-center text-gray-300">{item.quantity} {item.unit}</td>
                            <td className="py-2 px-3 text-center text-blue-300">{item.materialCost.toLocaleString()}</td>
                            <td className="py-2 px-3 text-center text-green-300">{item.laborCost.toLocaleString()}</td>
                            <td className="py-2 px-3 text-center text-amber-300 font-semibold">{item.total.toLocaleString()}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* زر التصدير */}
                <button
                  onClick={() => {
                    const report = `تقرير تقدير التكلفة
=====================================
التاريخ: ${new Date().toLocaleString('ar-EG')}
العملة: ${costCurrency}

الإعدادات:
- مصاريف إدارية: ${costSettings.overheadPercent}%
- أرباح: ${costSettings.profitPercent}%
- احتياطي: ${costSettings.contingency}%

تفاصيل البنود:
${costResult.breakdown.map(i => `- ${i.category} | ${i.item}: ${i.quantity} ${i.unit} = ${i.total.toLocaleString()} ${costCurrency}`).join('\n')}

الملخص:
- تكلفة المواد: ${costResult.totalMaterial.toLocaleString()} ${costCurrency}
- تكلفة العمالة: ${costResult.totalLabor.toLocaleString()} ${costCurrency}
- إجمالي مباشر: ${costResult.grandTotal.toLocaleString()} ${costCurrency}
- مصاريف إدارية: ${costResult.overhead.toLocaleString()} ${costCurrency}
- أرباح: ${costResult.profit.toLocaleString()} ${costCurrency}
- الإجمالي النهائي: ${costResult.finalTotal.toLocaleString()} ${costCurrency}
`;
                    const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'cost-estimate-report.txt';
                    a.click();
                    toast.success(language === 'ar' ? '✓ تم تصدير التقرير' : '✓ Report exported');
                  }}
                  className="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2"
                  data-testid="button-export-cost"
                >
                  <Download className="w-5 h-5" />
                  {language === 'ar' ? 'تصدير التقرير' : 'Export Report'}
                </button>
              </div>
            )}
          </div>
        )}

        {calcType === "brick" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">🧱 {language === 'ar' ? 'حاسبة كميات الطوب والبلوك' : 'Brick & Block Calculator'}</h2>
            
            {/* اختيار نوع الطوب */}
            <div className="bg-gradient-to-r from-orange-900/40 to-red-900/40 p-4 rounded-xl border border-orange-500/30 mb-4">
              <h3 className="text-white font-semibold mb-3">📦 {language === 'ar' ? 'نوع الطوب' : 'Brick Type'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                {Object.entries(brickTypes).map(([key, bt]) => (
                  <button
                    key={key}
                    onClick={() => setBrickType(key as BrickType)}
                    className={`p-3 rounded-lg text-center transition ${
                      brickType === key 
                        ? 'bg-orange-600 text-white' 
                        : 'bg-white/10 text-gray-300 hover:bg-white/20'
                    }`}
                    data-testid={`button-brick-type-${key}`}
                  >
                    <span className="text-lg">{language === 'ar' ? bt.ar : bt.en}</span>
                    <p className="text-xs mt-1">{bt.length}×{bt.width}×{bt.height} cm</p>
                  </button>
                ))}
              </div>
            </div>

            {/* أبعاد الحائط */}
            <div className="bg-white/5 p-4 rounded-xl border border-white/10">
              <h3 className="text-white font-semibold mb-3">📐 {language === 'ar' ? 'أبعاد الحائط' : 'Wall Dimensions'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'طول الحائط (م)' : 'Wall Length (m)'}</Label>
                  <Input
                    type="number"
                    step="0.1"
                    value={brickInputs.wallLength}
                    onChange={(e) => setBrickInputs({...brickInputs, wallLength: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white"
                    data-testid="input-brick-wall-length"
                  />
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'ارتفاع الحائط (م)' : 'Wall Height (m)'}</Label>
                  <Input
                    type="number"
                    step="0.1"
                    value={brickInputs.wallHeight}
                    onChange={(e) => setBrickInputs({...brickInputs, wallHeight: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white"
                    data-testid="input-brick-wall-height"
                  />
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'سمك الحائط (سم)' : 'Wall Thickness (cm)'}</Label>
                  <Input
                    type="number"
                    value={brickInputs.wallThickness}
                    onChange={(e) => setBrickInputs({...brickInputs, wallThickness: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white"
                    data-testid="input-brick-wall-thickness"
                  />
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'سمك المونة (سم)' : 'Mortar (cm)'}</Label>
                  <Input
                    type="number"
                    step="0.1"
                    value={brickInputs.mortarThickness}
                    onChange={(e) => setBrickInputs({...brickInputs, mortarThickness: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white"
                    data-testid="input-brick-mortar"
                  />
                </div>
              </div>
            </div>

            {/* الفتحات */}
            <div className="bg-white/5 p-4 rounded-xl border border-white/10">
              <h3 className="text-white font-semibold mb-3">🚪 {language === 'ar' ? 'الفتحات (أبواب/نوافذ)' : 'Openings (Doors/Windows)'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عدد الفتحات' : 'Number of Openings'}</Label>
                  <Input
                    type="number"
                    value={brickInputs.openingsCount}
                    onChange={(e) => setBrickInputs({...brickInputs, openingsCount: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white"
                    data-testid="input-brick-openings-count"
                  />
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عرض الفتحة (م)' : 'Opening Width (m)'}</Label>
                  <Input
                    type="number"
                    step="0.1"
                    value={brickInputs.openingWidth}
                    onChange={(e) => setBrickInputs({...brickInputs, openingWidth: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white"
                    data-testid="input-brick-opening-width"
                  />
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'ارتفاع الفتحة (م)' : 'Opening Height (m)'}</Label>
                  <Input
                    type="number"
                    step="0.1"
                    value={brickInputs.openingHeight}
                    onChange={(e) => setBrickInputs({...brickInputs, openingHeight: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white"
                    data-testid="input-brick-opening-height"
                  />
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'نسبة الهالك %' : 'Wastage %'}</Label>
                  <Input
                    type="number"
                    value={brickInputs.wastagePercent}
                    onChange={(e) => setBrickInputs({...brickInputs, wastagePercent: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white"
                    data-testid="input-brick-wastage"
                  />
                </div>
              </div>
            </div>

            {/* زر الحساب */}
            <button
              onClick={calculateBrick}
              className="w-full py-4 bg-orange-600 hover:bg-orange-700 text-white rounded-xl font-bold text-lg transition flex items-center justify-center gap-2"
              data-testid="button-calculate-brick"
            >
              <Calculator className="w-6 h-6" />
              {language === 'ar' ? 'حساب الكميات' : 'Calculate Quantities'}
            </button>

            {/* النتائج */}
            {brickResult && (
              <div className="space-y-4 mt-6">
                {/* ملخص المساحات */}
                <div className="bg-gradient-to-r from-orange-900/40 to-red-900/40 p-5 rounded-xl border border-orange-500/40">
                  <h3 className="text-xl font-bold text-white mb-4 text-center">📊 {language === 'ar' ? 'نتائج الحساب' : 'Calculation Results'}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'المساحة الإجمالية' : 'Gross Area'}</p>
                      <p className="text-2xl font-bold text-white">{brickResult.grossArea.toFixed(1)}</p>
                      <p className="text-gray-400">m²</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'مساحة الفتحات' : 'Openings'}</p>
                      <p className="text-2xl font-bold text-red-300">{brickResult.openingsArea.toFixed(1)}</p>
                      <p className="text-gray-400">m²</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'المساحة الصافية' : 'Net Area'}</p>
                      <p className="text-2xl font-bold text-green-300">{brickResult.netArea.toFixed(1)}</p>
                      <p className="text-gray-400">m²</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'عدد الطوب' : 'Bricks'}</p>
                      <p className="text-2xl font-bold text-orange-300">{brickResult.bricksWithWastage.toLocaleString()}</p>
                      <p className="text-gray-400">{language === 'ar' ? 'وحدة' : 'pcs'}</p>
                    </div>
                  </div>
                </div>

                {/* كميات المواد */}
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                  <h3 className="text-white font-semibold mb-3">🏗️ {language === 'ar' ? 'كميات المواد المطلوبة' : 'Required Materials'}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-orange-900/30 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'الطوب (صافي)' : 'Bricks (Net)'}</p>
                      <p className="text-xl font-bold text-orange-300">{brickResult.bricksNeeded.toLocaleString()}</p>
                    </div>
                    <div className="bg-orange-900/30 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'مع الهالك' : 'With Wastage'}</p>
                      <p className="text-xl font-bold text-orange-300">{brickResult.bricksWithWastage.toLocaleString()}</p>
                    </div>
                    <div className="bg-gray-900/30 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'أسمنت (أكياس)' : 'Cement (bags)'}</p>
                      <p className="text-xl font-bold text-gray-300">{brickResult.cementBags}</p>
                    </div>
                    <div className="bg-yellow-900/30 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'رمل (م³)' : 'Sand (m³)'}</p>
                      <p className="text-xl font-bold text-yellow-300">{brickResult.sandVolume.toFixed(2)}</p>
                    </div>
                  </div>
                </div>

                {/* التكلفة والعمالة */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-green-900/30 p-4 rounded-xl text-center">
                    <p className="text-gray-400 text-sm">{language === 'ar' ? 'التكلفة التقديرية' : 'Estimated Cost'}</p>
                    <p className="text-2xl font-bold text-green-300">{brickResult.estimatedCost.toLocaleString()}</p>
                    <p className="text-gray-400">{language === 'ar' ? 'جنيه' : 'EGP'}</p>
                  </div>
                  <div className="bg-blue-900/30 p-4 rounded-xl text-center">
                    <p className="text-gray-400 text-sm">{language === 'ar' ? 'أيام العمل' : 'Labor Days'}</p>
                    <p className="text-2xl font-bold text-blue-300">{brickResult.laborDays.toFixed(1)}</p>
                    <p className="text-gray-400">{language === 'ar' ? 'يوم' : 'days'}</p>
                  </div>
                </div>

                {/* زر التصدير */}
                <button
                  onClick={() => {
                    const bt = brickTypes[brickType];
                    const report = `تقرير حساب كميات الطوب
=====================================
التاريخ: ${new Date().toLocaleString('ar-EG')}

نوع الطوب: ${language === 'ar' ? bt.ar : bt.en}
أبعاد الطوبة: ${bt.length}×${bt.width}×${bt.height} سم

أبعاد الحائط:
- الطول: ${brickInputs.wallLength} م
- الارتفاع: ${brickInputs.wallHeight} م
- السمك: ${brickInputs.wallThickness} سم

الفتحات:
- العدد: ${brickInputs.openingsCount}
- أبعاد الفتحة: ${brickInputs.openingWidth}×${brickInputs.openingHeight} م

النتائج:
- المساحة الإجمالية: ${brickResult.grossArea.toFixed(2)} م²
- مساحة الفتحات: ${brickResult.openingsArea.toFixed(2)} م²
- المساحة الصافية: ${brickResult.netArea.toFixed(2)} م²
- عدد الطوب (صافي): ${brickResult.bricksNeeded.toLocaleString()} وحدة
- عدد الطوب (مع ${brickInputs.wastagePercent}% هالك): ${brickResult.bricksWithWastage.toLocaleString()} وحدة

المواد المطلوبة:
- أسمنت: ${brickResult.cementBags} كيس
- رمل: ${brickResult.sandVolume.toFixed(2)} م³
- مونة: ${brickResult.mortarVolume.toFixed(2)} م³

التكلفة والعمالة:
- التكلفة التقديرية: ${brickResult.estimatedCost.toLocaleString()} جنيه
- أيام العمل: ${brickResult.laborDays.toFixed(1)} يوم
`;
                    const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'brick-calculation-report.txt';
                    a.click();
                    toast.success(language === 'ar' ? '✓ تم تصدير التقرير' : '✓ Report exported');
                  }}
                  className="flex-1 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2"
                  data-testid="button-export-brick"
                >
                  <Download className="w-5 h-5" />
                  TXT
                </button>
                <button
                  onClick={() => {
                    generateBrickPDF(brickResult, brickInputs, brickTypes[brickType], language);
                    toast.success(language === 'ar' ? '✓ تم تصدير PDF' : '✓ PDF exported');
                  }}
                  className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2"
                  data-testid="button-export-brick-pdf"
                >
                  <FileText className="w-5 h-5" />
                  PDF
                </button>
              </div>
            )}
          </div>
        )}

        {/* Paint Calculator */}
        {calcType === "paint" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">🎨 {language === 'ar' ? 'حاسبة الدهانات' : 'Paint Calculator'}</h2>
            
            {/* اختيار نوع الدهان */}
            <div className="bg-gradient-to-r from-pink-900/40 to-purple-900/40 p-4 rounded-xl border border-pink-500/30 mb-4">
              <h3 className="text-white font-semibold mb-3">🎨 {language === 'ar' ? 'نوع الدهان' : 'Paint Type'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                {Object.entries(paintTypes).map(([key, pt]) => (
                  <button key={key} onClick={() => setPaintType(key as PaintType)}
                    className={`p-3 rounded-lg text-center transition ${paintType === key ? 'bg-pink-600 text-white' : 'bg-white/10 text-gray-300 hover:bg-white/20'}`}
                    data-testid={`button-paint-type-${key}`}>
                    <span className="text-lg">{language === 'ar' ? pt.ar : pt.en}</span>
                    <p className="text-xs mt-1">{pt.coverage} m²/L</p>
                  </button>
                ))}
              </div>
            </div>

            {/* أبعاد الغرفة */}
            <div className="bg-white/5 p-4 rounded-xl border border-white/10">
              <h3 className="text-white font-semibold mb-3">📐 {language === 'ar' ? 'أبعاد الغرفة' : 'Room Dimensions'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'طول الغرفة (م)' : 'Room Length (m)'}</Label>
                  <Input type="number" step="0.1" value={paintInputs.wallLength}
                    onChange={(e) => setPaintInputs({...paintInputs, wallLength: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-paint-length"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'ارتفاع الجدران (م)' : 'Wall Height (m)'}</Label>
                  <Input type="number" step="0.1" value={paintInputs.wallHeight}
                    onChange={(e) => setPaintInputs({...paintInputs, wallHeight: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-paint-height"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عدد الوجوه' : 'Coats'}</Label>
                  <Input type="number" value={paintInputs.coats}
                    onChange={(e) => setPaintInputs({...paintInputs, coats: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-paint-coats"/>
                </div>
                <div className="flex items-center gap-2">
                  <input type="checkbox" checked={paintInputs.includePutty}
                    onChange={(e) => setPaintInputs({...paintInputs, includePutty: e.target.checked})}
                    className="w-5 h-5" data-testid="input-paint-putty"/>
                  <Label className="text-gray-400 text-sm">{language === 'ar' ? 'شامل المعجون' : 'Include Putty'}</Label>
                </div>
              </div>
            </div>

            {/* الأبواب والنوافذ */}
            <div className="bg-white/5 p-4 rounded-xl border border-white/10">
              <h3 className="text-white font-semibold mb-3">🚪 {language === 'ar' ? 'الفتحات' : 'Openings'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عدد الأبواب' : 'Doors'}</Label>
                  <Input type="number" value={paintInputs.doorsCount}
                    onChange={(e) => setPaintInputs({...paintInputs, doorsCount: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-paint-doors"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عرض الباب' : 'Door W'}</Label>
                  <Input type="number" step="0.1" value={paintInputs.doorWidth}
                    onChange={(e) => setPaintInputs({...paintInputs, doorWidth: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-paint-door-w"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'ارتفاع الباب' : 'Door H'}</Label>
                  <Input type="number" step="0.1" value={paintInputs.doorHeight}
                    onChange={(e) => setPaintInputs({...paintInputs, doorHeight: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-paint-door-h"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عدد النوافذ' : 'Windows'}</Label>
                  <Input type="number" value={paintInputs.windowsCount}
                    onChange={(e) => setPaintInputs({...paintInputs, windowsCount: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-paint-windows"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عرض النافذة' : 'Win W'}</Label>
                  <Input type="number" step="0.1" value={paintInputs.windowWidth}
                    onChange={(e) => setPaintInputs({...paintInputs, windowWidth: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-paint-win-w"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'ارتفاع النافذة' : 'Win H'}</Label>
                  <Input type="number" step="0.1" value={paintInputs.windowHeight}
                    onChange={(e) => setPaintInputs({...paintInputs, windowHeight: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-paint-win-h"/>
                </div>
              </div>
            </div>

            <button onClick={calculatePaint}
              className="w-full py-4 bg-pink-600 hover:bg-pink-700 text-white rounded-xl font-bold text-lg transition flex items-center justify-center gap-2"
              data-testid="button-calculate-paint">
              <Calculator className="w-6 h-6" />
              {language === 'ar' ? 'حساب الكميات' : 'Calculate'}
            </button>

            {paintResult && (
              <div className="space-y-4 mt-6">
                <div className="bg-gradient-to-r from-pink-900/40 to-purple-900/40 p-5 rounded-xl border border-pink-500/40">
                  <h3 className="text-xl font-bold text-white mb-4 text-center">📊 {language === 'ar' ? 'النتائج' : 'Results'}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'المساحة الإجمالية' : 'Gross Area'}</p>
                      <p className="text-2xl font-bold text-white" data-testid="text-paint-gross">{paintResult.grossArea.toFixed(1)}</p>
                      <p className="text-gray-400">m²</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'الخصومات' : 'Deductions'}</p>
                      <p className="text-2xl font-bold text-red-300" data-testid="text-paint-deduct">{paintResult.deductions.toFixed(1)}</p>
                      <p className="text-gray-400">m²</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'المساحة الصافية' : 'Net Area'}</p>
                      <p className="text-2xl font-bold text-green-300" data-testid="text-paint-net">{paintResult.netArea.toFixed(1)}</p>
                      <p className="text-gray-400">m²</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'كمية الدهان' : 'Paint'}</p>
                      <p className="text-2xl font-bold text-pink-300" data-testid="text-paint-liters">{paintResult.paintLiters.toFixed(1)}</p>
                      <p className="text-gray-400">L ({paintResult.paintBuckets} {language === 'ar' ? 'جردل' : 'buckets'})</p>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-yellow-900/30 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-xs">{language === 'ar' ? 'معجون' : 'Putty'}</p>
                    <p className="text-xl font-bold text-yellow-300">{paintResult.puttyKg.toFixed(1)} kg</p>
                  </div>
                  <div className="bg-blue-900/30 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-xs">{language === 'ar' ? 'برايمر' : 'Primer'}</p>
                    <p className="text-xl font-bold text-blue-300">{paintResult.primerLiters.toFixed(1)} L</p>
                  </div>
                  <div className="bg-green-900/30 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-xs">{language === 'ar' ? 'التكلفة' : 'Cost'}</p>
                    <p className="text-xl font-bold text-green-300">{paintResult.estimatedCost.toLocaleString()}</p>
                  </div>
                  <div className="bg-purple-900/30 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-xs">{language === 'ar' ? 'أيام العمل' : 'Labor'}</p>
                    <p className="text-xl font-bold text-purple-300">{paintResult.laborDays.toFixed(1)}</p>
                  </div>
                </div>
                <button onClick={() => {
                  const report = `تقرير حساب الدهانات\n${'='.repeat(40)}\nالتاريخ: ${new Date().toLocaleString('ar-EG')}\n\nنوع الدهان: ${language === 'ar' ? paintTypes[paintType].ar : paintTypes[paintType].en}\n\nأبعاد الغرفة:\n- الطول: ${paintInputs.wallLength} م\n- الارتفاع: ${paintInputs.wallHeight} م\n- عدد الوجوه: ${paintInputs.coats}\n\nالفتحات:\n- الأبواب: ${paintInputs.doorsCount} (${paintInputs.doorWidth}×${paintInputs.doorHeight} م)\n- النوافذ: ${paintInputs.windowsCount} (${paintInputs.windowWidth}×${paintInputs.windowHeight} م)\n\nالنتائج:\n- المساحة الإجمالية: ${paintResult.grossArea.toFixed(2)} م²\n- الخصومات: ${paintResult.deductions.toFixed(2)} م²\n- المساحة الصافية: ${paintResult.netArea.toFixed(2)} م²\n- كمية الدهان: ${paintResult.paintLiters.toFixed(1)} لتر (${paintResult.paintBuckets} جردل)\n- المعجون: ${paintResult.puttyKg.toFixed(1)} كجم\n- البرايمر: ${paintResult.primerLiters.toFixed(1)} لتر\n\nالتكلفة: ${paintResult.estimatedCost.toLocaleString()} جنيه\nأيام العمل: ${paintResult.laborDays.toFixed(1)} يوم`;
                  const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a'); a.href = url; a.download = 'paint-report.txt'; a.click();
                  toast.success(language === 'ar' ? '✓ تم التصدير' : '✓ Exported');
                }} className="flex-1 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2" data-testid="button-export-paint">
                  <Download className="w-5 h-5" />TXT
                </button>
                <button onClick={() => {
                  generatePaintPDF(paintResult, paintInputs, paintTypes[paintType], language);
                  toast.success(language === 'ar' ? '✓ تم تصدير PDF' : '✓ PDF exported');
                }} className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2" data-testid="button-export-paint-pdf">
                  <FileText className="w-5 h-5" />PDF
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tiles Calculator */}
        {calcType === "tiles" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">🔲 {language === 'ar' ? 'حاسبة البلاط والسيراميك' : 'Tiles Calculator'}</h2>
            
            <div className="bg-gradient-to-r from-cyan-900/40 to-blue-900/40 p-4 rounded-xl border border-cyan-500/30 mb-4">
              <h3 className="text-white font-semibold mb-3">📦 {language === 'ar' ? 'نوع البلاط' : 'Tile Type'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                {Object.entries(tileTypes).map(([key, tt]) => (
                  <button key={key} onClick={() => setTileType(key as TileType)}
                    className={`p-3 rounded-lg text-center transition ${tileType === key ? 'bg-cyan-600 text-white' : 'bg-white/10 text-gray-300 hover:bg-white/20'}`}
                    data-testid={`button-tile-type-${key}`}>
                    <span className="text-lg">{language === 'ar' ? tt.ar : tt.en}</span>
                    <p className="text-xs mt-1">{tt.pricePerM2} EGP/m²</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-white/5 p-4 rounded-xl border border-white/10">
              <h3 className="text-white font-semibold mb-3">📐 {language === 'ar' ? 'أبعاد الغرفة والبلاطة' : 'Dimensions'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'طول الغرفة (م)' : 'Room L (m)'}</Label>
                  <Input type="number" step="0.1" value={tilesInputs.roomLength}
                    onChange={(e) => setTilesInputs({...tilesInputs, roomLength: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-tiles-room-l"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عرض الغرفة (م)' : 'Room W (m)'}</Label>
                  <Input type="number" step="0.1" value={tilesInputs.roomWidth}
                    onChange={(e) => setTilesInputs({...tilesInputs, roomWidth: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-tiles-room-w"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'طول البلاطة (سم)' : 'Tile L (cm)'}</Label>
                  <Input type="number" value={tilesInputs.tileLength}
                    onChange={(e) => setTilesInputs({...tilesInputs, tileLength: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-tiles-tile-l"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عرض البلاطة (سم)' : 'Tile W (cm)'}</Label>
                  <Input type="number" value={tilesInputs.tileWidth}
                    onChange={(e) => setTilesInputs({...tilesInputs, tileWidth: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-tiles-tile-w"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'الفاصل (مم)' : 'Joint (mm)'}</Label>
                  <Input type="number" value={tilesInputs.jointWidth}
                    onChange={(e) => setTilesInputs({...tilesInputs, jointWidth: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-tiles-joint"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'الهالك %' : 'Wastage %'}</Label>
                  <Input type="number" value={tilesInputs.wastagePercent}
                    onChange={(e) => setTilesInputs({...tilesInputs, wastagePercent: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-tiles-waste"/>
                </div>
              </div>
            </div>

            <button onClick={calculateTiles}
              className="w-full py-4 bg-cyan-600 hover:bg-cyan-700 text-white rounded-xl font-bold text-lg transition flex items-center justify-center gap-2"
              data-testid="button-calculate-tiles">
              <Calculator className="w-6 h-6" />{language === 'ar' ? 'حساب الكميات' : 'Calculate'}
            </button>

            {tilesResult && (
              <div className="space-y-4 mt-6">
                <div className="bg-gradient-to-r from-cyan-900/40 to-blue-900/40 p-5 rounded-xl border border-cyan-500/40">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'مساحة الأرضية' : 'Floor Area'}</p>
                      <p className="text-2xl font-bold text-white" data-testid="text-tiles-area">{tilesResult.floorArea.toFixed(1)}</p>
                      <p className="text-gray-400">m²</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'عدد البلاط' : 'Tiles'}</p>
                      <p className="text-2xl font-bold text-cyan-300" data-testid="text-tiles-count">{tilesResult.tilesWithWastage}</p>
                      <p className="text-gray-400">{language === 'ar' ? 'قطعة' : 'pcs'}</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'عدد الكراتين' : 'Boxes'}</p>
                      <p className="text-2xl font-bold text-blue-300" data-testid="text-tiles-boxes">{tilesResult.boxesNeeded}</p>
                      <p className="text-gray-400">{language === 'ar' ? 'كرتونة' : 'boxes'}</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'التكلفة' : 'Cost'}</p>
                      <p className="text-2xl font-bold text-green-300" data-testid="text-tiles-cost">{tilesResult.estimatedCost.toLocaleString()}</p>
                      <p className="text-gray-400">EGP</p>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-900/30 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-xs">{language === 'ar' ? 'لاصق' : 'Adhesive'}</p>
                    <p className="text-xl font-bold text-gray-300">{tilesResult.adhesiveKg.toFixed(0)} kg</p>
                  </div>
                  <div className="bg-yellow-900/30 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-xs">{language === 'ar' ? 'روبة' : 'Grout'}</p>
                    <p className="text-xl font-bold text-yellow-300">{tilesResult.groutKg.toFixed(1)} kg</p>
                  </div>
                </div>
                <button onClick={() => {
                  const report = `تقرير حساب البلاط\n${'='.repeat(40)}\nالتاريخ: ${new Date().toLocaleString('ar-EG')}\n\nنوع البلاط: ${language === 'ar' ? tileTypes[tileType].ar : tileTypes[tileType].en}\n\nأبعاد الغرفة: ${tilesInputs.roomLength}×${tilesInputs.roomWidth} م\nأبعاد البلاطة: ${tilesInputs.tileLength}×${tilesInputs.tileWidth} سم\n\nالنتائج:\n- مساحة الأرضية: ${tilesResult.floorArea.toFixed(2)} م²\n- عدد البلاط (صافي): ${tilesResult.tilesNeeded} قطعة\n- مع الهالك ${tilesInputs.wastagePercent}%: ${tilesResult.tilesWithWastage} قطعة\n- عدد الكراتين: ${tilesResult.boxesNeeded} كرتونة\n- اللاصق: ${tilesResult.adhesiveKg.toFixed(0)} كجم\n- الروبة: ${tilesResult.groutKg.toFixed(1)} كجم\n\nالتكلفة التقديرية: ${tilesResult.estimatedCost.toLocaleString()} جنيه`;
                  const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
                  const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'tiles-report.txt'; a.click();
                  toast.success(language === 'ar' ? '✓ تم التصدير' : '✓ Exported');
                }} className="flex-1 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2" data-testid="button-export-tiles">
                  <Download className="w-5 h-5" />TXT
                </button>
                <button onClick={() => {
                  generateTilesPDF(tilesResult, tilesInputs, tileTypes[tileType], language);
                  toast.success(language === 'ar' ? '✓ تم تصدير PDF' : '✓ PDF exported');
                }} className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2" data-testid="button-export-tiles-pdf">
                  <FileText className="w-5 h-5" />PDF
                </button>
              </div>
            )}
          </div>
        )}

        {/* Stairs Calculator */}
        {calcType === "stairs" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">🪜 {language === 'ar' ? 'حاسبة تصميم السلالم' : 'Stairs Design Calculator'}</h2>
            
            <div className="bg-gradient-to-r from-amber-900/40 to-orange-900/40 p-4 rounded-xl border border-amber-500/30">
              <h3 className="text-white font-semibold mb-3">📐 {language === 'ar' ? 'مدخلات التصميم' : 'Design Inputs'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'الارتفاع الكلي (م)' : 'Total Height (m)'}</Label>
                  <Input type="number" step="0.1" value={stairsInputs.totalHeight}
                    onChange={(e) => setStairsInputs({...stairsInputs, totalHeight: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-stairs-height"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عرض السلم (م)' : 'Stair Width (m)'}</Label>
                  <Input type="number" step="0.1" value={stairsInputs.stairWidth}
                    onChange={(e) => setStairsInputs({...stairsInputs, stairWidth: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-stairs-width"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'ارتفاع القائمة (سم)' : 'Riser (cm)'}</Label>
                  <Input type="number" value={stairsInputs.riserHeight}
                    onChange={(e) => setStairsInputs({...stairsInputs, riserHeight: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-stairs-riser"/>
                  <p className="text-xs text-gray-500 mt-1">{language === 'ar' ? '(15-18 سم)' : '(15-18 cm)'}</p>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عمق النائمة (سم)' : 'Tread (cm)'}</Label>
                  <Input type="number" value={stairsInputs.treadDepth}
                    onChange={(e) => setStairsInputs({...stairsInputs, treadDepth: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-stairs-tread"/>
                  <p className="text-xs text-gray-500 mt-1">{language === 'ar' ? '(25-30 سم)' : '(25-30 cm)'}</p>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'طول البسطة (م)' : 'Landing (m)'}</Label>
                  <Input type="number" step="0.1" value={stairsInputs.floorLength}
                    onChange={(e) => setStairsInputs({...stairsInputs, floorLength: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-stairs-landing"/>
                </div>
              </div>
            </div>

            <button onClick={calculateStairs}
              className="w-full py-4 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold text-lg transition flex items-center justify-center gap-2"
              data-testid="button-calculate-stairs">
              <Calculator className="w-6 h-6" />{language === 'ar' ? 'حساب السلم' : 'Calculate Stairs'}
            </button>

            {stairsResult && (
              <div className="space-y-4 mt-6">
                <div className={`p-4 rounded-xl border ${stairsResult.isComfortable ? 'bg-green-900/30 border-green-500/40' : 'bg-red-900/30 border-red-500/40'}`}>
                  <p className="text-center font-bold text-lg">
                    {stairsResult.isComfortable 
                      ? (language === 'ar' ? '✅ تصميم مريح' : '✅ Comfortable Design')
                      : (language === 'ar' ? '⚠️ تصميم غير مريح - راجع الأبعاد' : '⚠️ Uncomfortable - Review dimensions')}
                  </p>
                  <p className="text-center text-sm text-gray-400">
                    2R + T = {((2 * stairsResult.actualRiserHeight) + stairsInputs.treadDepth).toFixed(1)} cm 
                    ({language === 'ar' ? 'المثالي: 60-65 سم' : 'Ideal: 60-65 cm'})
                  </p>
                </div>

                <div className="bg-gradient-to-r from-amber-900/40 to-orange-900/40 p-5 rounded-xl border border-amber-500/40">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'عدد القوائم' : 'Risers'}</p>
                      <p className="text-2xl font-bold text-white" data-testid="text-stairs-risers">{stairsResult.numberOfRisers}</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'عدد النوائم' : 'Treads'}</p>
                      <p className="text-2xl font-bold text-amber-300" data-testid="text-stairs-treads">{stairsResult.numberOfTreads}</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'ارتفاع القائمة الفعلي' : 'Actual Riser'}</p>
                      <p className="text-2xl font-bold text-orange-300">{stairsResult.actualRiserHeight.toFixed(1)}</p>
                      <p className="text-gray-400">cm</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'زاوية الميل' : 'Angle'}</p>
                      <p className="text-2xl font-bold text-yellow-300">{stairsResult.stairAngle.toFixed(1)}°</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="bg-blue-900/30 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-xs">{language === 'ar' ? 'الطول الأفقي' : 'Run Length'}</p>
                    <p className="text-xl font-bold text-blue-300">{stairsResult.totalRunLength.toFixed(2)} m</p>
                  </div>
                  <div className="bg-gray-900/30 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-xs">{language === 'ar' ? 'حجم الخرسانة' : 'Concrete'}</p>
                    <p className="text-xl font-bold text-gray-300">{stairsResult.concreteVolume.toFixed(2)} m³</p>
                  </div>
                  <div className="bg-red-900/30 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-xs">{language === 'ar' ? 'وزن الحديد' : 'Rebar'}</p>
                    <p className="text-xl font-bold text-red-300">{stairsResult.rebarWeight.toFixed(0)} kg</p>
                  </div>
                </div>

                <button onClick={() => {
                  const report = `تقرير تصميم السلم\n${'='.repeat(40)}\nالتاريخ: ${new Date().toLocaleString('ar-EG')}\n\nمدخلات التصميم:\n- الارتفاع الكلي: ${stairsInputs.totalHeight} م\n- عرض السلم: ${stairsInputs.stairWidth} م\n- ارتفاع القائمة المطلوب: ${stairsInputs.riserHeight} سم\n- عمق النائمة: ${stairsInputs.treadDepth} سم\n\nالنتائج:\n- عدد القوائم: ${stairsResult.numberOfRisers}\n- عدد النوائم: ${stairsResult.numberOfTreads}\n- ارتفاع القائمة الفعلي: ${stairsResult.actualRiserHeight.toFixed(1)} سم\n- زاوية الميل: ${stairsResult.stairAngle.toFixed(1)}°\n- الطول الأفقي: ${stairsResult.totalRunLength.toFixed(2)} م\n\nمعادلة الراحة (2R+T): ${((2*stairsResult.actualRiserHeight)+stairsInputs.treadDepth).toFixed(1)} سم\nالتقييم: ${stairsResult.isComfortable ? 'تصميم مريح ✅' : 'تصميم غير مريح ⚠️'}\n\nالكميات التقديرية:\n- الخرسانة: ${stairsResult.concreteVolume.toFixed(2)} م³\n- الحديد: ${stairsResult.rebarWeight.toFixed(0)} كجم`;
                  const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
                  const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'stairs-design.txt'; a.click();
                  toast.success(language === 'ar' ? '✓ تم التصدير' : '✓ Exported');
                }} className="flex-1 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2" data-testid="button-export-stairs">
                  <Download className="w-5 h-5" />TXT
                </button>
                <button onClick={() => {
                  generateStairsPDF(stairsResult, stairsInputs, language);
                  toast.success(language === 'ar' ? '✓ تم تصدير PDF' : '✓ PDF exported');
                }} className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2" data-testid="button-export-stairs-pdf">
                  <FileText className="w-5 h-5" />PDF
                </button>
              </div>
            )}
          </div>
        )}

        {/* Water Tank Calculator */}
        {calcType === "tank" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">💧 {language === 'ar' ? 'حاسبة خزانات المياه' : 'Water Tank Calculator'}</h2>
            
            <div className="bg-gradient-to-r from-blue-900/40 to-cyan-900/40 p-4 rounded-xl border border-blue-500/30">
              <h3 className="text-white font-semibold mb-3">🏠 {language === 'ar' ? 'بيانات المبنى' : 'Building Data'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عدد السكان' : 'Residents'}</Label>
                  <Input type="number" value={tankInputs.residents}
                    onChange={(e) => setTankInputs({...tankInputs, residents: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-tank-residents"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'الاستهلاك اليومي (لتر/فرد)' : 'Daily Use (L/person)'}</Label>
                  <Input type="number" value={tankInputs.dailyConsumption}
                    onChange={(e) => setTankInputs({...tankInputs, dailyConsumption: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-tank-consumption"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'أيام التخزين' : 'Storage Days'}</Label>
                  <Input type="number" value={tankInputs.storageDays}
                    onChange={(e) => setTankInputs({...tankInputs, storageDays: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-tank-days"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عدد الأدوار' : 'Floors'}</Label>
                  <Input type="number" value={tankInputs.buildingFloors}
                    onChange={(e) => setTankInputs({...tankInputs, buildingFloors: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-tank-floors"/>
                </div>
              </div>
              <div className="flex gap-6 mt-4">
                <label className="flex items-center gap-2 text-gray-300">
                  <input type="checkbox" checked={tankInputs.hasGarden}
                    onChange={(e) => setTankInputs({...tankInputs, hasGarden: e.target.checked})}
                    className="w-5 h-5" data-testid="input-tank-garden"/>
                  🌳 {language === 'ar' ? 'يوجد حديقة' : 'Has Garden'}
                </label>
                <label className="flex items-center gap-2 text-gray-300">
                  <input type="checkbox" checked={tankInputs.hasFire}
                    onChange={(e) => setTankInputs({...tankInputs, hasFire: e.target.checked})}
                    className="w-5 h-5" data-testid="input-tank-fire"/>
                  🔥 {language === 'ar' ? 'احتياطي حريق' : 'Fire Reserve'}
                </label>
              </div>
            </div>

            <button onClick={calculateTank}
              className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-lg transition flex items-center justify-center gap-2"
              data-testid="button-calculate-tank">
              <Calculator className="w-6 h-6" />{language === 'ar' ? 'حساب سعة الخزان' : 'Calculate Tank'}
            </button>

            {tankResult && (
              <div className="space-y-4 mt-6">
                <div className="bg-gradient-to-r from-blue-900/40 to-cyan-900/40 p-5 rounded-xl border border-blue-500/40">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'الاستهلاك اليومي' : 'Daily Demand'}</p>
                      <p className="text-2xl font-bold text-white" data-testid="text-tank-daily">{tankResult.dailyDemand.toLocaleString()}</p>
                      <p className="text-gray-400">L</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'السعة الكلية' : 'Total Capacity'}</p>
                      <p className="text-2xl font-bold text-blue-300" data-testid="text-tank-total">{tankResult.totalCapacity.toLocaleString()}</p>
                      <p className="text-gray-400">L</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'خزان أرضي' : 'Ground Tank'}</p>
                      <p className="text-2xl font-bold text-cyan-300">{tankResult.groundTankVolume.toLocaleString()}</p>
                      <p className="text-gray-400">L (70%)</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'خزان علوي' : 'Roof Tank'}</p>
                      <p className="text-2xl font-bold text-sky-300">{tankResult.roofTankVolume.toLocaleString()}</p>
                      <p className="text-gray-400">L (30%)</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                  <h3 className="text-white font-semibold mb-3">📐 {language === 'ar' ? 'أبعاد الخزان الأرضي المقترحة' : 'Suggested Ground Tank Dimensions'}</h3>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-blue-900/30 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'الطول' : 'Length'}</p>
                      <p className="text-xl font-bold text-blue-300">{tankResult.dimensions.length.toFixed(2)} m</p>
                    </div>
                    <div className="bg-blue-900/30 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'العرض' : 'Width'}</p>
                      <p className="text-xl font-bold text-blue-300">{tankResult.dimensions.width.toFixed(2)} m</p>
                    </div>
                    <div className="bg-blue-900/30 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'الارتفاع' : 'Height'}</p>
                      <p className="text-xl font-bold text-blue-300">{tankResult.dimensions.height.toFixed(2)} m</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-yellow-900/30 p-4 rounded-xl text-center">
                    <p className="text-gray-400 text-sm">{language === 'ar' ? 'قدرة المضخة' : 'Pump Power'}</p>
                    <p className="text-2xl font-bold text-yellow-300">{tankResult.pumpPower.toFixed(2)} kW</p>
                    <p className="text-gray-400">≈ {(tankResult.pumpPower * 1.34).toFixed(1)} HP</p>
                  </div>
                  <div className="bg-green-900/30 p-4 rounded-xl text-center">
                    <p className="text-gray-400 text-sm">{language === 'ar' ? 'التكلفة التقديرية' : 'Estimated Cost'}</p>
                    <p className="text-2xl font-bold text-green-300">{tankResult.estimatedCost.toLocaleString()}</p>
                    <p className="text-gray-400">EGP</p>
                  </div>
                </div>

                <button onClick={() => {
                  const report = `تقرير حساب خزان المياه\n${'='.repeat(40)}\nالتاريخ: ${new Date().toLocaleString('ar-EG')}\n\nبيانات المبنى:\n- عدد السكان: ${tankInputs.residents} فرد\n- الاستهلاك اليومي: ${tankInputs.dailyConsumption} لتر/فرد\n- أيام التخزين: ${tankInputs.storageDays} يوم\n- عدد الأدوار: ${tankInputs.buildingFloors}\n- حديقة: ${tankInputs.hasGarden ? 'نعم' : 'لا'}\n- احتياطي حريق: ${tankInputs.hasFire ? 'نعم' : 'لا'}\n\nالنتائج:\n- الاستهلاك اليومي الكلي: ${tankResult.dailyDemand.toLocaleString()} لتر\n- السعة الكلية المطلوبة: ${tankResult.totalCapacity.toLocaleString()} لتر\n- الخزان الأرضي (70%): ${tankResult.groundTankVolume.toLocaleString()} لتر\n- الخزان العلوي (30%): ${tankResult.roofTankVolume.toLocaleString()} لتر\n\nأبعاد الخزان الأرضي:\n- الطول: ${tankResult.dimensions.length.toFixed(2)} م\n- العرض: ${tankResult.dimensions.width.toFixed(2)} م\n- الارتفاع: ${tankResult.dimensions.height.toFixed(2)} م\n\nقدرة المضخة: ${tankResult.pumpPower.toFixed(2)} كيلوواط (${(tankResult.pumpPower*1.34).toFixed(1)} حصان)\nالتكلفة التقديرية: ${tankResult.estimatedCost.toLocaleString()} جنيه`;
                  const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
                  const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'water-tank-report.txt'; a.click();
                  toast.success(language === 'ar' ? '✓ تم التصدير' : '✓ Exported');
                }} className="flex-1 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2" data-testid="button-export-tank">
                  <Download className="w-5 h-5" />TXT
                </button>
                <button onClick={() => {
                  generateTankPDF(tankResult, tankInputs, language);
                  toast.success(language === 'ar' ? '✓ تم تصدير PDF' : '✓ PDF exported');
                }} className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2" data-testid="button-export-tank-pdf">
                  <FileText className="w-5 h-5" />PDF
                </button>
              </div>
            )}
          </div>
        )}

        {/* Sewage Network Simulator */}
        {calcType === "sewage" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">🌊 {language === 'ar' ? 'محاكاة شبكات الصرف الصحي' : 'Sewage Network Simulator'}</h2>
            
            {/* نوع الشبكة */}
            <div className="bg-gradient-to-r from-teal-900/40 to-cyan-900/40 p-4 rounded-xl border border-teal-500/30 mb-4">
              <h3 className="text-white font-semibold mb-3">🔧 {language === 'ar' ? 'نوع الشبكة' : 'Network Type'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {[
                  { id: 'gravity' as const, icon: '⬇️', ar: 'انحداري', en: 'Gravity' },
                  { id: 'pressure' as const, icon: '💨', ar: 'ضغط', en: 'Pressure' },
                  { id: 'vacuum' as const, icon: '🌀', ar: 'تفريغ', en: 'Vacuum' },
                  { id: 'combined' as const, icon: '🔄', ar: 'مشترك', en: 'Combined' }
                ].map((type) => (
                  <button key={type.id} onClick={() => setSewageType(type.id)}
                    className={`p-3 rounded-lg text-center transition ${sewageType === type.id ? 'bg-teal-600 text-white' : 'bg-white/10 text-gray-300 hover:bg-white/20'}`}
                    data-testid={`button-sewage-type-${type.id}`}>
                    <span className="text-2xl">{type.icon}</span>
                    <p className="text-sm mt-1">{language === 'ar' ? type.ar : type.en}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* بيانات السكان والتدفق */}
            <div className="bg-white/5 p-4 rounded-xl border border-white/10">
              <h3 className="text-white font-semibold mb-3">👥 {language === 'ar' ? 'بيانات السكان والتدفق' : 'Population & Flow Data'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عدد السكان' : 'Population'}</Label>
                  <Input type="number" value={sewageInputs.population}
                    onChange={(e) => setSewageInputs({...sewageInputs, population: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-sewage-population"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'معامل الذروة' : 'Peak Factor'}</Label>
                  <Input type="number" step="0.1" value={sewageInputs.peakFactor}
                    onChange={(e) => setSewageInputs({...sewageInputs, peakFactor: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-sewage-peak"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'التسرب (L/s/km)' : 'Infiltration'}</Label>
                  <Input type="number" value={sewageInputs.infiltration}
                    onChange={(e) => setSewageInputs({...sewageInputs, infiltration: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-sewage-infiltration"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'طول الأنبوب (م)' : 'Pipe Length (m)'}</Label>
                  <Input type="number" value={sewageInputs.pipeLength}
                    onChange={(e) => setSewageInputs({...sewageInputs, pipeLength: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-sewage-length"/>
                </div>
              </div>
            </div>

            {/* بيانات الأنبوب */}
            <div className="bg-white/5 p-4 rounded-xl border border-white/10">
              <h3 className="text-white font-semibold mb-3">🔵 {language === 'ar' ? 'خصائص الأنبوب' : 'Pipe Properties'}</h3>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'القطر (مم)' : 'Diameter (mm)'}</Label>
                  <select value={sewageInputs.pipeDiameter}
                    onChange={(e) => setSewageInputs({...sewageInputs, pipeDiameter: Number(e.target.value)})}
                    className="w-full h-9 bg-white/10 border border-white/20 text-white rounded-md px-2" data-testid="input-sewage-diameter">
                    {[150, 200, 250, 300, 400, 500, 600, 800, 1000, 1200].map(d => (
                      <option key={d} value={d} className="bg-gray-800">{d} mm</option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'الميل (%)' : 'Slope (%)'}</Label>
                  <Input type="number" step="0.01" value={sewageInputs.pipeSlope}
                    onChange={(e) => setSewageInputs({...sewageInputs, pipeSlope: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-sewage-slope"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'معامل مانينج (n)' : 'Manning n'}</Label>
                  <select value={sewageInputs.manningN}
                    onChange={(e) => setSewageInputs({...sewageInputs, manningN: Number(e.target.value)})}
                    className="w-full h-9 bg-white/10 border border-white/20 text-white rounded-md px-2" data-testid="input-sewage-manning">
                    <option value={0.010} className="bg-gray-800">0.010 - HDPE</option>
                    <option value={0.011} className="bg-gray-800">0.011 - GRP</option>
                    <option value={0.013} className="bg-gray-800">0.013 - PVC</option>
                    <option value={0.015} className="bg-gray-800">0.015 - Concrete</option>
                    <option value={0.017} className="bg-gray-800">0.017 - Clay</option>
                  </select>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عمق الدخول (م)' : 'Inlet Depth (m)'}</Label>
                  <Input type="number" step="0.1" value={sewageInputs.inletDepth}
                    onChange={(e) => setSewageInputs({...sewageInputs, inletDepth: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-sewage-inlet"/>
                </div>
                <div>
                  <Label className="text-gray-400 text-xs">{language === 'ar' ? 'عمق الخروج (م)' : 'Outlet Depth (m)'}</Label>
                  <Input type="number" step="0.1" value={sewageInputs.outletDepth}
                    onChange={(e) => setSewageInputs({...sewageInputs, outletDepth: Number(e.target.value)})}
                    className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-sewage-outlet"/>
                </div>
              </div>
            </div>

            <button onClick={calculateSewage}
              className="w-full py-4 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold text-lg transition flex items-center justify-center gap-2"
              data-testid="button-calculate-sewage">
              <Calculator className="w-6 h-6" />{language === 'ar' ? 'تحليل الشبكة' : 'Analyze Network'}
            </button>

            {sewageResult && (
              <div className="space-y-4 mt-6">
                {/* حالة التصميم */}
                <div className={`p-4 rounded-xl border ${sewageResult.isSelfCleansing && sewageResult.fillRatio <= 0.8 ? 'bg-green-900/30 border-green-500/40' : 'bg-yellow-900/30 border-yellow-500/40'}`}>
                  <p className="text-center font-bold text-lg">
                    {sewageResult.isSelfCleansing && sewageResult.fillRatio <= 0.8
                      ? (language === 'ar' ? '✅ تصميم مقبول' : '✅ Acceptable Design')
                      : (language === 'ar' ? '⚠️ يحتاج مراجعة' : '⚠️ Needs Review')}
                  </p>
                </div>

                {/* النتائج الرئيسية */}
                <div className="bg-gradient-to-r from-teal-900/40 to-cyan-900/40 p-5 rounded-xl border border-teal-500/40">
                  <h3 className="text-xl font-bold text-white mb-4 text-center">📊 {language === 'ar' ? 'نتائج التحليل' : 'Analysis Results'}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'التدفق المتوسط' : 'Avg Flow'}</p>
                      <p className="text-2xl font-bold text-white" data-testid="text-sewage-avg">{sewageResult.avgFlow.toFixed(2)}</p>
                      <p className="text-gray-400">L/s</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'تدفق الذروة' : 'Peak Flow'}</p>
                      <p className="text-2xl font-bold text-blue-300" data-testid="text-sewage-peak">{sewageResult.peakFlow.toFixed(2)}</p>
                      <p className="text-gray-400">L/s</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'تدفق التصميم' : 'Design Flow'}</p>
                      <p className="text-2xl font-bold text-teal-300" data-testid="text-sewage-design">{sewageResult.designFlow.toFixed(2)}</p>
                      <p className="text-gray-400">L/s</p>
                    </div>
                    <div className="bg-white/10 p-4 rounded-lg text-center">
                      <p className="text-gray-400 text-sm">{language === 'ar' ? 'السعة' : 'Capacity'}</p>
                      <p className="text-2xl font-bold text-cyan-300" data-testid="text-sewage-capacity">{sewageResult.capacity.toFixed(2)}</p>
                      <p className="text-gray-400">L/s</p>
                    </div>
                  </div>
                </div>

                {/* الخصائص الهيدروليكية */}
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                  <h3 className="text-white font-semibold mb-3">🌊 {language === 'ar' ? 'الخصائص الهيدروليكية' : 'Hydraulic Properties'}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                    <div className="bg-blue-900/30 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'السرعة' : 'Velocity'}</p>
                      <p className="text-xl font-bold text-blue-300">{sewageResult.velocity.toFixed(2)} m/s</p>
                      <p className="text-xs text-gray-500">{sewageResult.isSelfCleansing ? '✓' : '⚠️'}</p>
                    </div>
                    <div className="bg-teal-900/30 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'نسبة الامتلاء' : 'Fill Ratio'}</p>
                      <p className="text-xl font-bold text-teal-300">{(sewageResult.fillRatio * 100).toFixed(1)}%</p>
                    </div>
                    <div className="bg-cyan-900/30 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'نصف القطر الهيدروليكي' : 'Hyd. Radius'}</p>
                      <p className="text-xl font-bold text-cyan-300">{(sewageResult.hydraulicRadius * 1000).toFixed(1)} mm</p>
                    </div>
                    <div className="bg-purple-900/30 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'رقم فرود' : 'Froude No.'}</p>
                      <p className="text-xl font-bold text-purple-300">{sewageResult.froudeNumber.toFixed(3)}</p>
                    </div>
                    <div className="bg-orange-900/30 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'إجهاد القص' : 'Shear Stress'}</p>
                      <p className="text-xl font-bold text-orange-300">{sewageResult.shearStress.toFixed(2)} N/m²</p>
                    </div>
                  </div>
                </div>

                {/* التوصيات */}
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                  <h3 className="text-white font-semibold mb-2">💡 {language === 'ar' ? 'التوصيات' : 'Recommendations'}</h3>
                  <div className="space-y-1">
                    {sewageResult.recommendations.map((rec, i) => (
                      <p key={i} className="text-gray-300 text-sm">{rec}</p>
                    ))}
                  </div>
                </div>

                {/* أزرار التصدير */}
                <div className="flex gap-2">
                  <button onClick={() => {
                    const report = `تقرير تحليل شبكة الصرف الصحي\n${'='.repeat(40)}\nالتاريخ: ${new Date().toLocaleString('ar-EG')}\n\nالمدخلات:\n- عدد السكان: ${sewageInputs.population}\n- معامل الذروة: ${sewageInputs.peakFactor}\n- قطر الأنبوب: ${sewageInputs.pipeDiameter} مم\n- الميل: ${sewageInputs.pipeSlope}%\n- معامل مانينج: ${sewageInputs.manningN}\n\nالنتائج:\n- التدفق المتوسط: ${sewageResult.avgFlow.toFixed(2)} L/s\n- تدفق الذروة: ${sewageResult.peakFlow.toFixed(2)} L/s\n- تدفق التصميم: ${sewageResult.designFlow.toFixed(2)} L/s\n- السعة: ${sewageResult.capacity.toFixed(2)} L/s\n- السرعة: ${sewageResult.velocity.toFixed(2)} m/s\n- نسبة الامتلاء: ${(sewageResult.fillRatio * 100).toFixed(1)}%\n- التنظيف الذاتي: ${sewageResult.isSelfCleansing ? 'نعم ✓' : 'لا ⚠️'}\n\nالتوصيات:\n${sewageResult.recommendations.join('\n')}`;
                    const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
                    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'sewage-analysis.txt'; a.click();
                    toast.success(language === 'ar' ? '✓ تم التصدير' : '✓ Exported');
                  }} className="flex-1 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2" data-testid="button-export-sewage">
                    <Download className="w-5 h-5" />TXT
                  </button>
                  <button onClick={() => {
                    generateSewagePDF(sewageResult, sewageInputs, language);
                    toast.success(language === 'ar' ? '✓ تم تصدير PDF' : '✓ PDF exported');
                  }} className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2" data-testid="button-export-sewage-pdf">
                    <FileText className="w-5 h-5" />PDF
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Foundation Calculator */}
        {calcType === "foundation" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">🏛️ {language === 'ar' ? 'حاسبة الأساسات' : 'Foundation Design'}</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <Label className="text-gray-400">{language === 'ar' ? 'حمل العمود (kN)' : 'Column Load'}</Label>
                <Input type="number" value={foundationInputs.columnLoad} onChange={(e) => setFoundationInputs({...foundationInputs, columnLoad: Number(e.target.value)})} className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-foundation-load"/>
              </div>
              <div>
                <Label className="text-gray-400">{language === 'ar' ? 'قدرة التربة (kPa)' : 'Soil Bearing'}</Label>
                <Input type="number" value={foundationInputs.soilBearing} onChange={(e) => setFoundationInputs({...foundationInputs, soilBearing: Number(e.target.value)})} className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-foundation-bearing"/>
              </div>
              <div>
                <Label className="text-gray-400">{language === 'ar' ? 'الطول (م)' : 'Length (m)'}</Label>
                <Input type="number" step="0.1" value={foundationInputs.length} onChange={(e) => setFoundationInputs({...foundationInputs, length: Number(e.target.value)})} className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-foundation-length"/>
              </div>
              <div>
                <Label className="text-gray-400">{language === 'ar' ? 'العرض (م)' : 'Width (m)'}</Label>
                <Input type="number" step="0.1" value={foundationInputs.width} onChange={(e) => setFoundationInputs({...foundationInputs, width: Number(e.target.value)})} className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-foundation-width"/>
              </div>
              <div>
                <Label className="text-gray-400">{language === 'ar' ? 'العمق (م)' : 'Depth (m)'}</Label>
                <Input type="number" step="0.1" value={foundationInputs.depth} onChange={(e) => setFoundationInputs({...foundationInputs, depth: Number(e.target.value)})} className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-foundation-depth"/>
              </div>
              <div>
                <Label className="text-gray-400">{language === 'ar' ? 'معامل الأمان' : 'Safety Factor'}</Label>
                <Input type="number" step="0.1" value={foundationInputs.safetyFactor} onChange={(e) => setFoundationInputs({...foundationInputs, safetyFactor: Number(e.target.value)})} className="h-9 bg-white/10 border-white/20 text-white" data-testid="input-foundation-safety"/>
              </div>
            </div>
            <button onClick={calculateFoundation} className="w-full py-3 bg-orange-600 hover:bg-orange-700 text-white rounded-xl font-bold" data-testid="button-calculate-foundation">
              {language === 'ar' ? 'حساب الأساس' : 'Calculate'}
            </button>
            {foundationResult && (
              <div className="bg-gradient-to-r from-orange-900/40 to-red-900/40 p-4 rounded-xl space-y-3">
                <div className={`p-3 rounded-lg text-center font-bold ${foundationResult.isAdequate ? 'bg-green-900/40 text-green-300' : 'bg-red-900/40 text-red-300'}`}>
                  {foundationResult.isAdequate ? '✅ كافي' : '⚠️ غير كافي'}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-white/10 p-2 rounded"><p className="text-xs text-gray-400">مساحة مطلوبة</p><p className="text-lg font-bold text-white">{foundationResult.requiredArea.toFixed(2)} m²</p></div>
                  <div className="bg-white/10 p-2 rounded"><p className="text-xs text-gray-400">مساحة فعلية</p><p className="text-lg font-bold text-white">{foundationResult.actualArea.toFixed(2)} m²</p></div>
                  <div className="bg-white/10 p-2 rounded"><p className="text-xs text-gray-400">خرسانة</p><p className="text-lg font-bold text-white">{foundationResult.concreteVolume.toFixed(2)} m³</p></div>
                  <div className="bg-white/10 p-2 rounded"><p className="text-xs text-gray-400">حديد</p><p className="text-lg font-bold text-white">{foundationResult.rebarWeight.toFixed(0)} kg</p></div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Projects Manager */}
        {calcType === "projects" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">💾 {language === 'ar' ? 'إدارة المشاريع' : 'Project Manager'}</h2>
            <div className="flex gap-2 mb-4">
              <Input type="text" placeholder={language === 'ar' ? 'اسم المشروع' : 'Project name'} value={projectName} onChange={(e) => setProjectName(e.target.value)} className="flex-1 h-10 bg-white/10 border-white/20 text-white" data-testid="input-project-name"/>
              <button onClick={saveProject} className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-bold" data-testid="button-save-project">{language === 'ar' ? 'حفظ' : 'Save'}</button>
              <button onClick={exportToExcel} className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold" data-testid="button-export-excel">Excel</button>
            </div>
            {projects.length > 0 && (
              <div className="space-y-2">
                {projects.map((p) => (
                  <div key={p.id} className="bg-white/10 p-3 rounded-lg flex justify-between items-center">
                    <div>
                      <p className="text-white font-semibold">{p.name}</p>
                      <p className="text-xs text-gray-400">{p.date}</p>
                    </div>
                    <button onClick={() => loadProject(p.id)} className="px-3 py-1 bg-purple-600 text-white rounded" data-testid={`button-load-${p.id}`}>{language === 'ar' ? 'تحميل' : 'Load'}</button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {calcType === "boq" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">📋 {language === 'ar' ? 'حصر بنود المباني' : 'Building Bill of Quantities'}</h2>
            
            {/* اختيار نوع البند */}
            <div className="grid grid-cols-3 md:grid-cols-5 gap-2 mb-4">
              {[
                { id: "masonry" as const, icon: "🧱", label: language === 'ar' ? "بناء" : "Masonry" },
                { id: "plastering" as const, icon: "🪣", label: language === 'ar' ? "محارة" : "Plaster" },
                { id: "tiling" as const, icon: "🔲", label: language === 'ar' ? "بلاط" : "Tiles" },
                { id: "painting" as const, icon: "🎨", label: language === 'ar' ? "دهانات" : "Paint" },
                { id: "waterproofing" as const, icon: "💧", label: language === 'ar' ? "عزل" : "Waterproof" },
                { id: "doors" as const, icon: "🚪", label: language === 'ar' ? "أبواب" : "Doors" },
                { id: "windows" as const, icon: "🪟", label: language === 'ar' ? "نوافذ" : "Windows" },
                { id: "electrical" as const, icon: "⚡", label: language === 'ar' ? "كهرباء" : "Electrical" },
                { id: "plumbing" as const, icon: "🔧", label: language === 'ar' ? "سباكة" : "Plumbing" },
              ].map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setBoqCategory(cat.id);
                    setBoqResult(null);
                  }}
                  className={`px-3 py-3 rounded-xl font-medium transition text-center ${
                    boqCategory === cat.id
                      ? 'bg-indigo-600 text-white shadow-lg'
                      : 'bg-white/5 text-gray-300 hover:bg-white/15 border border-white/10'
                  }`}
                  data-testid={`button-boq-${cat.id}`}
                >
                  <span className="text-2xl block mb-1">{cat.icon}</span>
                  <span className="text-xs">{cat.label}</span>
                </button>
              ))}
            </div>

            {/* حقول الإدخال حسب نوع البند */}
            <div className="bg-black/20 p-4 rounded-xl space-y-4">
              
              {/* البناء - الطوب والبلوك */}
              {boqCategory === "masonry" && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'طول الحائط (م)' : 'Wall Length (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="10"
                      value={boqInputs.length || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, length: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-length"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'ارتفاع الحائط (م)' : 'Wall Height (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="3"
                      value={boqInputs.height || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, height: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-height"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'العدد' : 'Quantity'}</Label>
                    <Input
                      type="number"
                      placeholder="1"
                      value={boqInputs.quantity || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, quantity: parseInt(e.target.value) || 1})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-quantity"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'مقاس البلوك' : 'Block Size'}</Label>
                    <select
                      value={boqInputs.blockSize}
                      onChange={(e) => setBoqInputs({...boqInputs, blockSize: e.target.value})}
                      className="w-full bg-white/10 border border-white/20 text-white rounded-md p-2"
                      data-testid="select-boq-block-size"
                    >
                      <option value="20x20x40">20×20×40 سم (بلوك)</option>
                      <option value="15x20x40">15×20×40 سم (بلوك)</option>
                      <option value="10x20x40">10×20×40 سم (بلوك)</option>
                      <option value="12x25x25">12×25×25 سم (طوب أحمر)</option>
                    </select>
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'مساحة الفتحات (م²)' : 'Openings Area (m²)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="0"
                      value={boqInputs.openingsArea || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, openingsArea: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-openings"
                    />
                  </div>
                </div>
              )}

              {/* المحارة/اللياسة */}
              {boqCategory === "plastering" && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'المساحة (م²) أو الطول (م)' : 'Area (m²) or Length (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="100"
                      value={boqInputs.area || boqInputs.length || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, area: parseFloat(e.target.value) || 0, length: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-plaster-area"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'الارتفاع (م) - إن وجد' : 'Height (m) - if any'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="3"
                      value={boqInputs.height || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, height: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-plaster-height"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'سمك المحارة (سم)' : 'Plaster Thickness (cm)'}</Label>
                    <Input
                      type="number"
                      step="0.5"
                      placeholder="2"
                      value={boqInputs.plasterThickness}
                      onChange={(e) => setBoqInputs({...boqInputs, plasterThickness: parseFloat(e.target.value) || 2})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-plaster-thickness"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'عدد الطبقات' : 'Coats'}</Label>
                    <Input
                      type="number"
                      placeholder="2"
                      value={boqInputs.coats}
                      onChange={(e) => setBoqInputs({...boqInputs, coats: parseInt(e.target.value) || 2})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-plaster-coats"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'مساحة الفتحات (م²)' : 'Openings (m²)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="0"
                      value={boqInputs.openingsArea || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, openingsArea: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-plaster-openings"
                    />
                  </div>
                </div>
              )}

              {/* البلاط/السيراميك */}
              {boqCategory === "tiling" && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'المساحة (م²) أو الطول (م)' : 'Area (m²) or Length (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="50"
                      value={boqInputs.area || boqInputs.length || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, area: parseFloat(e.target.value) || 0, length: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-tile-area"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'العرض (م) - إن وجد' : 'Width (m) - if any'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="5"
                      value={boqInputs.width || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, width: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-tile-width"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'مقاس البلاط' : 'Tile Size'}</Label>
                    <select
                      value={boqInputs.tileSize}
                      onChange={(e) => setBoqInputs({...boqInputs, tileSize: e.target.value})}
                      className="w-full bg-white/10 border border-white/20 text-white rounded-md p-2"
                      data-testid="select-boq-tile-size"
                    >
                      <option value="60x60">60×60 سم</option>
                      <option value="80x80">80×80 سم</option>
                      <option value="60x120">60×120 سم</option>
                      <option value="40x40">40×40 سم</option>
                      <option value="30x30">30×30 سم</option>
                      <option value="20x20">20×20 سم</option>
                    </select>
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'نسبة الهالك %' : 'Waste Factor %'}</Label>
                    <Input
                      type="number"
                      placeholder="10"
                      value={boqInputs.wasteFactor}
                      onChange={(e) => setBoqInputs({...boqInputs, wasteFactor: parseInt(e.target.value) || 10})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-tile-waste"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'العدد' : 'Quantity'}</Label>
                    <Input
                      type="number"
                      placeholder="1"
                      value={boqInputs.quantity || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, quantity: parseInt(e.target.value) || 1})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-tile-quantity"
                    />
                  </div>
                </div>
              )}

              {/* الدهانات */}
              {boqCategory === "painting" && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'المساحة (م²) أو الطول (م)' : 'Area (m²) or Length (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="100"
                      value={boqInputs.area || boqInputs.length || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, area: parseFloat(e.target.value) || 0, length: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-paint-area"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'الارتفاع (م)' : 'Height (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="3"
                      value={boqInputs.height || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, height: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-paint-height"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'عدد الأوجه (الوحدات)' : 'Units/Faces'}</Label>
                    <Input
                      type="number"
                      placeholder="1"
                      value={boqInputs.quantity || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, quantity: parseInt(e.target.value) || 1})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-paint-quantity"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'عدد الطبقات' : 'Coats'}</Label>
                    <Input
                      type="number"
                      placeholder="2"
                      value={boqInputs.coatsCount}
                      onChange={(e) => setBoqInputs({...boqInputs, coatsCount: parseInt(e.target.value) || 2})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-paint-coats"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'تغطية الدهان (م²/لتر)' : 'Coverage (m²/L)'}</Label>
                    <Input
                      type="number"
                      placeholder="12"
                      value={boqInputs.coverage}
                      onChange={(e) => setBoqInputs({...boqInputs, coverage: parseInt(e.target.value) || 12})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-paint-coverage"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'مساحة الفتحات (م²)' : 'Openings (m²)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="0"
                      value={boqInputs.openingsArea || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, openingsArea: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-paint-openings"
                    />
                  </div>
                </div>
              )}

              {/* العزل المائي */}
              {boqCategory === "waterproofing" && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'المساحة (م²) أو الطول (م)' : 'Area (m²) or Length (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="50"
                      value={boqInputs.area || boqInputs.length || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, area: parseFloat(e.target.value) || 0, length: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-waterproof-area"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'العرض (م) - إن وجد' : 'Width (m) - if any'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="5"
                      value={boqInputs.width || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, width: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-waterproof-width"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'العدد' : 'Quantity'}</Label>
                    <Input
                      type="number"
                      placeholder="1"
                      value={boqInputs.quantity || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, quantity: parseInt(e.target.value) || 1})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-waterproof-quantity"
                    />
                  </div>
                </div>
              )}

              {/* الأبواب */}
              {boqCategory === "doors" && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'عدد الأبواب' : 'Number of Doors'}</Label>
                    <Input
                      type="number"
                      placeholder="5"
                      value={boqInputs.quantity || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, quantity: parseInt(e.target.value) || 1})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-doors-quantity"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'نوع الباب' : 'Door Type'}</Label>
                    <select
                      value={boqInputs.doorType}
                      onChange={(e) => setBoqInputs({...boqInputs, doorType: e.target.value})}
                      className="w-full bg-white/10 border border-white/20 text-white rounded-md p-2"
                      data-testid="select-boq-door-type"
                    >
                      <option value="wooden">{language === 'ar' ? 'خشب' : 'Wooden'}</option>
                      <option value="aluminum">{language === 'ar' ? 'ألمنيوم' : 'Aluminum'}</option>
                      <option value="steel">{language === 'ar' ? 'حديد' : 'Steel'}</option>
                    </select>
                  </div>
                </div>
              )}

              {/* النوافذ */}
              {boqCategory === "windows" && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'عرض النافذة (م)' : 'Window Width (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="1.2"
                      value={boqInputs.length || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, length: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-window-width"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'ارتفاع النافذة (م)' : 'Window Height (m)'}</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="1.5"
                      value={boqInputs.width || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, width: parseFloat(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-window-height"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'عدد النوافذ' : 'Number of Windows'}</Label>
                    <Input
                      type="number"
                      placeholder="10"
                      value={boqInputs.quantity || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, quantity: parseInt(e.target.value) || 1})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-windows-quantity"
                    />
                  </div>
                </div>
              )}

              {/* الكهرباء */}
              {boqCategory === "electrical" && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'عدد النقاط الكهربائية' : 'Electrical Points'}</Label>
                    <Input
                      type="number"
                      placeholder="50"
                      value={boqInputs.pointsCount || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, pointsCount: parseInt(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-elec-points"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'عدد الغرف/الوحدات' : 'Rooms/Units'}</Label>
                    <Input
                      type="number"
                      placeholder="1"
                      value={boqInputs.quantity || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, quantity: parseInt(e.target.value) || 1})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-elec-quantity"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'عدد الدوائر' : 'Circuits'}</Label>
                    <Input
                      type="number"
                      placeholder="8"
                      value={boqInputs.circuitsCount || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, circuitsCount: parseInt(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-elec-circuits"
                    />
                  </div>
                </div>
              )}

              {/* السباكة */}
              {boqCategory === "plumbing" && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'نقاط مياه باردة' : 'Cold Water Points'}</Label>
                    <Input
                      type="number"
                      placeholder="10"
                      value={boqInputs.coldPoints || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, coldPoints: parseInt(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-plumb-cold"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'نقاط مياه ساخنة' : 'Hot Water Points'}</Label>
                    <Input
                      type="number"
                      placeholder="5"
                      value={boqInputs.hotPoints || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, hotPoints: parseInt(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-plumb-hot"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'نقاط صرف' : 'Drain Points'}</Label>
                    <Input
                      type="number"
                      placeholder="8"
                      value={boqInputs.drainPoints || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, drainPoints: parseInt(e.target.value) || 0})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-plumb-drain"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">{language === 'ar' ? 'عدد الحمامات/الوحدات' : 'Bathrooms/Units'}</Label>
                    <Input
                      type="number"
                      placeholder="1"
                      value={boqInputs.quantity || ''}
                      onChange={(e) => setBoqInputs({...boqInputs, quantity: parseInt(e.target.value) || 1})}
                      className="bg-white/10 border-white/20 text-white"
                      data-testid="input-boq-plumb-quantity"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* زر الحساب */}
            <button
              onClick={calculateBOQ}
              className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-lg transition flex items-center justify-center gap-2"
              data-testid="button-calculate-boq"
            >
              <Calculator className="w-6 h-6" />
              {language === 'ar' ? 'احسب الكميات' : 'Calculate Quantities'}
            </button>

            {/* النتائج */}
            {boqResult && (
              <div className="bg-gradient-to-br from-indigo-900/40 to-purple-900/40 p-6 rounded-xl border border-indigo-500/30 space-y-4">
                <h3 className="text-xl font-bold text-indigo-300 flex items-center gap-2">
                  📊 {language === 'ar' ? 'حصر الكميات' : 'Bill of Quantities'}
                </h3>

                {boqResult.totalArea && boqResult.totalArea > 0 && (
                  <div className="bg-black/20 p-4 rounded-lg">
                    <p className="text-gray-400">{language === 'ar' ? 'إجمالي المساحة' : 'Total Area'}</p>
                    <p className="text-3xl font-bold text-cyan-400">{boqResult.totalArea.toFixed(2)} م²</p>
                  </div>
                )}

                {/* جدول البنود */}
                <div className="bg-black/20 rounded-xl overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-indigo-600/30">
                      <tr>
                        <th className="py-2 px-4 text-right text-white">#</th>
                        <th className="py-2 px-4 text-right text-white">{language === 'ar' ? 'البند' : 'Item'}</th>
                        <th className="py-2 px-4 text-center text-white">{language === 'ar' ? 'الكمية' : 'Qty'}</th>
                        <th className="py-2 px-4 text-center text-white">{language === 'ar' ? 'الوحدة' : 'Unit'}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {boqResult.items.map((item, idx) => (
                        <tr key={idx} className={idx % 2 === 0 ? 'bg-white/5' : ''}>
                          <td className="py-2 px-4 text-gray-400">{idx + 1}</td>
                          <td className="py-2 px-4 text-white">{language === 'ar' ? item.name : item.nameEn}</td>
                          <td className="py-2 px-4 text-center text-cyan-300 font-bold">{item.quantity}</td>
                          <td className="py-2 px-4 text-center text-gray-400">{item.unit}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* أزرار التصدير */}
                <div className="flex gap-2">
                  <button
                    onClick={exportBOQ}
                    className="flex-1 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2"
                    data-testid="button-export-boq"
                  >
                    <Download className="w-5 h-5" />
                    {language === 'ar' ? 'تصدير CSV' : 'Export CSV'}
                  </button>
                  <button
                    onClick={() => {
                      const text = boqResult.items.map((item, idx) => 
                        `${idx + 1}. ${language === 'ar' ? item.name : item.nameEn}: ${item.quantity} ${item.unit}`
                      ).join('\n');
                      navigator.clipboard.writeText(text);
                      toast.success(language === 'ar' ? '✓ تم النسخ' : '✓ Copied');
                    }}
                    className="px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2"
                    data-testid="button-copy-boq"
                  >
                    <Copy className="w-5 h-5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {calcType === "cad-boq" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">📁 {language === 'ar' ? 'حصر تلقائي من أوتوكاد' : 'AutoCAD Auto BOQ'}</h2>
            
            <div className="bg-black/20 p-4 rounded-xl">
              <p className="text-gray-400 text-sm mb-4">
                {language === 'ar' 
                  ? 'قم بتحميل ملف DXF وسيتم استخراج الكميات تلقائياً (الأطوال، المساحات، البلوكات) مصنفة حسب الطبقات'
                  : 'Upload a DXF file and quantities will be automatically extracted (lengths, areas, blocks) organized by layers'}
              </p>
              
              <button 
                onClick={() => cadBoqFileRef.current?.click()}
                disabled={cadBoqLoading}
                className="w-full py-4 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-600/50 text-white rounded-xl font-semibold transition flex items-center justify-center gap-2"
                data-testid="button-upload-cad-boq"
              >
                {cadBoqLoading ? (
                  <>
                    <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full" />
                    {language === 'ar' ? 'جاري التحليل...' : 'Analyzing...'}
                  </>
                ) : (
                  <>
                    <Upload className="w-5 h-5" />
                    {language === 'ar' ? 'اختر ملف DXF' : 'Select DXF File'}
                  </>
                )}
              </button>
              <input
                ref={cadBoqFileRef}
                type="file"
                accept=".dxf"
                onChange={handleCadBoqUpload}
                className="hidden"
                data-testid="input-cad-boq-file"
              />
            </div>

            {cadBoqFileName && (
              <div className="text-sm text-gray-400">
                📄 {language === 'ar' ? 'الملف:' : 'File:'} {cadBoqFileName}
              </div>
            )}

            {/* النتائج */}
            {cadBoqResult && (
              <div className="space-y-4">
                {/* ملخص عام */}
                <div className="bg-gradient-to-br from-blue-900/40 to-cyan-900/40 p-6 rounded-xl border border-blue-500/30">
                  <h3 className="text-xl font-bold text-blue-300 flex items-center gap-2 mb-4">
                    📊 {language === 'ar' ? 'ملخص الملف' : 'File Summary'}
                  </h3>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-black/20 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'خطوط' : 'Lines'}</p>
                      <p className="text-2xl font-bold text-cyan-400">{cadBoqResult.summary.totalLines}</p>
                    </div>
                    <div className="bg-black/20 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'خطوط متعددة' : 'Polylines'}</p>
                      <p className="text-2xl font-bold text-green-400">{cadBoqResult.summary.totalPolylines}</p>
                    </div>
                    <div className="bg-black/20 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'دوائر' : 'Circles'}</p>
                      <p className="text-2xl font-bold text-yellow-400">{cadBoqResult.summary.totalCircles}</p>
                    </div>
                    <div className="bg-black/20 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'أقواس' : 'Arcs'}</p>
                      <p className="text-2xl font-bold text-orange-400">{cadBoqResult.summary.totalArcs}</p>
                    </div>
                    <div className="bg-black/20 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'نصوص' : 'Texts'}</p>
                      <p className="text-2xl font-bold text-purple-400">{cadBoqResult.summary.totalTexts}</p>
                    </div>
                    <div className="bg-black/20 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'بلوكات' : 'Blocks'}</p>
                      <p className="text-2xl font-bold text-pink-400">{cadBoqResult.summary.totalBlocks}</p>
                    </div>
                    <div className="bg-black/20 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'إجمالي الأطوال' : 'Total Length'}</p>
                      <p className="text-xl font-bold text-white">{cadBoqResult.summary.totalLength.toFixed(2)}</p>
                      <p className="text-xs text-gray-500">{language === 'ar' ? 'وحدة' : 'units'}</p>
                    </div>
                    <div className="bg-black/20 p-3 rounded-lg text-center">
                      <p className="text-gray-400 text-xs">{language === 'ar' ? 'إجمالي المساحات' : 'Total Area'}</p>
                      <p className="text-xl font-bold text-white">{cadBoqResult.summary.totalArea.toFixed(2)}</p>
                      <p className="text-xs text-gray-500">{language === 'ar' ? 'وحدة²' : 'units²'}</p>
                    </div>
                  </div>
                </div>

                {/* البلوكات */}
                {cadBoqResult.blocks.length > 0 && (
                  <div className="bg-gradient-to-br from-purple-900/40 to-pink-900/40 p-6 rounded-xl border border-purple-500/30">
                    <h3 className="text-xl font-bold text-purple-300 flex items-center gap-2 mb-4">
                      🧩 {language === 'ar' ? 'البلوكات (الرموز)' : 'Blocks (Symbols)'}
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {cadBoqResult.blocks.slice(0, 12).map((block, idx) => (
                        <div key={idx} className="bg-black/20 p-3 rounded-lg flex justify-between items-center">
                          <span className="text-white text-sm truncate">{block.name}</span>
                          <span className="text-pink-400 font-bold">{block.count}</span>
                        </div>
                      ))}
                      {cadBoqResult.blocks.length > 12 && (
                        <div className="bg-black/20 p-3 rounded-lg text-center text-gray-400">
                          +{cadBoqResult.blocks.length - 12} {language === 'ar' ? 'بلوك آخر' : 'more blocks'}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* الطبقات والتفاصيل */}
                <div className="bg-gradient-to-br from-green-900/40 to-teal-900/40 p-6 rounded-xl border border-green-500/30">
                  <h3 className="text-xl font-bold text-green-300 flex items-center gap-2 mb-4">
                    📋 {language === 'ar' ? 'التفاصيل حسب الطبقة' : 'Details by Layer'}
                  </h3>
                  
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {cadBoqResult.layers.map((layer, idx) => (
                      <div key={idx} className="bg-black/20 p-4 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <div 
                            className="w-4 h-4 rounded" 
                            style={{ backgroundColor: `hsl(${(layer.color * 30) % 360}, 70%, 50%)` }}
                          />
                          <span className="text-white font-semibold">{layer.name}</span>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                          {layer.items.map((item, itemIdx) => (
                            <div key={itemIdx} className="bg-white/5 p-2 rounded text-center">
                              <p className="text-xs text-gray-400">{item.type}</p>
                              <p className="text-sm font-bold text-cyan-300">{item.count}</p>
                              {item.totalLength && item.totalLength > 0 && (
                                <p className="text-xs text-gray-500">{item.totalLength.toFixed(1)} {language === 'ar' ? 'و' : 'u'}</p>
                              )}
                              {item.totalArea && item.totalArea > 0 && (
                                <p className="text-xs text-gray-500">{item.totalArea.toFixed(1)} {language === 'ar' ? 'و²' : 'u²'}</p>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* زر التصدير */}
                <button
                  onClick={exportCadBOQ}
                  className="w-full py-4 bg-green-600 hover:bg-green-700 text-white rounded-xl font-bold text-lg transition flex items-center justify-center gap-2"
                  data-testid="button-export-cad-boq"
                >
                  <Download className="w-6 h-6" />
                  {language === 'ar' ? 'تصدير الحصر إلى CSV' : 'Export BOQ to CSV'}
                </button>
              </div>
            )}
          </div>
        )}

        {calcType === "measure" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">🛰️ {language === 'ar' ? 'أداة القياس GPS' : 'GPS Measurement Tool'}</h2>
            
            <div className="grid grid-cols-4 gap-2 mb-4">
              {[
                { id: "distance" as MeasureMode, icon: "📏", label: language === 'ar' ? "المسافة" : "Distance" },
                { id: "area" as MeasureMode, icon: "📐", label: language === 'ar' ? "المساحة" : "Area" },
                { id: "slope" as MeasureMode, icon: "📐", label: language === 'ar' ? "الميل" : "Slope" },
                { id: "gps" as MeasureMode, icon: "📍", label: "GPS" }
              ].map((mode) => (
                <button
                  key={mode.id}
                  onClick={() => {
                    setMeasureMode(mode.id);
                    setMeasureResult(null);
                  }}
                  className={`px-3 py-3 rounded-xl font-medium transition text-center ${
                    measureMode === mode.id
                      ? 'bg-green-600 text-white'
                      : 'bg-white/5 text-gray-300 hover:bg-white/15'
                  }`}
                  data-testid={`button-measure-${mode.id}`}
                >
                  <span className="text-xl block mb-1">{mode.icon}</span>
                  <span className="text-xs">{mode.label}</span>
                </button>
              ))}
            </div>

            {measureMode === "distance" && (
              <div className="space-y-4">
                <p className="text-gray-400 text-sm">{language === 'ar' ? 'أدخل إحداثيات نقطتين لحساب المسافة بينهما' : 'Enter coordinates of two points to calculate distance'}</p>
                
                <div className="bg-black/20 p-4 rounded-xl">
                  <h3 className="text-white font-semibold mb-3">{language === 'ar' ? 'النقطة الأولى' : 'Point 1'}</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-300">{language === 'ar' ? 'خط العرض' : 'Latitude'}</Label>
                      <Input
                        type="number"
                        step="0.000001"
                        placeholder="24.7136"
                        value={measurePoints[0]?.lat || ""}
                        onChange={(e) => {
                          const newPoints = [...measurePoints];
                          newPoints[0] = { ...newPoints[0], lat: parseFloat(e.target.value) || 0 };
                          setMeasurePoints(newPoints);
                        }}
                        className="bg-white/10 border-white/20 text-white"
                        data-testid="input-measure-lat1"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-300">{language === 'ar' ? 'خط الطول' : 'Longitude'}</Label>
                      <Input
                        type="number"
                        step="0.000001"
                        placeholder="46.6753"
                        value={measurePoints[0]?.lng || ""}
                        onChange={(e) => {
                          const newPoints = [...measurePoints];
                          newPoints[0] = { ...newPoints[0], lng: parseFloat(e.target.value) || 0 };
                          setMeasurePoints(newPoints);
                        }}
                        className="bg-white/10 border-white/20 text-white"
                        data-testid="input-measure-lng1"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="bg-black/20 p-4 rounded-xl">
                  <h3 className="text-white font-semibold mb-3">{language === 'ar' ? 'النقطة الثانية' : 'Point 2'}</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-300">{language === 'ar' ? 'خط العرض' : 'Latitude'}</Label>
                      <Input
                        type="number"
                        step="0.000001"
                        placeholder="24.7236"
                        value={measurePoints[1]?.lat || ""}
                        onChange={(e) => {
                          const newPoints = [...measurePoints];
                          newPoints[1] = { ...newPoints[1], lat: parseFloat(e.target.value) || 0 };
                          setMeasurePoints(newPoints);
                        }}
                        className="bg-white/10 border-white/20 text-white"
                        data-testid="input-measure-lat2"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-300">{language === 'ar' ? 'خط الطول' : 'Longitude'}</Label>
                      <Input
                        type="number"
                        step="0.000001"
                        placeholder="46.6853"
                        value={measurePoints[1]?.lng || ""}
                        onChange={(e) => {
                          const newPoints = [...measurePoints];
                          newPoints[1] = { ...newPoints[1], lng: parseFloat(e.target.value) || 0 };
                          setMeasurePoints(newPoints);
                        }}
                        className="bg-white/10 border-white/20 text-white"
                        data-testid="input-measure-lng2"
                      />
                    </div>
                  </div>
                </div>
                
                <button
                  onClick={() => {
                    const dist = haversineDistance(
                      measurePoints[0].lat, measurePoints[0].lng,
                      measurePoints[1].lat, measurePoints[1].lng
                    );
                    setMeasureResult({
                      type: 'distance',
                      meters: dist,
                      kilometers: dist / 1000
                    });
                  }}
                  className="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-semibold transition"
                  data-testid="button-calculate-distance"
                >
                  {language === 'ar' ? 'حساب المسافة' : 'Calculate Distance'}
                </button>
              </div>
            )}

            {measureMode === "area" && (
              <div className="space-y-4">
                <p className="text-gray-400 text-sm">{language === 'ar' ? 'أضف 3 نقاط على الأقل لحساب المساحة' : 'Add at least 3 points to calculate area'}</p>
                
                <div className="space-y-3">
                  {measurePoints.map((point, index) => (
                    <div key={index} className="bg-black/20 p-3 rounded-xl">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-white font-semibold">{language === 'ar' ? `النقطة ${index + 1}` : `Point ${index + 1}`}</h3>
                        {measurePoints.length > 3 && (
                          <button
                            onClick={() => {
                              const newPoints = measurePoints.filter((_, i) => i !== index);
                              setMeasurePoints(newPoints);
                            }}
                            className="p-1 bg-red-500/20 hover:bg-red-500/40 rounded text-red-400"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label className="text-gray-300 text-xs">{language === 'ar' ? 'خط العرض' : 'Lat'}</Label>
                          <Input
                            type="number"
                            step="0.000001"
                            placeholder="24.7136"
                            value={point.lat || ""}
                            onChange={(e) => {
                              const newPoints = [...measurePoints];
                              newPoints[index] = { ...newPoints[index], lat: parseFloat(e.target.value) || 0 };
                              setMeasurePoints(newPoints);
                            }}
                            className="bg-white/10 border-white/20 text-white text-sm"
                          />
                        </div>
                        <div>
                          <Label className="text-gray-300 text-xs">{language === 'ar' ? 'خط الطول' : 'Lng'}</Label>
                          <Input
                            type="number"
                            step="0.000001"
                            placeholder="46.6753"
                            value={point.lng || ""}
                            onChange={(e) => {
                              const newPoints = [...measurePoints];
                              newPoints[index] = { ...newPoints[index], lng: parseFloat(e.target.value) || 0 };
                              setMeasurePoints(newPoints);
                            }}
                            className="bg-white/10 border-white/20 text-white text-sm"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <button
                  onClick={() => {
                    setMeasurePoints([...measurePoints, { lat: 0, lng: 0 }]);
                  }}
                  className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  {language === 'ar' ? 'إضافة نقطة' : 'Add Point'}
                </button>
                
                <button
                  onClick={() => {
                    if (measurePoints.length < 3) {
                      toast.error(language === 'ar' ? 'يرجى إضافة 3 نقاط على الأقل' : 'Please add at least 3 points');
                      return;
                    }
                    const area = shoelaceArea(measurePoints);
                    setMeasureResult({
                      type: 'area',
                      squareMeters: area,
                      hectares: area / 10000
                    });
                  }}
                  className="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-semibold transition"
                  data-testid="button-calculate-area"
                >
                  {language === 'ar' ? 'حساب المساحة' : 'Calculate Area'}
                </button>
              </div>
            )}

            {measureMode === "slope" && (
              <div className="space-y-4">
                <p className="text-gray-400 text-sm">{language === 'ar' ? 'أدخل إحداثيات نقطتين مع الارتفاع لحساب الميل' : 'Enter coordinates of two points with elevation to calculate slope'}</p>
                
                <div className="bg-black/20 p-4 rounded-xl">
                  <h3 className="text-white font-semibold mb-3">{language === 'ar' ? 'النقطة الأولى' : 'Point 1'}</h3>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <Label className="text-gray-300 text-xs">{language === 'ar' ? 'خط العرض' : 'Lat'}</Label>
                      <Input
                        type="number"
                        step="0.000001"
                        placeholder="24.7136"
                        value={measurePoints[0]?.lat || ""}
                        onChange={(e) => {
                          const newPoints = [...measurePoints];
                          newPoints[0] = { ...newPoints[0], lat: parseFloat(e.target.value) || 0 };
                          setMeasurePoints(newPoints);
                        }}
                        className="bg-white/10 border-white/20 text-white text-sm"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-300 text-xs">{language === 'ar' ? 'خط الطول' : 'Lng'}</Label>
                      <Input
                        type="number"
                        step="0.000001"
                        placeholder="46.6753"
                        value={measurePoints[0]?.lng || ""}
                        onChange={(e) => {
                          const newPoints = [...measurePoints];
                          newPoints[0] = { ...newPoints[0], lng: parseFloat(e.target.value) || 0 };
                          setMeasurePoints(newPoints);
                        }}
                        className="bg-white/10 border-white/20 text-white text-sm"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-300 text-xs">{language === 'ar' ? 'الارتفاع (م)' : 'Elev (m)'}</Label>
                      <Input
                        type="number"
                        step="0.1"
                        placeholder="100"
                        value={slopeElevations.elev1 || ""}
                        onChange={(e) => setSlopeElevations({ ...slopeElevations, elev1: parseFloat(e.target.value) || 0 })}
                        className="bg-white/10 border-white/20 text-white text-sm"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="bg-black/20 p-4 rounded-xl">
                  <h3 className="text-white font-semibold mb-3">{language === 'ar' ? 'النقطة الثانية' : 'Point 2'}</h3>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <Label className="text-gray-300 text-xs">{language === 'ar' ? 'خط العرض' : 'Lat'}</Label>
                      <Input
                        type="number"
                        step="0.000001"
                        placeholder="24.7236"
                        value={measurePoints[1]?.lat || ""}
                        onChange={(e) => {
                          const newPoints = [...measurePoints];
                          newPoints[1] = { ...newPoints[1], lat: parseFloat(e.target.value) || 0 };
                          setMeasurePoints(newPoints);
                        }}
                        className="bg-white/10 border-white/20 text-white text-sm"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-300 text-xs">{language === 'ar' ? 'خط الطول' : 'Lng'}</Label>
                      <Input
                        type="number"
                        step="0.000001"
                        placeholder="46.6853"
                        value={measurePoints[1]?.lng || ""}
                        onChange={(e) => {
                          const newPoints = [...measurePoints];
                          newPoints[1] = { ...newPoints[1], lng: parseFloat(e.target.value) || 0 };
                          setMeasurePoints(newPoints);
                        }}
                        className="bg-white/10 border-white/20 text-white text-sm"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-300 text-xs">{language === 'ar' ? 'الارتفاع (م)' : 'Elev (m)'}</Label>
                      <Input
                        type="number"
                        step="0.1"
                        placeholder="120"
                        value={slopeElevations.elev2 || ""}
                        onChange={(e) => setSlopeElevations({ ...slopeElevations, elev2: parseFloat(e.target.value) || 0 })}
                        className="bg-white/10 border-white/20 text-white text-sm"
                      />
                    </div>
                  </div>
                </div>
                
                <button
                  onClick={() => {
                    const horizontalDist = haversineDistance(
                      measurePoints[0].lat, measurePoints[0].lng,
                      measurePoints[1].lat, measurePoints[1].lng
                    );
                    const slope = calculateSlope(horizontalDist, slopeElevations.elev1, slopeElevations.elev2);
                    setMeasureResult({
                      type: 'slope',
                      horizontalDistance: horizontalDist,
                      ...slope
                    });
                  }}
                  className="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-semibold transition"
                  data-testid="button-calculate-slope"
                >
                  {language === 'ar' ? 'حساب الميل' : 'Calculate Slope'}
                </button>
              </div>
            )}

            {measureMode === "gps" && (
              <div className="space-y-4">
                <p className="text-gray-400 text-sm">{language === 'ar' ? 'احصل على إحداثيات موقعك الحالي' : 'Get your current location coordinates'}</p>
                
                <button
                  onClick={() => {
                    if (!navigator.geolocation) {
                      toast.error(language === 'ar' ? 'المتصفح لا يدعم GPS' : 'Browser does not support GPS');
                      return;
                    }
                    setGpsLoading(true);
                    navigator.geolocation.getCurrentPosition(
                      (position) => {
                        setUserLocation({
                          lat: position.coords.latitude,
                          lng: position.coords.longitude,
                          accuracy: position.coords.accuracy,
                          altitude: position.coords.altitude
                        });
                        setGpsLoading(false);
                        toast.success(language === 'ar' ? 'تم الحصول على الموقع' : 'Location obtained');
                      },
                      (error) => {
                        setGpsLoading(false);
                        toast.error(language === 'ar' ? 'فشل في الحصول على الموقع' : 'Failed to get location');
                      },
                      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
                    );
                  }}
                  disabled={gpsLoading}
                  className="w-full py-4 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white rounded-xl font-semibold transition flex items-center justify-center gap-2"
                  data-testid="button-get-gps"
                >
                  {gpsLoading ? (
                    <>
                      <span className="animate-spin">⏳</span>
                      {language === 'ar' ? 'جاري تحديد الموقع...' : 'Getting location...'}
                    </>
                  ) : (
                    <>
                      <span>📍</span>
                      {language === 'ar' ? 'احصل على موقعك' : 'Get Your Location'}
                    </>
                  )}
                </button>
                
                {userLocation && (
                  <div className="bg-gradient-to-r from-blue-600/20 to-cyan-600/20 p-4 rounded-xl border border-blue-500/30 space-y-3">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-black/20 p-3 rounded-lg">
                        <p className="text-gray-400 text-xs mb-1">{language === 'ar' ? 'خط العرض' : 'Latitude'}</p>
                        <p className="text-white font-mono text-lg">{userLocation.lat.toFixed(6)}</p>
                      </div>
                      <div className="bg-black/20 p-3 rounded-lg">
                        <p className="text-gray-400 text-xs mb-1">{language === 'ar' ? 'خط الطول' : 'Longitude'}</p>
                        <p className="text-white font-mono text-lg">{userLocation.lng.toFixed(6)}</p>
                      </div>
                      <div className="bg-black/20 p-3 rounded-lg">
                        <p className="text-gray-400 text-xs mb-1">{language === 'ar' ? 'الدقة' : 'Accuracy'}</p>
                        <p className="text-white font-mono">±{userLocation.accuracy.toFixed(1)} {language === 'ar' ? 'م' : 'm'}</p>
                      </div>
                      <div className="bg-black/20 p-3 rounded-lg">
                        <p className="text-gray-400 text-xs mb-1">{language === 'ar' ? 'الارتفاع' : 'Altitude'}</p>
                        <p className="text-white font-mono">{userLocation.altitude ? `${userLocation.altitude.toFixed(1)} ${language === 'ar' ? 'م' : 'm'}` : 'N/A'}</p>
                      </div>
                    </div>
                    
                    <button
                      onClick={() => {
                        const coordText = `${userLocation.lat.toFixed(6)}, ${userLocation.lng.toFixed(6)}`;
                        navigator.clipboard.writeText(coordText);
                        toast.success(language === 'ar' ? 'تم نسخ الإحداثيات' : 'Coordinates copied');
                      }}
                      className="w-full py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg font-semibold transition flex items-center justify-center gap-2"
                      data-testid="button-copy-coords"
                    >
                      <Copy className="w-4 h-4" />
                      {language === 'ar' ? 'نسخ الإحداثيات' : 'Copy Coordinates'}
                    </button>
                  </div>
                )}
              </div>
            )}

            {measureResult && measureResult.type === 'distance' && (
              <div className="bg-gradient-to-r from-green-600/20 to-emerald-600/20 p-4 rounded-xl border border-green-500/30">
                <h3 className="text-green-400 font-bold mb-3">✅ {language === 'ar' ? 'نتيجة المسافة' : 'Distance Result'}</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <p className="text-3xl font-bold text-white">{measureResult.meters.toFixed(2)}</p>
                    <p className="text-gray-400">{language === 'ar' ? 'متر' : 'meters'}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-3xl font-bold text-white">{measureResult.kilometers.toFixed(4)}</p>
                    <p className="text-gray-400">{language === 'ar' ? 'كيلومتر' : 'km'}</p>
                  </div>
                </div>
              </div>
            )}

            {measureResult && measureResult.type === 'area' && (
              <div className="bg-gradient-to-r from-green-600/20 to-emerald-600/20 p-4 rounded-xl border border-green-500/30">
                <h3 className="text-green-400 font-bold mb-3">✅ {language === 'ar' ? 'نتيجة المساحة' : 'Area Result'}</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <p className="text-3xl font-bold text-white">{measureResult.squareMeters.toFixed(2)}</p>
                    <p className="text-gray-400">{language === 'ar' ? 'متر مربع' : 'm²'}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-3xl font-bold text-white">{measureResult.hectares.toFixed(4)}</p>
                    <p className="text-gray-400">{language === 'ar' ? 'هكتار' : 'hectares'}</p>
                  </div>
                </div>
              </div>
            )}

            {measureResult && measureResult.type === 'slope' && (
              <div className="bg-gradient-to-r from-green-600/20 to-emerald-600/20 p-4 rounded-xl border border-green-500/30">
                <h3 className="text-green-400 font-bold mb-3">✅ {language === 'ar' ? 'نتيجة الميل' : 'Slope Result'}</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-black/20 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-xs mb-1">{language === 'ar' ? 'المسافة الأفقية' : 'Horizontal Distance'}</p>
                    <p className="text-white font-bold">{measureResult.horizontalDistance.toFixed(2)} {language === 'ar' ? 'م' : 'm'}</p>
                  </div>
                  <div className="bg-black/20 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-xs mb-1">{language === 'ar' ? 'فرق الارتفاع' : 'Elevation Diff'}</p>
                    <p className="text-white font-bold">{measureResult.elevDiff.toFixed(2)} {language === 'ar' ? 'م' : 'm'}</p>
                  </div>
                  <div className="bg-black/20 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-xs mb-1">{language === 'ar' ? 'نسبة الميل' : 'Slope %'}</p>
                    <p className="text-white font-bold">{measureResult.slopePercent.toFixed(2)}%</p>
                  </div>
                  <div className="bg-black/20 p-3 rounded-lg text-center">
                    <p className="text-gray-400 text-xs mb-1">{language === 'ar' ? 'زاوية الميل' : 'Slope Angle'}</p>
                    <p className="text-white font-bold">{measureResult.slopeAngle.toFixed(2)}°</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {(calcType === "area" || calcType === "volume") && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
            <h2 className="text-xl font-bold text-white mb-4">🔷 اختر الشكل</h2>
            <div className="grid grid-cols-3 md:grid-cols-5 gap-2">
              {calcType === "area" ? (
                <>
                  {[
                    { id: "rectangle", icon: "▬", label: "مستطيل" },
                    { id: "circle", icon: "●", label: "دائرة" },
                    { id: "triangle", icon: "▲", label: "مثلث" },
                    { id: "trapezoid", icon: "⏢", label: "شبه منحرف" },
                    { id: "hexagon", icon: "⬡", label: "سداسي" }
                  ].map((shape) => (
                    <button
                      key={shape.id}
                      onClick={() => setShapeType(shape.id as ShapeType)}
                      className={`px-3 py-3 rounded-xl font-medium transition text-center ${
                        shapeType === shape.id
                          ? 'bg-cyan-600 text-white'
                          : 'bg-white/5 text-gray-300 hover:bg-white/15'
                      }`}
                    >
                      <span className="text-xl block mb-1">{shape.icon}</span>
                      <span className="text-xs">{shape.label}</span>
                    </button>
                  ))}
                </>
              ) : (
                <>
                  {[
                    { id: "cube", icon: "🧊", label: "مكعب" },
                    { id: "cylinder", icon: "🥫", label: "أسطوانة" },
                    { id: "sphere", icon: "🔮", label: "كرة" }
                  ].map((shape) => (
                    <button
                      key={shape.id}
                      onClick={() => setShapeType(shape.id as ShapeType)}
                      className={`px-3 py-3 rounded-xl font-medium transition text-center ${
                        shapeType === shape.id
                          ? 'bg-cyan-600 text-white'
                          : 'bg-white/5 text-gray-300 hover:bg-white/15'
                      }`}
                    >
                      <span className="text-xl block mb-1">{shape.icon}</span>
                      <span className="text-xs">{shape.label}</span>
                    </button>
                  ))}
                </>
              )}
            </div>
          </div>
        )}

        {calcType === "polygon" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
            <h2 className="text-xl font-bold text-white mb-4">⬡ حساب مساحة المضلع</h2>
            <p className="text-gray-400 mb-4">أضف نقاط المضلع بالترتيب (3 نقاط على الأقل)</p>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <Label className="text-gray-300">X</Label>
                <Input
                  type="number"
                  placeholder="0"
                  value={inputs[`px${pointCount}`] || ""}
                  onChange={(e) => handleInputChange(`px${pointCount}`, e.target.value)}
                  className="bg-white/10 border-white/20 text-white"
                />
              </div>
              <div>
                <Label className="text-gray-300">Y</Label>
                <Input
                  type="number"
                  placeholder="0"
                  value={inputs[`py${pointCount}`] || ""}
                  onChange={(e) => handleInputChange(`py${pointCount}`, e.target.value)}
                  className="bg-white/10 border-white/20 text-white"
                />
              </div>
            </div>
            
            <button
              onClick={addPolygonPoint}
              className="w-full py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold transition flex items-center justify-center gap-2 mb-4"
            >
              <Plus className="w-4 h-4" />
              إضافة نقطة
            </button>

            {polygonPoints.length > 0 && (
              <div className="space-y-2 mb-4">
                {polygonPoints.map((point, index) => (
                  <div key={point.id} className="flex items-center justify-between bg-black/20 p-3 rounded-lg">
                    <span className="text-white">النقطة {index + 1}: ({point.x}, {point.y})</span>
                    <button
                      onClick={() => removePolygonPoint(point.id)}
                      className="p-1 bg-red-500/20 hover:bg-red-500/40 rounded text-red-400"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {(calcType === "area" || calcType === "volume" || calcType === "length") && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
            <h2 className="text-xl font-bold text-white mb-4">📝 أدخل القيم</h2>
            <div className="grid grid-cols-2 gap-4">
              {renderInputs()}
            </div>
          </div>
        )}

        {calcType === "advanced" && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
            <h2 className="text-xl font-bold text-white mb-4">🔬 حسابات متقدمة</h2>
            <div className="grid grid-cols-3 gap-2 mb-4">
              {[
                { id: "triangle", label: "مثلث (هيرون)" },
                { id: "ellipse", label: "إهليلج" },
                { id: "hexagon", label: "سداسي منتظم" }
              ].map((shape) => (
                <button
                  key={shape.id}
                  onClick={() => setShapeType(shape.id as ShapeType)}
                  className={`px-3 py-2 rounded-lg font-medium transition ${
                    shapeType === shape.id
                      ? 'bg-purple-600 text-white'
                      : 'bg-white/5 text-gray-300 hover:bg-white/15'
                  }`}
                >
                  {shape.label}
                </button>
              ))}
            </div>

            {shapeType === "triangle" && (
              <div className="grid grid-cols-3 gap-4">
                {[0, 1, 2].map((i) => (
                  <div key={i}>
                    <Label className="text-gray-300">الضلع {i + 1} (م)</Label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={heronSides[i] || ""}
                      onChange={(e) => {
                        const newSides = [...heronSides] as [number | null, number | null, number | null];
                        newSides[i] = parseFloat(e.target.value) || null;
                        setHeronSides(newSides);
                      }}
                      className="bg-white/10 border-white/20 text-white"
                    />
                  </div>
                ))}
              </div>
            )}

            {shapeType === "ellipse" && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">نصف المحور الأكبر (م)</Label>
                  <Input
                    type="number"
                    placeholder="0"
                    value={inputs.semiMajor || ""}
                    onChange={(e) => handleInputChange("semiMajor", e.target.value)}
                    className="bg-white/10 border-white/20 text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">نصف المحور الأصغر (م)</Label>
                  <Input
                    type="number"
                    placeholder="0"
                    value={inputs.semiMinor || ""}
                    onChange={(e) => handleInputChange("semiMinor", e.target.value)}
                    className="bg-white/10 border-white/20 text-white"
                  />
                </div>
              </div>
            )}

            {shapeType === "hexagon" && (
              <div>
                <Label className="text-gray-300">طول الضلع (م)</Label>
                <Input
                  type="number"
                  placeholder="0"
                  value={inputs.side1 || ""}
                  onChange={(e) => handleInputChange("side1", e.target.value)}
                  className="bg-white/10 border-white/20 text-white"
                />
              </div>
            )}
          </div>
        )}

        <button
          onClick={calculate}
          className="w-full py-4 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-xl font-bold text-lg transition shadow-lg"
          data-testid="button-calculate"
        >
          <Calculator className="w-5 h-5 inline-block ml-2" />
          احسب الآن
        </button>

        {result !== null && (
          <div className="bg-gradient-to-r from-green-600/20 to-emerald-600/20 backdrop-blur-md rounded-2xl p-6 border border-green-500/30">
            <h2 className="text-xl font-bold text-green-400 mb-4">✅ النتيجة</h2>
            <div className="text-center">
              <p className="text-4xl font-bold text-white mb-2">
                {result.toFixed(4)}
                <span className="text-xl text-gray-400 mr-2">
                  {calcType === "area" || calcType === "polygon" || calcType === "advanced" ? "م²" : calcType === "volume" ? "م³" : "م"}
                </span>
              </p>
              {perimeter !== null && (
                <p className="text-lg text-gray-300">
                  المحيط: {perimeter.toFixed(4)} م
                </p>
              )}
            </div>
          </div>
        )}

        <Link href="/">
          <button className="w-full py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-semibold transition flex items-center justify-center gap-2">
            العودة للرئيسية
            <ArrowRight className="w-5 h-5" />
          </button>
        </Link>
      </div>
    </div>
  );
}
