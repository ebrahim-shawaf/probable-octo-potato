import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
      <Card className="w-full max-w-md mx-4 bg-slate-800 border-slate-700">
        <CardContent className="pt-6">
          <div className="flex mb-4 gap-2">
            <AlertCircle className="h-8 w-8 text-red-500" />
            <h1 className="text-2xl font-bold text-white">404 - الصفحة غير موجودة</h1>
          </div>

          <p className="mt-4 text-sm text-gray-300">
            عذراً، الصفحة التي تبحث عنها غير موجودة. يرجى العودة إلى الصفحة الرئيسية.
          </p>

          <Link href="/" className="mt-6 block">
            <Button className="w-full" data-testid="button-home">
              العودة للرئيسية
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
