import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Settings, Plus, Save, Download, Users } from "lucide-react";
import type { District, Candidate, InsertVote, InsertVoter } from "@shared/schema";

async function fetchData() {
  const [districtsRes, candidatesRes, votesRes] = await Promise.all([
    fetch("/api/districts"),
    fetch("/api/candidates"),
    fetch("/api/votes"),
  ]);

  return {
    districts: (await districtsRes.json()) as District[],
    candidates: (await candidatesRes.json()) as Candidate[],
    votes: await votesRes.json(),
  };
}

const ADMIN_KEY = "demo-admin-key-2024"; // In production, store securely

async function createCandidate(data: { name: string; party: string; color: string }) {
  const res = await fetch("/api/candidates", {
    method: "POST",
    headers: { 
      "Content-Type": "application/json",
      "x-admin-key": ADMIN_KEY,
    },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const error = await res.json();
    throw new Error(error.message || "Failed to create candidate");
  }
  return res.json();
}

async function upsertVote(data: InsertVote) {
  const res = await fetch("/api/votes", {
    method: "POST",
    headers: { 
      "Content-Type": "application/json",
      "x-admin-key": ADMIN_KEY,
    },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const error = await res.json();
    throw new Error(error.message || "Failed to save vote");
  }
  return res.json();
}

async function createVoter(data: InsertVoter) {
  const res = await fetch("/api/voters", {
    method: "POST",
    headers: { 
      "Content-Type": "application/json",
      "x-admin-key": ADMIN_KEY,
    },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const error = await res.json();
    throw new Error(error.message || "Failed to add voter");
  }
  return res.json();
}

export default function Admin() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin-data"],
    queryFn: fetchData,
  });

  const [newCandidate, setNewCandidate] = useState({
    name: "",
    party: "",
    color: "#3b82f6",
  });

  const [voteEntry, setVoteEntry] = useState({
    districtId: "",
    candidateId: "",
    voteCount: 0,
  });

  const [voterEntry, setVoterEntry] = useState({
    name: "",
    districtId: "",
    pollingStation: "",
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importResult, setImportResult] = useState<{success: boolean; imported: number; failed: number; message: string; errors?: string[]} | null>(null);

  const importVotersFromCSV = async (csvContent: string) => {
    setIsImporting(true);
    try {
      const res = await fetch("/api/voters/import", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-key": ADMIN_KEY,
        },
        body: JSON.stringify({ csvData: csvContent }),
      });
      
      const result = await res.json();
      setImportResult(result);
      
      if (result.success) {
        toast.success(`تم استيراد ${result.imported} ناخب بنجاح${result.failed > 0 ? ` (${result.failed} فشل)` : ''}`);
        queryClient.invalidateQueries({ queryKey: ["voters"] });
      } else {
        toast.error(result.message || "فشل الاستيراد");
      }
    } catch (error: any) {
      toast.error(error.message || "خطأ في الاستيراد");
    } finally {
      setIsImporting(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        importVotersFromCSV(content);
      };
      reader.readAsText(file);
    }
  };

  const downloadVoterData = async () => {
    try {
      const response = await fetch("/api/export/votes");
      if (!response.ok) {
        toast.error("فشل في تحميل البيانات");
        return;
      }
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `voter_data_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast.success("تم تحميل البيانات بنجاح");
    } catch (error) {
      toast.error("خطأ في تحميل البيانات");
    }
  };

  const generatePredictions = async () => {
    setIsGenerating(true);
    try {
      const res = await fetch("/api/predictions/generate", {
        method: "POST",
        headers: { "x-admin-key": ADMIN_KEY },
      });
      if (res.ok) {
        queryClient.invalidateQueries({ queryKey: ["predictions"] });
        toast.success("تم توليد التنبؤات بنجاح!");
      } else {
        toast.error("فشل في توليد التنبؤات");
      }
    } catch (error) {
      toast.error("خطأ في توليد التنبؤات");
    } finally {
      setIsGenerating(false);
    }
  };

  const createCandidateMutation = useMutation({
    mutationFn: createCandidate,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-data"] });
      queryClient.invalidateQueries({ queryKey: ["election-results"] });
      toast.success("تم إضافة المرشح بنجاح");
      setNewCandidate({ name: "", party: "", color: "#3b82f6" });
    },
    onError: () => {
      toast.error("فشل في إضافة المرشح");
    },
  });

  const upsertVoteMutation = useMutation({
    mutationFn: upsertVote,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-data"] });
      queryClient.invalidateQueries({ queryKey: ["election-results"] });
      toast.success("تم حفظ النتيجة بنجاح");
    },
    onError: () => {
      toast.error("فشل في حفظ النتيجة");
    },
  });

  const createVoterMutation = useMutation({
    mutationFn: createVoter,
    onSuccess: () => {
      toast.success("تم إضافة الناخب بنجاح");
      setVoterEntry({
        name: "",
        districtId: "",
        pollingStation: "",
      });
    },
    onError: (error: any) => {
      toast.error(error.message || "فشل في إضافة الناخب");
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-xl">جاري التحميل...</div>
      </div>
    );
  }

  const { districts, candidates } = data!;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card to-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground py-8 px-6 shadow-xl">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center gap-4 mb-2">
            <Settings className="w-10 h-10" />
            <h1 className="text-4xl font-bold" data-testid="admin-title">
              لوحة التحكم
            </h1>
          </div>
          <p className="text-primary-foreground/80 text-lg">
            إدارة المرشحين والنتائج الانتخابية
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto p-6 space-y-6">
        {/* Add Candidate */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl font-bold flex items-center gap-2">
              <Plus className="w-6 h-6" />
              إضافة مرشح جديد
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="candidate-name">اسم المرشح</Label>
                <Input
                  id="candidate-name"
                  data-testid="input-candidate-name"
                  placeholder="أدخل اسم المرشح"
                  value={newCandidate.name}
                  onChange={(e) =>
                    setNewCandidate({ ...newCandidate, name: e.target.value })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="candidate-party">الحزب</Label>
                <Input
                  id="candidate-party"
                  data-testid="input-candidate-party"
                  placeholder="أدخل اسم الحزب"
                  value={newCandidate.party}
                  onChange={(e) =>
                    setNewCandidate({ ...newCandidate, party: e.target.value })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="candidate-color">اللون</Label>
                <Input
                  id="candidate-color"
                  data-testid="input-candidate-color"
                  type="color"
                  value={newCandidate.color}
                  onChange={(e) =>
                    setNewCandidate({ ...newCandidate, color: e.target.value })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label>&nbsp;</Label>
                <Button
                  data-testid="button-add-candidate"
                  onClick={() => createCandidateMutation.mutate(newCandidate)}
                  disabled={!newCandidate.name || !newCandidate.party}
                  className="w-full"
                >
                  <Plus className="w-4 h-4 ml-2" />
                  إضافة
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Add Voter */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl font-bold flex items-center gap-2">
              <Users className="w-6 h-6" />
              إضافة ناخب
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="voter-name">الاسم</Label>
                <Input
                  id="voter-name"
                  data-testid="input-voter-name"
                  placeholder="أدخل اسم الناخب"
                  value={voterEntry.name}
                  onChange={(e) =>
                    setVoterEntry({ ...voterEntry, name: e.target.value })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="voter-district">المحافظة</Label>
                <Select
                  value={voterEntry.districtId}
                  onValueChange={(value) =>
                    setVoterEntry({ ...voterEntry, districtId: value })
                  }
                >
                  <SelectTrigger id="voter-district" data-testid="select-voter-district">
                    <SelectValue placeholder="اختر المحافظة" />
                  </SelectTrigger>
                  <SelectContent>
                    {districts.map((district) => (
                      <SelectItem key={district.id} value={district.id}>
                        {district.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="voter-station">مكان اللجنة</Label>
                <Input
                  id="voter-station"
                  data-testid="input-voter-station"
                  placeholder="اسم اللجنة أو المدرسة"
                  value={voterEntry.pollingStation}
                  onChange={(e) =>
                    setVoterEntry({ ...voterEntry, pollingStation: e.target.value })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label>&nbsp;</Label>
                <Button
                  data-testid="button-add-voter"
                  onClick={() => createVoterMutation.mutate(voterEntry)}
                  disabled={
                    !voterEntry.name ||
                    !voterEntry.districtId ||
                    !voterEntry.pollingStation
                  }
                  className="w-full"
                >
                  <Plus className="w-4 h-4 ml-2" />
                  إضافة
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Enter Vote Results */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl font-bold flex items-center gap-2">
              <Save className="w-6 h-6" />
              إدخال النتائج
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="vote-district">المحافظة</Label>
                <Select
                  value={voteEntry.districtId}
                  onValueChange={(value) =>
                    setVoteEntry({ ...voteEntry, districtId: value })
                  }
                >
                  <SelectTrigger id="vote-district" data-testid="select-district">
                    <SelectValue placeholder="اختر المحافظة" />
                  </SelectTrigger>
                  <SelectContent>
                    {districts.map((district) => (
                      <SelectItem key={district.id} value={district.id}>
                        {district.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="vote-candidate">المرشح</Label>
                <Select
                  value={voteEntry.candidateId}
                  onValueChange={(value) =>
                    setVoteEntry({ ...voteEntry, candidateId: value })
                  }
                >
                  <SelectTrigger id="vote-candidate" data-testid="select-candidate">
                    <SelectValue placeholder="اختر المرشح" />
                  </SelectTrigger>
                  <SelectContent>
                    {candidates.map((candidate) => (
                      <SelectItem key={candidate.id} value={candidate.id}>
                        {candidate.name} ({candidate.party})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="vote-count">عدد الأصوات</Label>
                <Input
                  id="vote-count"
                  data-testid="input-vote-count"
                  type="number"
                  min="0"
                  placeholder="0"
                  value={voteEntry.voteCount || ""}
                  onChange={(e) =>
                    setVoteEntry({
                      ...voteEntry,
                      voteCount: parseInt(e.target.value) || 0,
                    })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label>&nbsp;</Label>
                <Button
                  data-testid="button-save-vote"
                  onClick={() => upsertVoteMutation.mutate(voteEntry)}
                  disabled={
                    !voteEntry.districtId ||
                    !voteEntry.candidateId ||
                    voteEntry.voteCount <= 0
                  }
                  className="w-full"
                >
                  <Save className="w-4 h-4 ml-2" />
                  حفظ
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Import Voters */}
        <Card className="shadow-xl border-2 border-purple-200 bg-purple-50">
          <CardHeader>
            <CardTitle className="text-2xl font-bold flex items-center gap-2">
              📤 استيراد الناخبين
            </CardTitle>
            <p className="text-sm text-muted-foreground mt-2">
              استيراد الناخبين من ملف CSV (name, district, polling_station)
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label htmlFor="csv-upload" className="block text-sm font-medium mb-2">
                اختر ملف CSV
              </label>
              <input
                id="csv-upload"
                data-testid="input-import-voters"
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                disabled={isImporting}
                className="block w-full text-sm text-gray-500
                  file:mr-4 file:py-2 file:px-4
                  file:rounded-full file:border-0
                  file:text-sm file:font-semibold
                  file:bg-purple-600 file:text-white
                  hover:file:bg-purple-700 file:cursor-pointer file:disabled:bg-gray-300"
              />
            </div>
            {importResult && (
              <div className={`p-3 rounded-lg ${importResult.success ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                <p className="font-semibold">{importResult.message}</p>
                {importResult.errors && importResult.errors.length > 0 && (
                  <ul className="mt-2 text-sm list-disc list-inside">
                    {importResult.errors.slice(0, 3).map((err, idx) => (
                      <li key={idx}>{err}</li>
                    ))}
                    {importResult.errors.length > 3 && (
                      <li>...و {importResult.errors.length - 3} أخطاء أخرى</li>
                    )}
                  </ul>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Export & Predictions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Download Vote Results */}
          <Card className="shadow-xl border-2 border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="text-2xl font-bold flex items-center gap-2">
                <Download className="w-6 h-6" />
                تحميل النتائج
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-2">
                تحميل نتائج الأصوات بصيغة CSV
              </p>
            </CardHeader>
            <CardContent>
              <Button
                data-testid="button-download-votes"
                onClick={downloadVoterData}
                className="w-full bg-blue-600 text-white hover:bg-blue-700"
                size="lg"
              >
                <Download className="w-4 h-4 ml-2" />
                تحميل النتائج
              </Button>
            </CardContent>
          </Card>

          {/* Download Voters Data */}
          <Card className="shadow-xl border-2 border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="text-2xl font-bold flex items-center gap-2">
                <Download className="w-6 h-6" />
                تحميل الناخبين
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-2">
                تحميل بيانات الناخبين بصيغة CSV
              </p>
            </CardHeader>
            <CardContent>
              <Button
                data-testid="button-download-voters"
                onClick={async () => {
                  try {
                    const response = await fetch("/api/export/voters");
                    if (!response.ok) {
                      toast.error("فشل في تحميل البيانات");
                      return;
                    }
                    const blob = await response.blob();
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement("a");
                    a.href = url;
                    a.download = `voters_${new Date().toISOString().split('T')[0]}.csv`;
                    document.body.appendChild(a);
                    a.click();
                    window.URL.revokeObjectURL(url);
                    document.body.removeChild(a);
                    toast.success("تم تحميل البيانات بنجاح");
                  } catch (error) {
                    toast.error("خطأ في تحميل البيانات");
                  }
                }}
                className="w-full bg-green-600 text-white hover:bg-green-700"
                size="lg"
              >
                <Download className="w-4 h-4 ml-2" />
                تحميل الناخبين
              </Button>
            </CardContent>
          </Card>

          {/* Generate Predictions */}
          <Card className="shadow-xl border-2 border-accent/20 bg-accent/5">
            <CardHeader>
              <CardTitle className="text-2xl font-bold flex items-center gap-2">
                🤖 توليد التنبؤات
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-2">
                توليد توقعات تلقائية بناءً على الأصوات الفعلية الحالية
              </p>
            </CardHeader>
            <CardContent>
              <Button
                data-testid="button-generate-predictions"
                onClick={generatePredictions}
                disabled={isGenerating}
                className="w-full bg-accent text-accent-foreground hover:bg-accent/90"
                size="lg"
              >
                {isGenerating ? "جاري التوليد..." : "توليد التنبؤات الآن"}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Current Candidates */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl font-bold">المرشحون الحاليون</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {candidates.map((candidate) => (
                <Card
                  key={candidate.id}
                  className="border-2"
                  style={{ borderColor: candidate.color }}
                  data-testid={`candidate-card-${candidate.id}`}
                >
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-3">
                      <div
                        className="w-12 h-12 rounded-full flex-shrink-0"
                        style={{ backgroundColor: candidate.color }}
                      />
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-lg truncate">
                          {candidate.name}
                        </h3>
                        <p className="text-sm text-muted-foreground truncate">
                          {candidate.party}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
