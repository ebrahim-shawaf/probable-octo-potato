import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, Camera, Trash2, Copy } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";

interface MeasurePoint {
  id: number;
  x: number;
  y: number;
  label: string;
  distance?: number;
  coordinates?: { lat: number; lon: number };
}

interface Measurement {
  id: number;
  points: MeasurePoint[];
  distance?: number;
  area?: number;
  type: 'distance' | 'area' | 'angle';
  timestamp: Date;
}

export default function PrecisionCameraMeasurement() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [points, setPoints] = useState<MeasurePoint[]>([]);
  const [measurements, setMeasurements] = useState<Measurement[]>([]);
  const [selectedPoint, setSelectedPoint] = useState<number | null>(null);
  const [calibrationDistance, setCalibrationDistance] = useState(1);
  const [pixelsPerMeter, setPixelsPerMeter] = useState(1);
  const [measurementMode, setMeasurementMode] = useState<'distance' | 'area' | 'angle'>('distance');
  const [showResults, setShowResults] = useState(false);

  // بدء الكاميرا
  const startCamera = async () => {
    try {
      if (videoRef.current?.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach(track => track.stop());
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        
        // Wait for video metadata to load before playing
        const playVideo = async () => {
          try {
            await videoRef.current!.play();
            setCameraActive(true);
            toast.success('✅ تم تشغيل الكاميرا');
          } catch (playError) {
            console.error('Play error:', playError);
            toast.error('❌ خطأ في تشغيل الفيديو');
          }
        };
        
        // If metadata is already loaded, play immediately
        if (videoRef.current.readyState >= 1) {
          playVideo();
        } else {
          // Otherwise, wait for metadata
          videoRef.current.onloadedmetadata = playVideo;
        }
      }
    } catch (error) {
      console.error('Camera error:', error);
      toast.error('❌ لم يتمكن من الوصول إلى الكاميرا');
      setCameraActive(false);
    }
  };

  // إيقاف الكاميرا
  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
    }
    setCameraActive(false);
  };

  // معالجة النقر على الشاشة
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const newPoint: MeasurePoint = {
      id: Date.now(),
      x,
      y,
      label: `نقطة ${points.length + 1}`,
    };

    setPoints([...points, newPoint]);
    setSelectedPoint(newPoint.id);
  };

  // حساب المسافة بدقة عالية
  const calculateDistance = (p1: MeasurePoint, p2: MeasurePoint): number => {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const pixelDistance = Math.sqrt(dx * dx + dy * dy);
    return (pixelDistance / pixelsPerMeter);
  };

  // حساب المساحة بصيغة Shoelace
  const calculateArea = (pts: MeasurePoint[]): number => {
    if (pts.length < 3) return 0;
    let area = 0;
    for (let i = 0; i < pts.length; i++) {
      const p1 = pts[i];
      const p2 = pts[(i + 1) % pts.length];
      area += (p1.x * p2.y - p2.x * p1.y);
    }
    const pixelArea = Math.abs(area) / 2;
    return pixelArea / (pixelsPerMeter * pixelsPerMeter);
  };

  // حساب الزاوية
  const calculateAngle = (p1: MeasurePoint, p2: MeasurePoint, p3: MeasurePoint): number => {
    const dx1 = p1.x - p2.x;
    const dy1 = p1.y - p2.y;
    const dx2 = p3.x - p2.x;
    const dy2 = p3.y - p2.y;

    const dot = dx1 * dx2 + dy1 * dy2;
    const mag1 = Math.sqrt(dx1 * dx1 + dy1 * dy1);
    const mag2 = Math.sqrt(dx2 * dx2 + dy2 * dy2);

    const cosAngle = dot / (mag1 * mag2);
    const angle = Math.acos(Math.max(-1, Math.min(1, cosAngle)));
    return (angle * 180) / Math.PI;
  };

  // معايرة الكاميرا
  const handleCalibrate = () => {
    if (points.length < 2) {
      toast.error('❌ يرجى تحديد نقطتين لمعايرة الكاميرا');
      return;
    }

    const pixelDistance = Math.sqrt(
      Math.pow(points[1].x - points[0].x, 2) +
      Math.pow(points[1].y - points[0].y, 2)
    );

    const ratio = pixelDistance / calibrationDistance;
    setPixelsPerMeter(ratio);
    setPoints([]);
    toast.success(`✅ تم المعايرة: ${ratio.toFixed(2)} بكسل = ${calibrationDistance}م`);
  };

  // إضافة قياس
  const addMeasurement = () => {
    if (points.length < 2) {
      toast.error('❌ يرجى تحديد نقطتين على الأقل');
      return;
    }

    let distance: number | undefined;
    let area: number | undefined;
    let type: 'distance' | 'area' | 'angle' = 'distance';

    if (measurementMode === 'distance' && points.length >= 2) {
      distance = calculateDistance(points[0], points[1]);
      type = 'distance';
    } else if (measurementMode === 'area' && points.length >= 3) {
      area = calculateArea(points);
      type = 'area';
    }

    const measurement: Measurement = {
      id: Date.now(),
      points: [...points],
      distance,
      area,
      type,
      timestamp: new Date()
    };

    setMeasurements([...measurements, measurement]);
    setPoints([]);
    setShowResults(true);
    toast.success('✅ تم إضافة القياس بنجاح');
  };

  // حذف النقطة
  const deletePoint = (id: number) => {
    setPoints(points.filter(p => p.id !== id));
  };

  // حذف جميع النقاط
  const clearAllPoints = () => {
    setPoints([]);
    setSelectedPoint(null);
  };

  // نسخ النتائج
  const copyResults = () => {
    if (measurements.length === 0) return;
    const text = measurements
      .map((m, idx) => {
        if (m.distance) return `القياس ${idx + 1}: ${m.distance.toFixed(10)}م`;
        if (m.area) return `المساحة ${idx + 1}: ${m.area.toFixed(10)}م²`;
        return `القياس ${idx + 1}`;
      })
      .join('\n');
    navigator.clipboard.writeText(text);
    toast.success('✅ تم نسخ النتائج');
  };

  // رسم النقاط على الـ Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video || !cameraActive) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    
    const updateCanvasSize = () => {
      const container = canvas.parentElement;
      if (container) {
        const rect = container.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;
      } else {
        canvas.width = video.videoWidth || 1280;
        canvas.height = video.videoHeight || 720;
      }
    };

    updateCanvasSize();

    const drawFrame = () => {
      try {
        if (video.readyState >= 2) { // HAVE_CURRENT_DATA
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        } else {
          // Fill with black if video not ready
          ctx.fillStyle = '#000000';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }

        // رسم النقاط
        points.forEach((point, idx) => {
          const isSelected = selectedPoint === point.id;
          
          // دائرة النقطة
          ctx.fillStyle = isSelected ? '#ff6b6b' : '#4dabf7';
          ctx.beginPath();
          ctx.arc(point.x, point.y, 8, 0, Math.PI * 2);
          ctx.fill();

          // حد النقطة
          ctx.strokeStyle = isSelected ? '#ffff00' : '#ffffff';
          ctx.lineWidth = 3;
          ctx.stroke();

          // النص
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 14px Arial';
          ctx.textAlign = 'center';
          ctx.fillText(point.label, point.x, point.y - 20);
        });

        // رسم الخطوط بين النقاط
        if (points.length > 1) {
          ctx.strokeStyle = 'rgba(77, 171, 247, 0.5)';
          ctx.lineWidth = 2;
          ctx.setLineDash([5, 5]);
          for (let i = 0; i < points.length - 1; i++) {
            ctx.beginPath();
            ctx.moveTo(points[i].x, points[i].y);
            ctx.lineTo(points[i + 1].x, points[i + 1].y);
            ctx.stroke();
          }
          ctx.setLineDash([]);
        }

        // رسم المسافات
        if (measurementMode === 'distance' && points.length > 1) {
          const dist = calculateDistance(points[0], points[1]);
          const midX = (points[0].x + points[1].x) / 2;
          const midY = (points[0].y + points[1].y) / 2;

          ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
          ctx.fillRect(midX - 60, midY - 15, 120, 30);

          ctx.fillStyle = '#ffff00';
          ctx.font = 'bold 12px Arial';
          ctx.textAlign = 'center';
          ctx.fillText(`${dist.toFixed(4)}م`, midX, midY + 5);
        }
      } catch (error) {
        console.error('Canvas drawing error:', error);
      }

      animationId = requestAnimationFrame(drawFrame);
    };

    animationId = requestAnimationFrame(drawFrame);
    
    // Handle window resize
    const handleResize = () => updateCanvasSize();
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, [points, selectedPoint, cameraActive, measurementMode, pixelsPerMeter, calculateDistance]);

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 to-slate-800 text-white" data-testid="precision-camera-page">
      {/* Navigation */}
      <div className="sticky top-0 z-10 bg-black/30 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">🎯 كاميرا القياس الدقيقة</h1>
          <Link href="/camera-gps">
            <Button variant="ghost" className="text-white hover:bg-white/10" data-testid="button-back">
              <ArrowRight className="w-4 h-4 ml-2" />
              العودة
            </Button>
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Controls */}
        <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10 mb-6">
          <div className="grid md:grid-cols-6 gap-4 mb-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">نمط القياس</label>
              <select
                value={measurementMode}
                onChange={(e) => setMeasurementMode(e.target.value as any)}
                className="w-full bg-black/30 border border-blue-400/30 rounded-lg px-3 py-2 text-white"
                data-testid="select-mode"
              >
                <option value="distance">📏 المسافة</option>
                <option value="area">📐 المساحة</option>
                <option value="angle">🔢 الزاوية</option>
              </select>
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">معايرة (متر)</label>
              <input
                type="number"
                step="0.01"
                min="0.1"
                value={calibrationDistance}
                onChange={(e) => setCalibrationDistance(parseFloat(e.target.value))}
                className="w-full bg-black/30 border border-blue-400/30 rounded-lg px-3 py-2 text-white"
                data-testid="input-calibration"
              />
            </div>

            <div className="flex items-end gap-2">
              <Button
                onClick={startCamera}
                disabled={cameraActive}
                className="flex-1 bg-green-600 hover:bg-green-700"
                data-testid="button-start-camera"
              >
                <Camera className="w-4 h-4 ml-2" />
                بدء
              </Button>
            </div>

            <div className="flex items-end gap-2">
              <Button
                onClick={stopCamera}
                disabled={!cameraActive}
                className="flex-1 bg-red-600 hover:bg-red-700"
                data-testid="button-stop-camera"
              >
                إيقاف
              </Button>
            </div>

            <div className="flex items-end gap-2">
              <Button
                onClick={handleCalibrate}
                variant="secondary"
                className="flex-1"
                data-testid="button-calibrate"
              >
                معايرة
              </Button>
            </div>

            <div className="flex items-end gap-2">
              <Button
                onClick={addMeasurement}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
                data-testid="button-measure"
              >
                قياس
              </Button>
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={clearAllPoints}
              variant="outline"
              size="sm"
              className="flex-1 bg-red-900/20 hover:bg-red-900/40"
              data-testid="button-clear-points"
            >
              <Trash2 className="w-4 h-4 ml-2" />
              مسح النقاط
            </Button>
          </div>
        </div>

        {/* Camera View */}
        {cameraActive && (
          <div className="bg-black/30 rounded-xl border border-white/10 p-4 mb-6">
            <div className="relative w-full bg-black rounded-lg overflow-hidden" style={{ aspectRatio: "16 / 9" }}>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                style={{ display: 'none' }}
                onLoadedMetadata={() => {
                  if (canvasRef.current) {
                    const container = canvasRef.current.parentElement;
                    if (container) {
                      const rect = container.getBoundingClientRect();
                      canvasRef.current.width = rect.width;
                      canvasRef.current.height = rect.height;
                    }
                  }
                }}
              />
              <canvas
                ref={canvasRef}
                onClick={handleCanvasClick}
                className="w-full h-full cursor-crosshair block bg-black"
                style={{ display: 'block', width: '100%', height: '100%' }}
                data-testid="measurement-canvas"
              />

              {/* Info Panel */}
              <div className="absolute top-4 left-4 bg-black/70 backdrop-blur-sm rounded-lg p-3 text-sm border border-white/10">
                <div className="text-cyan-300 font-bold">📊 القياس الدقيق</div>
                <div className="text-xs text-gray-300 mt-1">النقاط: {points.length}</div>
                <div className="text-xs text-gray-300">النسبة: {pixelsPerMeter.toFixed(2)} بكسل/متر</div>
              </div>

              {/* Points List */}
              {points.length > 0 && (
                <div className="absolute bottom-4 left-4 bg-black/70 backdrop-blur-sm rounded-lg p-3 text-sm border border-white/10 max-w-xs max-h-40 overflow-y-auto">
                  {points.map((p, idx) => (
                    <div
                      key={p.id}
                      className="flex justify-between items-center text-xs text-gray-300 mb-1 p-1 hover:bg-white/10 rounded cursor-pointer"
                      onClick={() => setSelectedPoint(p.id)}
                      data-testid={`point-item-${p.id}`}
                    >
                      <span>{p.label}</span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          deletePoint(p.id);
                        }}
                        className="text-red-400 hover:text-red-600"
                        data-testid={`delete-point-${p.id}`}
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Results Section */}
        {measurements.length > 0 && (
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">📈 النتائج</h2>
              <Button
                onClick={copyResults}
                variant="outline"
                size="sm"
                data-testid="button-copy-results"
              >
                <Copy className="w-4 h-4 ml-2" />
                نسخ
              </Button>
            </div>

            <div className="space-y-2">
              {measurements.map((m, idx) => (
                <div
                  key={m.id}
                  className="bg-black/30 rounded-lg p-4 border border-blue-400/20"
                  data-testid={`result-${m.id}`}
                >
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-blue-300 font-bold">القياس {idx + 1}</span>
                    <span className="text-xs text-gray-400">{m.timestamp.toLocaleTimeString('ar-EG')}</span>
                  </div>
                  {m.distance && (
                    <div className="text-lg font-bold text-green-300">
                      المسافة: {m.distance.toFixed(10)}م
                    </div>
                  )}
                  {m.area && (
                    <div className="text-lg font-bold text-yellow-300">
                      المساحة: {m.area.toFixed(10)}م²
                    </div>
                  )}
                  <div className="text-xs text-gray-400 mt-2">عدد النقاط: {m.points.length}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Guide */}
        <div className="mt-8 bg-blue-900/20 border border-blue-400/30 rounded-lg p-4">
          <h3 className="font-bold text-blue-300 mb-2">📌 دليل الاستخدام:</h3>
          <ol className="text-sm text-gray-300 space-y-1 list-decimal list-inside">
            <li>اضغط "بدء" لتشغيل الكاميرا</li>
            <li>حدد نقطتين لمعايرة المسافة المرجعية (1 متر)</li>
            <li>اضغط "معايرة" لإعداد النسبة</li>
            <li>حدد النقاط للقياس على الشاشة</li>
            <li>اضغط "قياس" لإضافة القياس</li>
            <li>شاهد النتائج بدقة 10 منازل عشرية</li>
          </ol>
        </div>
      </div>
    </div>
  );
}
