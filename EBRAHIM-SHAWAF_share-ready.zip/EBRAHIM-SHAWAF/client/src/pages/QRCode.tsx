import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { QRCodeCanvas } from "qrcode.react";
import { Download, ArrowRight, Globe } from "lucide-react";
import { useRef } from "react";
import { useLanguage } from "@/lib/i18n";

export default function QRCodePage() {
  const { language, toggleLanguage } = useLanguage();
  const isRTL = language === 'ar';
  const qrRef = useRef<HTMLDivElement>(null);
  
  // Get the current origin for the QR code
  const appUrl = typeof window !== 'undefined' 
    ? window.location.origin 
    : 'https://ibrahim-shawaf.replit.dev';
  
  const downloadQR = () => {
    if (qrRef.current) {
      const canvas = qrRef.current.querySelector('canvas');
      if (canvas) {
        const link = document.createElement('a');
        link.download = 'ibrahim-shawaf-qrcode.png';
        link.href = canvas.toDataURL();
        link.click();
      }
    }
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white" dir={isRTL ? 'rtl' : 'ltr'} data-testid="qrcode-page">
      {/* Navigation */}
      <div className="sticky top-0 z-50 bg-black/40 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">🎯 {language === 'ar' ? 'رمز QR' : 'QR Code'}</h1>
          <div className="flex gap-2">
            <Link href="/">
              <Button variant="secondary" size="sm">
                <ArrowRight className={`w-4 h-4 ${isRTL ? 'mr-2' : 'ml-2'}`} />
                {language === 'ar' ? 'الرئيسية' : 'Home'}
              </Button>
            </Link>
            <Button 
              variant="secondary" 
              size="sm" 
              onClick={toggleLanguage}
            >
              <Globe className="w-4 h-4 ml-2" />
              {language === 'ar' ? 'EN' : 'العربية'}
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="flex flex-col items-center gap-8 max-w-md w-full">
          {/* Header */}
          <div className="text-center">
            <h2 className="text-4xl font-bold mb-2">📱 إبراهيم شواف</h2>
            <p className="text-gray-300">{language === 'ar' ? 'امسح رمز QR للوصول للتطبيق' : 'Scan QR code to access the app'}</p>
          </div>

          {/* QR Code Container */}
          <div 
            ref={qrRef}
            className="bg-white p-8 rounded-xl border-4 border-blue-500 shadow-2xl"
            data-testid="qrcode-container"
          >
            <QRCodeCanvas 
              value={appUrl}
              size={250}
              level="H"
              includeMargin={true}
              fgColor="#3B82F6"
              bgColor="#FFFFFF"
            />
          </div>

          {/* URL Display */}
          <div className="text-center w-full bg-white/10 rounded-lg p-4 border border-white/20">
            <p className="text-sm text-gray-300 mb-2">{language === 'ar' ? 'رابط التطبيق:' : 'App URL:'}</p>
            <a 
              href={appUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-400 font-mono text-sm break-all hover:underline"
              data-testid="app-url"
            >
              {appUrl}
            </a>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col gap-2 w-full">
            <Button 
              onClick={downloadQR}
              size="lg"
              className="w-full bg-blue-600 hover:bg-blue-700"
              data-testid="button-download-qr"
            >
              <Download className={`w-4 h-4 ${isRTL ? 'mr-2' : 'ml-2'}`} />
              {language === 'ar' ? 'تحميل الرمز' : 'Download QR Code'}
            </Button>
          </div>

          {/* Info */}
          <div className="text-center text-sm text-gray-300 bg-white/5 p-4 rounded-lg w-full border border-white/20">
            <p>{language === 'ar' ? 'امسح هذا الرمز للوصول المباشر إلى تطبيق المساحة' : 'Scan this code to access the surveying app directly'}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
