import { useState, useRef, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Camera, Trash2, Copy, MapPin, Mic, MicOff } from "lucide-react";
import { toast } from "sonner";
import { useVoiceCommands } from "@/hooks/useVoiceCommands";

interface MeasurePoint {
  id: number;
  x: number;
  y: number;
  label: string;
}

interface Measurement {
  id: number;
  points: MeasurePoint[];
  distance?: number;
  area?: number;
  type: 'distance' | 'area' | 'angle';
  timestamp: Date;
}

interface CoordinateData {
  latitude: number;
  longitude: number;
  accuracy: number;
  altitude: number | null;
  timestamp: Date;
}

type CameraMode = 'measurement' | 'gps' | 'precision';

export default function UnifiedCameraTools() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const watchIdRef = useRef<number | null>(null);

  // Camera states
  const [cameraActive, setCameraActive] = useState(false);
  const [points, setPoints] = useState<MeasurePoint[]>([]);
  const [measurements, setMeasurements] = useState<Measurement[]>([]);
  const [selectedPoint, setSelectedPoint] = useState<number | null>(null);
  const [calibrationDistance, setCalibrationDistance] = useState(1);
  const [pixelsPerMeter, setPixelsPerMeter] = useState(1);
  const [measurementMode, setMeasurementMode] = useState<'distance' | 'area' | 'angle'>('distance');

  // GPS states
  const [currentCoordinates, setCurrentCoordinates] = useState<CoordinateData | null>(null);
  const [locationLoading, setLocationLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");
  const [attempts, setAttempts] = useState(0);
  const [accuracyMode, setAccuracyMode] = useState<"normal" | "high">("normal");

  // UI states
  const [activeMode, setActiveMode] = useState<CameraMode>('measurement');
  const [voiceEnabled, setVoiceEnabled] = useState(false);

  // Voice commands setup
  const voiceCommands = [
    { command: "بدء", action: () => !cameraActive && startCamera(), keywords: ["بدء", "شغل", "تشغيل", "كاميرا"] },
    { command: "إيقاف", action: () => cameraActive && stopCamera(), keywords: ["إيقاف", "وقف", "أوقف", "إطفاء"] },
    { command: "معايرة", action: handleCalibrate, keywords: ["معايرة", "قياس معايرة", "كالبريشن"] },
    { command: "قياس", action: addMeasurement, keywords: ["قياس", "قيس", "احسب", "حساب"] },
    { command: "مسح", action: clearAllPoints, keywords: ["مسح", "امسح", "حذف جميع", "نقاط جديدة"] },
    { command: "مسافة", action: () => setMeasurementMode('distance'), keywords: ["مسافة", "طول", "بعد"] },
    { command: "مساحة", action: () => setMeasurementMode('area'), keywords: ["مساحة", "مساحه"] },
    { command: "زاوية", action: () => setMeasurementMode('angle'), keywords: ["زاوية", "زاويه", "درجة"] },
    { command: "موقع", action: () => activeMode === 'gps' && getLocation(), keywords: ["موقع", "جي بي إس", "إحداثيات", "تحديد موقع"] },
    { command: "دقة عالية", action: () => setAccuracyMode('high'), keywords: ["دقة عالية", "دقة"] },
    { command: "دقة عادية", action: () => setAccuracyMode('normal'), keywords: ["دقة عادية", "عادية"] },
    { command: "قياس دقيق", action: () => setActiveMode('measurement'), keywords: ["قياس دقيق", "measurement"] },
    { command: "جي بي إس", action: () => setActiveMode('gps'), keywords: ["جي بي إس", "GPS", "موقع"] },
    { command: "دقة", action: () => setActiveMode('precision'), keywords: ["دقة", "precision"] },
  ];

  const { isListening, transcript, toggleListening, isSupported: voiceSupported } = useVoiceCommands(voiceCommands);

  // Cleanup
  useEffect(() => {
    return () => {
      stopCamera();
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
    };
  }, []);

  // Camera functions
  const startCamera = async () => {
    try {
      if (videoRef.current?.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach(track => track.stop());
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        const playVideo = async () => {
          try {
            await videoRef.current!.play();
            setCameraActive(true);
            toast.success('✅ تم تشغيل الكاميرا');
          } catch (playError) {
            console.error('Play error:', playError);
            toast.error('❌ خطأ في تشغيل الفيديو');
          }
        };

        if (videoRef.current.readyState >= 1) {
          playVideo();
        } else {
          videoRef.current.onloadedmetadata = playVideo;
        }
      }
    } catch (error) {
      console.error('Camera error:', error);
      toast.error('❌ لم يتمكن من الوصول إلى الكاميرا');
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
    }
    setCameraActive(false);
  };

  // GPS function
  const getLocation = async () => {
    setLocationLoading(true);
    setStatusMessage("جاري البحث عن الموقع...");
    setAttempts(0);

    return new Promise<void>((resolve) => {
      let bestPosition: GeolocationPosition | null = null;
      let maxAttempts = accuracyMode === "high" ? 50 : 10;
      let currentAttempt = 0;
      const targetAccuracy = accuracyMode === "high" ? 1 : 10;

      const handlePosition = (position: GeolocationPosition) => {
        currentAttempt++;
        setAttempts(currentAttempt);
        const accuracy = position.coords.accuracy;

        if (!bestPosition || accuracy < bestPosition.coords.accuracy) {
          bestPosition = position;
          setCurrentCoordinates({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: accuracy,
            altitude: position.coords.altitude,
            timestamp: new Date(),
          });
        }

        if (accuracy <= targetAccuracy || currentAttempt >= maxAttempts) {
          if (watchIdRef.current !== null) {
            navigator.geolocation.clearWatch(watchIdRef.current);
            watchIdRef.current = null;
          }
          setStatusMessage(`✅ تم تأكيد الموقع: ±${accuracy.toFixed(2)}متر`);
          setLocationLoading(false);
          resolve();
        }
      };

      const handleError = (error: GeolocationPositionError) => {
        toast.error("❌ خطأ في الموقع: " + error.message);
        setLocationLoading(false);
        resolve();
      };

      watchIdRef.current = navigator.geolocation.watchPosition(handlePosition, handleError, {
        enableHighAccuracy: accuracyMode === "high",
        timeout: 10000,
        maximumAge: 0,
      });
    });
  };

  // Measurement functions
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const newPoint: MeasurePoint = {
      id: Date.now(),
      x,
      y,
      label: `نقطة ${points.length + 1}`,
    };

    setPoints([...points, newPoint]);
    setSelectedPoint(newPoint.id);
  };

  const calculateDistance = (p1: MeasurePoint, p2: MeasurePoint): number => {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const pixelDistance = Math.sqrt(dx * dx + dy * dy);
    return pixelDistance / pixelsPerMeter;
  };

  const calculateArea = (pts: MeasurePoint[]): number => {
    if (pts.length < 3) return 0;
    let area = 0;
    for (let i = 0; i < pts.length; i++) {
      const p1 = pts[i];
      const p2 = pts[(i + 1) % pts.length];
      area += p1.x * p2.y - p2.x * p1.y;
    }
    return Math.abs(area) / 2 / (pixelsPerMeter * pixelsPerMeter);
  };

  function handleCalibrate() {
    if (points.length < 2) {
      toast.error('❌ يرجى تحديد نقطتين');
      return;
    }
    const pixelDistance = Math.sqrt(
      Math.pow(points[1].x - points[0].x, 2) + Math.pow(points[1].y - points[0].y, 2)
    );
    const ratio = pixelDistance / calibrationDistance;
    setPixelsPerMeter(ratio);
    setPoints([]);
    toast.success(`✅ تم المعايرة`);
  }

  function addMeasurement() {
    if (points.length < 2) {
      toast.error('❌ يرجى تحديد نقطتين على الأقل');
      return;
    }

    let distance: number | undefined;
    let area: number | undefined;

    if (measurementMode === 'distance' && points.length >= 2) {
      distance = calculateDistance(points[0], points[1]);
    } else if (measurementMode === 'area' && points.length >= 3) {
      area = calculateArea(points);
    }

    const measurement: Measurement = {
      id: Date.now(),
      points: [...points],
      distance,
      area,
      type: measurementMode,
      timestamp: new Date()
    };

    setMeasurements([...measurements, measurement]);
    setPoints([]);
    toast.success('✅ تم إضافة القياس');
  }

  function clearAllPoints() {
    setPoints([]);
    setSelectedPoint(null);
  }

  const deletePoint = (id: number) => {
    setPoints(points.filter(p => p.id !== id));
  };

  // Canvas drawing
  useEffect(() => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video || !cameraActive) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;

    const updateCanvasSize = () => {
      const container = canvas.parentElement;
      if (container) {
        const rect = container.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;
      } else {
        canvas.width = video.videoWidth || 1280;
        canvas.height = video.videoHeight || 720;
      }
    };

    updateCanvasSize();

    const drawFrame = () => {
      try {
        if (video.readyState >= 2) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        } else {
          ctx.fillStyle = '#000000';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }

        points.forEach((point) => {
          const isSelected = selectedPoint === point.id;
          ctx.fillStyle = isSelected ? '#ff6b6b' : '#4dabf7';
          ctx.beginPath();
          ctx.arc(point.x, point.y, 8, 0, Math.PI * 2);
          ctx.fill();

          ctx.strokeStyle = isSelected ? '#ffff00' : '#ffffff';
          ctx.lineWidth = 3;
          ctx.stroke();

          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 14px Arial';
          ctx.textAlign = 'center';
          ctx.fillText(point.label, point.x, point.y - 20);
        });

        if (points.length > 1) {
          ctx.strokeStyle = 'rgba(77, 171, 247, 0.5)';
          ctx.lineWidth = 2;
          ctx.setLineDash([5, 5]);
          for (let i = 0; i < points.length - 1; i++) {
            ctx.beginPath();
            ctx.moveTo(points[i].x, points[i].y);
            ctx.lineTo(points[i + 1].x, points[i + 1].y);
            ctx.stroke();
          }
          ctx.setLineDash([]);
        }

        if (measurementMode === 'distance' && points.length > 1) {
          const dist = calculateDistance(points[0], points[1]);
          const midX = (points[0].x + points[1].x) / 2;
          const midY = (points[0].y + points[1].y) / 2;

          ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
          ctx.fillRect(midX - 60, midY - 15, 120, 30);

          ctx.fillStyle = '#ffff00';
          ctx.font = 'bold 12px Arial';
          ctx.textAlign = 'center';
          ctx.fillText(`${dist.toFixed(4)}م`, midX, midY + 5);
        }
      } catch (error) {
        console.error('Canvas drawing error:', error);
      }

      animationId = requestAnimationFrame(drawFrame);
    };

    animationId = requestAnimationFrame(drawFrame);

    const handleResize = () => updateCanvasSize();
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, [points, selectedPoint, cameraActive, measurementMode, pixelsPerMeter, calculateDistance]);

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      {/* Navigation */}
      <div className="sticky top-0 z-10 bg-black/30 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">📷 أدوات الكاميرا الموحدة</h1>
          <div className="flex items-center gap-4">
            {voiceSupported && (
              <Button
                onClick={() => {
                  toggleListening();
                  setVoiceEnabled(!voiceEnabled);
                }}
                className={`transition ${isListening ? 'bg-red-600 hover:bg-red-700 animate-pulse' : 'bg-purple-600 hover:bg-purple-700'}`}
              >
                {isListening ? (
                  <>
                    <Mic className="w-4 h-4 ml-2" />
                    يستمع... 🎤
                  </>
                ) : (
                  <>
                    <MicOff className="w-4 h-4 ml-2" />
                    صوت
                  </>
                )}
              </Button>
            )}
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10">
                <ArrowRight className="w-4 h-4 ml-2" />
                العودة
              </Button>
            </Link>
          </div>
        </div>

        {/* Voice Transcript */}
        {isListening && transcript && (
          <div className="bg-purple-900/30 border-t border-purple-400/30 px-6 py-2 text-sm text-purple-300">
            🎤 {transcript}
          </div>
        )}

        {/* Mode Tabs */}
        <div className="flex gap-4 px-6 border-t border-white/10 overflow-x-auto">
          {[
            { id: 'measurement' as const, label: '📏 القياس العادي', color: 'blue' },
            { id: 'precision' as const, label: '🎯 القياس الدقيق', color: 'cyan' },
            { id: 'gps' as const, label: '📍 الإحداثيات GPS', color: 'green' },
          ].map((mode) => (
            <button
              key={mode.id}
              onClick={() => setActiveMode(mode.id)}
              className={`px-4 py-3 border-b-2 font-semibold transition whitespace-nowrap ${
                activeMode === mode.id
                  ? `border-${mode.color}-400 text-${mode.color}-400`
                  : 'border-transparent text-gray-400 hover:text-gray-300'
              }`}
            >
              {mode.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Camera View */}
        {cameraActive && (
          <div className="bg-black/30 rounded-xl border border-white/10 p-4 mb-6">
            <div className="relative w-full bg-black rounded-lg overflow-hidden" style={{ aspectRatio: "16 / 9" }}>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                style={{ display: 'none' }}
                onLoadedMetadata={() => {
                  if (canvasRef.current) {
                    const container = canvasRef.current.parentElement;
                    if (container) {
                      const rect = container.getBoundingClientRect();
                      canvasRef.current.width = rect.width;
                      canvasRef.current.height = rect.height;
                    }
                  }
                }}
              />
              <canvas
                ref={canvasRef}
                onClick={(activeMode === 'measurement' || activeMode === 'precision') ? handleCanvasClick : undefined}
                className="w-full h-full cursor-crosshair block bg-black"
                style={{ display: 'block', width: '100%', height: '100%' }}
              />
            </div>
          </div>
        )}

        {/* Measurement Mode */}
        {(activeMode === 'measurement' || activeMode === 'precision') && (
          <div className="space-y-6">
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
              <div className="grid md:grid-cols-6 gap-4 mb-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-2">نمط القياس</label>
                  <select
                    value={measurementMode}
                    onChange={(e) => setMeasurementMode(e.target.value as any)}
                    className="w-full bg-black/30 border border-blue-400/30 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="distance">📏 المسافة</option>
                    <option value="area">📐 المساحة</option>
                    <option value="angle">🔢 الزاوية</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-2">معايرة (متر)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0.1"
                    value={calibrationDistance}
                    onChange={(e) => setCalibrationDistance(parseFloat(e.target.value))}
                    className="w-full bg-black/30 border border-blue-400/30 rounded-lg px-3 py-2 text-white"
                  />
                </div>

                <Button onClick={startCamera} disabled={cameraActive} className="bg-green-600 hover:bg-green-700">
                  <Camera className="w-4 h-4 ml-2" />
                  بدء
                </Button>

                <Button onClick={stopCamera} disabled={!cameraActive} className="bg-red-600 hover:bg-red-700">
                  إيقاف
                </Button>

                <Button onClick={handleCalibrate} variant="secondary">
                  معايرة
                </Button>

                <Button onClick={addMeasurement} className="bg-blue-600 hover:bg-blue-700">
                  قياس
                </Button>
              </div>

              <Button onClick={clearAllPoints} variant="outline" className="w-full bg-red-900/20 hover:bg-red-900/40">
                <Trash2 className="w-4 h-4 ml-2" />
                مسح
              </Button>
            </div>

            {points.length > 0 && (
              <div className="bg-blue-900/20 border border-blue-400/30 rounded-lg p-4">
                <h3 className="font-bold text-blue-300 mb-3">النقاط المضافة ({points.length})</h3>
                <div className="space-y-2">
                  {points.map((p) => (
                    <div key={p.id} className="flex justify-between items-center text-sm bg-black/30 rounded p-2">
                      <span>{p.label}</span>
                      <button onClick={() => deletePoint(p.id)} className="text-red-400 hover:text-red-600">
                        حذف
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {measurements.length > 0 && (
              <div className="bg-green-900/20 border border-green-400/30 rounded-lg p-4">
                <h3 className="font-bold text-green-300 mb-3">📊 النتائج ({measurements.length})</h3>
                <div className="space-y-2">
                  {measurements.map((m) => (
                    <div key={m.id} className="bg-black/30 rounded p-2 text-sm">
                      {m.distance && <span>📏 مسافة: {m.distance.toFixed(10)} متر</span>}
                      {m.area && <span>📐 مساحة: {m.area.toFixed(10)} م²</span>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* GPS Mode */}
        {activeMode === 'gps' && (
          <div className="space-y-6">
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
              <div className="grid md:grid-cols-3 gap-4 mb-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-2">دقة الموقع</label>
                  <select
                    value={accuracyMode}
                    onChange={(e) => setAccuracyMode(e.target.value as any)}
                    className="w-full bg-black/30 border border-green-400/30 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="normal">عادية (±10م)</option>
                    <option value="high">عالية جداً (±1م)</option>
                  </select>
                </div>

                <Button onClick={startCamera} disabled={cameraActive} className="bg-green-600 hover:bg-green-700">
                  <Camera className="w-4 h-4 ml-2" />
                  الكاميرا
                </Button>

                <Button onClick={getLocation} disabled={locationLoading} className="bg-green-600 hover:bg-green-700">
                  <MapPin className="w-4 h-4 ml-2" />
                  {locationLoading ? `جاري... (${attempts})` : 'احصل على الموقع'}
                </Button>
              </div>

              {statusMessage && <div className="bg-blue-900/30 border border-blue-400 rounded p-3 text-blue-300 text-sm">{statusMessage}</div>}
            </div>

            {currentCoordinates && (
              <div className="bg-green-900/20 border border-green-400/30 rounded-lg p-6">
                <h3 className="font-bold text-green-300 mb-4">📍 الموقع الحالي</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="bg-black/30 rounded p-4">
                    <p className="text-gray-400 text-sm mb-1">خط العرض</p>
                    <p className="text-2xl font-bold text-white">{currentCoordinates.latitude.toFixed(8)}°</p>
                  </div>
                  <div className="bg-black/30 rounded p-4">
                    <p className="text-gray-400 text-sm mb-1">خط الطول</p>
                    <p className="text-2xl font-bold text-white">{currentCoordinates.longitude.toFixed(8)}°</p>
                  </div>
                  <div className="bg-black/30 rounded p-4">
                    <p className="text-gray-400 text-sm mb-1">الدقة</p>
                    <p className="text-2xl font-bold text-green-400">±{currentCoordinates.accuracy.toFixed(2)}م</p>
                  </div>
                  <div className="bg-black/30 rounded p-4">
                    <p className="text-gray-400 text-sm mb-1">الارتفاع</p>
                    <p className="text-2xl font-bold text-white">{currentCoordinates.altitude ? `${currentCoordinates.altitude.toFixed(2)}م` : 'N/A'}</p>
                  </div>
                </div>

                <Button
                  onClick={() => {
                    const text = `${currentCoordinates.latitude}, ${currentCoordinates.longitude}`;
                    navigator.clipboard.writeText(text);
                    toast.success('✅ تم نسخ الإحداثيات');
                  }}
                  className="mt-4 w-full bg-green-600 hover:bg-green-700"
                >
                  <Copy className="w-4 h-4 ml-2" />
                  نسخ الإحداثيات
                </Button>
              </div>
            )}
          </div>
        )}

        {/* Guide */}
        <div className="mt-8 bg-purple-900/20 border border-purple-400/30 rounded-lg p-4">
          <h3 className="font-bold text-purple-300 mb-3">🎤 أوامر صوتية متاحة:</h3>
          <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-300">
            <div>
              <p className="font-bold mb-2">🎬 التحكم:</p>
              <ul className="space-y-1 text-gray-400 text-xs">
                <li>قل: "بدء" / "إيقاف"</li>
                <li>قل: "قياس" / "معايرة"</li>
                <li>قل: "مسح" / "موقع"</li>
              </ul>
            </div>
            <div>
              <p className="font-bold mb-2">🔀 التبديل:</p>
              <ul className="space-y-1 text-gray-400 text-xs">
                <li>قل: "قياس عادي"</li>
                <li>قل: "قياس دقيق"</li>
                <li>قل: "جي بي إس"</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
