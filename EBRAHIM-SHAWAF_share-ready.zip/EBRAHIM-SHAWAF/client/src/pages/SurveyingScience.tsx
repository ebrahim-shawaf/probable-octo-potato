import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, MapPin, Calculator, Navigation } from "lucide-react";

export default function SurveyingScience() {
  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 to-slate-800 text-white" data-testid="surveying-science-page">
      {/* Navigation */}
      <div className="sticky top-0 z-10 bg-black/30 backdrop-blur-md border-b border-white/10">
        <div className="max-w-4xl mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">إبراهيم شواف</h1>
          <Link href="/">
            <Button variant="ghost" className="text-white hover:bg-white/10" data-testid="button-back-home">
              <ArrowRight className="w-4 h-4 ml-2" />
              العودة للرئيسية
            </Button>
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-12">
        {/* Hero Section */}
        <div className="mb-12">
          <h2 className="text-5xl font-bold mb-4 text-blue-400">ما هي المساحة؟</h2>
          <p className="text-xl text-gray-300 leading-relaxed">
            المساحة هي فن وعلم قياس وتحديد موقع وخصائص الأراضي والمنشآت على سطح الأرض، باستخدام تقنيات متقدمة وأدوات دقيقة.
          </p>
        </div>

        {/* Key Sections */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {/* Section 1 */}
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-blue-400/50 transition" data-testid="card-surveying-definition">
            <MapPin className="w-8 h-8 text-blue-400 mb-4" />
            <h3 className="text-xl font-bold mb-3">الموقع الجغرافي</h3>
            <p className="text-gray-300 text-sm leading-relaxed">
              تحديد الموقع الدقيق للأراضي والمشاريع باستخدام نظام الإحداثيات الجغرافية، مما يساعد في التخطيط العمراني والتطوير.
            </p>
          </div>

          {/* Section 2 */}
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-blue-400/50 transition" data-testid="card-surveying-methods">
            <Calculator className="w-8 h-8 text-blue-400 mb-4" />
            <h3 className="text-xl font-bold mb-3">الأدوات والقياسات</h3>
            <p className="text-gray-300 text-sm leading-relaxed">
              استخدام أدوات قياس متقدمة مثل GPS وأجهزة التيودوليت والرافعات، بالإضافة إلى معالجة البيانات بواسطة الحاسب الآلي.
            </p>
          </div>

          {/* Section 3 */}
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-blue-400/50 transition" data-testid="card-surveying-applications">
            <Navigation className="w-8 h-8 text-blue-400 mb-4" />
            <h3 className="text-xl font-bold mb-3">التطبيقات</h3>
            <p className="text-gray-300 text-sm leading-relaxed">
              المشاريع الهندسية، التخطيط العمراني، الملاحة البحرية، الأعمال الجيولوجية، والتطبيقات العسكرية والأمنية.
            </p>
          </div>
        </div>

        {/* Coordinate Systems */}
        <div className="mb-12 bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10">
          <h3 className="text-3xl font-bold mb-6 text-blue-400">أنظمة الإحداثيات</h3>
          
          <div className="space-y-6">
            {/* Geographic Coordinates */}
            <div>
              <h4 className="text-xl font-semibold mb-2 text-white">الإحداثيات الجغرافية (Latitude/Longitude)</h4>
              <p className="text-gray-300 mb-3">
                نظام عالمي يعتمد على خطوط الطول والعرض، حيث تقاس المسافة من خط الاستواء (العرض) ومن خط غرينتش (الطول).
              </p>
            </div>

            {/* Decimal Degrees */}
            <div>
              <h4 className="text-xl font-semibold mb-2 text-white">الدرجات العشرية (Decimal Degrees)</h4>
              <p className="text-gray-300 mb-3">
                صيغة حديثة من الإحداثيات الجغرافية، تستخدم الكسور العشرية بدلاً من الدقائق والثواني، مما يجعلها أسهل للحسابات الرقمية.
              </p>
            </div>

            {/* DMS */}
            <div>
              <h4 className="text-xl font-semibold mb-2 text-white">الدرجات والدقائق والثواني (DMS)</h4>
              <p className="text-gray-300 mb-3">
                الصيغة التقليدية للإحداثيات، حيث تُقسم كل درجة إلى 60 دقيقة وكل دقيقة إلى 60 ثانية. تستخدم على نطاق واسع في الخرائط التقليدية والملاحة.
              </p>
            </div>

            {/* UTM */}
            <div>
              <h4 className="text-xl font-semibold mb-2 text-white">نظام UTM (Universal Transverse Mercator)</h4>
              <p className="text-gray-300 mb-3">
                نظام إحداثيات مسقط عالمي يقسم الأرض إلى مناطق بعرض 6 درجات طول. يوفر دقة عالية للقياسات المحلية خاصة في المشاريع الهندسية.
              </p>
            </div>
          </div>
        </div>

        {/* Applications in Modern Surveying */}
        <div className="mb-12 bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10">
          <h3 className="text-3xl font-bold mb-6 text-blue-400">تطبيقات المساحة الحديثة</h3>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-lg font-semibold mb-2 text-white">ملفات CAD</h4>
              <p className="text-gray-300">
                استخراج الإحداثيات من ملفات التصميم CAD (DXF, DWG) لتحليل المشاريع الهندسية والمعمارية والمدنية.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-2 text-white">نظام GPS</h4>
              <p className="text-gray-300">
                الحصول على إحداثيات دقيقة باستخدام أجهزة GPS عالية الدقة للتطبيقات المختلفة.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-2 text-white">الخرائط الرقمية</h4>
              <p className="text-gray-300">
                إنشاء وتحديث الخرائط الرقمية والقواعس البيانية الجغرافية للتخطيط والتحليل.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-2 text-white">الاستشعار عن بعد</h4>
              <p className="text-gray-300">
                استخدام الأقمار الصناعية والطائرات بدون طيار لجمع بيانات جغرافية دقيقة.
              </p>
            </div>
          </div>
        </div>

        {/* Surveying Instruments */}
        <div className="mb-12 bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10">
          <h3 className="text-3xl font-bold mb-8 text-blue-400">أجهزة المساحة والقياس</h3>
          
          <div className="space-y-8">
            {/* GPS */}
            <div className="border-l-4 border-blue-400 pl-6">
              <h4 className="text-2xl font-bold text-white mb-3">1. جهاز تحديد المواقع (GPS)</h4>
              <p className="text-gray-300 mb-3">
                جهاز يستقبل إشارات من الأقمار الصناعية لتحديد الموقع الجغرافي بدقة عالية. يستخدم في التطبيقات التي تتطلب دقة من 1 إلى 10 أمتار.
              </p>
              <div className="bg-black/30 p-4 rounded-lg border border-blue-400/30 mb-3">
                <p className="text-yellow-400 font-semibold mb-2">✓ الاستخدام:</p>
                <ul className="text-gray-300 text-sm space-y-1 mr-4">
                  <li>• تحديد مواقع النقاط الأساسية للمشاريع الكبيرة</li>
                  <li>• الملاحة والتطبيقات الجغرافية</li>
                  <li>• رسم الخرائط الرقمية والدراسات البيئية</li>
                </ul>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-purple-400/30">
                <p className="text-purple-400 font-semibold mb-2">🛠️ طريقة الاستخدام:</p>
                <ol className="text-gray-300 text-sm space-y-2 mr-4 list-decimal list-inside">
                  <li>شغّل الجهاز وانتظر 1-2 دقيقة لاستقبال الإشارة من الأقمار</li>
                  <li>اذهب إلى الموقع المراد قياسه واستقر في مكان واحد</li>
                  <li>اضغط على زر التسجيل للحصول على الإحداثيات</li>
                  <li>احفظ البيانات على الجهاز أو نقلها للحاسب</li>
                </ol>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-cyan-400/30 mt-3">
                <p className="text-cyan-400 font-semibold mb-2">📖 شرح الاستخدام:</p>
                <p className="text-gray-300 text-sm">
                  يعمل GPS بتلقي إشارات من عدة أقمار صناعية. كلما زاد عدد الأقمار المستقبلة، زادت الدقة. الجهاز يحسب الموقع من خلال حساب الوقت الذي تستغرقه الإشارات للوصول. بعض الأجهزة تخزن البيانات بصيغة إحداثيات جغرافية أو UTM حسب إعداداتك.
                </p>
              </div>
            </div>

            {/* Theodolite */}
            <div className="border-l-4 border-blue-400 pl-6">
              <h4 className="text-2xl font-bold text-white mb-3">2. جهاز التيودوليت (Theodolite)</h4>
              <p className="text-gray-300 mb-3">
                أداة بصرية دقيقة لقياس الزوايا الأفقية والرأسية. يستخدم في المساحة الهندسية والتطبيقات التي تتطلب دقة عالية جداً.
              </p>
              <div className="bg-black/30 p-4 rounded-lg border border-blue-400/30 mb-3">
                <p className="text-yellow-400 font-semibold mb-2">✓ الاستخدام:</p>
                <ul className="text-gray-300 text-sm space-y-1 mr-4">
                  <li>• قياس الزوايا بدقة تصل إلى ثانية واحدة</li>
                  <li>• أعمال التوثيق والمساح الهندسية</li>
                  <li>• رفع الخرائط التفصيلية للمناطق الصغيرة</li>
                  <li>• تحديد الارتفاعات والمنحدرات</li>
                </ul>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-purple-400/30">
                <p className="text-purple-400 font-semibold mb-2">🛠️ طريقة الاستخدام:</p>
                <ol className="text-gray-300 text-sm space-y-2 mr-4 list-decimal list-inside">
                  <li>ضع الجهاز على حامل ثلاثي الأرجل وسط النقطة المراد قياس زواياها</li>
                  <li>استخدم نقالة المستوى لتسوية الجهاز أفقياً</li>
                  <li>وجّه المنظار نحو النقطة الأولى واضبط المسمار الدقيق</li>
                  <li>اقرأ الزاوية الأفقية من المقياس الدائري</li>
                  <li>كرر العملية مع النقاط الأخرى وسجل جميع القياسات</li>
                </ol>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-cyan-400/30 mt-3">
                <p className="text-cyan-400 font-semibold mb-2">📖 شرح الاستخدام:</p>
                <p className="text-gray-300 text-sm">
                  التيودوليت يقيس الزوايا من خلال منظار دقيق ومقاييس درجات مدرجة. يجب إسقاط الخط العمودي للجهاز على النقطة بدقة شديدة. الزوايا تُقاس من الشمال الحقيقي أو من خط مرجعي آخر. تحتاج لتسجيل زوايا أفقية ورأسية متعددة من نفس النقطة للحصول على خريطة دقيقة.
                </p>
              </div>
            </div>

            {/* Level */}
            <div className="border-l-4 border-blue-400 pl-6">
              <h4 className="text-2xl font-bold text-white mb-3">3. جهاز المستوى (Level/Dumpy Level)</h4>
              <p className="text-gray-300 mb-3">
                أداة لقياس الفروقات في الارتفاع بين النقاط المختلفة. أساسي في المشاريع الهندسية والعمرانية لتحديد المنسوب.
              </p>
              <div className="bg-black/30 p-4 rounded-lg border border-blue-400/30 mb-3">
                <p className="text-yellow-400 font-semibold mb-2">✓ الاستخدام:</p>
                <ul className="text-gray-300 text-sm space-y-1 mr-4">
                  <li>• تحديد مناسيب الأراضي والمشاريع</li>
                  <li>• أعمال الصرف والتصريف</li>
                  <li>• رفع تفاصيل الطرق والقنوات</li>
                  <li>• التحكم في ارتفاع المنشآت</li>
                </ul>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-purple-400/30">
                <p className="text-purple-400 font-semibold mb-2">🛠️ طريقة الاستخدام:</p>
                <ol className="text-gray-300 text-sm space-y-2 mr-4 list-decimal list-inside">
                  <li>ضع الجهاز على حامل ثلاثي في موقع متوسط بين النقاط</li>
                  <li>استخدم فقاعة المستوى لتسوية الجهاز تماماً</li>
                  <li>ضع قضيب القياس (Staff) على النقطة الأولى وجاهز القياس</li>
                  <li>اقرأ الرقم على القضيب من خلال المنظار</li>
                  <li>انقل القضيب للنقطة التالية وكرر القياس</li>
                  <li>احسب فروق الارتفاع من فروق القراءات</li>
                </ol>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-cyan-400/30 mt-3">
                <p className="text-cyan-400 font-semibold mb-2">📖 شرح الاستخدام:</p>
                <p className="text-gray-300 text-sm">
                  جهاز المستوى يعمل على مبدأ الخط الأفقي. يوجه منظاراً أفقياً تماماً نحو قضبان قياس عمودية. الفرق بين القراءات على القضبان يعطيك الفرق في الارتفاع بين النقاط. كلما كانت قراءاتك أدق، كانت مناسيبك أصح، خاصة في المشاريع الكبيرة.
                </p>
              </div>
            </div>

            {/* EDM */}
            <div className="border-l-4 border-blue-400 pl-6">
              <h4 className="text-2xl font-bold text-white mb-3">4. جهاز قياس المسافات الإلكترونية (EDM)</h4>
              <p className="text-gray-300 mb-3">
                جهاز يستخدم شعاع ضوئي أو ليزر لقياس المسافات بدقة عالية. يقيس من بضعة أمتار إلى آلاف الأمتار.
              </p>
              <div className="bg-black/30 p-4 rounded-lg border border-blue-400/30 mb-3">
                <p className="text-yellow-400 font-semibold mb-2">✓ الاستخدام:</p>
                <ul className="text-gray-300 text-sm space-y-1 mr-4">
                  <li>• قياس المسافات الطويلة بدقة عالية</li>
                  <li>• أعمال المساح الهندسية المعقدة</li>
                  <li>• تحديد حدود الممتلكات والأراضي</li>
                  <li>• المشاريع البنائية والجسور والطرق</li>
                </ul>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-purple-400/30">
                <p className="text-purple-400 font-semibold mb-2">🛠️ طريقة الاستخدام:</p>
                <ol className="text-gray-300 text-sm space-y-2 mr-4 list-decimal list-inside">
                  <li>ضع جهاز الإرسال على النقطة الأولى</li>
                  <li>ضع عاكس الشعاع (Prism) على النقطة المراد قياس المسافة إليها</li>
                  <li>وجّه شعاع الليزر من الجهاز نحو العاكس</li>
                  <li>اضغط على زر القياس وانتظر ظهور النتيجة</li>
                  <li>قراءة المسافة تظهر على شاشة الجهاز مباشرة</li>
                </ol>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-cyan-400/30 mt-3">
                <p className="text-cyan-400 font-semibold mb-2">📖 شرح الاستخدام:</p>
                <p className="text-gray-300 text-sm">
                  يعمل على مبدأ قياس سرعة الضوء والزمن. يرسل الجهاز نبضة ضوئية تنعكس على العاكس وتعود، وحساب الوقت يعطي المسافة الدقيقة. دقة هذا الجهاز عالية جداً وتتأثر بالطقس والأتربة والشفافية الجوية. يفضل استخدام عدة قياسات والأخذ بالمتوسط للحصول على أفضل نتيجة.
                </p>
              </div>
            </div>

            {/* Total Station */}
            <div className="border-l-4 border-blue-400 pl-6">
              <h4 className="text-2xl font-bold text-white mb-3">5. المحطة العاملة (Total Station)</h4>
              <p className="text-gray-300 mb-3">
                جهاز متطور يجمع بين التيودوليت والمسافة الإلكترونية والحاسب الآلي. يوفر دقة عالية وسرعة في العمل.
              </p>
              <div className="bg-black/30 p-4 rounded-lg border border-blue-400/30 mb-3">
                <p className="text-yellow-400 font-semibold mb-2">✓ الاستخدام:</p>
                <ul className="text-gray-300 text-sm space-y-1 mr-4">
                  <li>• رفع الخرائط التفصيلية بدقة عالية</li>
                  <li>• المشاريع الهندسية المعقدة والضخمة</li>
                  <li>• العمل في المناطق الحضرية والريفية</li>
                  <li>• تحديد مواقع المباني والطرق بدقة ميليمتر</li>
                </ul>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-purple-400/30">
                <p className="text-purple-400 font-semibold mb-2">🛠️ طريقة الاستخدام:</p>
                <ol className="text-gray-300 text-sm space-y-2 mr-4 list-decimal list-inside">
                  <li>ثبّت الجهاز على الحامل الثلاثي وسوّه أفقياً</li>
                  <li>أدخل بيانات النقطة المرجعية والارتفاع</li>
                  <li>ضع العاكس على النقطة التالية</li>
                  <li>وجّه منظار الجهاز على العاكس واضغط القياس</li>
                  <li>الجهاز يحسب الزاوية والمسافة والارتفاع تلقائياً</li>
                  <li>خزّن البيانات في الجهاز أو نقلها للحاسب</li>
                </ol>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-cyan-400/30 mt-3">
                <p className="text-cyan-400 font-semibold mb-2">📖 شرح الاستخدام:</p>
                <p className="text-gray-300 text-sm">
                  المحطة العاملة توفر جميع المعلومات في قياس واحد: الزاوية الأفقية، الزاوية الرأسية، المسافة، والإحداثيات والارتفاع. الحاسب الصغير المدمج يحسب كل شيء تلقائياً. توفر هذه الأجهزة وقتاً كبيراً وتقلل الأخطاء لأنها تلغي الحسابات اليدوية.
                </p>
              </div>
            </div>

            {/* Compass */}
            <div className="border-l-4 border-blue-400 pl-6">
              <h4 className="text-2xl font-bold text-white mb-3">6. البوصلة والطاقية (Compass/Clinometer)</h4>
              <p className="text-gray-300 mb-3">
                أداة بسيطة لتحديد الاتجاهات والشمال الحقيقي. تستخدم في المسح السريع والأعمال الحقلية.
              </p>
              <div className="bg-black/30 p-4 rounded-lg border border-blue-400/30 mb-3">
                <p className="text-yellow-400 font-semibold mb-2">✓ الاستخدام:</p>
                <ul className="text-gray-300 text-sm space-y-1 mr-4">
                  <li>• تحديد الاتجاه والشمال الحقيقي</li>
                  <li>• قياس زوايا الانحدار والميول</li>
                  <li>• الأعمال الحقلية البسيطة والسريعة</li>
                  <li>• التطبيقات الأثرية والجيولوجية</li>
                </ul>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-purple-400/30">
                <p className="text-purple-400 font-semibold mb-2">🛠️ طريقة الاستخدام:</p>
                <ol className="text-gray-300 text-sm space-y-2 mr-4 list-decimal list-inside">
                  <li>أمسك البوصلة في يدك بشكل أفقي (للاتجاه)</li>
                  <li>اترك الإبرة تستقر وتشير للشمال</li>
                  <li>استخدم الخطوط المرجعية لقراءة الاتجاه</li>
                  <li>للميل: استخدم الطاقية بإمالة البوصلة بزاوية</li>
                  <li>اقرأ مقياس الميل الموجود على الجانب</li>
                </ol>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-cyan-400/30 mt-3">
                <p className="text-cyan-400 font-semibold mb-2">📖 شرح الاستخدام:</p>
                <p className="text-gray-300 text-sm">
                  البوصلة تعتمد على المجال المغناطيسي للأرض. الإبرة تشير دائماً نحو الشمال المغناطيسي. تذكر أن هناك فرقاً بين الشمال المغناطيسي والجغرافي يختلف حسب الموقع. الطاقية تقيس الميل (الزاوية عن الأفق)، مفيدة في حساب الارتفاعات والمسافات على التضاريس الجبلية.
                </p>
              </div>
            </div>

            {/* Measuring Wheel */}
            <div className="border-l-4 border-blue-400 pl-6">
              <h4 className="text-2xl font-bold text-white mb-3">7. عجلة القياس (Measuring Wheel)</h4>
              <p className="text-gray-300 mb-3">
                جهاز ميكانيكي بسيط يستخدم لقياس المسافات بتمريره على الأرض. دقيق للمسافات المتوسطة والقصيرة.
              </p>
              <div className="bg-black/30 p-4 rounded-lg border border-blue-400/30 mb-3">
                <p className="text-yellow-400 font-semibold mb-2">✓ الاستخدام:</p>
                <ul className="text-gray-300 text-sm space-y-1 mr-4">
                  <li>• قياس المسافات على الطرق والمشاريع</li>
                  <li>• الأعمال السريعة والمسوحات الأولية</li>
                  <li>• قياس المحيطات والحدود</li>
                  <li>• التطبيقات الزراعية والبيئية</li>
                </ul>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-purple-400/30">
                <p className="text-purple-400 font-semibold mb-2">🛠️ طريقة الاستخدام:</p>
                <ol className="text-gray-300 text-sm space-y-2 mr-4 list-decimal list-inside">
                  <li>صفّر العداد قبل البدء بالقياس</li>
                  <li>أمسك يد العجلة وحافظ عليها عمودية</li>
                  <li>مرّر العجلة على الأرض بخط مستقيم وثابت</li>
                  <li>تأكد من أن العجلة تلمس الأرض طوال القياس</li>
                  <li>اقرأ المسافة على العداد الميكانيكي عند النهاية</li>
                </ol>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-cyan-400/30 mt-3">
                <p className="text-cyan-400 font-semibold mb-2">📖 شرح الاستخدام:</p>
                <p className="text-gray-300 text-sm">
                  كل دورة كاملة للعجلة تمثل محيطها (عادة متر واحد). العداد يحسب عدد الدورات ويحولها لمسافة. دقة القياس تعتمد على ثبات الضغط على الأرض وسلاسة الحركة. لا تستخدمها على الأسطح الرطبة أو الوحلة لأنها تؤثر على دقة القراءة.
                </p>
              </div>
            </div>

            {/* Measuring Tape */}
            <div className="border-l-4 border-blue-400 pl-6">
              <h4 className="text-2xl font-bold text-white mb-3">8. شريط القياس (Measuring Tape/Chain)</h4>
              <p className="text-gray-300 mb-3">
                أداة بسيطة وتقليدية لقياس المسافات القصيرة. تستخدم في الأعمال الحقلية اليومية والتفاصيل الصغيرة.
              </p>
              <div className="bg-black/30 p-4 rounded-lg border border-blue-400/30 mb-3">
                <p className="text-yellow-400 font-semibold mb-2">✓ الاستخدام:</p>
                <ul className="text-gray-300 text-sm space-y-1 mr-4">
                  <li>• قياس المسافات القصيرة والتفاصيل</li>
                  <li>• العلامات والحدود البسيطة</li>
                  <li>• الأعمال الحقلية اليومية</li>
                  <li>• التحقق من الأبعاد والمسافات</li>
                </ul>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-purple-400/30">
                <p className="text-purple-400 font-semibold mb-2">🛠️ طريقة الاستخدام:</p>
                <ol className="text-gray-300 text-sm space-y-2 mr-4 list-decimal list-inside">
                  <li>ثبّت نقطة البداية على الأرض بوتد أو علامة</li>
                  <li>مد الشريط بخط مستقيم نحو النقطة النهائية</li>
                  <li>ثبّت الشريط بشكل متوازٍ مع الأرض (لا يرتفع أو ينخفض)</li>
                  <li>اقرأ الرقم عند النقطة النهائية</li>
                  <li>في المسافات الطويلة: قس بعلامات متعددة واجمع النتائج</li>
                </ol>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-cyan-400/30 mt-3">
                <p className="text-cyan-400 font-semibold mb-2">📖 شرح الاستخدام:</p>
                <p className="text-gray-300 text-sm">
                  الشريط يجب أن يكون توتراً متساوياً من البداية للنهاية. أي ارتخاء يزيد القراءة، وأي شد زائد يقلصها. يفضل استخدام شريط معايري (معاير بدقة). في التربة الرطبة أو الوحل، ضع لواحاً مسطحة تحت الشريط لتجنب الغوص والقراءات الخاطئة.
                </p>
              </div>
            </div>

            {/* RTK-GPS */}
            <div className="border-l-4 border-blue-400 pl-6">
              <h4 className="text-2xl font-bold text-white mb-3">9. نظام GPS المتقدم (RTK-GPS / DGPS)</h4>
              <p className="text-gray-300 mb-3">
                نسخة متطورة من GPS توفر دقة عالية جداً (سنتيمتر واحد). تستخدم محطة أساسية مرجعية لتصحيح الإشارات.
              </p>
              <div className="bg-black/30 p-4 rounded-lg border border-blue-400/30 mb-3">
                <p className="text-yellow-400 font-semibold mb-2">✓ الاستخدام:</p>
                <ul className="text-gray-300 text-sm space-y-1 mr-4">
                  <li>• المشاريع الهندسية الدقيقة جداً</li>
                  <li>• الأعمال البنائية والبنية التحتية</li>
                  <li>• الملاحة الدقيقة والزراعة الذكية</li>
                  <li>• رسم الخرائط الرقمية عالية الدقة</li>
                </ul>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-purple-400/30">
                <p className="text-purple-400 font-semibold mb-2">🛠️ طريقة الاستخدام:</p>
                <ol className="text-gray-300 text-sm space-y-2 mr-4 list-decimal list-inside">
                  <li>ثبّت محطة مرجعية (Base Station) على نقطة معروفة الإحداثيات</li>
                  <li>شغّل جهاز الاستقبال المتنقل (Rover) على الموقع</li>
                  <li>تأكد من الاتصال اللاسلكي بين الجهازين</li>
                  <li>انتظر تحقق الجهاز من الإشارات (عادة ثواني قليلة)</li>
                  <li>سجّل الإحداثيات على الجهاز ذي الدقة العالية</li>
                </ol>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-cyan-400/30 mt-3">
                <p className="text-cyan-400 font-semibold mb-2">📖 شرح الاستخدام:</p>
                <p className="text-gray-300 text-sm">
                  يعمل بإرسال البيانات من محطة ثابتة معروفة لتصحيح أخطاء الأقمار. الفرق بين إشاراتها والإشارات الخام تُرسل لاسلكياً لتصحيح جهاز الاستقبال. هذا يقلل الخطأ من ±10م للـ GPS العادي إلى ±2سم فقط. ضرورية جداً للمشاريع الحساسة والدقيقة.
                </p>
              </div>
            </div>

            {/* Drone / UAV */}
            <div className="border-l-4 border-blue-400 pl-6">
              <h4 className="text-2xl font-bold text-white mb-3">10. الطائرات بدون طيار (Drone / UAV)</h4>
              <p className="text-gray-300 mb-3">
                طائرة صغيرة مسيرة بحرية تحمل كاميرا ومستشعرات متقدمة. توفر صور جوية عالية الدقة ورسم خرائط سريع.
              </p>
              <div className="bg-black/30 p-4 rounded-lg border border-blue-400/30 mb-3">
                <p className="text-yellow-400 font-semibold mb-2">✓ الاستخدام:</p>
                <ul className="text-gray-300 text-sm space-y-1 mr-4">
                  <li>• التصوير الجوي والفيديوغرافيا</li>
                  <li>• رسم الخرائط السريع والمسح الشامل</li>
                  <li>• مراقبة المشاريع الكبيرة والإنشاءات</li>
                  <li>• الدراسات البيئية والزراعية والأثرية</li>
                </ul>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-purple-400/30">
                <p className="text-purple-400 font-semibold mb-2">🛠️ طريقة الاستخدام:</p>
                <ol className="text-gray-300 text-sm space-y-2 mr-4 list-decimal list-inside">
                  <li>شغّل الدرون في مكان مفتوح خالٍ من العوائق</li>
                  <li>اربط برنامج التخطيط والتصوير على الجهاز اللاسلكي</li>
                  <li>خطط مسار الرحلة والارتفاع ودقة الصور</li>
                  <li>أطلق الدرون وتابع الرحلة عبر الكاميرا الحية</li>
                  <li>بعد الهبوط، نزّل الصور وعالجها بالبرامج</li>
                </ol>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-cyan-400/30 mt-3">
                <p className="text-cyan-400 font-semibold mb-2">📖 شرح الاستخدام:</p>
                <p className="text-gray-300 text-sm">
                  الدرون توفر صوراً متقاطعة يمكن دمجها لإنشاء خريطة ثلاثية الأبعاد دقيقة. كلما كان الارتفاع أقل، كانت الدقة أعلى. البرامج الحديثة تعالج الصور تلقائياً لإنتاج خرائط ونماذج ثلاثية الأبعاد. تذكر أن تتحقق من القوانين المحلية لاستخدام الدرون في منطقتك.
                </p>
              </div>
            </div>

            {/* Soil Investigation Equipment */}
            <div className="border-l-4 border-blue-400 pl-6">
              <h4 className="text-2xl font-bold text-white mb-3">11. أجهزة كشف التربة والاستكشاف الجيوتقني</h4>
              <p className="text-gray-300 mb-3">
                مجموعة متخصصة من الأجهزة لفحص خصائص التربة والصخور تحت السطح. ضرورية قبل أي مشروع بناء.
              </p>
              <div className="bg-black/30 p-4 rounded-lg border border-blue-400/30 mb-3">
                <p className="text-yellow-400 font-semibold mb-2">✓ الأنواع الرئيسية:</p>
                <ul className="text-gray-300 text-sm space-y-2 mr-4">
                  <li><span className="font-semibold">• مثقاب التربة (Auger/Boring):</span> حفر عينات التربة من أعماق مختلفة</li>
                  <li><span className="font-semibold">• كاشف المعادن (Metal Detector):</span> كشف المعادن تحت السطح</li>
                  <li><span className="font-semibold">• جهاز الرادار الأرضي (GPR):</span> كشف الهياكل تحت السطح</li>
                  <li><span className="font-semibold">• جهاز قياس الكثافة (Density Meter):</span> قياس كثافة التربة المضغوطة</li>
                  <li><span className="font-semibold">• أجهزة اختبار الضغط (CPT):</span> قياس مقاومة التربة والطبقات</li>
                </ul>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-purple-400/30">
                <p className="text-purple-400 font-semibold mb-2">🛠️ طريقة الاستخدام:</p>
                <ol className="text-gray-300 text-sm space-y-2 mr-4 list-decimal list-inside">
                  <li>حدد نقاط الحفر على الموقع بناءً على خطة المسح</li>
                  <li>استخدم المثقاب لحفر عينات من أعماق مختلفة</li>
                  <li>ضع العينات في حاويات معايرة ووسمها بالعمق</li>
                  <li>استخدم كاشف المعادن على السطح للكشف عن أي معادن أو أنابيب</li>
                  <li>استخدم جهاز الرادار الأرضي لرسم خريطة الطبقات</li>
                  <li>اختبر الكثافة والضغط على العينات في المختبر</li>
                </ol>
              </div>
              <div className="bg-black/30 p-4 rounded-lg border border-cyan-400/30 mt-3">
                <p className="text-cyan-400 font-semibold mb-2">📖 شرح الاستخدام:</p>
                <p className="text-gray-300 text-sm">
                  التحقيق الجيوتقني يحدد قدرة التربة على تحمل المشاريع. كل عمق لديه خصائص مختلفة: كثافة، رطوبة، نوع التربة (رمل، طين، الخ). نتائج الاختبار تحدد عمق الأساسات ونوعها. المياه الجوفية مهمة جداً وتؤثر على نوع الأساسات. هذه الاختبارات ضرورية لكل مشروع بناء ولا يمكن تخطيها.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Key Terms */}
        <div className="mb-12 bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10">
          <h3 className="text-3xl font-bold mb-6 text-blue-400">مصطلحات مهمة</h3>
          
          <div className="space-y-4">
            <div className="flex gap-4">
              <span className="text-blue-400 font-bold min-w-[120px]">Latitude:</span>
              <span className="text-gray-300">العرض - المسافة من خط الاستواء شمالاً أو جنوباً</span>
            </div>
            <div className="flex gap-4">
              <span className="text-blue-400 font-bold min-w-[120px]">Longitude:</span>
              <span className="text-gray-300">الطول - المسافة من خط غرينتش شرقاً أو غرباً</span>
            </div>
            <div className="flex gap-4">
              <span className="text-blue-400 font-bold min-w-[120px]">Azimuth:</span>
              <span className="text-gray-300">الاتجاه - الزاوية المقاسة من الشمال الحقيقي في اتجاه عقارب الساعة</span>
            </div>
            <div className="flex gap-4">
              <span className="text-blue-400 font-bold min-w-[120px]">Datum:</span>
              <span className="text-gray-300">المرجع الجيوديسي - نموذج رياضي لتمثيل شكل وحجم الأرض</span>
            </div>
            <div className="flex gap-4">
              <span className="text-blue-400 font-bold min-w-[120px]">Scale:</span>
              <span className="text-gray-300">المقياس - النسبة بين المسافة على الخريطة والمسافة الحقيقية</span>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="bg-gradient-to-r from-blue-600/20 to-indigo-600/20 rounded-xl p-8 border border-blue-400/30 text-center">
          <h3 className="text-2xl font-bold mb-4">جاهز لاستخدام الأدوات؟</h3>
          <p className="text-gray-300 mb-6">
            استخدم تطبيق إبراهيم شواف لاستخراج وتحليل الإحداثيات من ملفات CAD والقيام بالحسابات الهندسية المختلفة.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Link href="/coordinates">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700" data-testid="button-coordinates-extractor">
                استخراج الإحداثيات
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
            <Link href="/calculator">
              <Button size="lg" variant="secondary" data-testid="button-calculator">
                حاسبة المساحة
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
