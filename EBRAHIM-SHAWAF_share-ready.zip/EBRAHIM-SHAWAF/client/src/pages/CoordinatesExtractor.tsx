import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { ArrowRight, Upload, Download, Trash2, Copy, Home } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import * as XLSX from "xlsx";
import { useLanguage } from "@/lib/i18n";

interface Coordinate {
  id: number;
  name: string;
  x: number;
  y: number;
  z?: number;
  type?: string;
}

const decimalToDMS = (decimal: number, isLat: boolean = true): string => {
  const absolute = Math.abs(decimal);
  const degrees = Math.floor(absolute);
  const minutesDecimal = (absolute - degrees) * 60;
  const minutes = Math.floor(minutesDecimal);
  const seconds = ((minutesDecimal - minutes) * 60).toFixed(2);
  
  const direction = isLat 
    ? (decimal >= 0 ? 'N' : 'S')
    : (decimal >= 0 ? 'E' : 'W');
  
  return `${degrees}° ${minutes}' ${seconds}" ${direction}`;
};

const computeDistance = (p1: Coordinate, p2: Coordinate): number => {
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  const dz = (p2.z || 0) - (p1.z || 0);
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
};

const calculatePolygonArea = (points: Coordinate[]): number => {
  if (points.length < 3) return 0;
  let area = 0;
  for (let i = 0; i < points.length; i++) {
    const p1 = points[i];
    const p2 = points[(i + 1) % points.length];
    area += p1.x * p2.y - p2.x * p1.y;
  }
  return Math.abs(area) / 2;
};

const parseGeoJSON = (content: string): Coordinate[] => {
  try {
    const geojson = JSON.parse(content);
    const coordinates: Coordinate[] = [];
    let coordId = 1;

    if (geojson.features && Array.isArray(geojson.features)) {
      geojson.features.forEach((feature: any) => {
        const props = feature.properties || {};
        const name = props.name || `Point ${coordId}`;
        
        if (feature.geometry?.type === 'Point' && feature.geometry.coordinates) {
          const [lon, lat, alt] = feature.geometry.coordinates;
          coordinates.push({
            id: coordId++,
            name,
            x: lon,
            y: lat,
            z: alt,
            type: 'GeoJSON'
          });
        }
      });
    }

    return coordinates;
  } catch (error) {
    throw new Error('خطأ في قراءة ملف GeoJSON');
  }
};

const parseKML = (content: string): Coordinate[] => {
  const coordinates: Coordinate[] = [];
  let coordId = 1;

  try {
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(content, 'text/xml');

    if (xmlDoc.getElementsByTagName('parsererror').length > 0) {
      throw new Error('خطأ في تحليل ملف KML');
    }

    const placemarks = xmlDoc.getElementsByTagName('Placemark');
    
    Array.from(placemarks).forEach((placemark: any) => {
      const nameEl = placemark.getElementsByTagName('name')[0];
      const name = nameEl?.textContent || `Point ${coordId}`;
      
      const pointEl = placemark.getElementsByTagName('Point')[0];
      if (pointEl) {
        const coordsEl = pointEl.getElementsByTagName('coordinates')[0];
        if (coordsEl?.textContent) {
          const coords = coordsEl.textContent.trim().split(',').map((c: string) => parseFloat(c));
          if (coords.length >= 2) {
            coordinates.push({
              id: coordId++,
              name,
              x: coords[0],
              y: coords[1],
              z: coords[2],
              type: 'KML'
            });
          }
        }
      }
    });

    return coordinates;
  } catch (error) {
    throw new Error('خطأ في قراءة ملف KML');
  }
};

const parseGPX = (content: string): Coordinate[] => {
  const coordinates: Coordinate[] = [];
  let coordId = 1;

  try {
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(content, 'text/xml');

    if (xmlDoc.getElementsByTagName('parsererror').length > 0) {
      throw new Error('خطأ في تحليل ملف GPX');
    }

    const wpts = xmlDoc.getElementsByTagName('wpt');
    Array.from(wpts).forEach((wpt: any) => {
      const lat = parseFloat(wpt.getAttribute('lat') || '0');
      const lon = parseFloat(wpt.getAttribute('lon') || '0');
      const nameEl = wpt.getElementsByTagName('name')[0];
      const name = nameEl?.textContent || `Waypoint ${coordId}`;

      if (!isNaN(lat) && !isNaN(lon)) {
        coordinates.push({
          id: coordId++,
          name,
          x: lon,
          y: lat,
          type: 'GPX'
        });
      }
    });

    return coordinates;
  } catch (error) {
    throw new Error('خطأ في قراءة ملف GPX');
  }
};

const parseDXF = (content: string): Coordinate[] => {
  const coordinates: Coordinate[] = [];
  const lines = content.split('\n');
  let coordId = 1;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    if (line === 'POINT' || line === 'CIRCLE' || line === 'LINE') {
      let x = 0, y = 0, z = 0;
      const type = line;
      
      for (let j = i + 1; j < Math.min(i + 40, lines.length); j++) {
        const code = lines[j]?.trim();
        const value = lines[j + 1]?.trim();
        
        if (code === '10') {
          x = parseFloat(value || '0');
        } else if (code === '20') {
          y = parseFloat(value || '0');
        } else if (code === '30') {
          z = parseFloat(value || '0');
        } else if (code === '0') {
          break;
        }
      }
      
      if (!isNaN(x) && !isNaN(y)) {
        coordinates.push({
          id: coordId++,
          name: `${type}${coordId}`,
          x,
          y,
          z: z !== 0 && !isNaN(z) ? z : undefined,
          type
        });
      }
    } 
    else if (line === 'LWPOLYLINE' || line === 'POLYLINE') {
      let currentX = 0, currentY = 0, currentZ = 0;
      
      for (let j = i + 1; j < Math.min(i + 200, lines.length); j++) {
        const code = lines[j]?.trim();
        const value = lines[j + 1]?.trim();
        
        if (code === '10') {
          currentX = parseFloat(value || '0');
        } else if (code === '20') {
          currentY = parseFloat(value || '0');
          
          if (!isNaN(currentX) && !isNaN(currentY)) {
            coordinates.push({
              id: coordId++,
              name: `POINT${coordId}`,
              x: currentX,
              y: currentY,
              z: !isNaN(currentZ) && currentZ !== 0 ? currentZ : undefined,
              type: 'POLYLINE'
            });
          }
        } else if (code === '30') {
          currentZ = parseFloat(value || '0');
        } else if (code === 'SEQEND' || code === '0') {
          break;
        }
      }
    }
  }
  
  return coordinates;
};


const parseExcelFile = (file: File): Promise<Coordinate[]> => {
  return new Promise((resolve, reject) => {
    const fileName = file.name.toLowerCase();
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        let coords: Coordinate[] = [];

        if (fileName.endsWith('.dxf')) {
          coords = parseDXF(content);
        } else if (fileName.endsWith('.geojson') || fileName.endsWith('.json')) {
          coords = parseGeoJSON(content);
        } else if (fileName.endsWith('.kml')) {
          coords = parseKML(content);
        } else if (fileName.endsWith('.gpx')) {
          coords = parseGPX(content);
        } else {
          const lines = content.split('\n');
          let id = 1;

          for (let i = 1; i < lines.length; i++) {
            const line = lines[i].trim();
            if (!line) continue;

            const cells = line.split(',').map(cell => cell.trim());
            
            if (cells.length >= 3) {
              const name = cells[0] || `Point ${id}`;
              const x = parseFloat(cells[1]);
              const y = parseFloat(cells[2]);
              const z = cells.length > 3 ? parseFloat(cells[3]) : undefined;

              if (!isNaN(x) && !isNaN(y)) {
                coords.push({
                  id,
                  name,
                  x,
                  y,
                  z: !isNaN(z || NaN) ? z : undefined,
                  type: 'CSV'
                });
                id++;
              }
            }
          }
        }

        if (coords.length === 0) {
          reject(new Error('❌ لم يتم العثور على إحداثيات في الملف'));
        } else {
          resolve(coords);
        }
      } catch (error) {
        reject(new Error('خطأ في قراءة الملف: ' + (error instanceof Error ? error.message : '')));
      }
    };

    reader.onerror = () => reject(new Error('❌ خطأ في قراءة الملف'));
    reader.readAsText(file);
  });
};

const exportToExcel = (coordinates: Coordinate[]) => {
  const data = [
    ['الاسم', 'X', 'Y', 'Z'],
    ...coordinates.map(c => 
      [c.name, c.x, c.y, c.z || '']
    )
  ];

  const worksheet = XLSX.utils.aoa_to_sheet(data);
  
  worksheet['!cols'] = [
    { wch: 15 },
    { wch: 15 },
    { wch: 15 },
    { wch: 15 }
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'الإحداثيات');
  
  workbook.Props = {
    Title: 'الإحداثيات',
    Author: 'Survey Calculator'
  };

  XLSX.writeFile(workbook, 'coordinates.xlsx');
};

const exportToGeoJSON = (coordinates: Coordinate[]) => {
  const features = coordinates.map(c => ({
    type: 'Feature',
    properties: {
      name: c.name,
      type: c.type || 'Point'
    },
    geometry: {
      type: 'Point',
      coordinates: [c.x, c.y, c.z || 0]
    }
  }));

  const geojson = {
    type: 'FeatureCollection',
    features
  };

  const blob = new Blob([JSON.stringify(geojson, null, 2)], { type: 'application/json' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'coordinates.geojson';
  link.click();
};

const exportToKML = (coordinates: Coordinate[]) => {
  let kml = `<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <name>الإحداثيات</name>
    <description>إحداثيات معالجة</description>
    <Folder>
      <name>النقاط</name>
`;

  coordinates.forEach(c => {
    kml += `      <Placemark>
        <name>${c.name}</name>
        <description>نوع: ${c.type || 'نقطة'}</description>
        <Point>
          <coordinates>${c.x},${c.y}${c.z ? ',' + c.z : ''}</coordinates>
        </Point>
      </Placemark>
`;
  });

  kml += `    </Folder>
  </Document>
</kml>`;

  const blob = new Blob([kml], { type: 'application/vnd.google-earth.kml+xml' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'coordinates.kml';
  link.click();
};

const exportToCSV = (coordinates: Coordinate[]) => {
  const rows = [
    ['الاسم', 'X', 'Y', 'Z', 'النوع'],
    ...coordinates.map(c => [c.name, c.x, c.y, c.z || '', c.type || ''])
  ];

  const csv = rows.map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'coordinates.csv';
  link.click();
};

const exportToJSON = (coordinates: Coordinate[]) => {
  const json = {
    type: 'Coordinates',
    count: coordinates.length,
    data: coordinates.map(c => ({
      id: c.id,
      name: c.name,
      x: c.x,
      y: c.y,
      z: c.z || null,
      type: c.type || 'Point'
    }))
  };

  const blob = new Blob([JSON.stringify(json, null, 2)], { type: 'application/json' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'coordinates.json';
  link.click();
};

const exportToGPX = (coordinates: Coordinate[]) => {
  let gpx = `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="Survey Calculator">
  <metadata>
    <name>Surveyed Points</name>
    <time>${new Date().toISOString()}</time>
  </metadata>
`;

  coordinates.forEach(c => {
    gpx += `  <wpt lat="${c.y}" lon="${c.x}">
    <name>${c.name}</name>
    <desc>Type: ${c.type || 'Point'}</desc>
${c.z ? `    <ele>${c.z}</ele>\n` : ''}  </wpt>
`;
  });

  gpx += `</gpx>`;

  const blob = new Blob([gpx], { type: 'application/gpx+xml' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'coordinates.gpx';
  link.click();
};

type CoordinateFormat = 'raw' | 'decimal' | 'dms';

export default function CoordinatesExtractor() {
  const { language } = useLanguage();
  const [coordinates, setCoordinates] = useState<Coordinate[]>([]);
  const [distanceResult, setDistanceResult] = useState<number | null>(null);
  const [areaResult, setAreaResult] = useState<number | null>(null);
  const [selectedPoints, setSelectedPoints] = useState<Set<number>>(new Set());
  const [isConverting, setIsConverting] = useState(false);
  const [coordFormat, setCoordFormat] = useState<CoordinateFormat>('raw');
  const [progress, setProgress] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processStatus, setProcessStatus] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const converterInputRef = useRef<HTMLInputElement>(null);

  const [coordInput, setCoordInput] = useState({
    lat: '',
    lng: '',
    easting: '',
    northing: '',
    zone: '36',
    hemisphere: 'N' as 'N' | 'S'
  });
  const [coordResult, setCoordResult] = useState<any>(null);
  const [conversionMode, setConversionMode] = useState<'wgs84_to_utm' | 'utm_to_wgs84'>('wgs84_to_utm');

  const convertWGS84toUTM = (lat: number, lng: number) => {
    const zone = Math.floor((lng + 180) / 6) + 1;
    const k0 = 0.9996;
    const a = 6378137;
    const e = 0.081819191;
    const e2 = e * e;
    const latRad = lat * Math.PI / 180;
    const lngRad = lng * Math.PI / 180;
    const centralMeridian = ((zone - 1) * 6 - 180 + 3) * Math.PI / 180;
    const N = a / Math.sqrt(1 - e2 * Math.sin(latRad) * Math.sin(latRad));
    const T = Math.tan(latRad) * Math.tan(latRad);
    const C = (e2 / (1 - e2)) * Math.cos(latRad) * Math.cos(latRad);
    const A = Math.cos(latRad) * (lngRad - centralMeridian);
    const M = a * ((1 - e2/4 - 3*e2*e2/64) * latRad - (3*e2/8 + 3*e2*e2/32) * Math.sin(2*latRad) + (15*e2*e2/256) * Math.sin(4*latRad));
    let easting = k0 * N * (A + (1-T+C)*A*A*A/6) + 500000;
    let northing = k0 * (M + N*Math.tan(latRad)*(A*A/2 + (5-T+9*C+4*C*C)*A*A*A*A/24));
    if (lat < 0) northing += 10000000;
    
    return {
      zone,
      easting,
      northing,
      hemisphere: lat >= 0 ? 'N' : 'S'
    };
  };

  const convertUTMtoWGS84 = (easting: number, northing: number, zone: number, hemisphere: 'N' | 'S') => {
    const k0 = 0.9996;
    const a = 6378137;
    const e = 0.081819191;
    const e2 = e * e;
    const e1 = (1 - Math.sqrt(1 - e*e)) / (1 + Math.sqrt(1 - e*e));
    const x = easting - 500000;
    const y = hemisphere === 'S' ? northing - 10000000 : northing;
    const centralMeridian = ((zone - 1) * 6 - 180 + 3) * Math.PI / 180;
    const M = y / k0;
    const mu = M / (a * (1 - e2/4 - 3*e2*e2/64));
    const phi1 = mu + (3*e1/2 - 27*e1*e1*e1/32)*Math.sin(2*mu) + (21*e1*e1/16)*Math.sin(4*mu);
    const N1 = a / Math.sqrt(1 - e2 * Math.sin(phi1)*Math.sin(phi1));
    const T1 = Math.tan(phi1) * Math.tan(phi1);
    const C1 = (e2/(1-e2)) * Math.cos(phi1)*Math.cos(phi1);
    const R1 = a * (1-e2) / Math.pow(1 - e2*Math.sin(phi1)*Math.sin(phi1), 1.5);
    const D = x / (N1 * k0);
    const latRad = phi1 - (N1*Math.tan(phi1)/R1) * (D*D/2 - (5+3*T1)*D*D*D*D/24);
    const lngRad = centralMeridian + (D - (1+2*T1+C1)*D*D*D/6) / Math.cos(phi1);
    const latDeg = latRad * 180 / Math.PI;
    const lngDeg = lngRad * 180 / Math.PI;
    
    return {
      lat: latDeg,
      lng: lngDeg,
      latDMS: decimalToDMS(latDeg, true),
      lngDMS: decimalToDMS(lngDeg, false)
    };
  };

  const handleWGS84toUTM = () => {
    const lat = parseFloat(coordInput.lat);
    const lng = parseFloat(coordInput.lng);
    
    if (isNaN(lat) || isNaN(lng)) {
      toast.error(language === 'ar' ? 'يرجى إدخال قيم صحيحة' : 'Please enter valid values');
      return;
    }
    
    if (lat < -90 || lat > 90) {
      toast.error(language === 'ar' ? 'خط العرض يجب أن يكون بين -90 و 90' : 'Latitude must be between -90 and 90');
      return;
    }
    
    if (lng < -180 || lng > 180) {
      toast.error(language === 'ar' ? 'خط الطول يجب أن يكون بين -180 و 180' : 'Longitude must be between -180 and 180');
      return;
    }
    
    const result = convertWGS84toUTM(lat, lng);
    setCoordResult(result);
    setConversionMode('wgs84_to_utm');
    toast.success(language === 'ar' ? '✓ تم التحويل بنجاح' : '✓ Conversion successful');
  };

  const handleUTMtoWGS84 = () => {
    const easting = parseFloat(coordInput.easting);
    const northing = parseFloat(coordInput.northing);
    const zone = parseInt(coordInput.zone);
    
    if (isNaN(easting) || isNaN(northing) || isNaN(zone)) {
      toast.error(language === 'ar' ? 'يرجى إدخال قيم صحيحة' : 'Please enter valid values');
      return;
    }
    
    if (zone < 1 || zone > 60) {
      toast.error(language === 'ar' ? 'المنطقة يجب أن تكون بين 1 و 60' : 'Zone must be between 1 and 60');
      return;
    }
    
    const result = convertUTMtoWGS84(easting, northing, zone, coordInput.hemisphere);
    setCoordResult(result);
    setConversionMode('utm_to_wgs84');
    toast.success(language === 'ar' ? '✓ تم التحويل بنجاح' : '✓ Conversion successful');
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const maxFileSize = 10 * 1024 * 1024;
    if (file.size > maxFileSize) {
      toast.error('حجم الملف كبير جداً. يجب أن يكون أقل من 10 ميجابايت');
      return;
    }

    const fileName = file.name.toLowerCase();
    const supportedFormats = ['.csv', '.xlsx', '.dxf', '.geojson', '.json', '.kml', '.gpx'];
    const isValid = supportedFormats.some(fmt => fileName.endsWith(fmt));
    
    if (!isValid) {
      toast.error('صيغة الملف غير مدعومة. استخدم: CSV, Excel, DXF, GeoJSON, KML, GPX');
      return;
    }

    setIsProcessing(true);
    setProgress(0);
    setProcessStatus('جاري تحميل الملف...');

    try {
      setProgress(10);
      setProcessStatus('جاري قراءة الملف...');
      
      await new Promise(resolve => setTimeout(resolve, 300));
      setProgress(30);
      setProcessStatus('جاري استخراج الإحداثيات...');

      const coords = await parseExcelFile(file);
      
      setProgress(80);
      setProcessStatus('جاري معالجة البيانات...');
      
      await new Promise(resolve => setTimeout(resolve, 200));
      
      if (coords && coords.length > 0) {
        setCoordinates(coords);
        setSelectedPoints(new Set());
        setDistanceResult(null);
        setAreaResult(null);
        setProgress(100);
        setProcessStatus('✅ تم التحميل بنجاح!');
        toast.success(`✓ تم تحميل ${coords.length} إحداثية`);
      } else {
        setProgress(0);
        setProcessStatus('');
        toast.error('لم يتم استخراج إحداثيات من الملف');
      }
    } catch (error) {
      setProgress(0);
      setProcessStatus('');
      toast.error(`❌ ${error instanceof Error ? error.message : 'خطأ في تحميل الملف'}`);
    } finally {
      setIsProcessing(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
      
      setTimeout(() => {
        setProgress(0);
        setProcessStatus('');
      }, 1000);
    }
  };

  const togglePointSelection = (id: number) => {
    const newSelected = new Set(selectedPoints);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedPoints(newSelected);
  };

  const handleCalculateDistance = () => {
    if (selectedPoints.size !== 2) {
      toast.error('يرجى تحديد نقطتين بالضبط');
      return;
    }

    const points = coordinates.filter(c => selectedPoints.has(c.id));
    const distance = computeDistance(points[0], points[1]);
    setDistanceResult(distance);
  };

  const calculateArea = () => {
    if (selectedPoints.size < 3) {
      toast.error('يرجى تحديد 3 نقاط على الأقل');
      return;
    }

    const points = coordinates.filter(c => selectedPoints.has(c.id))
      .sort((a, b) => a.id - b.id);
    const area = calculatePolygonArea(points);
    setAreaResult(area);
  };

  const clearSelection = () => {
    setSelectedPoints(new Set());
    setDistanceResult(null);
    setAreaResult(null);
  };

  const handleConvertFile = () => {
    setIsConverting(true);
    setTimeout(() => setIsConverting(false), 1000);
    
    toast.success('افتح CloudConvert لتحويل ملفات DWG إلى DXF', {
      duration: 5000,
      action: {
        label: '➜ افتح',
        onClick: () => {
          window.open('https://cloudconvert.com/dwg-to-dxf', '_blank');
        }
      }
    });
  };

  const formatCoordinate = (coord: Coordinate): string => {
    switch (coordFormat) {
      case 'decimal':
        if (coord.x < 360 && coord.y < 360) {
          return `${coord.x.toFixed(6)}, ${coord.y.toFixed(6)}`;
        } else {
          return `${coord.x.toFixed(2)}, ${coord.y.toFixed(2)}`;
        }
      case 'dms':
        return `${decimalToDMS(coord.x, false)}, ${decimalToDMS(coord.y, true)}`;
      case 'raw':
      default:
        return `X: ${coord.x}, Y: ${coord.y}`;
    }
  };

  const copyCoordinates = () => {
    const text = coordinates
      .map(c => `${c.name}: ${formatCoordinate(c)}`)
      .join('\n');
    navigator.clipboard.writeText(text);
    toast.success('✓ تم نسخ الإحداثيات');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-emerald-900 to-slate-900 p-4 pt-6" dir="rtl" data-testid="coordinates-extractor-page">
      <div className="max-w-4xl mx-auto space-y-6">
        
        <div className="flex items-center justify-between mb-6">
          <Link href="/">
            <button className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition">
              <Home className="w-5 h-5" />
              <span>الرئيسية</span>
            </button>
          </Link>
          <div className="text-center flex-1">
            <h1 className="text-3xl font-bold text-white mb-2 flex items-center justify-center gap-3">
              <Upload className="w-10 h-10 text-emerald-400" />
              استخراج الإحداثيات
            </h1>
            <p className="text-gray-400">استخراج وتحليل الإحداثيات من ملفات Excel و DXF و KML</p>
          </div>
          <div className="w-24"></div>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
          <h2 className="text-xl font-bold text-white mb-4">⚙️ تحويل الملفات (DWG → DXF)</h2>
          <p className="text-gray-400 mb-4">حول ملفات AutoCAD من صيغة DWG إلى صيغة DXF المدعومة</p>
          
          <div 
            className="border-2 border-dashed border-blue-400/50 rounded-xl p-6 text-center hover:bg-blue-500/10 cursor-pointer transition"
            onClick={() => converterInputRef.current?.click()}
            data-testid="converter-area"
          >
            {isConverting ? (
              <>
                <div className="animate-spin inline-block w-8 h-8 border-4 border-blue-400 border-t-blue-600 rounded-full mb-2"></div>
                <p className="text-sm font-medium text-white">جاري التحويل...</p>
              </>
            ) : (
              <>
                <Upload className="w-10 h-10 mx-auto mb-2 text-blue-400" />
                <p className="text-lg font-medium text-white">انقر أو اسحب ملف DWG هنا</p>
                <p className="text-sm text-gray-400">سيتم توجيهك لأداة تحويل مجانية</p>
              </>
            )}
          </div>
          <input
            ref={converterInputRef}
            type="file"
            accept=".dwg"
            disabled={isConverting}
            className="hidden"
            onChange={() => handleConvertFile()}
          />

          <div className="grid grid-cols-3 gap-2 mt-4">
            {[
              { name: 'CloudConvert', url: 'https://cloudconvert.com/dwg-to-dxf', icon: '☁️' },
              { name: 'OnlineConvert', url: 'https://www.onlineconvert.com/convert/dwg-to-dxf', icon: '🔄' },
              { name: 'Zamzar', url: 'https://www.zamzar.com/convert/dwg-to-dxf/', icon: '🌐' }
            ].map((tool) => (
              <a
                key={tool.name}
                href={tool.url}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition text-center"
              >
                {tool.icon} {tool.name}
              </a>
            ))}
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
          <h2 className="text-xl font-bold text-white mb-4">📂 تحميل ملف الإحداثيات</h2>
          
          {(isProcessing || progress > 0) && (
            <div className="mb-4 space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-white">{processStatus}</p>
                <p className="text-sm text-gray-400">{progress}%</p>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}
          
          <div 
            className={`border-2 border-dashed ${isProcessing ? 'border-emerald-400/30' : 'border-emerald-400/50'} rounded-xl p-8 text-center hover:bg-emerald-500/10 cursor-pointer transition ${isProcessing ? 'opacity-50' : ''}`}
            onClick={() => !isProcessing && fileInputRef.current?.click()}
            data-testid="upload-area"
          >
            {isProcessing ? (
              <>
                <div className="animate-spin inline-block w-10 h-10 border-4 border-emerald-400/30 border-t-emerald-400 rounded-full mb-3"></div>
                <p className="text-lg font-medium text-white">جاري معالجة الملف...</p>
              </>
            ) : (
              <>
                <Upload className="w-12 h-12 mx-auto mb-3 text-emerald-400" />
                <p className="text-lg font-medium text-white">انقر أو اسحب الملف هنا</p>
                <p className="text-sm text-gray-400 mt-2">ملفات مدعومة: Excel، CSV، DXF، GeoJSON، KML، GPX</p>
                <p className="text-xs text-amber-400 mt-2">
                  📝 ملفات DWG: يرجى تحويلها إلى DXF أولاً
                </p>
              </>
            )}
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,.xlsx,.dxf,.geojson,.json,.kml,.gpx"
            onChange={handleFileUpload}
            disabled={isProcessing}
            className="hidden"
            data-testid="input-file"
          />
        </div>

        {/* Coordinate Conversion Tool Section */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
          <h2 className="text-xl font-bold text-white mb-4">
            🌐 {language === 'ar' ? 'تحويل الإحداثيات' : 'Coordinate Conversion'}
          </h2>
          <p className="text-gray-400 mb-6">
            {language === 'ar' 
              ? 'تحويل الإحداثيات بين نظام WGS84 (خطوط الطول والعرض) ونظام UTM (الإحداثيات المترية)'
              : 'Convert coordinates between WGS84 (Lat/Lng) and UTM (metric coordinates)'}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* WGS84 to UTM Panel */}
            <div className="bg-gradient-to-br from-blue-600/20 to-cyan-600/20 rounded-xl p-5 border border-blue-500/30">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <span className="text-2xl">🌍</span>
                WGS84 → UTM
              </h3>
              
              <div className="space-y-4">
                <div>
                  <Label className="text-gray-300 text-sm mb-1 block">
                    {language === 'ar' ? 'خط العرض (Latitude)' : 'Latitude'}
                  </Label>
                  <Input
                    type="number"
                    step="any"
                    placeholder={language === 'ar' ? 'مثال: 24.7136' : 'e.g., 24.7136'}
                    value={coordInput.lat}
                    onChange={(e) => setCoordInput({...coordInput, lat: e.target.value})}
                    className="bg-white/10 border-white/20 text-white placeholder:text-gray-500"
                    data-testid="input-wgs84-lat"
                  />
                </div>
                
                <div>
                  <Label className="text-gray-300 text-sm mb-1 block">
                    {language === 'ar' ? 'خط الطول (Longitude)' : 'Longitude'}
                  </Label>
                  <Input
                    type="number"
                    step="any"
                    placeholder={language === 'ar' ? 'مثال: 46.6753' : 'e.g., 46.6753'}
                    value={coordInput.lng}
                    onChange={(e) => setCoordInput({...coordInput, lng: e.target.value})}
                    className="bg-white/10 border-white/20 text-white placeholder:text-gray-500"
                    data-testid="input-wgs84-lng"
                  />
                </div>

                <Button 
                  onClick={handleWGS84toUTM}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  data-testid="button-convert-to-utm"
                >
                  {language === 'ar' ? '🔄 تحويل إلى UTM' : '🔄 Convert to UTM'}
                </Button>

                {coordResult && conversionMode === 'wgs84_to_utm' && (
                  <div className="mt-4 p-4 bg-white/10 rounded-lg border border-white/20 space-y-2">
                    <h4 className="text-sm font-semibold text-emerald-400 mb-3">
                      {language === 'ar' ? '✅ النتيجة:' : '✅ Result:'}
                    </h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="text-gray-400">{language === 'ar' ? 'المنطقة (Zone):' : 'Zone:'}</div>
                      <div className="text-white font-mono">{coordResult.zone}{coordResult.hemisphere}</div>
                      
                      <div className="text-gray-400">{language === 'ar' ? 'الإحداثي الشرقي (E):' : 'Easting (E):'}</div>
                      <div className="text-white font-mono">{coordResult.easting?.toFixed(2)} m</div>
                      
                      <div className="text-gray-400">{language === 'ar' ? 'الإحداثي الشمالي (N):' : 'Northing (N):'}</div>
                      <div className="text-white font-mono">{coordResult.northing?.toFixed(2)} m</div>
                      
                      <div className="text-gray-400">{language === 'ar' ? 'نصف الكرة:' : 'Hemisphere:'}</div>
                      <div className="text-white font-mono">{coordResult.hemisphere === 'N' ? (language === 'ar' ? 'شمالي' : 'North') : (language === 'ar' ? 'جنوبي' : 'South')}</div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* UTM to WGS84 Panel */}
            <div className="bg-gradient-to-br from-emerald-600/20 to-teal-600/20 rounded-xl p-5 border border-emerald-500/30">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <span className="text-2xl">📍</span>
                UTM → WGS84
              </h3>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-gray-300 text-sm mb-1 block">
                      {language === 'ar' ? 'المنطقة (Zone)' : 'Zone'}
                    </Label>
                    <Input
                      type="number"
                      min="1"
                      max="60"
                      placeholder="36"
                      value={coordInput.zone}
                      onChange={(e) => setCoordInput({...coordInput, zone: e.target.value})}
                      className="bg-white/10 border-white/20 text-white placeholder:text-gray-500"
                      data-testid="input-utm-zone"
                    />
                  </div>
                  
                  <div>
                    <Label className="text-gray-300 text-sm mb-1 block">
                      {language === 'ar' ? 'نصف الكرة' : 'Hemisphere'}
                    </Label>
                    <select
                      value={coordInput.hemisphere}
                      onChange={(e) => setCoordInput({...coordInput, hemisphere: e.target.value as 'N' | 'S'})}
                      className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-md text-white text-sm"
                      data-testid="select-utm-hemisphere"
                    >
                      <option value="N" className="bg-slate-800">{language === 'ar' ? 'شمالي (N)' : 'North (N)'}</option>
                      <option value="S" className="bg-slate-800">{language === 'ar' ? 'جنوبي (S)' : 'South (S)'}</option>
                    </select>
                  </div>
                </div>
                
                <div>
                  <Label className="text-gray-300 text-sm mb-1 block">
                    {language === 'ar' ? 'الإحداثي الشرقي (Easting)' : 'Easting'}
                  </Label>
                  <Input
                    type="number"
                    step="any"
                    placeholder={language === 'ar' ? 'مثال: 500000' : 'e.g., 500000'}
                    value={coordInput.easting}
                    onChange={(e) => setCoordInput({...coordInput, easting: e.target.value})}
                    className="bg-white/10 border-white/20 text-white placeholder:text-gray-500"
                    data-testid="input-utm-easting"
                  />
                </div>
                
                <div>
                  <Label className="text-gray-300 text-sm mb-1 block">
                    {language === 'ar' ? 'الإحداثي الشمالي (Northing)' : 'Northing'}
                  </Label>
                  <Input
                    type="number"
                    step="any"
                    placeholder={language === 'ar' ? 'مثال: 2700000' : 'e.g., 2700000'}
                    value={coordInput.northing}
                    onChange={(e) => setCoordInput({...coordInput, northing: e.target.value})}
                    className="bg-white/10 border-white/20 text-white placeholder:text-gray-500"
                    data-testid="input-utm-northing"
                  />
                </div>

                <Button 
                  onClick={handleUTMtoWGS84}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                  data-testid="button-convert-to-wgs84"
                >
                  {language === 'ar' ? '🔄 تحويل إلى WGS84' : '🔄 Convert to WGS84'}
                </Button>

                {coordResult && conversionMode === 'utm_to_wgs84' && (
                  <div className="mt-4 p-4 bg-white/10 rounded-lg border border-white/20 space-y-2">
                    <h4 className="text-sm font-semibold text-emerald-400 mb-3">
                      {language === 'ar' ? '✅ النتيجة:' : '✅ Result:'}
                    </h4>
                    <div className="space-y-3 text-sm">
                      <div>
                        <div className="text-gray-400 mb-1">{language === 'ar' ? 'خط العرض (Latitude):' : 'Latitude:'}</div>
                        <div className="text-white font-mono">{coordResult.lat?.toFixed(6)}°</div>
                        <div className="text-cyan-400 font-mono text-xs mt-1">{coordResult.latDMS}</div>
                      </div>
                      
                      <div>
                        <div className="text-gray-400 mb-1">{language === 'ar' ? 'خط الطول (Longitude):' : 'Longitude:'}</div>
                        <div className="text-white font-mono">{coordResult.lng?.toFixed(6)}°</div>
                        <div className="text-cyan-400 font-mono text-xs mt-1">{coordResult.lngDMS}</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {coordinates.length > 0 && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white">📍 الإحداثيات المحملة ({coordinates.length})</h2>
              <select
                value={coordFormat}
                onChange={(e) => setCoordFormat(e.target.value as CoordinateFormat)}
                className="px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm"
                data-testid="format-select"
              >
                <option value="raw" className="bg-slate-800">📄 خام (كما في الملف)</option>
                <option value="decimal" className="bg-slate-800">📊 عشرية (Decimal)</option>
                <option value="dms" className="bg-slate-800">📐 درجات (DMS)</option>
              </select>
            </div>

            <div className="flex flex-wrap gap-2 mb-4">
              <button onClick={copyCoordinates} className="px-3 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg text-sm font-medium transition flex items-center gap-1">
                <Copy className="w-4 h-4" /> نسخ
              </button>
              <button onClick={() => { exportToExcel(coordinates); toast.success('✓ تم التصدير'); }} className="px-3 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm font-medium transition flex items-center gap-1">
                <Download className="w-4 h-4" /> Excel
              </button>
              <button onClick={() => { exportToGeoJSON(coordinates); toast.success('✓ تم التصدير'); }} className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition flex items-center gap-1">
                <Download className="w-4 h-4" /> GeoJSON
              </button>
              <button onClick={() => { exportToKML(coordinates); toast.success('✓ تم التصدير'); }} className="px-3 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-sm font-medium transition flex items-center gap-1">
                <Download className="w-4 h-4" /> KML
              </button>
              <button onClick={() => { exportToCSV(coordinates); toast.success('✓ تم التصدير'); }} className="px-3 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm font-medium transition flex items-center gap-1">
                <Download className="w-4 h-4" /> CSV
              </button>
              <button onClick={() => { exportToGPX(coordinates); toast.success('✓ تم التصدير'); }} className="px-3 py-2 bg-cyan-600 hover:bg-cyan-700 text-white rounded-lg text-sm font-medium transition flex items-center gap-1">
                <Download className="w-4 h-4" /> GPX
              </button>
            </div>

            <div className="overflow-x-auto max-h-96 overflow-y-auto">
              <table className="w-full text-sm" data-testid="coordinates-table">
                <thead className="sticky top-0 bg-slate-800">
                  <tr className="border-b border-white/20">
                    <th className="text-right p-3 text-gray-300">✓</th>
                    <th className="text-right p-3 text-gray-300">الاسم</th>
                    <th className="text-right p-3 text-gray-300">الإحداثيات</th>
                    <th className="text-right p-3 text-gray-300">Z</th>
                  </tr>
                </thead>
                <tbody>
                  {coordinates.map((coord) => (
                    <tr 
                      key={coord.id}
                      className={`border-b border-white/10 cursor-pointer hover:bg-white/5 transition ${
                        selectedPoints.has(coord.id) ? 'bg-emerald-500/20' : ''
                      }`}
                      onClick={() => togglePointSelection(coord.id)}
                      data-testid={`row-coordinate-${coord.id}`}
                    >
                      <td className="p-3">
                        <input
                          type="checkbox"
                          checked={selectedPoints.has(coord.id)}
                          onChange={() => togglePointSelection(coord.id)}
                          className="cursor-pointer accent-emerald-500"
                        />
                      </td>
                      <td className="p-3 font-medium text-white">{coord.name}</td>
                      <td className="p-3 font-mono text-xs text-gray-300">{formatCoordinate(coord)}</td>
                      <td className="p-3 font-mono text-xs text-gray-400">{coord.z?.toFixed(2) || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {coordinates.length > 0 && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
            <h2 className="text-xl font-bold text-white mb-4">📐 الحسابات</h2>
            <p className="text-gray-400 mb-4">اختر النقاط من الجدول أعلاه لحساب المسافة والمساحة</p>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <button
                onClick={handleCalculateDistance}
                className={`py-3 rounded-xl font-semibold transition ${
                  selectedPoints.size === 2
                    ? 'bg-blue-600 hover:bg-blue-700 text-white'
                    : 'bg-white/5 text-gray-400 border border-white/10'
                }`}
                data-testid="button-distance"
              >
                📏 حساب المسافة (نقطتين)
              </button>
              <button
                onClick={calculateArea}
                className={`py-3 rounded-xl font-semibold transition ${
                  selectedPoints.size >= 3
                    ? 'bg-purple-600 hover:bg-purple-700 text-white'
                    : 'bg-white/5 text-gray-400 border border-white/10'
                }`}
                data-testid="button-area"
              >
                📐 حساب المساحة (3+ نقاط)
              </button>
            </div>

            {distanceResult !== null && (
              <div className="bg-gradient-to-r from-blue-600/20 to-cyan-600/20 rounded-xl p-4 border border-blue-500/30 mb-4">
                <p className="text-sm text-gray-400 mb-1">📏 المسافة</p>
                <p className="text-3xl font-bold text-white">
                  {distanceResult.toFixed(2)} <span className="text-lg text-gray-400">متر</span>
                </p>
              </div>
            )}

            {areaResult !== null && (
              <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-xl p-4 border border-purple-500/30 mb-4">
                <p className="text-sm text-gray-400 mb-1">📐 المساحة</p>
                <p className="text-3xl font-bold text-white">
                  {areaResult.toFixed(2)} <span className="text-lg text-gray-400">متر مربع</span>
                </p>
              </div>
            )}

            {selectedPoints.size > 0 && (
              <button
                onClick={clearSelection}
                className="w-full py-3 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-xl font-semibold transition flex items-center justify-center gap-2"
                data-testid="button-clear"
              >
                <Trash2 className="w-4 h-4" />
                مسح الاختيار ({selectedPoints.size} نقطة)
              </button>
            )}
          </div>
        )}

        <Link href="/">
          <button className="w-full py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-semibold transition flex items-center justify-center gap-2">
            العودة للرئيسية
            <ArrowRight className="w-5 h-5" />
          </button>
        </Link>
      </div>
    </div>
  );
}
