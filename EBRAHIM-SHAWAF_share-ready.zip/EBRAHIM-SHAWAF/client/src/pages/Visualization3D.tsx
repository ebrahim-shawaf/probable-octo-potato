import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, MapPin, Eye, EyeOff, Trash2, Download, RotateCw, Camera, Loader, Globe } from "lucide-react";
import { useLanguage } from "@/lib/i18n";

interface Point3D {
  id: number;
  latitude: number;
  longitude: number;
  altitude: number | null;
  description: string;
  accuracy: number;
  timestamp: Date;
}

// Simple 3D visualization using HTML5 Canvas and basic math
// Shows points projected on a 3D perspective map
export default function Visualization3D() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [points, setPoints] = useState<Point3D[]>([]);
  const [viewMode, setViewMode] = useState<"map" | "3d" | "table" | "ar">("map");
  const [selectedPoint, setSelectedPoint] = useState<number | null>(null);
  const [autoRotate, setAutoRotate] = useState(true);
  const [cameraDistance, setCameraDistance] = useState(100);
  const [rotationAngle, setRotationAngle] = useState(0);
  const [cameraActive, setCameraActive] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lon: number; accuracy: number } | null>(null);
  const [newPointName, setNewPointName] = useState("");
  const [showNewPointDialog, setShowNewPointDialog] = useState(false);
  const [pendingPoint, setPendingPoint] = useState<{ lat: number; lon: number } | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(null);
  const [verticalRotation, setVerticalRotation] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [panX, setPanX] = useState(0);
  const [panY, setPanY] = useState(0);
  const [hoveredPointId, setHoveredPointId] = useState<number | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  // Load points from localStorage
  useEffect(() => {
    const savedPoints = localStorage.getItem("surveyPoints");
    if (savedPoints) {
      try {
        const parsed = JSON.parse(savedPoints);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const validPoints = parsed.filter((p: any) => 
            p && typeof p.latitude === 'number' && typeof p.longitude === 'number'
          );
          setPoints(
            validPoints.map((p: any) => ({
              ...p,
              timestamp: new Date(p.timestamp),
            }))
          );
        }
      } catch (error) {
        console.error("Error loading points:", error);
      }
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (videoRef.current?.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach((track) => track.stop());
      }
    };
  }, []);

  // Auto rotate camera
  useEffect(() => {
    if (!autoRotate) return;
    const interval = setInterval(() => {
      setRotationAngle((prev) => (prev + 1) % 360);
    }, 50);
    return () => clearInterval(interval);
  }, [autoRotate]);

  // Start camera
  const startCamera = async () => {
    try {
      if (videoRef.current?.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach((track) => track.stop());
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setCameraActive(true);
    } catch (error) {
      console.error("Error accessing camera:", error);
      alert("لا يمكن الوصول للكاميرا");
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach((track) => track.stop());
    }
    setCameraActive(false);
  };

  // Get current location
  const getLocation = async () => {
    return new Promise<void>((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lon: position.coords.longitude,
            accuracy: position.coords.accuracy,
          });
          resolve();
        },
        (error) => {
          console.error("Location error:", error);
          resolve();
        },
        { enableHighAccuracy: true, timeout: 10000 }
      );
    });
  };

  // Calculate distance between two points in meters (Haversine formula)
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371000; // Earth radius in meters
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  // Calculate bearing (direction) between two points in degrees (0-360)
  const calculateBearing = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const lat1Rad = (lat1 * Math.PI) / 180;
    const lat2Rad = (lat2 * Math.PI) / 180;
    
    const y = Math.sin(dLon) * Math.cos(lat2Rad);
    const x =
      Math.cos(lat1Rad) * Math.sin(lat2Rad) -
      Math.sin(lat1Rad) * Math.cos(lat2Rad) * Math.cos(dLon);
    
    let bearing = Math.atan2(y, x) * (180 / Math.PI);
    bearing = (bearing + 360) % 360; // Normalize to 0-360
    return bearing;
  };

  // Project point on camera view based on distance and bearing
  const projectPointOnCamera = (
    distance: number,
    bearing: number,
    screenWidth: number,
    screenHeight: number
  ): { x: number; y: number; scale: number } => {
    // Bearing: 0° = up, 90° = right, 180° = down, 270° = left
    const centerX = screenWidth / 2;
    const centerY = screenHeight / 2;
    
    // Scale distance to screen coordinates (1 meter = 0.5 pixels, max 200 pixels)
    const maxDistance = 400; // Maximum visible distance in meters
    const maxPixels = 150;
    const scale = Math.min(maxPixels, (distance / maxDistance) * maxPixels);
    
    // Convert bearing to radians
    const angle = (bearing * Math.PI) / 180;
    
    // Calculate position
    const x = centerX + scale * Math.sin(angle);
    const y = centerY - scale * Math.cos(angle); // Negative because Y increases downward
    
    // Calculate opacity based on distance
    const opacity = Math.max(0.3, 1 - distance / maxDistance);
    
    return { x, y, scale: opacity };
  };

  // Calculate coordinates from screen click position
  const calculateCoordinatesFromClick = (
    clickX: number,
    clickY: number,
    screenWidth: number,
    screenHeight: number,
    currentLat: number,
    currentLon: number
  ): { lat: number; lon: number } => {
    // Reverse the projection formula
    const centerX = screenWidth / 2;
    const centerY = screenHeight / 2;
    
    const offsetX = clickX - centerX;
    const offsetY = -(clickY - centerY); // Negate because Y increases downward
    
    // Calculate bearing from offset
    const bearing = (Math.atan2(offsetX, offsetY) * 180) / Math.PI;
    const normalizedBearing = (bearing + 360) % 360;
    
    // Calculate distance from offset
    const pixelDistance = Math.sqrt(offsetX * offsetX + offsetY * offsetY);
    const maxPixels = 150;
    const maxDistance = 400;
    const distance = (pixelDistance / maxPixels) * maxDistance;
    
    // Calculate new coordinates
    const bearingRad = (normalizedBearing * Math.PI) / 180;
    const earthRadiusMeters = 6371000;
    
    const dLat = (distance * Math.cos(bearingRad)) / earthRadiusMeters;
    const dLon = (distance * Math.sin(bearingRad)) / (earthRadiusMeters * Math.cos((currentLat * Math.PI) / 180));
    
    return {
      lat: currentLat + (dLat * 180) / Math.PI,
      lon: currentLon + (dLon * 180) / Math.PI,
    };
  };

  // Add new point from camera click
  const addNewPointFromCamera = () => {
    if (!pendingPoint || !newPointName.trim()) {
      alert("يرجى إدخال اسم للنقطة");
      return;
    }

    const now = new Date();
    const newPoint: Point3D = {
      id: Date.now(),
      latitude: pendingPoint.lat,
      longitude: pendingPoint.lon,
      altitude: null,
      description: newPointName.trim(),
      accuracy: currentLocation?.accuracy || 5,
      timestamp: now,
    };

    const updatedPoints = [...points, newPoint];
    setPoints(updatedPoints);

    // Save to localStorage
    const surveyPoints = updatedPoints.map((p) => ({
      id: p.id,
      latitude: p.latitude,
      longitude: p.longitude,
      altitude: p.altitude,
      accuracy: p.accuracy,
      description: p.description,
      timestamp: p.timestamp.toISOString(),
    }));
    localStorage.setItem("surveyPoints", JSON.stringify(surveyPoints));

    // Reset dialog
    setShowNewPointDialog(false);
    setNewPointName("");
    setPendingPoint(null);
    alert("✅ تم إضافة النقطة بنجاح!");
  };

  // Handle camera view click
  const handleCameraClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!currentLocation) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const newCoords = calculateCoordinatesFromClick(
      clickX,
      clickY,
      rect.width,
      rect.height,
      currentLocation.lat,
      currentLocation.lon
    );

    setPendingPoint(newCoords);
    setShowNewPointDialog(true);
  };

  // Handle 3D view mouse events
  const handle3DMouseDown = (e: React.MouseEvent<SVGSVGElement>) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handle3DMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!isDragging || !dragStart) return;

    const deltaX = e.clientX - dragStart.x;
    const deltaY = e.clientY - dragStart.y;

    // Update rotation based on mouse movement
    setRotationAngle((prev) => prev + deltaX * 0.5);
    setVerticalRotation((prev) => Math.max(-Math.PI / 3, Math.min(Math.PI / 3, prev + deltaY * 0.01)));

    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handle3DMouseUp = () => {
    setIsDragging(false);
    setDragStart(null);
  };

  const handle3DWheel = (e: React.WheelEvent<SVGSVGElement>) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    setZoom((prev) => Math.max(0.3, Math.min(3, prev * delta)));
  };

  const clearAllPoints = () => {
    if (window.confirm("هل تريد حذف جميع النقاط؟")) {
      setPoints([]);
      localStorage.removeItem("surveyPoints");
      setSelectedPoint(null);
    }
  };

  const downloadPointsKML = () => {
    if (points.length === 0) {
      alert("لا توجد نقاط لتحميلها");
      return;
    }

    let kml = `<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <name>Survey Points</name>
    <description>نقاط المسح</description>`;

    points.forEach((point) => {
      kml += `
    <Placemark>
      <name>${point.description}</name>
      <description>الدقة: ±${point.accuracy.toFixed(1)} متر\nالارتفاع: ${point.altitude?.toFixed(2) || "N/A"} متر</description>
      <Point>
        <coordinates>${point.longitude},${point.latitude},${point.altitude || 0}</coordinates>
      </Point>
    </Placemark>`;
    });

    kml += `
  </Document>
</kml>`;

    const blob = new Blob([kml], { type: "application/vnd.google-earth.kml+xml" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `survey_points_${Date.now()}.kml`;
    link.click();
  };

  const downloadPointsGeoJSON = () => {
    if (points.length === 0) {
      alert("لا توجد نقاط لتحميلها");
      return;
    }

    const geojson = {
      type: "FeatureCollection",
      features: points.map((point) => ({
        type: "Feature",
        properties: {
          id: point.id,
          name: point.description,
          accuracy: point.accuracy,
          altitude: point.altitude,
          timestamp: point.timestamp.toISOString(),
        },
        geometry: {
          type: "Point",
          coordinates: [point.longitude, point.latitude, point.altitude || 0],
        },
      })),
    };

    const blob = new Blob([JSON.stringify(geojson, null, 2)], {
      type: "application/json",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `survey_points_${Date.now()}.geojson`;
    link.click();
  };

  // Calculate bounds for all points
  const getBounds = () => {
    if (points.length === 0) return null;
    const lats = points.map((p) => p.latitude);
    const lons = points.map((p) => p.longitude);
    const alts = points.map((p) => p.altitude || 0);

    return {
      minLat: Math.min(...lats),
      maxLat: Math.max(...lats),
      minLon: Math.min(...lons),
      maxLon: Math.max(...lons),
      minAlt: Math.min(...alts),
      maxAlt: Math.max(...alts),
      centerLat: (Math.min(...lats) + Math.max(...lats)) / 2,
      centerLon: (Math.min(...lons) + Math.max(...lons)) / 2,
      centerAlt: (Math.min(...alts) + Math.max(...alts)) / 2,
    };
  };

  const bounds = getBounds();

  // Normalize coordinates for visualization
  const normalizePoint = (point: Point3D, bounds: any) => {
    const latRange = bounds.maxLat - bounds.minLat || 1;
    const lonRange = bounds.maxLon - bounds.minLon || 1;
    const altRange = bounds.maxAlt - bounds.minAlt || 1;

    return {
      x: ((point.longitude - bounds.minLon) / lonRange) * 200 - 100,
      y: ((point.latitude - bounds.minLat) / latRange) * 200 - 100,
      z: ((point.altitude || 0) - bounds.minAlt) / Math.max(altRange, 1) * 50,
    };
  };

  // Rotate point in 3D space (horizontal rotation around Y axis)
  const rotate3D = (x: number, y: number, z: number, angleRad: number) => {
    const cos = Math.cos(angleRad);
    const sin = Math.sin(angleRad);
    return {
      x: x * cos - z * sin,
      y: y,
      z: x * sin + z * cos,
    };
  };

  // Rotate point vertically (around X axis)
  const rotateVertical = (x: number, y: number, z: number, angleRad: number) => {
    const cos = Math.cos(angleRad);
    const sin = Math.sin(angleRad);
    return {
      x: x,
      y: y * cos - z * sin,
      z: y * sin + z * cos,
    };
  };

  // Project 3D to 2D
  const project2D = (
    x: number,
    y: number,
    z: number,
    distance: number
  ) => {
    const focalLength = 500;
    const scale = focalLength / (focalLength + z + distance);
    return {
      x: x * scale + 250,
      y: y * scale + 250,
      scale: scale,
    };
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 to-slate-800 text-white" data-testid="visualization-3d-page">
      {/* Navigation */}
      <div className="sticky top-0 z-10 bg-black/30 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">🎯 تصور البيانات ثلاثي الأبعاد</h1>
          <Link href="/camera-gps">
            <Button variant="ghost" className="text-white hover:bg-white/10" data-testid="button-back">
              <ArrowRight className="w-4 h-4 ml-2" />
              العودة
            </Button>
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Controls */}
        <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10 mb-6">
          <div className="grid md:grid-cols-5 gap-4 mb-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">نمط العرض</label>
              <select
                value={viewMode}
                onChange={(e) => {
                  const newMode = e.target.value as "map" | "3d" | "table" | "ar";
                  setViewMode(newMode);
                  if (newMode === "ar") {
                    startCamera();
                  } else {
                    stopCamera();
                  }
                }}
                className="w-full bg-black/30 border border-blue-400/30 rounded-lg px-3 py-2 text-white"
                data-testid="select-view-mode"
              >
                <option value="map">🗺️ خريطة</option>
                <option value="3d">🎬 عرض 3D</option>
                <option value="table">📊 جدول</option>
                <option value="ar">📸 الكاميرا الحية</option>
              </select>
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">مسافة الكاميرا</label>
              <input
                type="range"
                min="20"
                max="200"
                value={cameraDistance}
                onChange={(e) => setCameraDistance(Number(e.target.value))}
                className="w-full"
                data-testid="slider-camera-distance"
              />
              <span className="text-xs text-gray-400">{cameraDistance} متر</span>
            </div>

            <div className="flex items-end gap-2">
              <Button
                onClick={() => setAutoRotate(!autoRotate)}
                variant={autoRotate ? "default" : "secondary"}
                className="flex-1"
                data-testid="button-toggle-rotate"
              >
                <RotateCw className="w-4 h-4 ml-2" />
                {autoRotate ? "دوران تلقائي" : "إيقاف الدوران"}
              </Button>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={downloadPointsKML}
                variant="secondary"
                size="sm"
                className="flex-1"
                data-testid="button-download-kml"
              >
                <Download className="w-4 h-4 ml-1" />
                KML
              </Button>
              <Button
                onClick={downloadPointsGeoJSON}
                variant="secondary"
                size="sm"
                className="flex-1"
                data-testid="button-download-geojson"
              >
                <Download className="w-4 h-4 ml-1" />
                GeoJSON
              </Button>
            </div>
          </div>

          {points.length === 0 && (
            <div className="bg-yellow-500/20 border border-yellow-400/30 rounded-lg p-4 text-center">
              <p className="text-yellow-300">لا توجد نقاط مسجلة حتى الآن</p>
              <p className="text-sm text-gray-400 mt-1">
                اذهب إلى صفحة الإحداثيات من الكاميرا وسجل بعض النقاط
              </p>
            </div>
          )}
        </div>

        {/* 3D Visualization Canvas */}
        {points.length > 0 && (
          <>
            {viewMode === "3d" && bounds && (
              <div className="bg-black/30 rounded-xl border border-white/10 p-4 mb-6">
                <div className="relative w-full bg-gradient-to-b from-blue-900/20 to-cyan-900/20 rounded-lg overflow-hidden cursor-grab active:cursor-grabbing"
                  style={{ aspectRatio: "16 / 9" }}>
                  <svg
                    ref={svgRef}
                    width="100%"
                    height="100%"
                    viewBox="0 0 500 500"
                    className="w-full h-full"
                    onMouseDown={handle3DMouseDown}
                    onMouseMove={handle3DMouseMove}
                    onMouseUp={handle3DMouseUp}
                    onMouseLeave={handle3DMouseUp}
                    onWheel={handle3DWheel}
                    style={{ userSelect: "none" }}
                  >
                    {/* Background grid */}
                    <defs>
                      <pattern
                        id="grid"
                        width="50"
                        height="50"
                        patternUnits="userSpaceOnUse"
                      >
                        <path
                          d="M 50 0 L 0 0 0 50"
                          fill="none"
                          stroke="rgba(255,255,255,0.05)"
                          strokeWidth="0.5"
                        />
                      </pattern>
                    </defs>
                    <rect width="500" height="500" fill="url(#grid)" />

                    {/* Transform group for zoom and pan */}
                    <g transform={`translate(${panX}, ${panY}) scale(${zoom})`}>
                      {/* Center origin marker */}
                      <circle cx="250" cy="250" r="3" fill="rgba(255,255,255,0.2)" />
                      
                      {/* Connection lines between points */}
                      {points.map((point1, idx1) =>
                        points.map((point2, idx2) => {
                          if (idx1 >= idx2) return null;
                          
                          const normalized1 = normalizePoint(point1, bounds);
                          const normalized2 = normalizePoint(point2, bounds);
                          
                          const angleRad = (rotationAngle * Math.PI) / 180;
                          const verticalRad = verticalRotation;
                          
                          let rotated1 = rotate3D(normalized1.x, normalized1.y, normalized1.z, angleRad);
                          rotated1 = rotateVertical(rotated1.x, rotated1.y, rotated1.z, verticalRad);
                          
                          let rotated2 = rotate3D(normalized2.x, normalized2.y, normalized2.z, angleRad);
                          rotated2 = rotateVertical(rotated2.x, rotated2.y, rotated2.z, verticalRad);
                          
                          const projected1 = project2D(rotated1.x, rotated1.y, rotated1.z, cameraDistance);
                          const projected2 = project2D(rotated2.x, rotated2.y, rotated2.z, cameraDistance);

                          return (
                            <line
                              key={`line-${idx1}-${idx2}`}
                              x1={projected1.x}
                              y1={projected1.y}
                              x2={projected2.x}
                              y2={projected2.y}
                              stroke="rgba(100,200,255,0.1)"
                              strokeWidth="1"
                              pointerEvents="none"
                            />
                          );
                        })
                      )}

                      {/* Plot points */}
                      {points.map((point) => {
                        const normalized = normalizePoint(point, bounds);
                        const angleRad = (rotationAngle * Math.PI) / 180;
                        const verticalRad = verticalRotation;
                        
                        let rotated = rotate3D(normalized.x, normalized.y, normalized.z, angleRad);
                        rotated = rotateVertical(rotated.x, rotated.y, rotated.z, verticalRad);
                        
                        const projected = project2D(rotated.x, rotated.y, rotated.z, cameraDistance);

                        const isSelected = selectedPoint === point.id;
                        const isHovered = hoveredPointId === point.id;
                        const color = isSelected
                          ? "#ff4444"
                          : isHovered
                          ? "#ffaa44"
                          : point.altitude !== null && point.altitude > bounds.centerAlt
                          ? "#4488ff"
                          : "#44ff88";
                        const size = isSelected ? 14 : isHovered ? 11 : 8;

                        return (
                          <g
                            key={point.id}
                            onMouseEnter={() => setHoveredPointId(point.id)}
                            onMouseLeave={() => setHoveredPointId(null)}
                          >
                            {/* Point glow effect */}
                            {(isSelected || isHovered) && (
                              <circle
                                cx={projected.x}
                                cy={projected.y}
                                r={size + 4}
                                fill={color}
                                opacity={0.2}
                              />
                            )}

                            {/* Point shadow */}
                            <circle
                              cx={projected.x}
                              cy={projected.y + 4}
                              r={size / 2}
                              fill="rgba(0,0,0,0.4)"
                            />

                            {/* Main point */}
                            <circle
                              cx={projected.x}
                              cy={projected.y}
                              r={size}
                              fill={color}
                              opacity={Math.max(0.5, projected.scale)}
                              style={{ cursor: "pointer", transition: "all 0.2s" }}
                              onClick={() => setSelectedPoint(point.id)}
                              data-testid={`point-3d-${point.id}`}
                            />

                            {/* Label */}
                            {(isSelected || isHovered) && (
                              <text
                                x={projected.x}
                                y={projected.y - size - 5}
                                fill={color}
                                fontSize="11"
                                fontWeight="bold"
                                textAnchor="middle"
                                pointerEvents="none"
                                style={{ textShadow: "0 0 3px black" }}
                              >
                                {point.description}
                              </text>
                            )}

                            {/* Altitude label for hovered/selected */}
                            {(isSelected || isHovered) && point.altitude !== null && (
                              <text
                                x={projected.x}
                                y={projected.y + size + 12}
                                fill={color}
                                fontSize="10"
                                textAnchor="middle"
                                pointerEvents="none"
                              >
                                {point.altitude.toFixed(1)}م
                              </text>
                            )}
                          </g>
                        );
                      })}
                    </g>
                  </svg>

                  {/* Legend */}
                  <div className="absolute top-4 left-4 bg-black/70 backdrop-blur-sm rounded-lg p-3 text-sm space-y-1 border border-white/10">
                    <div className="text-xs font-bold text-cyan-300 mb-2">تحكم:</div>
                    <div className="text-xs text-gray-300">🖱️ اسحب لتدوير</div>
                    <div className="text-xs text-gray-300">🔄 عجلة الماوس للتكبير</div>
                    <div className="mt-2 border-t border-white/10 pt-2">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                        <span className="text-xs">محدد</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                        <span className="text-xs">أعلى</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="text-xs">أسفل</span>
                      </div>
                    </div>
                  </div>

                  {/* Statistics Panel */}
                  <div className="absolute bottom-4 right-4 bg-black/70 backdrop-blur-sm rounded-lg p-3 text-sm border border-white/10">
                    <div className="text-cyan-300 font-bold text-xs mb-2">الإحصائيات:</div>
                    <div className="text-xs text-gray-300">عدد النقاط: {points.length}</div>
                    <div className="text-xs text-gray-300">التكبير: {(zoom * 100).toFixed(0)}%</div>
                    <div className="text-xs text-gray-300">الدوران: {rotationAngle}°</div>
                    <div className="text-xs text-gray-300">الميل: {(verticalRotation * 180 / Math.PI).toFixed(0)}°</div>
                  </div>

                  {/* Selected Point Info */}
                  {selectedPoint && points.find((p) => p.id === selectedPoint) && (
                    <div className="absolute bottom-4 left-4 bg-black/70 backdrop-blur-sm rounded-lg p-3 text-sm border border-green-400/30 max-w-xs">
                      {(() => {
                        const point = points.find((p) => p.id === selectedPoint)!;
                        return (
                          <>
                            <div className="text-green-400 font-bold text-sm mb-1">{point.description}</div>
                            <div className="text-xs text-gray-300">
                              <div>📍 عرض: {point.latitude.toFixed(6)}°</div>
                              <div>📍 طول: {point.longitude.toFixed(6)}°</div>
                              {point.altitude !== null && <div>📈 ارتفاع: {point.altitude.toFixed(1)}م</div>}
                              <div>📏 دقة: ±{point.accuracy.toFixed(0)}م</div>
                            </div>
                          </>
                        );
                      })()}
                    </div>
                  )}
                </div>
              </div>
            )}

            {viewMode === "ar" && (
              <div className="bg-black/30 rounded-xl border border-white/10 p-4 mb-6">
                <div className="relative w-full bg-black rounded-lg overflow-hidden" style={{ aspectRatio: "16 / 9" }}>
                  {!cameraActive ? (
                    <div className="w-full h-full flex items-center justify-center bg-gray-900">
                      <div className="text-center">
                        <Camera className="w-12 h-12 mx-auto mb-4 text-gray-500" />
                        <Button onClick={() => { startCamera(); getLocation(); }} className="mt-4">
                          <Camera className="w-4 h-4 ml-2" />
                          تشغيل الكاميرا
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div
                        onClick={handleCameraClick}
                        className="w-full h-full cursor-crosshair"
                        style={{ pointerEvents: "auto" }}
                      >
                        <video
                          ref={videoRef}
                          autoPlay
                          playsInline
                          className="w-full h-full object-cover"
                        />
                      </div>
                      
                      {/* AR Overlay */}
                      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                        {/* Current Location Info */}
                        {currentLocation && (
                          <div className="absolute top-4 left-4 right-4 bg-black/70 backdrop-blur-sm rounded-lg px-4 py-3 text-left text-cyan-300 text-sm font-mono max-w-sm">
                            <div>📍 موقعك الحالي:</div>
                            <div className="text-xs mt-1">عرض: {currentLocation.lat.toFixed(6)}°</div>
                            <div className="text-xs">طول: {currentLocation.lon.toFixed(6)}°</div>
                            <div className="text-xs">الدقة: ±{currentLocation.accuracy.toFixed(1)}م</div>
                          </div>
                        )}

                        {/* Center Crosshair */}
                        <div className="absolute w-20 h-20 border-2 border-red-500 rounded-full opacity-50"></div>
                        <div className="absolute w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>

                        {/* Points Overlay */}
                        {points.length > 0 && currentLocation && (
                          <svg className="absolute inset-0 w-full h-full" style={{ pointerEvents: "none" }}>
                            {points.map((point) => {
                              const distance = calculateDistance(
                                currentLocation.lat,
                                currentLocation.lon,
                                point.latitude,
                                point.longitude
                              );
                              
                              const bearing = calculateBearing(
                                currentLocation.lat,
                                currentLocation.lon,
                                point.latitude,
                                point.longitude
                              );
                              
                              const svgWidth = 1280;
                              const svgHeight = 720;
                              const projection = projectPointOnCamera(distance, bearing, svgWidth, svgHeight);
                              
                              // Only show points within reasonable distance
                              if (distance > 500) return null;
                              
                              const isSelected = selectedPoint === point.id;
                              const size = isSelected ? 12 : 8;
                              
                              return (
                                <g key={point.id} style={{ pointerEvents: "auto" }}>
                                  {/* Point circle */}
                                  <circle
                                    cx={projection.x}
                                    cy={projection.y}
                                    r={size}
                                    fill={isSelected ? "#fbbf24" : "#3b82f6"}
                                    opacity={projection.scale}
                                    style={{ cursor: "pointer" }}
                                    onClick={() => setSelectedPoint(point.id)}
                                    data-testid={`point-overlay-${point.id}`}
                                  />
                                  
                                  {/* Point label */}
                                  <text
                                    x={projection.x}
                                    y={projection.y - 20}
                                    textAnchor="middle"
                                    fill={isSelected ? "#fbbf24" : "#3b82f6"}
                                    fontSize="12"
                                    fontWeight="bold"
                                    style={{ pointerEvents: "none" }}
                                  >
                                    {point.description}
                                  </text>
                                  
                                  {/* Distance label */}
                                  <text
                                    x={projection.x}
                                    y={projection.y + 25}
                                    textAnchor="middle"
                                    fill="#06b6d4"
                                    fontSize="11"
                                    style={{ pointerEvents: "none" }}
                                  >
                                    {distance.toFixed(0)}م
                                  </text>
                                  
                                  {/* Bearing indicator */}
                                  <text
                                    x={projection.x}
                                    y={projection.y + 38}
                                    textAnchor="middle"
                                    fill="#10b981"
                                    fontSize="10"
                                    style={{ pointerEvents: "none" }}
                                  >
                                    {bearing.toFixed(0)}°
                                  </text>
                                  
                                  {/* Line to center */}
                                  {isSelected && (
                                    <line
                                      x1={svgWidth / 2}
                                      y1={svgHeight / 2}
                                      x2={projection.x}
                                      y2={projection.y}
                                      stroke="#fbbf24"
                                      strokeWidth="1"
                                      strokeDasharray="5,5"
                                      opacity="0.5"
                                      style={{ pointerEvents: "none" }}
                                    />
                                  )}
                                </g>
                              );
                            })}
                          </svg>
                        )}

                        {/* Selected Point Details */}
                        {selectedPoint && points.find((p) => p.id === selectedPoint) && currentLocation && (
                          <div className="absolute bottom-4 left-4 right-4 bg-black/85 backdrop-blur-sm rounded-lg px-4 py-3 text-left text-green-300 text-xs font-mono max-w-sm border border-green-500/30">
                            {(() => {
                              const point = points.find((p) => p.id === selectedPoint)!;
                              const distance = calculateDistance(
                                currentLocation.lat,
                                currentLocation.lon,
                                point.latitude,
                                point.longitude
                              );
                              const bearing = calculateBearing(
                                currentLocation.lat,
                                currentLocation.lon,
                                point.latitude,
                                point.longitude
                              );
                              
                              // Get compass direction
                              const directions = ["شمال ⬆️", "شمال شرق ↗️", "شرق ➡️", "جنوب شرق ↘️", "جنوب ⬇️", "جنوب غرب ↙️", "غرب ⬅️", "شمال غرب ↖️"];
                              const directionIndex = Math.round(bearing / 45) % 8;
                              const direction = directions[directionIndex];
                              
                              return (
                                <>
                                  <div className="font-bold text-green-400 text-sm">{point.description}</div>
                                  <div className="mt-2 space-y-1">
                                    <div className="text-white">📐 المسافة: <span className="text-yellow-400 font-bold">{distance.toFixed(1)}م</span></div>
                                    <div className="text-white">🧭 الاتجاه: <span className="text-yellow-400 font-bold">{bearing.toFixed(1)}° {direction}</span></div>
                                    <div className="mt-2">📍 الإحداثيات النقطة:</div>
                                    <div className="text-cyan-300 ml-2">
                                      عرض: {point.latitude.toFixed(6)}°<br/>
                                      طول: {point.longitude.toFixed(6)}°
                                    </div>
                                    <div className="mt-1">📍 إحداثياتك الحالية:</div>
                                    <div className="text-cyan-300 ml-2">
                                      عرض: {currentLocation.lat.toFixed(6)}°<br/>
                                      طول: {currentLocation.lon.toFixed(6)}°
                                    </div>
                                    <div className="mt-1 text-white">📏 دقة الموقع: <span className="text-yellow-300">±{point.accuracy.toFixed(0)}م</span></div>
                                    {point.altitude && <div className="text-white">📈 الارتفاع: <span className="text-yellow-300">{point.altitude.toFixed(1)}م</span></div>}
                                  </div>
                                </>
                              );
                            })()}
                          </div>
                        )}
                      </div>

                      {/* Stop Button */}
                      <Button
                        onClick={stopCamera}
                        size="sm"
                        className="absolute top-4 right-4 bg-red-600 hover:bg-red-700"
                        data-testid="button-stop-camera"
                      >
                        إيقاف
                      </Button>

                      {/* Instruction Text */}
                      <div className="absolute bottom-4 right-4 left-4 bg-black/80 backdrop-blur-sm rounded-lg px-4 py-2 text-center text-yellow-300 text-sm font-bold">
                        💡 اضغط على الشاشة لإضافة نقطة جديدة
                      </div>
                    </>
                  )}
                </div>
              </div>
            )}

            {/* New Point Dialog */}
            {showNewPointDialog && (
              <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
                <div className="bg-slate-900 rounded-xl p-6 border border-blue-400/30 max-w-sm w-full mx-4">
                  <h2 className="text-xl font-bold text-white mb-4">إضافة نقطة جديدة</h2>
                  
                  {pendingPoint && (
                    <div className="bg-black/30 rounded-lg p-3 mb-4 text-sm text-cyan-300 font-mono">
                      <div>📍 الإحداثيات:</div>
                      <div className="text-xs mt-1">عرض: {pendingPoint.lat.toFixed(6)}°</div>
                      <div className="text-xs">طول: {pendingPoint.lon.toFixed(6)}°</div>
                    </div>
                  )}

                  <input
                    type="text"
                    value={newPointName}
                    onChange={(e) => setNewPointName(e.target.value)}
                    placeholder="اسم النقطة"
                    className="w-full bg-black/30 border border-blue-400/30 rounded-lg px-4 py-2 text-white placeholder-gray-400 mb-4"
                    data-testid="input-new-point-name"
                    onKeyPress={(e) => {
                      if (e.key === "Enter") addNewPointFromCamera();
                    }}
                    autoFocus
                  />

                  <div className="flex gap-2">
                    <Button
                      onClick={addNewPointFromCamera}
                      className="flex-1 bg-green-600 hover:bg-green-700"
                      data-testid="button-save-point"
                    >
                      ✅ حفظ
                    </Button>
                    <Button
                      onClick={() => {
                        setShowNewPointDialog(false);
                        setNewPointName("");
                        setPendingPoint(null);
                      }}
                      variant="secondary"
                      className="flex-1"
                      data-testid="button-cancel-point"
                    >
                      ❌ إلغاء
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {viewMode === "map" && bounds && (
              <div className="bg-black/30 rounded-xl border border-white/10 p-4 mb-6">
                <div
                  className="relative w-full bg-gradient-to-b from-blue-900/20 to-cyan-900/20 rounded-lg overflow-hidden"
                  style={{ aspectRatio: "16 / 9" }}
                >
                  <svg
                    width="100%"
                    height="100%"
                    viewBox="0 0 800 450"
                    className="w-full h-full"
                  >
                    {/* Grid */}
                    <defs>
                      <pattern
                        id="mapgrid"
                        width="40"
                        height="40"
                        patternUnits="userSpaceOnUse"
                      >
                        <path
                          d="M 40 0 L 0 0 0 40"
                          fill="none"
                          stroke="rgba(255,255,255,0.05)"
                          strokeWidth="0.5"
                        />
                      </pattern>
                    </defs>
                    <rect width="800" height="450" fill="url(#mapgrid)" />

                    {/* Points (top-down view) */}
                    {points.map((point) => {
                      const x =
                        ((point.longitude - bounds.minLon) /
                          (bounds.maxLon - bounds.minLon)) *
                        700 +
                        50;
                      const y =
                        450 -
                        (((point.latitude - bounds.minLat) /
                          (bounds.maxLat - bounds.minLat)) *
                          350 +
                          50);

                      const isSelected = selectedPoint === point.id;
                      const color = isSelected ? "#ff4444" : "#44ff88";
                      const size = isSelected ? 12 : 8;

                      return (
                        <g key={point.id}>
                          <circle
                            cx={x}
                            cy={y}
                            r={size}
                            fill={color}
                            style={{ cursor: "pointer" }}
                            onClick={() => setSelectedPoint(point.id)}
                          />
                          {isSelected && (
                            <text
                              x={x}
                              y={y - 15}
                              fill="#ffff00"
                              fontSize="12"
                              textAnchor="middle"
                              pointerEvents="none"
                            >
                              {point.description}
                            </text>
                          )}
                        </g>
                      );
                    })}
                  </svg>

                  <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-sm rounded-lg p-3 text-sm">
                    <div className="font-bold mb-2">إحصائيات:</div>
                    <div>عدد النقاط: {points.length}</div>
                    <div className="text-xs text-gray-400 mt-1">
                      النطاق: {(bounds.maxLat - bounds.minLat).toFixed(4)}°
                      عرض
                    </div>
                  </div>
                </div>
              </div>
            )}

            {viewMode === "table" && (
              <div className="bg-black/30 rounded-xl border border-white/10 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-blue-900/30 border-b border-white/10">
                        <th className="px-4 py-3 text-right">الوصف</th>
                        <th className="px-4 py-3 text-right">خط الطول</th>
                        <th className="px-4 py-3 text-right">العرض</th>
                        <th className="px-4 py-3 text-right">الارتفاع</th>
                        <th className="px-4 py-3 text-right">الدقة</th>
                        <th className="px-4 py-3 text-right">التاريخ</th>
                      </tr>
                    </thead>
                    <tbody>
                      {points.map((point) => (
                        <tr
                          key={point.id}
                          className={`border-b border-white/5 hover:bg-white/5 cursor-pointer ${
                            selectedPoint === point.id ? "bg-blue-900/30" : ""
                          }`}
                          onClick={() => setSelectedPoint(point.id)}
                          data-testid={`row-point-${point.id}`}
                        >
                          <td className="px-4 py-3">{point.description}</td>
                          <td className="px-4 py-3 text-right font-mono text-xs">
                            {point.longitude.toFixed(6)}
                          </td>
                          <td className="px-4 py-3 text-right font-mono text-xs">
                            {point.latitude.toFixed(6)}
                          </td>
                          <td className="px-4 py-3 text-right">
                            {point.altitude ? `${point.altitude.toFixed(2)}م` : "N/A"}
                          </td>
                          <td className="px-4 py-3 text-right">
                            ±{point.accuracy.toFixed(1)}م
                          </td>
                          <td className="px-4 py-3 text-right text-xs">
                            {point.timestamp.toLocaleDateString("ar-EG")}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Selected Point Details */}
            {selectedPoint !== null && (
              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10 mt-6">
                {(() => {
                  const point = points.find((p) => p.id === selectedPoint);
                  if (!point) return null;

                  return (
                    <div>
                      <h3 className="text-lg font-bold text-blue-400 mb-4">
                        تفاصيل النقطة: {point.description}
                      </h3>
                      <div className="grid md:grid-cols-3 gap-4">
                        <div className="bg-black/30 rounded-lg p-4">
                          <p className="text-gray-400 mb-2 text-sm">خط الطول</p>
                          <p className="text-white font-mono">{point.longitude.toFixed(8)}</p>
                        </div>
                        <div className="bg-black/30 rounded-lg p-4">
                          <p className="text-gray-400 mb-2 text-sm">العرض</p>
                          <p className="text-white font-mono">{point.latitude.toFixed(8)}</p>
                        </div>
                        <div className="bg-black/30 rounded-lg p-4">
                          <p className="text-gray-400 mb-2 text-sm">الارتفاع</p>
                          <p className="text-white font-mono">
                            {point.altitude ? `${point.altitude.toFixed(2)}م` : "N/A"}
                          </p>
                        </div>
                        <div className="bg-black/30 rounded-lg p-4">
                          <p className="text-gray-400 mb-2 text-sm">الدقة</p>
                          <p className="text-white font-mono">±{point.accuracy.toFixed(2)}م</p>
                        </div>
                        <div className="bg-black/30 rounded-lg p-4">
                          <p className="text-gray-400 mb-2 text-sm">التاريخ والوقت</p>
                          <p className="text-white text-sm">
                            {point.timestamp.toLocaleString("ar-EG")}
                          </p>
                        </div>
                        <div className="bg-black/30 rounded-lg p-4">
                          <p className="text-gray-400 mb-2 text-sm">رقم النقطة</p>
                          <p className="text-white font-mono">#{point.id}</p>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-4 mt-6">
              <Button
                onClick={() => setSelectedPoint(null)}
                variant="secondary"
                data-testid="button-deselect"
              >
                <EyeOff className="w-4 h-4 ml-2" />
                إلغاء التحديد
              </Button>
              <Button
                onClick={clearAllPoints}
                variant="destructive"
                data-testid="button-clear-all"
              >
                <Trash2 className="w-4 h-4 ml-2" />
                حذف جميع النقاط
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
