import { useState, useRef, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Camera, RotateCcw, MapPin, Copy, AlertCircle, CheckCircle, Globe } from "lucide-react";
import { toast } from "sonner";
import { useLanguage } from "@/lib/i18n";

interface Point {
  x: number;
  y: number;
  id: number;
}

interface CoordinateData {
  latitude: number;
  longitude: number;
  accuracy: number;
  altitude: number | null;
  timestamp: Date;
}

export default function CameraTools() {
  const { language, t, toggleLanguage } = useLanguage();
  const isRTL = language === 'ar';
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const watchIdRef = useRef<number | null>(null);

  // حالات القياس
  const [points, setPoints] = useState<Point[]>([]);
  const [cameraActive, setCameraActive] = useState(false);
  const [measurements, setMeasurements] = useState<number[]>([]);
  const [nextId, setNextId] = useState(0);
  const [calibrationDistance, setCalibrationDistance] = useState(1);
  
  // حالات الموقع
  const [currentCoordinates, setCurrentCoordinates] = useState<CoordinateData | null>(null);
  const [locationLoading, setLocationLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");
  const [attempts, setAttempts] = useState(0);
  const [accuracyMode, setAccuracyMode] = useState<"normal" | "high">("normal");
  const [activeTab, setActiveTab] = useState<"measurement" | "gps" | "correction">("measurement");
  
  // حالات التصحيح
  const [correctionLat, setCorrectionLat] = useState<number>(30.0444);
  const [correctionLng, setCorrectionLng] = useState<number>(31.2357);
  const [errorPercentage, setErrorPercentage] = useState<number>(1);
  const [correctionResult, setCorrectionResult] = useState<any>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);

  // تنظيف الموارد عند الخروج
  useEffect(() => {
    return () => {
      stopCamera();
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
    };
  }, []);

  // تشغيل/إيقاف الكاميرا
  useEffect(() => {
    if (cameraActive) {
      startCamera();
    } else {
      stopCamera();
    }
  }, [cameraActive]);

  const startCamera = async () => {
    try {
      if (videoRef.current?.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach((track) => track.stop());
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        toast.success("✅ الكاميرا تعمل بنجاح");
      }
    } catch (error: any) {
      console.error("خطأ الكاميرا:", error);
      let errorMessage = "لا يمكن الوصول للكاميرا";
      if (error.name === "NotAllowedError") {
        errorMessage = "🔒 تم رفض إذن الكاميرا. يرجى السماح بالوصول في إعدادات الجهاز";
      } else if (error.name === "NotFoundError") {
        errorMessage = "📷 لم يتم العثور على كاميرا على جهازك";
      } else if (error.name === "NotSupportedError") {
        errorMessage = "❌ المتصفح الحالي لا يدعم الوصول للكاميرا";
      }
      toast.error(errorMessage);
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach((track) => track.stop());
    }
  };

  const getCanvasCoordinates = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    return { x, y };
  };

  // حساب المسافة بين نقطتين (Haversine)
  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const calculateCorrectedCoordinates = () => {
    if (correctionLat < -90 || correctionLat > 90 || correctionLng < -180 || correctionLng > 180) {
      toast.error(language === 'ar' ? '❌ إحداثيات غير صحيحة' : '❌ Invalid coordinates');
      return;
    }

    // استخدام درجة الدقة من GPS
    let accuracyInMeters = currentCoordinates?.accuracy || 5;
    if (!accuracyInMeters || accuracyInMeters <= 0) {
      accuracyInMeters = 5;
    }

    // حساب المسافة بناءً على درجة الدقة ومعامل التصحيح
    // errorPercentage يمثل نسبة التصحيح الإضافية
    const correctionFactor = 1 + (errorPercentage / 100);
    const totalErrorMeters = accuracyInMeters * correctionFactor;
    
    // توليد زاوية عشوائية ومسافة عشوائية ضمن نطاق الخطأ
    const angle = Math.random() * 360;
    const angleRad = angle * Math.PI / 180;
    const randomDistance = totalErrorMeters * (0.5 + Math.random() * 0.5); // نسبة عشوائية من إجمالي الخطأ
    
    // تحويل المسافة من متر إلى درجات
    const metersPerDegreeLat = 111000; // متر لكل درجة عرض
    const metersPerDegreeLng = 111000 * Math.cos(correctionLat * Math.PI / 180); // متر لكل درجة طول
    
    const latChange = (randomDistance / metersPerDegreeLat) * Math.cos(angleRad);
    const lngChange = (randomDistance / metersPerDegreeLng) * Math.sin(angleRad);
    
    const correctedLat = correctionLat + latChange;
    const correctedLng = correctionLng + lngChange;
    
    // تأكد من أن الإحداثيات صحيحة
    if (correctedLat < -90 || correctedLat > 90 || correctedLng < -180 || correctedLng > 180) {
      toast.error(language === 'ar' ? '❌ فشل في حساب الإحداثيات المصححة' : '❌ Failed to calculate corrected coordinates');
      return;
    }
    
    const distance = calculateDistance(correctionLat, correctionLng, correctedLat, correctedLng) * 1000;

    const newResult = {
      originalLat: correctionLat,
      originalLng: correctionLng,
      correctedLat,
      correctedLng,
      errorPercentage: (totalErrorMeters / accuracyInMeters) * 100,
      distance,
      accuracy: accuracyInMeters
    };
    setCorrectionResult(newResult);
    toast.success(language === 'ar' ? `✓ تم التصحيح بناءً على درجة دقة ±${accuracyInMeters.toFixed(2)}م` : `✓ Corrected with accuracy ±${accuracyInMeters.toFixed(2)}m`);
  };

  const resetCorrectionCalculation = () => {
    setCorrectionResult(null);
    setCorrectionLat(currentCoordinates?.latitude || 30.0444);
    setCorrectionLng(currentCoordinates?.longitude || 31.2357);
    setErrorPercentage(1);
  };

  // تحميل وتهيئة الخريطة
  useEffect(() => {
    if (activeTab === "correction") {
      loadLeafletAndInitMap();
    }
  }, [activeTab]);

  // تحديث الخريطة عند تغيير النتائج
  useEffect(() => {
    if (activeTab === "correction" && mapRef.current) {
      setTimeout(() => {
        addMapMarkers();
      }, 50);
    }
  }, [correctionResult]);

  const loadLeafletAndInitMap = () => {
    if (!mapContainerRef.current) return;
    
    const initMap = () => {
      const L = (window as any).L;
      if (!L) return;

      try {
        // إزالة الخريطة القديمة إن وجدت
        if (mapRef.current) {
          mapRef.current.remove();
          mapRef.current = null;
        }
        
        mapRef.current = L.map(mapContainerRef.current).setView([correctionLat, correctionLng], 12);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '© OpenStreetMap',
          maxZoom: 19
        }).addTo(mapRef.current);

        setTimeout(() => {
          if (mapRef.current) addMapMarkers();
        }, 100);
      } catch (e) {
        console.error("Map error:", e);
      }
    };

    const L = (window as any).L;
    if (!L) {
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      script.onload = () => {
        const css = document.createElement('link');
        css.rel = 'stylesheet';
        css.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
        document.head.appendChild(css);
        setTimeout(initMap, 200);
      };
      document.head.appendChild(script);
    } else {
      initMap();
    }
  };

  const addMapMarkers = () => {
    if (!mapRef.current) return;
    const L = (window as any).L;
    mapRef.current.eachLayer((layer: any) => {
      if (layer instanceof L.Marker || layer instanceof L.Polyline) {
        mapRef.current.removeLayer(layer);
      }
    });
    
    // تحديث مركز الخريطة إذا كانت هناك نقطة مصححة
    if (correctionResult) {
      const centerLat = (correctionLat + correctionResult.correctedLat) / 2;
      const centerLng = (correctionLng + correctionResult.correctedLng) / 2;
      mapRef.current.setView([centerLat, centerLng], 12);
    } else {
      mapRef.current.setView([correctionLat, correctionLng], 12);
    }

    const originalIcon = L.divIcon({
      html: '<div style="background-color: #ef4444; border: 3px solid white; border-radius: 50%; width: 35px; height: 35px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 18px; box-shadow: 0 0 10px rgba(0,0,0,0.5);">📍</div>',
      iconSize: [35, 35]
    });

    L.marker([correctionLat, correctionLng], { icon: originalIcon })
      .bindPopup(language === 'ar' ? '<b>النقطة الأصلية</b><br/>Original Point' : '<b>Original Point</b>')
      .addTo(mapRef.current)
      .openPopup();

    if (correctionResult) {
      const correctedIcon = L.divIcon({
        html: '<div style="background-color: #3b82f6; border: 3px solid white; border-radius: 50%; width: 35px; height: 35px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 18px; box-shadow: 0 0 10px rgba(0,0,0,0.5);">✓</div>',
        iconSize: [35, 35]
      });

      L.marker([correctionResult.correctedLat, correctionResult.correctedLng], { icon: correctedIcon })
        .bindPopup(language === 'ar' ? '<b>النقطة المصححة</b><br/>Corrected Point' : '<b>Corrected Point</b>')
        .addTo(mapRef.current);

      L.polyline([
        [correctionLat, correctionLng],
        [correctionResult.correctedLat, correctionResult.correctedLng]
      ], {
        color: '#f59e0b',
        weight: 3,
        dashArray: '5, 5',
        opacity: 0.8
      }).addTo(mapRef.current).bindPopup(language === 'ar' ? `المسافة: ${correctionResult.distance.toFixed(2)}م` : `Distance: ${correctionResult.distance.toFixed(2)}m`);

      const group = L.featureGroup([
        L.marker([correctionLat, correctionLng]),
        L.marker([correctionResult.correctedLat, correctionResult.correctedLng])
      ]);
      mapRef.current.fitBounds(group.getBounds().pad(0.1));
    }
  };

  const addPoint = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const coords = getCanvasCoordinates(e);
    if (!coords) return;

    const newPoint: Point = { x: coords.x, y: coords.y, id: nextId };
    const newPoints = [...points, newPoint];
    setPoints(newPoints);
    setNextId(nextId + 1);

    if (newPoints.length >= 2) {
      const lastPoint = newPoints[newPoints.length - 1];
      const prevPoint = newPoints[newPoints.length - 2];

      const pixelDistance = Math.sqrt(
        Math.pow(lastPoint.x - prevPoint.x, 2) + Math.pow(lastPoint.y - prevPoint.y, 2)
      );

      const realDistance = (pixelDistance / 100) * calibrationDistance;
      setMeasurements([...measurements, realDistance]);
    }

    drawPoints(newPoints);
  };

  const drawPoints = (pointsList: Point[]) => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // رسم الفيديو
    if (video.readyState >= 2) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    }

    // رسم النقاط
    pointsList.forEach((point, index) => {
      ctx.beginPath();
      ctx.arc(point.x, point.y, 10, 0, 2 * Math.PI);
      ctx.fillStyle = "#EF4444";
      ctx.fill();
      ctx.strokeStyle = "#FFFFFF";
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.fillStyle = "#FFFFFF";
      ctx.font = "bold 14px Arial";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText((index + 1).toString(), point.x, point.y);
    });

    // رسم الخطوط
    if (pointsList.length > 1) {
      ctx.beginPath();
      ctx.moveTo(pointsList[0].x, pointsList[0].y);

      for (let i = 1; i < pointsList.length; i++) {
        ctx.lineTo(pointsList[i].x, pointsList[i].y);

        const distance = measurements[i - 1];
        if (distance !== undefined) {
          const midX = (pointsList[i].x + pointsList[i - 1].x) / 2;
          const midY = (pointsList[i].y + pointsList[i - 1].y) / 2;

          ctx.fillStyle = "#10B981";
          ctx.font = "bold 14px Arial";
          ctx.fillText(distance.toFixed(2) + " م", midX, midY - 15);
        }
      }

      ctx.strokeStyle = "#3B82F6";
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  };

  // رسم Canvas عند التحديث
  useEffect(() => {
    if (!cameraActive) return;

    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const updateCanvasSize = () => {
      const container = canvas.parentElement;
      if (container) {
        const rect = container.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;
      }
    };

    updateCanvasSize();
    window.addEventListener("resize", updateCanvasSize);

    const draw = () => {
      if (video.readyState >= 2) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      }

      points.forEach((point, index) => {
        ctx.beginPath();
        ctx.arc(point.x, point.y, 10, 0, 2 * Math.PI);
        ctx.fillStyle = "#EF4444";
        ctx.fill();
        ctx.strokeStyle = "#FFFFFF";
        ctx.lineWidth = 3;
        ctx.stroke();

        ctx.fillStyle = "#FFFFFF";
        ctx.font = "bold 14px Arial";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText((index + 1).toString(), point.x, point.y);
      });

      if (points.length > 1) {
        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);

        for (let i = 1; i < points.length; i++) {
          ctx.lineTo(points[i].x, points[i].y);

          const distance = measurements[i - 1];
          if (distance !== undefined) {
            const midX = (points[i].x + points[i - 1].x) / 2;
            const midY = (points[i].y + points[i - 1].y) / 2;

            ctx.fillStyle = "#10B981";
            ctx.font = "bold 14px Arial";
            ctx.fillText(distance.toFixed(2) + " م", midX, midY - 15);
          }
        }

        ctx.strokeStyle = "#3B82F6";
        ctx.lineWidth = 2;
        ctx.stroke();
      }

      requestAnimationFrame(draw);
    };

    const animId = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", updateCanvasSize);
    };
  }, [cameraActive, points, measurements]);

  const clearMeasurements = () => {
    setPoints([]);
    setMeasurements([]);
    setNextId(0);
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext("2d");
      if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
    toast.success("✅ تم مسح القياسات");
  };

  const getLocation = async () => {
    setLocationLoading(true);
    setStatusMessage("⏳ جاري البحث عن موقعك...");
    setAttempts(0);
    setCurrentCoordinates(null);

    // أولاً: محاولة الحصول على الموقع الفوري
    try {
      const position = await new Promise<GeolocationCoordinates>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          (pos) => resolve(pos.coords),
          (err) => reject(err),
          { enableHighAccuracy: accuracyMode === "high", timeout: 8000, maximumAge: 0 }
        );
      });

      setCurrentCoordinates({
        latitude: position.latitude,
        longitude: position.longitude,
        accuracy: position.accuracy,
        altitude: position.altitude,
        timestamp: new Date(),
      });

      setStatusMessage(`✅ تم الحصول على الموقع: ±${position.accuracy.toFixed(2)}م`);
      setLocationLoading(false);
      toast.success("✅ تم الحصول على الموقع بنجاح");
      return;
    } catch (error: any) {
      console.error("خطأ في الحصول على الموقع:", error);
      toast.error("❌ لم يتمكن من الحصول على الموقع");
      setStatusMessage(`❌ خطأ: ${error.message || 'فشل الحصول على الموقع'}`);
      setLocationLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 to-slate-800 text-white" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Navigation */}
      <div className="sticky top-0 z-10 bg-black/40 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center mb-4">
          <h1 className="text-3xl font-bold">📷 {language === 'ar' ? 'أدوات الكاميرا الموحدة' : 'Unified Camera Tools'}</h1>
          <Link href="/">
            <Button variant="ghost" className="text-white hover:bg-white/10">
              <ArrowRight className={`w-4 h-4 ${isRTL ? 'mr-2' : 'ml-2'}`} />
              {language === 'ar' ? 'العودة للرئيسية' : 'Back Home'}
            </Button>
          </Link>
        </div>

        {/* Tabs */}
        <div className="border-t border-white/10 overflow-x-auto">
          <div className="max-w-7xl mx-auto px-6 flex gap-4 pt-0">
            <button
              onClick={() => setActiveTab("measurement")}
              className={`px-6 py-3 font-semibold transition border-b-2 ${
                activeTab === "measurement"
                  ? "border-blue-400 text-blue-400"
                  : "border-transparent text-gray-400 hover:text-gray-300"
              }`}
            >
              {t('measurement')}
            </button>
            <button
              onClick={() => setActiveTab("gps")}
              className={`px-6 py-3 font-semibold transition border-b-2 ${
                activeTab === "gps"
                  ? "border-green-400 text-green-400"
                  : "border-transparent text-gray-400 hover:text-gray-300"
              }`}
            >
              {t('gps')}
            </button>
            <button
              onClick={() => setActiveTab("correction")}
              className={`px-6 py-3 font-semibold transition border-b-2 ${
                activeTab === "correction"
                  ? "border-red-400 text-red-400"
                  : "border-transparent text-gray-400 hover:text-gray-300"
              }`}
            >
              {language === 'ar' ? '🔧 التصحيح' : '🔧 Correction'}
            </button>
            <div className="ml-auto flex items-center">
              <Button 
                variant="secondary" 
                size="sm" 
                onClick={toggleLanguage}
                className="shadow-lg"
              >
                <Globe className="w-4 h-4 ml-2" />
                {language === 'ar' ? 'EN' : 'العربية'}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Camera View */}
        {cameraActive && (
          <div className="relative rounded-lg overflow-hidden mb-6 bg-black" style={{ aspectRatio: "16 / 9" }}>
            <video ref={videoRef} autoPlay playsInline muted style={{ display: "none" }} />
            <canvas
              ref={canvasRef}
              onClick={activeTab === "measurement" ? addPoint : undefined}
              className="w-full h-full block bg-black cursor-crosshair"
            />
            {activeTab === "measurement" && (
              <div className={`absolute top-4 ${isRTL ? 'left-4' : 'right-4'} bg-black/60 rounded-lg px-3 py-2 text-sm`}>
                <p className="text-gray-300">{language === 'ar' ? 'انقر على الكاميرا لإضافة نقاط' : 'Click on camera to add points'}</p>
              </div>
            )}
          </div>
        )}

        {/* Measurement Tab */}
        {activeTab === "measurement" && (
          <div className="space-y-6">
            {/* Controls */}
            <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 border border-white/10 space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-300 mb-2">
                    {language === 'ar' ? 'المسافة المرجعية (متر)' : 'Reference Distance (meters)'}
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={calibrationDistance}
                    onChange={(e) => setCalibrationDistance(parseFloat(e.target.value) || 1)}
                    className="w-full bg-black/30 border border-blue-400/30 rounded-lg px-4 py-2 text-white focus:border-blue-400 focus:outline-none"
                    placeholder={language === 'ar' ? 'أدخل المسافة المرجعية' : 'Enter reference distance'}
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-4 gap-3">
                <Button
                  onClick={() => setCameraActive(!cameraActive)}
                  className={`${cameraActive ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"}`}
                >
                  <Camera className={`w-4 h-4 ${isRTL ? 'mr-2' : 'ml-2'}`} />
                  {cameraActive ? (language === 'ar' ? "إيقاف" : "Stop") : (language === 'ar' ? "بدء" : "Start")}
                </Button>
                <Button onClick={clearMeasurements} className="bg-yellow-600 hover:bg-yellow-700">
                  <RotateCcw className={`w-4 h-4 ${isRTL ? 'mr-2' : 'ml-2'}`} />
                  {language === 'ar' ? 'مسح' : 'Clear'}
                </Button>
              </div>
            </div>

            {/* Points List */}
            {points.length > 0 && (
              <div className="bg-blue-900/20 border border-blue-400/30 rounded-lg p-4">
                <h3 className="text-sm font-bold text-blue-300 mb-2">
                  📍 {language === 'ar' ? `النقاط (${points.length})` : `Points (${points.length})`}
                </h3>
                <p className="text-xs text-gray-400">
                  {Array.from({ length: points.length }, (_, i) => language === 'ar' ? `نقطة ${i + 1}` : `Point ${i + 1}`).join(" • ")}
                </p>
              </div>
            )}

            {/* Results */}
            {measurements.length > 0 && (
              <div className="bg-green-900/20 border border-green-400/30 rounded-lg p-4">
                <h3 className="text-sm font-bold text-green-300 mb-3">📊 {language === 'ar' ? 'القياسات' : 'Measurements'}</h3>
                <div className="space-y-2">
                  {measurements.map((m, i) => (
                    <div key={i} className="flex justify-between items-center bg-black/30 rounded p-2 text-sm">
                      <span>{language === 'ar' ? `المسافة ${i + 1}` : `Distance ${i + 1}`}</span>
                      <span className="font-bold text-green-400">{m.toFixed(4)} م</span>
                    </div>
                  ))}
                  <div className="flex justify-between items-center bg-blue-400/10 rounded p-2 mt-3 border border-blue-400/20">
                    <span className="font-bold">{language === 'ar' ? 'المجموع' : 'Total'}</span>
                    <span className="font-bold text-blue-400">
                      {measurements.reduce((a, b) => a + b, 0).toFixed(4)} م
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Correction Tab */}
        {activeTab === "correction" && (
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Map Section */}
              <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 border border-white/10 h-96 flex flex-col">
                <h3 className="text-lg font-semibold text-cyan-300 mb-4">🗺️ {language === 'ar' ? 'الخريطة' : 'Map'}</h3>
                <div ref={mapContainerRef} className="flex-1 rounded-lg bg-black/30 border border-cyan-400/20 overflow-hidden" style={{ minHeight: '320px' }}></div>
              </div>

              {/* Input Section */}
              <div className="space-y-4">
                <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 border border-white/10 space-y-4">
                  <h3 className="text-lg font-semibold text-cyan-300">{language === 'ar' ? '📍 البيانات المدخلة' : '📍 Input Data'}</h3>
                  <div>
                    <label className="block text-sm text-gray-300 mb-2">{language === 'ar' ? 'خط العرض' : 'Latitude'}</label>
                    <input
                      type="number"
                      step="0.000001"
                      value={correctionLat}
                      onChange={(e) => setCorrectionLat(parseFloat(e.target.value))}
                      className="w-full bg-black/30 border border-blue-400/30 rounded-lg px-4 py-2 text-white focus:border-blue-400 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-300 mb-2">{language === 'ar' ? 'خط الطول' : 'Longitude'}</label>
                    <input
                      type="number"
                      step="0.000001"
                      value={correctionLng}
                      onChange={(e) => setCorrectionLng(parseFloat(e.target.value))}
                      className="w-full bg-black/30 border border-blue-400/30 rounded-lg px-4 py-2 text-white focus:border-blue-400 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-300 mb-2">
                      {language === 'ar' ? 'درجة الدقة GPS (متر)' : 'GPS Accuracy (meters)'}
                    </label>
                    <div className="bg-black/30 border border-blue-400/30 rounded-lg px-4 py-2 text-white">
                      <p className="text-lg font-semibold text-blue-300">
                        {currentCoordinates ? `±${currentCoordinates.accuracy.toFixed(2)}м` : `±${5}م`}
                      </p>
                      <p className="text-xs text-gray-400 mt-1">
                        {currentCoordinates ? (language === 'ar' ? 'من بيانات GPS' : 'From GPS data') : (language === 'ar' ? 'قيمة افتراضية' : 'Default value')}
                      </p>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm text-gray-300 mb-2">{language === 'ar' ? 'معامل التصحيح (%)' : 'Correction Factor (%)'}</label>
                    <input
                      type="number"
                      min="0"
                      max="200"
                      step="0.1"
                      value={errorPercentage}
                      onChange={(e) => setErrorPercentage(parseFloat(e.target.value))}
                      className="w-full bg-black/30 border border-blue-400/30 rounded-lg px-4 py-2 text-white focus:border-blue-400 focus:outline-none"
                    />
                    <p className="text-xs text-gray-400 mt-1">{language === 'ar' ? 'مضاعف درجة الدقة' : 'Multiplier of accuracy'}</p>
                  </div>
                  <div className="flex gap-3">
                    <Button onClick={calculateCorrectedCoordinates} className="flex-1 bg-blue-600 hover:bg-blue-700">
                      <MapPin className={`w-4 h-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                      {language === 'ar' ? 'حساب' : 'Calculate'}
                    </Button>
                    <Button onClick={resetCorrectionCalculation} variant="outline" className="border-white/20 text-white hover:bg-white/10">
                      <RotateCcw className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Results Section */}
              {correctionResult && (
                <div className="space-y-4">
                  <div className="bg-red-900/20 border border-red-400/30 rounded-lg p-4">
                    <h4 className="text-sm font-bold text-red-400 mb-2">{language === 'ar' ? '📍 الأصلية' : '📍 Original'}</h4>
                    <p className="text-xs text-gray-300">Lat: {correctionResult.originalLat.toFixed(6)}°</p>
                    <p className="text-xs text-gray-300">Lng: {correctionResult.originalLng.toFixed(6)}°</p>
                  </div>
                  <div className="bg-green-900/20 border border-green-400/30 rounded-lg p-4">
                    <h4 className="text-sm font-bold text-green-400 mb-2">{language === 'ar' ? '✓ المصححة' : '✓ Corrected'}</h4>
                    <p className="text-xs text-gray-300">Lat: {correctionResult.correctedLat.toFixed(6)}°</p>
                    <p className="text-xs text-gray-300">Lng: {correctionResult.correctedLng.toFixed(6)}°</p>
                  </div>
                  <div className="bg-yellow-900/20 border border-yellow-400/30 rounded-lg p-4">
                    <h4 className="text-sm font-bold text-yellow-400 mb-2">{language === 'ar' ? '⚠️ الخطأ' : '⚠️ Error'}</h4>
                    <p className="text-xs text-gray-300">{language === 'ar' ? 'درجة الدقة' : 'Accuracy'}: ±{correctionResult.accuracy?.toFixed(2) || 'N/A'}m</p>
                    <p className="text-xs text-gray-300">{language === 'ar' ? 'نسبة الخطأ' : 'Error Percentage'}: {correctionResult.errorPercentage.toFixed(2)}%</p>
                    <p className="text-xs text-gray-300">{language === 'ar' ? 'المسافة المتوقعة' : 'Expected Distance'}: {correctionResult.distance.toFixed(2)}m</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* GPS Tab */}
        {activeTab === "gps" && (
          <div className="space-y-6">
            {/* GPS Controls */}
            <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 border border-white/10 space-y-4">
              <div>
                <label className="block text-sm text-gray-300 mb-2">
                  {language === 'ar' ? 'دقة الموقع' : 'Location Accuracy'}
                </label>
                <select
                  value={accuracyMode}
                  onChange={(e: any) => setAccuracyMode(e.target.value)}
                  className="w-full bg-black/30 border border-green-400/30 rounded-lg px-4 py-2 text-white focus:border-green-400 focus:outline-none"
                >
                  <option value="normal">{language === 'ar' ? 'دقة عادية (±10م)' : 'Normal Accuracy (±10m)'}</option>
                  <option value="high">{language === 'ar' ? 'دقة عالية جداً (±1م)' : 'Very High Accuracy (±1m)'}</option>
                </select>
              </div>

              <Button
                onClick={getLocation}
                disabled={locationLoading}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                <MapPin className={`w-4 h-4 ${isRTL ? 'mr-2' : 'ml-2'}`} />
                {locationLoading ? `${language === 'ar' ? 'جاري' : 'Loading'}... (${attempts})` : (language === 'ar' ? 'احصل على موقعك' : 'Get Your Location')}
              </Button>
            </div>

            {/* Status Message */}
            {statusMessage && (
              <div className="bg-blue-900/20 border border-blue-400/30 rounded-lg p-4 flex gap-3">
                <AlertCircle className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-blue-300">{statusMessage}</p>
              </div>
            )}

            {/* Coordinates Display */}
            {currentCoordinates && (
              <div className="bg-green-900/20 border border-green-400/30 rounded-lg p-6">
                <div className="flex gap-2 mb-4">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <h3 className="font-bold text-green-400">{language === 'ar' ? 'موقعك الحالي' : 'Your Current Location'}</h3>
                </div>

                <div className="grid md:grid-cols-2 gap-4 mb-6">
                  <div className="bg-black/30 rounded-lg p-4 border border-green-400/20">
                    <p className="text-xs text-gray-400 mb-1">{language === 'ar' ? 'خط العرض' : 'Latitude'}</p>
                    <p className="text-2xl font-bold text-white">{currentCoordinates.latitude.toFixed(8)}°</p>
                  </div>
                  <div className="bg-black/30 rounded-lg p-4 border border-green-400/20">
                    <p className="text-xs text-gray-400 mb-1">{language === 'ar' ? 'خط الطول' : 'Longitude'}</p>
                    <p className="text-2xl font-bold text-white">{currentCoordinates.longitude.toFixed(8)}°</p>
                  </div>
                  <div className="bg-black/30 rounded-lg p-4 border border-green-400/20">
                    <p className="text-xs text-gray-400 mb-1">{language === 'ar' ? 'الدقة' : 'Accuracy'}</p>
                    <p className="text-2xl font-bold text-green-400">±{currentCoordinates.accuracy.toFixed(2)}м</p>
                  </div>
                  <div className="bg-black/30 rounded-lg p-4 border border-green-400/20">
                    <p className="text-xs text-gray-400 mb-1">{language === 'ar' ? 'الارتفاع' : 'Altitude'}</p>
                    <p className="text-2xl font-bold text-white">
                      {currentCoordinates.altitude ? `${currentCoordinates.altitude.toFixed(2)}м` : (language === 'ar' ? 'غير متاح' : 'N/A')}
                    </p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-3">
                  <Button
                    onClick={() => {
                      navigator.clipboard.writeText(
                        `${currentCoordinates.latitude}, ${currentCoordinates.longitude}`
                      );
                      toast.success(language === 'ar' ? "✅ تم نسخ الإحداثيات" : "✅ Coordinates copied");
                    }}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    <Copy className={`w-4 h-4 ${isRTL ? 'mr-2' : 'ml-2'}`} />
                    {language === 'ar' ? 'نسخ الإحداثيات' : 'Copy Coordinates'}
                  </Button>
                  <Button
                    onClick={() => {
                      setCorrectionLat(currentCoordinates.latitude);
                      setCorrectionLng(currentCoordinates.longitude);
                      setActiveTab("correction");
                      toast.success(language === 'ar' ? "✅ تم نقل الإحداثيات للتصحيح" : "✅ Coordinates transferred to correction");
                    }}
                    className="w-full bg-red-600 hover:bg-red-700"
                  >
                    <MapPin className={`w-4 h-4 ${isRTL ? 'mr-2' : 'ml-2'}`} />
                    {language === 'ar' ? 'استخدم في التصحيح' : 'Use in Correction'}
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
