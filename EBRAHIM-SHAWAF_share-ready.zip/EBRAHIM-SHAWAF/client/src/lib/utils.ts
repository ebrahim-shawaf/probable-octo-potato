import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// ==================== Geo Calculation Functions ====================

const EARTH_RADIUS_METERS = 6371000;
const EARTH_RADIUS_KM = 6371;

export function toRadians(degrees: number): number {
  return degrees * Math.PI / 180;
}

export function toDegrees(radians: number): number {
  return radians * 180 / Math.PI;
}

/**
 * Calculate distance between two points using Haversine formula
 * @returns Distance in meters
 */
export function calculateHaversineDistance(
  lat1: number, lng1: number, 
  lat2: number, lng2: number
): number {
  const dLat = toRadians(lat2 - lat1);
  const dLng = toRadians(lng2 - lng1);
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) *
            Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return EARTH_RADIUS_METERS * c;
}

/**
 * Calculate polygon area using Shoelace formula with geodesic correction
 * @returns Area in square meters
 */
export function calculateGeodesicArea(coords: Array<{lat: number, lng: number}>): number {
  if (coords.length < 3) return 0;
  
  const centerLat = coords.reduce((sum, c) => sum + c.lat, 0) / coords.length;
  const latRad = toRadians(centerLat);
  
  // WGS84 ellipsoid parameters
  const a = 6378137.0;
  const b = 6356752.314245;
  const e2 = (a * a - b * b) / (a * a);
  
  const sinLat = Math.sin(latRad);
  const cosLat = Math.cos(latRad);
  const W = Math.sqrt(1 - e2 * sinLat * sinLat);
  
  const M = (a * (1 - e2)) / (W * W * W); // Meridional radius
  const N = a / W; // Prime vertical radius
  
  const metersPerDegLat = M * Math.PI / 180;
  const metersPerDegLng = N * cosLat * Math.PI / 180;
  
  // Convert to local tangent plane and use Shoelace
  const localCoords = coords.map(c => ({
    x: (c.lng - coords[0].lng) * metersPerDegLng,
    y: (c.lat - coords[0].lat) * metersPerDegLat
  }));
  
  let area = 0;
  for (let i = 0; i < localCoords.length; i++) {
    const j = (i + 1) % localCoords.length;
    area += localCoords[i].x * localCoords[j].y;
    area -= localCoords[j].x * localCoords[i].y;
  }
  
  return Math.abs(area) / 2;
}

/**
 * Calculate pressure difference based on elevation (water column)
 * ΔP = ρ × g × Δh / 100000 (bar)
 */
export function calculateElevationPressure(elevationDiff: number): number {
  const rho = 1000; // kg/m³
  const g = 9.81; // m/s²
  return (rho * g * Math.abs(elevationDiff)) / 100000;
}

/**
 * Calculate friction head loss using Hazen-Williams formula
 * @returns Head loss in meters
 */
export function calculateHazenWilliamsHeadLoss(
  flow: number, // L/s
  diameter: number, // mm
  length: number, // m
  C: number = 130 // Hazen-Williams coefficient
): number {
  if (diameter <= 0 || length <= 0) return 0;
  const Q = flow / 1000; // Convert to m³/s
  const D = diameter / 1000; // Convert to m
  const headLoss = 10.67 * Math.pow(Q, 1.852) * length / 
                   (Math.pow(C, 1.852) * Math.pow(D, 4.87));
  return headLoss;
}

/**
 * Convert head loss (meters) to pressure (bar)
 */
export function headLossToBar(headLoss: number): number {
  return headLoss * 0.0981; // ρ×g/100000 ≈ 0.0981
}

/**
 * Convert coordinates from WGS84 to UTM
 */
export function wgs84ToUtm(lat: number, lng: number): { easting: number, northing: number, zone: number } {
  const zone = Math.floor((lng + 180) / 6) + 1;
  const latRad = toRadians(lat);
  const lngRad = toRadians(lng);
  const centralMeridian = toRadians((zone - 1) * 6 - 180 + 3);
  
  const a = 6378137.0;
  const f = 1 / 298.257223563;
  const k0 = 0.9996;
  const e = Math.sqrt(2 * f - f * f);
  const e2 = e * e / (1 - e * e);
  
  const N = a / Math.sqrt(1 - e * e * Math.sin(latRad) * Math.sin(latRad));
  const T = Math.tan(latRad) * Math.tan(latRad);
  const C = e2 * Math.cos(latRad) * Math.cos(latRad);
  const A = Math.cos(latRad) * (lngRad - centralMeridian);
  
  const M = a * ((1 - e * e / 4 - 3 * e * e * e * e / 64) * latRad
           - (3 * e * e / 8 + 3 * e * e * e * e / 32) * Math.sin(2 * latRad)
           + (15 * e * e * e * e / 256) * Math.sin(4 * latRad));
  
  const easting = k0 * N * (A + (1 - T + C) * A * A * A / 6) + 500000;
  const northing = k0 * (M + N * Math.tan(latRad) * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A * A * A * A / 24)) + (lat < 0 ? 10000000 : 0);
  
  return { easting, northing, zone };
}

// ==================== Advanced Hydraulic Functions ====================

/**
 * Calculate Reynolds number for pipe flow
 * Re = ρVD/μ = VD/ν
 */
export function calculateReynoldsNumber(
  velocity: number, // m/s
  diameter: number, // mm
  kinematicViscosity: number = 1.004e-6 // m²/s (water at 20°C)
): number {
  const D = diameter / 1000; // Convert to m
  return (velocity * D) / kinematicViscosity;
}

/**
 * Calculate flow velocity in pipe
 * V = Q / A = 4Q / (πD²)
 * @returns Velocity in m/s
 */
export function calculateFlowVelocity(
  flow: number, // L/s
  diameter: number // mm
): number {
  if (diameter <= 0) return 0;
  const Q = flow / 1000; // Convert to m³/s
  const D = diameter / 1000; // Convert to m
  const A = Math.PI * D * D / 4;
  return Q / A;
}

/**
 * Calculate friction factor using Swamee-Jain equation (explicit approximation of Colebrook-White)
 * f = 0.25 / [log10(ε/(3.7D) + 5.74/Re^0.9)]²
 */
export function calculateSwameeJainFrictionFactor(
  diameter: number, // mm
  roughness: number = 0.26, // mm (for old cast iron, use 0.26; new PVC use 0.0015)
  reynoldsNumber: number
): number {
  if (reynoldsNumber < 2300) {
    // Laminar flow
    return 64 / reynoldsNumber;
  }
  const D = diameter; // mm
  const epsilon = roughness; // mm
  const term = (epsilon / (3.7 * D)) + (5.74 / Math.pow(reynoldsNumber, 0.9));
  return 0.25 / Math.pow(Math.log10(term), 2);
}

/**
 * Get typical roughness coefficient (mm) based on pipe material
 */
export function getPipeRoughness(material: string): number {
  const roughnessMap: Record<string, number> = {
    'pvc': 0.0015,
    'hdpe': 0.007,
    'new_steel': 0.045,
    'old_steel': 0.15,
    'new_cast_iron': 0.26,
    'old_cast_iron': 1.0,
    'concrete': 0.3,
    'asbestos_cement': 0.03,
    'ductile_iron': 0.26,
    'copper': 0.0015,
    'galvanized': 0.15,
    'default': 0.26
  };
  return roughnessMap[material.toLowerCase()] || roughnessMap['default'];
}

/**
 * Get Hazen-Williams C coefficient based on pipe material and age
 */
export function getHazenWilliamsC(material: string, ageYears: number = 0): number {
  const baseCMap: Record<string, number> = {
    'pvc': 150,
    'hdpe': 150,
    'new_steel': 140,
    'old_steel': 100,
    'new_cast_iron': 130,
    'old_cast_iron': 100,
    'concrete': 120,
    'asbestos_cement': 140,
    'ductile_iron': 140,
    'copper': 140,
    'galvanized': 120,
    'default': 130
  };
  const baseC = baseCMap[material.toLowerCase()] || baseCMap['default'];
  // Reduce C by approximately 1 per year for older pipes (simplified aging model)
  const ageFactor = Math.max(0, ageYears * 0.5);
  return Math.max(80, baseC - ageFactor);
}

/**
 * Calculate head loss using Darcy-Weisbach equation
 * h_f = f × (L/D) × (V²/2g)
 * @returns Head loss in meters
 */
export function calculateDarcyWeisbachHeadLoss(
  flow: number, // L/s
  diameter: number, // mm
  length: number, // m
  roughness: number = 0.26 // mm
): number {
  if (diameter <= 0 || length <= 0 || flow <= 0) return 0;
  
  const velocity = calculateFlowVelocity(flow, diameter);
  const Re = calculateReynoldsNumber(velocity, diameter);
  const f = calculateSwameeJainFrictionFactor(diameter, roughness, Re);
  const D = diameter / 1000; // Convert to m
  const g = 9.81;
  
  return f * (length / D) * (velocity * velocity) / (2 * g);
}

/**
 * Analyze pipe flow status
 * @returns Status object with warnings
 */
export function analyzePipeFlow(
  flow: number, // L/s
  diameter: number, // mm
  length: number, // m
  material: string = 'default'
): {
  velocity: number;
  reynoldsNumber: number;
  flowRegime: 'laminar' | 'transitional' | 'turbulent';
  headLossHW: number;
  headLossDW: number;
  pressureLossBar: number;
  velocityStatus: 'too_low' | 'optimal' | 'high' | 'too_high';
  warnings: string[];
} {
  const velocity = calculateFlowVelocity(flow, diameter);
  const Re = calculateReynoldsNumber(velocity, diameter);
  const C = getHazenWilliamsC(material);
  const roughness = getPipeRoughness(material);
  
  const headLossHW = calculateHazenWilliamsHeadLoss(flow, diameter, length, C);
  const headLossDW = calculateDarcyWeisbachHeadLoss(flow, diameter, length, roughness);
  const pressureLossBar = headLossToBar(headLossHW);
  
  let flowRegime: 'laminar' | 'transitional' | 'turbulent';
  if (Re < 2300) flowRegime = 'laminar';
  else if (Re < 4000) flowRegime = 'transitional';
  else flowRegime = 'turbulent';
  
  let velocityStatus: 'too_low' | 'optimal' | 'high' | 'too_high';
  const warnings: string[] = [];
  
  if (velocity < 0.3) {
    velocityStatus = 'too_low';
    warnings.push('سرعة منخفضة جداً - خطر تراكم الرواسب');
  } else if (velocity <= 1.5) {
    velocityStatus = 'optimal';
  } else if (velocity <= 2.5) {
    velocityStatus = 'high';
    warnings.push('سرعة عالية - زيادة في فقدان الضغط');
  } else {
    velocityStatus = 'too_high';
    warnings.push('سرعة عالية جداً - خطر تآكل الأنابيب');
  }
  
  if (pressureLossBar > 0.5) {
    warnings.push('فقدان ضغط كبير في هذا الخط');
  }
  
  return {
    velocity,
    reynoldsNumber: Re,
    flowRegime,
    headLossHW,
    headLossDW,
    pressureLossBar,
    velocityStatus,
    warnings
  };
}

/**
 * Calculate water age (residence time) in a pipe
 * @returns Time in hours
 */
export function calculateWaterAge(
  length: number, // m
  velocity: number // m/s
): number {
  if (velocity <= 0) return Infinity;
  const timeSeconds = length / velocity;
  return timeSeconds / 3600; // Convert to hours
}

/**
 * Calculate pipe volume
 * @returns Volume in liters
 */
export function calculatePipeVolume(
  diameter: number, // mm
  length: number // m
): number {
  const D = diameter / 1000; // m
  const A = Math.PI * D * D / 4;
  return A * length * 1000; // Convert m³ to liters
}

/**
 * Calculate optimal pipe diameter for given flow and head loss
 * Using Hazen-Williams rearranged: D = [10.67 × Q^1.852 × L / (C^1.852 × h_f)]^(1/4.87)
 * @returns Optimal diameter in mm
 */
export function calculateOptimalDiameter(
  flow: number, // L/s
  length: number, // m
  maxHeadLoss: number, // m
  C: number = 130
): number {
  if (flow <= 0 || length <= 0 || maxHeadLoss <= 0) return 0;
  const Q = flow / 1000; // m³/s
  const numerator = 10.67 * Math.pow(Q, 1.852) * length;
  const denominator = Math.pow(C, 1.852) * maxHeadLoss;
  const D = Math.pow(numerator / denominator, 1 / 4.87);
  return D * 1000; // Convert to mm
}

/**
 * Get standard pipe diameters (nominal diameters in mm)
 */
export function getStandardDiameters(): number[] {
  return [25, 32, 40, 50, 63, 75, 90, 110, 125, 160, 200, 250, 315, 400, 500, 630, 800, 1000, 1200];
}

/**
 * Find nearest standard diameter
 */
export function getNearestStandardDiameter(diameter: number): number {
  const standards = getStandardDiameters();
  let nearest = standards[0];
  let minDiff = Math.abs(diameter - nearest);
  
  for (const std of standards) {
    const diff = Math.abs(diameter - std);
    if (diff < minDiff) {
      minDiff = diff;
      nearest = std;
    }
  }
  return nearest;
}

/**
 * Find minimum standard diameter that satisfies requirements
 */
export function getMinimumStandardDiameter(optimalDiameter: number): number {
  const standards = getStandardDiameters();
  for (const std of standards) {
    if (std >= optimalDiameter) return std;
  }
  return standards[standards.length - 1];
}

/**
 * Calculate network demand at a node
 * @returns Demand in L/s
 */
export function calculateNodeDemand(
  population: number,
  perCapitaDemand: number = 200, // L/person/day
  peakFactor: number = 2.5
): number {
  const dailyDemand = population * perCapitaDemand; // L/day
  const peakDemand = dailyDemand * peakFactor; // L/day
  return peakDemand / 86400; // Convert to L/s
}

/**
 * Estimate fire flow requirement
 * @returns Fire flow in L/s
 */
export function calculateFireFlow(
  areaType: 'residential' | 'commercial' | 'industrial' | 'high_rise'
): number {
  const fireFlowMap: Record<string, number> = {
    'residential': 30, // 30 L/s minimum
    'commercial': 60,
    'industrial': 90,
    'high_rise': 120
  };
  return fireFlowMap[areaType] || 30;
}

/**
 * Calculate minimum pressure requirement
 * @returns Minimum pressure in bar
 */
export function getMinimumServicePressure(
  buildingFloors: number = 1
): number {
  // Base pressure of 2 bar + 0.35 bar per floor above ground
  return 2 + Math.max(0, (buildingFloors - 1) * 0.35);
}

/**
 * Analyze pressure adequacy
 */
export function analyzePressureAdequacy(
  pressure: number, // bar
  buildingFloors: number = 1
): {
  status: 'inadequate' | 'marginal' | 'adequate' | 'excessive';
  minRequired: number;
  recommendation: string;
} {
  const minRequired = getMinimumServicePressure(buildingFloors);
  
  let status: 'inadequate' | 'marginal' | 'adequate' | 'excessive';
  let recommendation: string;
  
  if (pressure < minRequired * 0.8) {
    status = 'inadequate';
    recommendation = 'ضغط غير كافٍ - يحتاج تعزيز (مضخة أو خزان مرتفع)';
  } else if (pressure < minRequired) {
    status = 'marginal';
    recommendation = 'ضغط حدي - قد لا يكفي في أوقات الذروة';
  } else if (pressure <= 8) {
    status = 'adequate';
    recommendation = 'ضغط مناسب للخدمة';
  } else {
    status = 'excessive';
    recommendation = 'ضغط زائد - يُنصح بتركيب مخفف ضغط (PRV)';
  }
  
  return { status, minRequired, recommendation };
}

/**
 * Calculate tank detention time (water age in tank)
 * @returns Time in hours
 */
export function calculateTankDetentionTime(
  tankVolume: number, // m³
  throughputFlow: number // L/s
): number {
  if (throughputFlow <= 0) return Infinity;
  const flowM3PerHour = (throughputFlow / 1000) * 3600;
  return tankVolume / flowM3PerHour;
}

/**
 * Network reliability metrics
 */
export function calculateNetworkReliability(
  pathsToSource: number,
  nodeCount: number,
  loopCount: number
): {
  redundancy: number;
  reliabilityScore: number;
  riskLevel: 'low' | 'medium' | 'high';
} {
  const redundancy = pathsToSource > 1 ? (pathsToSource - 1) / pathsToSource : 0;
  const loopRatio = loopCount / Math.max(1, nodeCount);
  const reliabilityScore = Math.min(100, (redundancy * 50) + (loopRatio * 50));
  
  let riskLevel: 'low' | 'medium' | 'high';
  if (reliabilityScore >= 70) riskLevel = 'low';
  else if (reliabilityScore >= 40) riskLevel = 'medium';
  else riskLevel = 'high';
  
  return { redundancy, reliabilityScore, riskLevel };
}
