import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface PDFReportOptions {
  title: string;
  subtitle?: string;
  date?: string;
  sections: PDFSection[];
  language?: 'ar' | 'en';
}

interface PDFSection {
  title: string;
  type: 'text' | 'table' | 'keyValue' | 'summary';
  content?: string;
  data?: { label: string; value: string | number; unit?: string }[];
  tableHeaders?: string[];
  tableRows?: (string | number)[][];
}

export function generatePDFReport(options: PDFReportOptions): void {
  const { title, subtitle, sections, language = 'ar' } = options;
  const isRTL = language === 'ar';
  
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 20;
  let currentY = margin;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(20);
  doc.setTextColor(44, 62, 80);
  
  const titleText = title;
  const titleWidth = doc.getTextWidth(titleText);
  doc.text(titleText, (pageWidth - titleWidth) / 2, currentY);
  currentY += 10;

  if (subtitle) {
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 100, 100);
    const subtitleWidth = doc.getTextWidth(subtitle);
    doc.text(subtitle, (pageWidth - subtitleWidth) / 2, currentY);
    currentY += 8;
  }

  doc.setFontSize(10);
  const dateText = options.date || new Date().toLocaleDateString(isRTL ? 'ar-EG' : 'en-US');
  const dateWidth = doc.getTextWidth(dateText);
  doc.text(dateText, (pageWidth - dateWidth) / 2, currentY);
  currentY += 5;

  doc.setDrawColor(200, 200, 200);
  doc.line(margin, currentY, pageWidth - margin, currentY);
  currentY += 10;

  sections.forEach((section, index) => {
    if (currentY > pageHeight - 40) {
      doc.addPage();
      currentY = margin;
    }

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.setTextColor(52, 73, 94);
    doc.text(section.title, margin, currentY);
    currentY += 8;

    switch (section.type) {
      case 'text':
        if (section.content) {
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(11);
          doc.setTextColor(60, 60, 60);
          const lines = doc.splitTextToSize(section.content, pageWidth - 2 * margin);
          doc.text(lines, margin, currentY);
          currentY += lines.length * 6 + 5;
        }
        break;

      case 'keyValue':
        if (section.data) {
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(11);
          
          section.data.forEach((item) => {
            if (currentY > pageHeight - 20) {
              doc.addPage();
              currentY = margin;
            }
            
            doc.setTextColor(100, 100, 100);
            doc.text(`${item.label}:`, margin, currentY);
            
            doc.setTextColor(44, 62, 80);
            doc.setFont('helvetica', 'bold');
            const valueText = `${item.value}${item.unit ? ' ' + item.unit : ''}`;
            doc.text(valueText, margin + 60, currentY);
            doc.setFont('helvetica', 'normal');
            
            currentY += 6;
          });
          currentY += 5;
        }
        break;

      case 'table':
        if (section.tableHeaders && section.tableRows) {
          autoTable(doc, {
            startY: currentY,
            head: [section.tableHeaders],
            body: section.tableRows.map(row => row.map(cell => String(cell))),
            margin: { left: margin, right: margin },
            styles: {
              fontSize: 10,
              cellPadding: 3,
              halign: 'center'
            },
            headStyles: {
              fillColor: [52, 73, 94],
              textColor: [255, 255, 255],
              fontStyle: 'bold'
            },
            alternateRowStyles: {
              fillColor: [245, 245, 245]
            }
          });
          currentY = (doc as any).lastAutoTable.finalY + 10;
        }
        break;

      case 'summary':
        if (section.data) {
          const cols = Math.min(section.data.length, 4);
          const boxWidth = (pageWidth - 2 * margin - (cols - 1) * 5) / cols;
          const boxHeight = 25;
          
          section.data.forEach((item, i) => {
            if (i > 0 && i % cols === 0) {
              currentY += boxHeight + 5;
            }
            
            const x = margin + (i % cols) * (boxWidth + 5);
            
            doc.setFillColor(241, 245, 249);
            doc.roundedRect(x, currentY, boxWidth, boxHeight, 3, 3, 'F');
            
            doc.setFontSize(9);
            doc.setTextColor(100, 100, 100);
            doc.setFont('helvetica', 'normal');
            const labelWidth = doc.getTextWidth(item.label);
            doc.text(item.label, x + (boxWidth - labelWidth) / 2, currentY + 8);
            
            doc.setFontSize(14);
            doc.setTextColor(44, 62, 80);
            doc.setFont('helvetica', 'bold');
            const valueText = `${item.value}${item.unit ? ' ' + item.unit : ''}`;
            const valueWidth = doc.getTextWidth(valueText);
            doc.text(valueText, x + (boxWidth - valueWidth) / 2, currentY + 18);
          });
          
          currentY += boxHeight + 10;
        }
        break;
    }

    if (index < sections.length - 1) {
      currentY += 5;
    }
  });

  const footerY = pageHeight - 10;
  doc.setFontSize(8);
  doc.setTextColor(150, 150, 150);
  doc.setFont('helvetica', 'italic');
  const footerText = isRTL ? 'إبراهيم شواف للمساحة - تقرير مُنشأ تلقائياً' : 'Ibrahim Shawaf Surveying - Auto-generated Report';
  const footerWidth = doc.getTextWidth(footerText);
  doc.text(footerText, (pageWidth - footerWidth) / 2, footerY);

  const fileName = `${title.replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.pdf`;
  doc.save(fileName);
}

export function generateBrickPDF(result: any, inputs: any, brickType: any, language: 'ar' | 'en') {
  const isAr = language === 'ar';
  
  generatePDFReport({
    title: isAr ? 'تقرير حساب كميات الطوب' : 'Brick Quantities Report',
    subtitle: isAr ? brickType.ar : brickType.en,
    language,
    sections: [
      {
        title: isAr ? 'أبعاد الحائط' : 'Wall Dimensions',
        type: 'keyValue',
        data: [
          { label: isAr ? 'طول الحائط' : 'Wall Length', value: inputs.wallLength, unit: 'm' },
          { label: isAr ? 'ارتفاع الحائط' : 'Wall Height', value: inputs.wallHeight, unit: 'm' },
          { label: isAr ? 'سمك الحائط' : 'Wall Thickness', value: inputs.wallThickness, unit: 'cm' },
          { label: isAr ? 'عدد الفتحات' : 'Openings', value: inputs.openingsCount },
          { label: isAr ? 'نسبة الهالك' : 'Wastage', value: inputs.wastagePercent, unit: '%' }
        ]
      },
      {
        title: isAr ? 'النتائج' : 'Results',
        type: 'summary',
        data: [
          { label: isAr ? 'المساحة الإجمالية' : 'Gross Area', value: result.grossArea.toFixed(1), unit: 'm²' },
          { label: isAr ? 'المساحة الصافية' : 'Net Area', value: result.netArea.toFixed(1), unit: 'm²' },
          { label: isAr ? 'عدد الطوب' : 'Bricks', value: result.bricksWithWastage.toLocaleString() },
          { label: isAr ? 'التكلفة' : 'Cost', value: result.estimatedCost.toLocaleString(), unit: 'EGP' }
        ]
      },
      {
        title: isAr ? 'المواد المطلوبة' : 'Required Materials',
        type: 'table',
        tableHeaders: [isAr ? 'المادة' : 'Material', isAr ? 'الكمية' : 'Quantity', isAr ? 'الوحدة' : 'Unit'],
        tableRows: [
          [isAr ? 'الطوب (صافي)' : 'Bricks (Net)', result.bricksNeeded.toLocaleString(), isAr ? 'وحدة' : 'pcs'],
          [isAr ? 'الطوب (مع الهالك)' : 'Bricks (With Wastage)', result.bricksWithWastage.toLocaleString(), isAr ? 'وحدة' : 'pcs'],
          [isAr ? 'الأسمنت' : 'Cement', result.cementBags, isAr ? 'كيس' : 'bags'],
          [isAr ? 'الرمل' : 'Sand', result.sandVolume.toFixed(2), 'm³'],
          [isAr ? 'أيام العمل' : 'Labor Days', result.laborDays.toFixed(1), isAr ? 'يوم' : 'days']
        ]
      }
    ]
  });
}

export function generatePaintPDF(result: any, inputs: any, paintType: any, language: 'ar' | 'en') {
  const isAr = language === 'ar';
  
  generatePDFReport({
    title: isAr ? 'تقرير حساب الدهانات' : 'Paint Calculation Report',
    subtitle: isAr ? paintType.ar : paintType.en,
    language,
    sections: [
      {
        title: isAr ? 'النتائج' : 'Results',
        type: 'summary',
        data: [
          { label: isAr ? 'المساحة الإجمالية' : 'Gross Area', value: result.grossArea.toFixed(1), unit: 'm²' },
          { label: isAr ? 'المساحة الصافية' : 'Net Area', value: result.netArea.toFixed(1), unit: 'm²' },
          { label: isAr ? 'كمية الدهان' : 'Paint', value: result.paintLiters.toFixed(1), unit: 'L' },
          { label: isAr ? 'التكلفة' : 'Cost', value: result.estimatedCost.toLocaleString(), unit: 'EGP' }
        ]
      },
      {
        title: isAr ? 'المواد المطلوبة' : 'Required Materials',
        type: 'table',
        tableHeaders: [isAr ? 'المادة' : 'Material', isAr ? 'الكمية' : 'Quantity', isAr ? 'الوحدة' : 'Unit'],
        tableRows: [
          [isAr ? 'الدهان' : 'Paint', result.paintLiters.toFixed(1), 'L'],
          [isAr ? 'جرادل' : 'Buckets', result.paintBuckets, isAr ? 'جردل 18L' : '18L buckets'],
          [isAr ? 'المعجون' : 'Putty', result.puttyKg.toFixed(1), 'kg'],
          [isAr ? 'البرايمر' : 'Primer', result.primerLiters.toFixed(1), 'L'],
          [isAr ? 'أيام العمل' : 'Labor Days', result.laborDays.toFixed(1), isAr ? 'يوم' : 'days']
        ]
      }
    ]
  });
}

export function generateTilesPDF(result: any, inputs: any, tileType: any, language: 'ar' | 'en') {
  const isAr = language === 'ar';
  
  generatePDFReport({
    title: isAr ? 'تقرير حساب البلاط' : 'Tiles Calculation Report',
    subtitle: isAr ? tileType.ar : tileType.en,
    language,
    sections: [
      {
        title: isAr ? 'النتائج' : 'Results',
        type: 'summary',
        data: [
          { label: isAr ? 'مساحة الأرضية' : 'Floor Area', value: result.floorArea.toFixed(1), unit: 'm²' },
          { label: isAr ? 'عدد البلاط' : 'Tiles', value: result.tilesWithWastage },
          { label: isAr ? 'عدد الكراتين' : 'Boxes', value: result.boxesNeeded },
          { label: isAr ? 'التكلفة' : 'Cost', value: result.estimatedCost.toLocaleString(), unit: 'EGP' }
        ]
      },
      {
        title: isAr ? 'المواد المطلوبة' : 'Required Materials',
        type: 'table',
        tableHeaders: [isAr ? 'المادة' : 'Material', isAr ? 'الكمية' : 'Quantity', isAr ? 'الوحدة' : 'Unit'],
        tableRows: [
          [isAr ? 'البلاط' : 'Tiles', result.tilesWithWastage, isAr ? 'قطعة' : 'pcs'],
          [isAr ? 'الكراتين' : 'Boxes', result.boxesNeeded, isAr ? 'كرتونة' : 'boxes'],
          [isAr ? 'اللاصق' : 'Adhesive', result.adhesiveKg.toFixed(0), 'kg'],
          [isAr ? 'الروبة' : 'Grout', result.groutKg.toFixed(1), 'kg']
        ]
      }
    ]
  });
}

export function generateStairsPDF(result: any, inputs: any, language: 'ar' | 'en') {
  const isAr = language === 'ar';
  const comfortValue = ((2 * result.actualRiserHeight) + inputs.treadDepth).toFixed(1);
  
  generatePDFReport({
    title: isAr ? 'تقرير تصميم السلم' : 'Stairs Design Report',
    subtitle: result.isComfortable 
      ? (isAr ? '✅ تصميم مريح' : '✅ Comfortable Design')
      : (isAr ? '⚠️ تصميم غير مريح' : '⚠️ Uncomfortable Design'),
    language,
    sections: [
      {
        title: isAr ? 'مدخلات التصميم' : 'Design Inputs',
        type: 'keyValue',
        data: [
          { label: isAr ? 'الارتفاع الكلي' : 'Total Height', value: inputs.totalHeight, unit: 'm' },
          { label: isAr ? 'عرض السلم' : 'Stair Width', value: inputs.stairWidth, unit: 'm' },
          { label: isAr ? 'ارتفاع القائمة' : 'Riser Height', value: inputs.riserHeight, unit: 'cm' },
          { label: isAr ? 'عمق النائمة' : 'Tread Depth', value: inputs.treadDepth, unit: 'cm' }
        ]
      },
      {
        title: isAr ? 'النتائج' : 'Results',
        type: 'summary',
        data: [
          { label: isAr ? 'عدد القوائم' : 'Risers', value: result.numberOfRisers },
          { label: isAr ? 'عدد النوائم' : 'Treads', value: result.numberOfTreads },
          { label: isAr ? 'زاوية الميل' : 'Angle', value: result.stairAngle.toFixed(1), unit: '°' },
          { label: '2R+T', value: comfortValue, unit: 'cm' }
        ]
      },
      {
        title: isAr ? 'الكميات' : 'Quantities',
        type: 'keyValue',
        data: [
          { label: isAr ? 'الطول الأفقي' : 'Run Length', value: result.totalRunLength.toFixed(2), unit: 'm' },
          { label: isAr ? 'حجم الخرسانة' : 'Concrete', value: result.concreteVolume.toFixed(2), unit: 'm³' },
          { label: isAr ? 'وزن الحديد' : 'Rebar', value: result.rebarWeight.toFixed(0), unit: 'kg' }
        ]
      }
    ]
  });
}

export function generateTankPDF(result: any, inputs: any, language: 'ar' | 'en') {
  const isAr = language === 'ar';
  
  generatePDFReport({
    title: isAr ? 'تقرير حساب خزان المياه' : 'Water Tank Calculation Report',
    language,
    sections: [
      {
        title: isAr ? 'بيانات المبنى' : 'Building Data',
        type: 'keyValue',
        data: [
          { label: isAr ? 'عدد السكان' : 'Residents', value: inputs.residents },
          { label: isAr ? 'الاستهلاك اليومي' : 'Daily Consumption', value: inputs.dailyConsumption, unit: 'L/person' },
          { label: isAr ? 'أيام التخزين' : 'Storage Days', value: inputs.storageDays },
          { label: isAr ? 'عدد الأدوار' : 'Floors', value: inputs.buildingFloors },
          { label: isAr ? 'حديقة' : 'Garden', value: inputs.hasGarden ? (isAr ? 'نعم' : 'Yes') : (isAr ? 'لا' : 'No') },
          { label: isAr ? 'احتياطي حريق' : 'Fire Reserve', value: inputs.hasFire ? (isAr ? 'نعم' : 'Yes') : (isAr ? 'لا' : 'No') }
        ]
      },
      {
        title: isAr ? 'النتائج' : 'Results',
        type: 'summary',
        data: [
          { label: isAr ? 'الاستهلاك اليومي' : 'Daily Demand', value: result.dailyDemand.toLocaleString(), unit: 'L' },
          { label: isAr ? 'السعة الكلية' : 'Total Capacity', value: result.totalCapacity.toLocaleString(), unit: 'L' },
          { label: isAr ? 'خزان أرضي' : 'Ground Tank', value: result.groundTankVolume.toLocaleString(), unit: 'L' },
          { label: isAr ? 'خزان علوي' : 'Roof Tank', value: result.roofTankVolume.toLocaleString(), unit: 'L' }
        ]
      },
      {
        title: isAr ? 'أبعاد الخزان الأرضي' : 'Ground Tank Dimensions',
        type: 'table',
        tableHeaders: [isAr ? 'البعد' : 'Dimension', isAr ? 'القيمة' : 'Value', isAr ? 'الوحدة' : 'Unit'],
        tableRows: [
          [isAr ? 'الطول' : 'Length', result.dimensions.length.toFixed(2), 'm'],
          [isAr ? 'العرض' : 'Width', result.dimensions.width.toFixed(2), 'm'],
          [isAr ? 'الارتفاع' : 'Height', result.dimensions.height.toFixed(2), 'm'],
          [isAr ? 'قدرة المضخة' : 'Pump Power', result.pumpPower.toFixed(2), 'kW'],
          [isAr ? 'التكلفة التقديرية' : 'Est. Cost', result.estimatedCost.toLocaleString(), 'EGP']
        ]
      }
    ]
  });
}

export function generateElectricalPDF(result: any, rooms: any[], settings: any, language: 'ar' | 'en') {
  const isAr = language === 'ar';
  
  generatePDFReport({
    title: isAr ? 'تقرير حساب الأحمال الكهربائية' : 'Electrical Load Report',
    subtitle: `${settings.voltage}V - ${settings.phases === 1 ? (isAr ? 'فاز واحد' : 'Single Phase') : (isAr ? '3 فاز' : '3 Phase')}`,
    language,
    sections: [
      {
        title: isAr ? 'النتائج الرئيسية' : 'Main Results',
        type: 'summary',
        data: [
          { label: isAr ? 'الحمل الكلي' : 'Total Load', value: result.totalLoad.toFixed(2), unit: 'kW' },
          { label: isAr ? 'حمل الطلب' : 'Demand Load', value: result.demandLoad.toFixed(2), unit: 'kW' },
          { label: isAr ? 'التيار المطلوب' : 'Current', value: result.requiredCurrent.toFixed(1), unit: 'A' },
          { label: isAr ? 'القاطع الرئيسي' : 'Main Breaker', value: result.mainBreakerSize, unit: 'A' }
        ]
      },
      {
        title: isAr ? 'المواصفات' : 'Specifications',
        type: 'keyValue',
        data: [
          { label: isAr ? 'مقاس الكابل' : 'Cable Size', value: result.cableSize, unit: 'mm²' },
          { label: isAr ? 'حجم العداد' : 'Meter Size', value: result.meterSize },
          { label: isAr ? 'معامل القدرة' : 'Power Factor', value: settings.powerFactor },
          { label: isAr ? 'معامل الطلب' : 'Demand Factor', value: settings.demandFactor }
        ]
      },
      {
        title: isAr ? 'تفاصيل الغرف' : 'Room Details',
        type: 'table',
        tableHeaders: [isAr ? 'الغرفة' : 'Room', isAr ? 'الحمل' : 'Load (W)', isAr ? 'النسبة' : 'Percentage'],
        tableRows: rooms.map(room => [
          room.name,
          room.load?.toLocaleString() || '0',
          `${((room.load || 0) / result.totalLoad * 100 / 10).toFixed(1)}%`
        ])
      }
    ]
  });
}

export function generateHVACPDF(result: any, rooms: any[], settings: any, language: 'ar' | 'en') {
  const isAr = language === 'ar';
  
  generatePDFReport({
    title: isAr ? 'تقرير حساب التكييف' : 'HVAC Calculation Report',
    subtitle: `${settings.climateZone} - ${settings.insulation}`,
    language,
    sections: [
      {
        title: isAr ? 'النتائج الرئيسية' : 'Main Results',
        type: 'summary',
        data: [
          { label: isAr ? 'حمل التبريد' : 'Cooling Load', value: result.totalBTU.toLocaleString(), unit: 'BTU/hr' },
          { label: isAr ? 'السعة بالطن' : 'Capacity', value: result.tonnage.toFixed(2), unit: isAr ? 'طن' : 'TR' },
          { label: isAr ? 'تدفق الهواء' : 'Air Flow', value: result.cfm.toFixed(0), unit: 'CFM' },
          { label: isAr ? 'حمل التدفئة' : 'Heating', value: result.heatingKW.toFixed(2), unit: 'kW' }
        ]
      },
      {
        title: isAr ? 'توصيات المعدات' : 'Equipment Recommendations',
        type: 'text',
        content: result.recommendations?.join('\n') || ''
      }
    ]
  });
}

export function generateCostPDF(result: any, items: any[], settings: any, language: 'ar' | 'en') {
  const isAr = language === 'ar';
  
  generatePDFReport({
    title: isAr ? 'تقرير تقدير التكلفة' : 'Cost Estimation Report',
    subtitle: settings.currency,
    language,
    sections: [
      {
        title: isAr ? 'ملخص التكلفة' : 'Cost Summary',
        type: 'summary',
        data: [
          { label: isAr ? 'المواد' : 'Materials', value: result.materialTotal.toLocaleString(), unit: settings.currency },
          { label: isAr ? 'العمالة' : 'Labor', value: result.laborTotal.toLocaleString(), unit: settings.currency },
          { label: isAr ? 'الإجمالي' : 'Total', value: result.finalTotal.toLocaleString(), unit: settings.currency }
        ]
      },
      {
        title: isAr ? 'التفاصيل' : 'Breakdown',
        type: 'table',
        tableHeaders: [isAr ? 'البند' : 'Item', isAr ? 'الكمية' : 'Qty', isAr ? 'السعر' : 'Price', isAr ? 'الإجمالي' : 'Total'],
        tableRows: items.map(item => [
          item.name,
          item.quantity,
          item.unitPrice.toLocaleString(),
          (item.quantity * item.unitPrice).toLocaleString()
        ])
      }
    ]
  });
}

export function generateSewagePDF(result: any, inputs: any, language: 'ar' | 'en') {
  const isAr = language === 'ar';
  
  generatePDFReport({
    title: isAr ? 'تقرير تحليل شبكة الصرف الصحي' : 'Sewage Network Analysis Report',
    subtitle: isAr ? 'تحليل هيدروليكي' : 'Hydraulic Analysis',
    language,
    sections: [
      {
        title: isAr ? 'بيانات المدخلات' : 'Input Data',
        type: 'keyValue',
        data: [
          { label: isAr ? 'عدد السكان' : 'Population', value: inputs.population },
          { label: isAr ? 'معامل الذروة' : 'Peak Factor', value: inputs.peakFactor },
          { label: isAr ? 'قطر الأنبوب' : 'Pipe Diameter', value: inputs.pipeDiameter, unit: 'mm' },
          { label: isAr ? 'الميل' : 'Slope', value: inputs.pipeSlope, unit: '%' },
          { label: isAr ? 'طول الأنبوب' : 'Pipe Length', value: inputs.pipeLength, unit: 'm' },
          { label: isAr ? 'معامل مانينج' : 'Manning n', value: inputs.manningN }
        ]
      },
      {
        title: isAr ? 'نتائج التدفق' : 'Flow Results',
        type: 'summary',
        data: [
          { label: isAr ? 'التدفق المتوسط' : 'Average Flow', value: result.avgFlow.toFixed(2), unit: 'L/s' },
          { label: isAr ? 'تدفق الذروة' : 'Peak Flow', value: result.peakFlow.toFixed(2), unit: 'L/s' },
          { label: isAr ? 'تدفق التصميم' : 'Design Flow', value: result.designFlow.toFixed(2), unit: 'L/s' },
          { label: isAr ? 'السعة' : 'Capacity', value: result.capacity.toFixed(2), unit: 'L/s' }
        ]
      },
      {
        title: isAr ? 'الخصائص الهيدروليكية' : 'Hydraulic Properties',
        type: 'summary',
        data: [
          { label: isAr ? 'السرعة' : 'Velocity', value: result.velocity.toFixed(2), unit: 'm/s' },
          { label: isAr ? 'نسبة الامتلاء' : 'Fill Ratio', value: (result.fillRatio * 100).toFixed(1), unit: '%' },
          { label: isAr ? 'نصف القطر الهيدروليكي' : 'Hydraulic Radius', value: (result.hydraulicRadius * 1000).toFixed(1), unit: 'mm' },
          { label: isAr ? 'رقم فرود' : 'Froude Number', value: result.froudeNumber.toFixed(3) },
          { label: isAr ? 'إجهاد القص' : 'Shear Stress', value: result.shearStress.toFixed(2), unit: 'N/m²' }
        ]
      },
      {
        title: isAr ? 'التقييم والتوصيات' : 'Assessment & Recommendations',
        type: 'text',
        content: [
          result.isSelfCleansing 
            ? (isAr ? '✅ التنظيف الذاتي: محقق (السرعة >= 0.6 م/ث)' : '✅ Self-cleansing: Achieved (Velocity >= 0.6 m/s)')
            : (isAr ? '⚠️ التنظيف الذاتي: غير محقق' : '⚠️ Self-cleansing: Not achieved'),
          '',
          ...result.recommendations
        ].join('\n')
      }
    ]
  });
}
