import React, { useState, useEffect } from 'react';

export type Language = 'ar' | 'en';
export type Theme = 'dark' | 'light';

export const translations = {
  ar: {
    // Navigation
    appName: 'إبراهيم شواف',
    coordinates: 'الإحداثيات',
    areas: 'المساحات',
    camera: 'الكاميرا',
    science: 'علم المساحة',
    software: 'برامج المساحة',
    visualization: '3D تصور',
    qrcode: 'الباركود',

    // Home Page
    homeTitle: 'إبراهيم شواف',
    homeSubtitle: 'أداة المساحة المتكاملة',
    homeDescription: 'تطبيق شامل لاستخراج الإحداثيات، قياس المسافات والمساحات، وتحليل البيانات الجغرافية من ملفات CAD والكاميرا',
    startNow: 'ابدأ الآن',
    extractCoordinates: 'استخراج الإحداثيات',

    // Features
    features: 'المميزات الرئيسية',
    cameraTitle: 'قياس الكاميرا',
    cameraDesc: 'قياس المسافات والمساحات باستخدام كاميرا جهازك مع معايرة دقيقة',
    tryNow: 'جرب الآن',
    gpsTitle: 'الإحداثيات GPS',
    gpsDesc: 'استخراج إحداثيات دقيقة من موقعك مع دقة تصل إلى ±1 متر',
    getLocation: 'احصل على موقعك',
    areasTitle: 'حساب المساحات',
    areasDesc: 'احسب مساحات المضلعات والأشكال الهندسية بسهولة',
    calculateNow: 'احسب الآن',
    extractTitle: 'استخراج الإحداثيات',
    extractDesc: 'استخرج الإحداثيات من ملفات CAD و DXF و Excel و CSV',
    extractData: 'استخرج البيانات',
    scienceTitle: 'علم المساحة',
    scienceDesc: 'تعلم أساسيات المساحة والقياسات الجغرافية',
    learnMore: 'تعلم أكثر',
    visualTitle: 'التصور 3D',
    visualDesc: 'عرض بيانات المساحة في تصور ثلاثي الأبعاد تفاعلي',
    viewNow: 'شاهد الآن',

    // Profile
    profileName: 'إبراهيم شواف',
    profileTitle: 'متخصص في المساحة والإحداثيات الجغرافية',
    profileDesc: 'خبرة عميقة في استخلاص البيانات من ملفات CAD وتحليل الإحداثيات بدقة عالية',
    equipment: 'أجهزة المساحة',

    // Info
    info: 'معلومات عن التطبيق',
    features_list: 'المميزات:',
    usage: 'الاستخدام:',
    feature1: 'قياس دقيق باستخدام الكاميرا',
    feature2: 'تحديد موقع بدقة GPS',
    feature3: 'حساب المساحات والمسافات',
    feature4: 'استخراج من ملفات CAD',
    feature5: 'تصدير للعديد من الصيغ',
    usage1: 'المساحين والمهندسين',
    usage2: 'المقاولين والعاملين',
    usage3: 'الدراسات الجغرافية',
    usage4: 'التطبيقات الزراعية',
    usage5: 'المشاريع العقارية',
    copyright: '© 2025 إبراهيم شواف للمساحة - جميع الحقوق محفوظة',

    // Camera Tools
    measurement: '📏 قياس',
    gps: '📍 إحداثيات GPS',
    calibration: 'معايرة',
    distance: 'المسافة',
    pixels: 'بكسل',
    startMeasuring: 'ابدأ القياس',
    clearMeasurements: 'مسح القياسات',
    accuracyMode: 'دقة عالية جداً',
    normal: 'عادية',
    high: 'عالية جداً',
    getYourLocation: 'احصل على موقعك',
    latitude: 'خط العرض',
    longitude: 'خط الطول',
    accuracy: 'الدقة',
    altitude: 'الارتفاع',
    timestamp: 'الوقت',
    statusMessage: 'رسالة الحالة',
    attempts: 'المحاولات',
    language: 'اللغة',

    // Water Pressure Calculator
    waterPressure: 'ضغوط المياه',
    waterPressureTitle: 'حاسبة ضغوط المياه',
    waterPressureDesc: 'حساب ضغط المياه بناءً على العمق والكثافة والجاذبية',
    depthLabel: 'العمق (متر)',
    densityLabel: 'الكثافة (كجم/م³)',
    gravityLabel: 'الجاذبية (م/ث²)',
    pressureResult: 'الضغط (باسكال)',
    pressureKPa: 'الضغط (كيلوباسكال)',
    pressureBar: 'الضغط (بار)',
    pressureAtm: 'الضغط (جو)',
    calculatePressure: 'حساب الضغط',
    resetPressure: 'إعادة تعيين',
    pressureFormula: 'الصيغة الأساسية: P = ρ × g × h',

    // Elevation Calculator
    elevation: 'حساب الارتفاع',
    elevationTitle: 'حاسبة الارتفاع',
    elevationDesc: 'حساب الارتفاع باستخدام نقطة مرجعية معروفة',
    referencePoint: 'النقطة المرجعية',
    refLatitude: 'خط عرض النقطة المرجعية',
    refLongitude: 'خط طول النقطة المرجعية',
    refElevation: 'الارتفاع المعروف (متر)',
    targetPoint: 'النقطة المستهدفة',
    targetLatitude: 'خط عرض النقطة المستهدفة',
    targetLongitude: 'خط طول النقطة المستهدفة',
    elevationDistance: 'المسافة (متر)',
    elevation_result: 'الارتفاع المحسوب (متر)',
    calculateElevation: 'حساب الارتفاع',
    selectFromMap: 'اختر من الخريطة',
    clickMap: 'اضغط على الخريطة لتحديد النقطة',

    // Water Network Pressure Calculator
    waterNetwork: 'ضغط الشبكة المائية',
    waterNetworkTitle: 'حاسبة ضغط شبكات المياه',
    waterNetworkDesc: 'حساب ضغط المياه في الشبكات بناءً على الارتفاع والمسافة',
    sourcePoint: 'نقطة المصدر',
    destinationPoint: 'نقطة الوجهة',
    sourceElevation: 'ارتفاع المصدر (متر)',
    destElevation: 'ارتفاع الوجهة (متر)',
    elevationDiff: 'الفارق في الارتفاع (متر)',
    pipeLength: 'طول الأنبوب (متر)',
    pipeFlow: 'معدل التدفق (لتر/ثانية)',
    pressureAtSource: 'الضغط في المصدر (بار)',
    pressureLoss: 'فقدان الضغط (بار)',
    pressureAtDest: 'الضغط في الوجهة (بار)',
    calculateNetworkPressure: 'حساب الضغط',
    pipeDiameter: 'قطر الأنبوب (ملم)',

    // Water Network Viewer
    waterNetworkViewer: 'عارض شبكات المياه',
    networkViewerDesc: 'عرض وتحليل شبكات المياه من ملفات KML على الخريطة',
  },
  en: {
    // Navigation
    appName: 'Ibrahim Shawaf',
    coordinates: 'Coordinates',
    areas: 'Areas',
    camera: 'Camera',
    science: 'Surveying Science',
    software: 'Surveying Software',
    visualization: '3D Visualization',
    qrcode: 'QR Code',

    // Home Page
    homeTitle: 'Ibrahim Shawaf',
    homeSubtitle: 'Integrated Surveying Tool',
    homeDescription: 'A comprehensive application for extracting coordinates, measuring distances and areas, and analyzing geographic data from CAD files and camera',
    startNow: 'Start Now',
    extractCoordinates: 'Extract Coordinates',

    // Features
    features: 'Main Features',
    cameraTitle: 'Camera Measurement',
    cameraDesc: 'Measure distances and areas using your device camera with precise calibration',
    tryNow: 'Try Now',
    gpsTitle: 'GPS Coordinates',
    gpsDesc: 'Extract precise coordinates from your location with accuracy up to ±1 meter',
    getLocation: 'Get Your Location',
    areasTitle: 'Calculate Areas',
    areasDesc: 'Calculate areas of polygons and geometric shapes easily',
    calculateNow: 'Calculate Now',
    extractTitle: 'Extract Coordinates',
    extractDesc: 'Extract coordinates from CAD, DXF, Excel, and CSV files',
    extractData: 'Extract Data',
    scienceTitle: 'Surveying Science',
    scienceDesc: 'Learn the basics of surveying and geographic measurements',
    learnMore: 'Learn More',
    visualTitle: '3D Visualization',
    visualDesc: 'Display surveying data in interactive 3D visualization',
    viewNow: 'View Now',

    // Profile
    profileName: 'Ibrahim Shawaf',
    profileTitle: 'Expert in Surveying and Geographic Coordinates',
    profileDesc: 'Deep experience in extracting data from CAD files and analyzing coordinates with high precision',
    equipment: 'Surveying Equipment',

    // Info
    info: 'About the Application',
    features_list: 'Features:',
    usage: 'Use Cases:',
    feature1: 'Precise measurement using camera',
    feature2: 'GPS location tracking',
    feature3: 'Calculate areas and distances',
    feature4: 'Extract from CAD files',
    feature5: 'Export to multiple formats',
    usage1: 'Surveyors and Engineers',
    usage2: 'Contractors and Workers',
    usage3: 'Geographic Studies',
    usage4: 'Agricultural Applications',
    usage5: 'Real Estate Projects',
    copyright: '© 2025 Ibrahim Shawaf Surveying - All Rights Reserved',

    // Camera Tools
    measurement: '📏 Measurement',
    gps: '📍 GPS Coordinates',
    calibration: 'Calibration',
    distance: 'Distance',
    pixels: 'Pixels',
    startMeasuring: 'Start Measuring',
    clearMeasurements: 'Clear Measurements',
    accuracyMode: 'Very High Accuracy',
    normal: 'Normal',
    high: 'Very High',
    getYourLocation: 'Get Your Location',
    latitude: 'Latitude',
    longitude: 'Longitude',
    accuracy: 'Accuracy',
    altitude: 'Altitude',
    timestamp: 'Timestamp',
    statusMessage: 'Status Message',
    attempts: 'Attempts',
    language: 'Language',

    // Water Pressure Calculator
    waterPressure: 'Water Pressure',
    waterPressureTitle: 'Water Pressure Calculator',
    waterPressureDesc: 'Calculate water pressure based on depth, density, and gravity',
    depthLabel: 'Depth (meters)',
    densityLabel: 'Density (kg/m³)',
    gravityLabel: 'Gravity (m/s²)',
    pressureResult: 'Pressure (Pascal)',
    pressureKPa: 'Pressure (kilopascal)',
    pressureBar: 'Pressure (bar)',
    pressureAtm: 'Pressure (atm)',
    calculatePressure: 'Calculate Pressure',
    resetPressure: 'Reset',
    pressureFormula: 'Basic Formula: P = ρ × g × h',

    // Elevation Calculator
    elevation: 'Calculate Elevation',
    elevationTitle: 'Elevation Calculator',
    elevationDesc: 'Calculate elevation using a known reference point',
    referencePoint: 'Reference Point',
    refLatitude: 'Reference Point Latitude',
    refLongitude: 'Reference Point Longitude',
    refElevation: 'Known Elevation (meters)',
    targetPoint: 'Target Point',
    targetLatitude: 'Target Point Latitude',
    targetLongitude: 'Target Point Longitude',
    elevationDistance: 'Distance (meters)',
    elevation_result: 'Calculated Elevation (meters)',
    calculateElevation: 'Calculate Elevation',
    selectFromMap: 'Select from Map',
    clickMap: 'Click on map to select point',

    // Water Network Pressure Calculator
    waterNetwork: 'Water Network Pressure',
    waterNetworkTitle: 'Water Network Pressure Calculator',
    waterNetworkDesc: 'Calculate water pressure in networks based on elevation and distance',
    sourcePoint: 'Source Point',
    destinationPoint: 'Destination Point',
    sourceElevation: 'Source Elevation (meters)',
    destElevation: 'Destination Elevation (meters)',
    elevationDiff: 'Elevation Difference (meters)',
    pipeLength: 'Pipe Length (meters)',
    pipeFlow: 'Flow Rate (liters/second)',
    pressureAtSource: 'Source Pressure (bar)',
    pressureLoss: 'Pressure Loss (bar)',
    pressureAtDest: 'Destination Pressure (bar)',
    calculateNetworkPressure: 'Calculate Pressure',
    pipeDiameter: 'Pipe Diameter (mm)',

    // Water Network Viewer
    waterNetworkViewer: 'Water Network Viewer',
    networkViewerDesc: 'View and analyze water networks from KML files on map',
  },
};

export const useLanguage = () => {
  const [language, setLanguage] = useState<Language>(() => {
    if (typeof window === 'undefined') return 'ar';
    return (localStorage.getItem('language') as Language) || 'ar';
  });

  const t = (key: keyof typeof translations.ar): string => {
    return translations[language][key] || key;
  };

  const toggleLanguage = () => {
    const newLang = language === 'ar' ? 'en' : 'ar';
    setLanguage(newLang);
    localStorage.setItem('language', newLang);
  };

  return { language, t, toggleLanguage };
};

// Theme Hook
export const useTheme = () => {
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window === 'undefined') return 'dark';
    return (localStorage.getItem('theme') as Theme) || 'dark';
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
      root.classList.remove('light');
    } else {
      root.classList.add('light');
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  const isDark = theme === 'dark';

  return { theme, toggleTheme, isDark };
};
