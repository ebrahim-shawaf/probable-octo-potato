import { useEffect, useRef, useState } from "react";
import L from "leaflet";
import { MapContainer, TileLayer, GeoJSON, useMap, Marker, Popup, ZoomControl } from "react-leaflet";
import { useQuery } from "@tanstack/react-query";
import "leaflet/dist/leaflet.css";
import type { District, Candidate, Vote, Subarea } from "@shared/schema";

interface ElectionMapProps {
  districts: District[];
  candidates: Candidate[];
  results: Array<{
    district: District;
    votes: Array<Vote & { candidate: Candidate }>;
  }>;
  subareas?: Subarea[];
  onDistrictClick?: (districtId: string) => void;
}

interface VoterStats {
  districtId: string;
  districtName: string;
  totalVoters: number;
  stations: {[key: string]: number};
}

function MapZoomHandler({ onZoomChange }: { onZoomChange: (zoom: number) => void }) {
  const map = useMap();
  
  useEffect(() => {
    if (!map) return;
    
    const handleZoom = () => {
      onZoomChange(map.getZoom());
    };
    
    map.on("zoomend", handleZoom);
    
    return () => {
      map.off("zoomend", handleZoom);
    };
  }, [map, onZoomChange]);
  
  return null;
}

export default function ElectionMap({ districts, candidates, results, subareas = [], onDistrictClick }: ElectionMapProps) {
  const mapRef = useRef<L.Map | null>(null);
  const [selectedDistrict, setSelectedDistrict] = useState<string | null>(null);
  const [zoomLevel, setZoomLevel] = useState<number>(6);
  
  // Fetch voter statistics
  const { data: voterStats = [] } = useQuery({
    queryKey: ["voter-stats"],
    queryFn: async () => {
      const res = await fetch("/api/voters/stats");
      return res.json() as Promise<VoterStats[]>;
    },
    refetchInterval: 5000,
  });

  const getVoterStats = (districtId: string): VoterStats | undefined => {
    return voterStats.find(s => s.districtId === districtId);
  };
  
  const showSubareas = zoomLevel >= 7 && subareas.length > 0;

  const getWinningCandidate = (districtId: string) => {
    const districtResults = results.find(r => r.district.id === districtId);
    if (!districtResults || districtResults.votes.length === 0) return null;
    
    const sorted = [...districtResults.votes].sort((a, b) => b.voteCount - a.voteCount);
    return sorted[0]?.candidate || null;
  };

  const getDistrictColor = (districtId: string) => {
    const winner = getWinningCandidate(districtId);
    return winner?.color || "#94a3b8";
  };

  const getDistrictCenter = (geometry: any): [number, number] | null => {
    try {
      if (geometry.type === "Polygon") {
        const coordinates = geometry.coordinates[0];
        let lat = 0, lng = 0;
        for (const [l, g] of coordinates) {
          lng += l;
          lat += g;
        }
        return [lat / coordinates.length, lng / coordinates.length];
      } else if (geometry.type === "MultiPolygon") {
        let lat = 0, lng = 0, count = 0;
        for (const polygon of geometry.coordinates) {
          for (const coord of polygon[0]) {
            lng += coord[0];
            lat += coord[1];
            count++;
          }
        }
        return [lat / count, lng / count];
      }
    } catch (e) {
      return null;
    }
    return null;
  };

  const getTotalVotes = (districtId: string): number => {
    const districtResults = results.find(r => r.district.id === districtId);
    return districtResults?.votes.reduce((sum, v) => sum + v.voteCount, 0) || 0;
  };

  const getSubareaCenter = (geometry: any): [number, number] | null => {
    try {
      if (geometry.type === "Polygon") {
        const coordinates = geometry.coordinates[0];
        let lat = 0, lng = 0;
        for (const [l, g] of coordinates) {
          lng += l;
          lat += g;
        }
        return [lat / coordinates.length, lng / coordinates.length];
      }
    } catch (e) {
      return null;
    }
    return null;
  };

  const onEachFeature = (feature: any, layer: L.Layer) => {
    const districtName = feature.properties?.district_name;
    const district = districts.find(d => d.name === districtName);
    
    if (district) {
      const winner = getWinningCandidate(district.id);
      const districtResults = results.find(r => r.district.id === district.id);
      const totalVotes = districtResults?.votes.reduce((sum, v) => sum + v.voteCount, 0) || 0;
      const stats = getVoterStats(district.id);

      layer.on({
        mouseover: (e) => {
          const layer = e.target;
          layer.setStyle({
            weight: 3,
            fillOpacity: 0.8,
          });
        },
        mouseout: (e) => {
          const layer = e.target;
          layer.setStyle({
            weight: 2,
            fillOpacity: 0.6,
          });
        },
        click: () => {
          setSelectedDistrict(district.id);
          if (onDistrictClick) {
            onDistrictClick(district.id);
          }
        },
      });

      const stationsHtml = stats && Object.keys(stats.stations).length > 0 
        ? `<div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid #ccc; font-size: 12px;">
            <p style="font-weight: bold; margin-bottom: 4px;">اللجان:</p>
            ${Object.entries(stats.stations)
              .map(([station, count]) => `<p style="margin: 2px 0;">• ${station}: ${count}</p>`)
              .join('')}
          </div>`
        : '';

      const popupContent = `
        <div style="text-align: right; direction: rtl; font-family: Cairo, sans-serif; max-width: 300px; padding: 8px;">
          <h3 style="font-weight: bold; font-size: 16px; margin-bottom: 8px;">${districtName}</h3>
          ${winner ? `
            <p style="margin: 4px 0;"><strong>الفائز:</strong> ${winner.name}</p>
            <p style="margin: 4px 0;"><strong>الحزب:</strong> ${winner.party}</p>
          ` : '<p style="margin: 4px 0;">لا توجد نتائج بعد</p>'}
          <p style="margin-top: 8px;"><strong>إجمالي الأصوات:</strong> ${totalVotes.toLocaleString('ar-EG')}</p>
          ${stats ? `
            <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid #ccc;">
              <p style="font-weight: bold; margin: 4px 0;">👥 الناخبون: ${stats.totalVoters}</p>
              ${stationsHtml}
            </div>
          ` : ''}
        </div>
      `;
      
      layer.bindPopup(popupContent);
    }
  };

  const geoStyle = (feature: any) => {
    const districtName = feature.properties?.district_name;
    const district = districts.find(d => d.name === districtName);
    const color = district ? getDistrictColor(district.id) : "#94a3b8";

    return {
      fillColor: color,
      weight: 2,
      opacity: 1,
      color: '#ffffff',
      fillOpacity: 0.6,
    };
  };

  const geoJsonData = {
    type: "FeatureCollection",
    features: districts.map(district => ({
      type: "Feature",
      properties: { district_name: district.name },
      geometry: district.geometry as any,
    })),
  };

  const subareaGeoJsonData = {
    type: "FeatureCollection",
    features: subareas.map(subarea => ({
      type: "Feature",
      properties: { subarea_name: subarea.name, district_id: subarea.districtId },
      geometry: subarea.geometry as any,
    })),
  };

  const onEachSubareaFeature = (feature: any, layer: L.Layer) => {
    const subareaName = feature.properties?.subarea_name;
    const subarea = subareas.find(s => s.name === subareaName);
    
    if (subarea) {
      const popupContent = `
        <div class="text-right" dir="rtl" style="font-family: Cairo, sans-serif;">
          <h3 class="font-bold text-lg mb-2">${subareaName}</h3>
        </div>
      `;
      
      layer.bindPopup(popupContent);
      layer.on({
        mouseover: (e) => {
          const layer = e.target;
          layer.setStyle({
            weight: 3,
            fillOpacity: 0.8,
          });
        },
        mouseout: (e) => {
          const layer = e.target;
          layer.setStyle({
            weight: 2,
            fillOpacity: 0.5,
          });
        },
      });
    }
  };

  const subareaGeoStyle = (feature: any) => {
    const districtId = feature.properties?.district_id;
    const district = districts.find(d => d.id === districtId);
    const winner = district ? getWinningCandidate(district.id) : null;
    const color = winner?.color || "#94a3b8";

    return {
      fillColor: color,
      weight: 2,
      opacity: 1,
      color: '#ffffff',
      fillOpacity: 0.5,
    };
  };

  return (
    <div className="w-full h-full rounded-lg border border-border shadow-lg" data-testid="election-map">
      <MapContainer
        center={[26.8206, 30.8025]}
        zoom={6}
        style={{ height: "100%", width: "100%" }}
        ref={mapRef}
      >
        <MapZoomHandler onZoomChange={setZoomLevel} />
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {!showSubareas && geoJsonData.features.length > 0 && (
          <GeoJSON
            data={geoJsonData as any}
            style={geoStyle}
            onEachFeature={onEachFeature}
          />
        )}
        
        {showSubareas && subareaGeoJsonData.features.length > 0 && (
          <GeoJSON
            data={subareaGeoJsonData as any}
            style={subareaGeoStyle}
            onEachFeature={onEachSubareaFeature}
          />
        )}
        
        {!showSubareas && districts.map((district) => {
          const center = getDistrictCenter(district.geometry);
          const totalVotes = getTotalVotes(district.id);
          
          if (!center || totalVotes === 0) return null;
          
          const customIcon = L.divIcon({
            className: "vote-count-marker",
            html: `
              <div style="
                background: white;
                border: 2px solid #333;
                border-radius: 4px;
                padding: 4px 6px;
                font-weight: bold;
                font-size: 12px;
                text-align: center;
                box-shadow: 0 2px 4px rgba(0,0,0,0.2);
              ">
                ${totalVotes.toLocaleString('ar-EG')}
              </div>
            `,
            iconSize: [60, 30],
            iconAnchor: [30, 15],
            popupAnchor: [0, -15],
          });
          
          return (
            <Marker key={district.id} position={center} icon={customIcon} data-testid={`vote-marker-${district.id}`}>
              <Popup>
                <div className="text-right" dir="rtl" style={{ fontFamily: "Cairo, sans-serif" }}>
                  <p className="font-bold">{district.name}</p>
                  <p>إجمالي الأصوات: {totalVotes.toLocaleString('ar-EG')}</p>
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>
    </div>
  );
}
