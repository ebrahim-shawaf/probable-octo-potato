import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera } from '@react-three/drei';

export type ElementType = "column" | "beam" | "wall" | "slab" | "footing" | "stairs" | "opening";

interface Element {
  id: number;
  type: ElementType;
  length: number;
  width: number;
  height: number;
  thickness?: number;
  qty: number;
}

const elementTypeColors: Record<ElementType, string> = {
  column: '#9B59B6',
  beam: '#3498DB',
  slab: '#2ECC71',
  footing: '#E74C3C',
  wall: '#F39C12',
  stairs: '#F1C40F',
  opening: '#EC4899'
};

function StructuralElement({ el, position, index }: { el: Element; position: [number, number, number]; index: number }) {
  const color = elementTypeColors[el.type];
  let boxHeight = el.height;
  let boxWidth = el.width;
  let boxLength = el.length;
  let yOffset = el.height / 2;
  
  // Validate element dimensions
  if (!boxHeight || !boxWidth || !boxLength || boxHeight <= 0 || boxWidth <= 0 || boxLength <= 0) {
    return null;
  }
  
  // Adjust dimensions based on element type
  if (el.type === 'slab') {
    boxHeight = el.thickness || 0.2;
    yOffset = boxHeight / 2;
  } else if (el.type === 'wall') {
    boxHeight = el.height;
    boxWidth = el.thickness || 0.15; // Use thickness for wall width
    yOffset = el.height / 2;
  } else if (el.type === 'stairs') {
    boxHeight = el.height;
    boxWidth = el.thickness || 0.15;
    yOffset = el.height / 2;
  } else if (el.type === 'opening') {
    // Door opening: thin frame representing the opening
    boxHeight = el.height;
    boxWidth = 0.08; // Very thin - just the frame
    yOffset = el.height / 2;
  } else if (el.type === 'footing') {
    // Footings are slightly shorter and wider
    yOffset = el.height / 2;
  }
  
  return (
    <group position={position}>
      {/* Foundation base for columns */}
      {el.type === 'column' && (
        <mesh position={[0, -0.15, 0]}>
          <boxGeometry args={[el.width + 0.15, 0.3, el.length + 0.15]} />
          <meshLambertMaterial color="#A0522D" />
        </mesh>
      )}

      {/* Element Body */}
      <mesh position={[0, yOffset, 0]} castShadow receiveShadow>
        <boxGeometry args={[boxWidth, boxHeight, boxLength]} />
        <meshStandardMaterial color={color} metalness={0.2} roughness={0.7} />
      </mesh>

      {/* Wireframe */}
      <mesh position={[0, yOffset, 0]}>
        <boxGeometry args={[boxWidth, boxHeight, boxLength]} />
        <meshBasicMaterial color="#000000" wireframe={true} transparent opacity={0.3} />
      </mesh>
    </group>
  );
}

export default function ColumnViewer3D({ elements }: { elements: Element[] }) {
  if (elements.length === 0) {
    return (
      <div className="w-full h-80 bg-slate-900 border border-white/20 rounded-lg flex items-center justify-center text-gray-400">
        No elements to display
      </div>
    );
  }

  // Calculate optimal viewing distance
  const cols_per_row = Math.max(1, Math.ceil(Math.sqrt(elements.length)));
  const spacing = 4;
  const gridSize = cols_per_row * spacing;
  const maxHeight = Math.max(...elements.map(e => e.type === 'slab' ? (e.thickness || 0.2) : e.height));
  const maxWidth = Math.max(...elements.map(e => Math.max(e.width, e.length)));
  
  // Calculate camera distance
  const minDimension = Math.min(gridSize, maxHeight);
  const maxDimension = Math.max(gridSize, maxHeight);
  const cameraDistance = maxDimension * 2;

  return (
    <div className="w-full h-80 bg-gradient-to-b from-slate-900 to-black border border-white/20 rounded-lg overflow-hidden" data-testid="viewer-3d">
      <Canvas shadows dpr={[1, 1.5]}>
        <PerspectiveCamera 
          makeDefault 
          position={[cameraDistance * 0.6, cameraDistance * 0.6, cameraDistance * 0.6]} 
          fov={50}
          near={0.1}
          far={10000}
        />
        
        {/* Lights */}
        <ambientLight intensity={0.5} />
        <directionalLight 
          position={[cameraDistance, cameraDistance, cameraDistance]} 
          intensity={1.5}
          castShadow
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
          shadow-camera-far={cameraDistance * 3}
          shadow-camera-left={-gridSize}
          shadow-camera-right={gridSize}
          shadow-camera-top={gridSize}
          shadow-camera-bottom={-gridSize}
        />
        <pointLight position={[0, maxHeight + 3, 0]} intensity={0.6} />
        
        {/* Ground */}
        <mesh position={[0, -0.2, 0]} receiveShadow>
          <planeGeometry args={[gridSize + 10, gridSize + 10]} />
          <meshLambertMaterial color="#505050" />
        </mesh>
        
        {/* Elements */}
        {elements.map((el, idx) => {
          const row = Math.floor(idx / cols_per_row);
          const col_pos = idx % cols_per_row;
          const x = (col_pos - (cols_per_row - 1) / 2) * spacing;
          const z = (row - (cols_per_row - 1) / 2) * spacing;
          
          return (
            <StructuralElement 
              key={el.id} 
              el={el} 
              position={[x, 0, z]}
              index={idx}
            />
          );
        })}
        
        {/* Grid */}
        <gridHelper args={[gridSize + 10, 20]} position={[0, -0.19, 0]} />
        
        {/* Controls */}
        <OrbitControls 
          autoRotate
          autoRotateSpeed={2}
          enableDamping
          dampingFactor={0.05}
          minDistance={5}
          maxDistance={cameraDistance * 4}
        />
      </Canvas>
    </div>
  );
}
