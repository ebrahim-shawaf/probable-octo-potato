import { useRef, useMemo, useState, useCallback } from 'react';
import { Canvas, ThreeEvent } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import Delaunator from 'delaunator';

interface SurfacePoint {
  station: string;
  x: number;
  y: number;
  z: number;
}

interface AlignedPoint {
  station: string;
  x: number;
  y: number;
  existingZ: number;
  designZ: number;
  difference: number;
}

interface SelectedPoint {
  station: string;
  x: number;
  y: number;
  existingZ: number;
  designZ: number;
  difference: number;
  type: 'cut' | 'fill' | 'balanced';
}

interface CutFill3DViewProps {
  existingData: SurfacePoint[];
  designData: SurfacePoint[];
  language: string;
}

function alignDatasets(existing: SurfacePoint[], design: SurfacePoint[]): AlignedPoint[] {
  const designMap = new Map<string, SurfacePoint>();
  design.forEach(p => designMap.set(p.station, p));
  
  const aligned: AlignedPoint[] = [];
  
  for (const ex of existing) {
    let designPoint = designMap.get(ex.station);
    
    if (!designPoint) {
      let minDist = Infinity;
      let closestDesign: SurfacePoint | null = null;
      
      for (const de of design) {
        const dist = Math.sqrt(Math.pow(de.x - ex.x, 2) + Math.pow(de.y - ex.y, 2));
        if (dist < minDist && dist < 1.0) {
          minDist = dist;
          closestDesign = de;
        }
      }
      
      designPoint = closestDesign || { station: ex.station, x: ex.x, y: ex.y, z: ex.z };
    }
    
    const difference = designPoint.z - ex.z;
    aligned.push({
      station: ex.station,
      x: ex.x,
      y: ex.y,
      existingZ: ex.z,
      designZ: designPoint.z,
      difference
    });
  }
  
  return aligned;
}

function samplePoints(points: AlignedPoint[], maxPoints: number = 5000): AlignedPoint[] {
  if (points.length <= maxPoints) return points;
  
  const step = Math.ceil(points.length / maxPoints);
  const sampled: AlignedPoint[] = [];
  
  for (let i = 0; i < points.length; i += step) {
    sampled.push(points[i]);
  }
  
  return sampled;
}

interface NormalizedData {
  points: AlignedPoint[];
  normalized: number[][];
  centroid: { x: number; y: number; z: number };
  scale: number;
}

function normalizeCoordinates(alignedPoints: AlignedPoint[]): NormalizedData {
  if (alignedPoints.length === 0) {
    return { 
      points: [], 
      normalized: [], 
      centroid: { x: 0, y: 0, z: 0 }, 
      scale: 1 
    };
  }

  const sumX = alignedPoints.reduce((acc, p) => acc + p.x, 0);
  const sumY = alignedPoints.reduce((acc, p) => acc + p.y, 0);
  const sumZ = alignedPoints.reduce((acc, p) => acc + p.existingZ, 0);
  
  const centroid = {
    x: sumX / alignedPoints.length,
    y: sumY / alignedPoints.length,
    z: sumZ / alignedPoints.length
  };

  const maxDist = Math.max(
    1,
    ...alignedPoints.map(p => Math.sqrt(
      Math.pow(p.x - centroid.x, 2) + 
      Math.pow(p.y - centroid.y, 2)
    ))
  );
  
  const scale = 10 / maxDist;

  const normalized = alignedPoints.map(p => [
    (p.x - centroid.x) * scale,
    (p.y - centroid.y) * scale,
    (p.existingZ - centroid.z) * scale
  ]);

  return { points: alignedPoints, normalized, centroid, scale };
}

function getDifferenceColor(difference: number): THREE.Color {
  if (difference < -1) return new THREE.Color(0xcc0000);
  if (difference < -0.5) return new THREE.Color(0xff3333);
  if (difference < -0.2) return new THREE.Color(0xff6644);
  if (difference < -0.05) return new THREE.Color(0xff9966);
  if (difference > 1) return new THREE.Color(0x006600);
  if (difference > 0.5) return new THREE.Color(0x00aa00);
  if (difference > 0.2) return new THREE.Color(0x44cc44);
  if (difference > 0.05) return new THREE.Color(0x88ff88);
  return new THREE.Color(0xffff00);
}

function createMeshGeometry(
  normalized: number[][],
  alignedPoints: AlignedPoint[],
  mode: 'existing' | 'design' | 'difference',
  centroidZ: number,
  scale: number
): THREE.BufferGeometry | null {
  if (normalized.length < 3) return null;

  const coords = normalized.flatMap(p => [p[0], p[1]]);
  
  try {
    const delaunay = new Delaunator(coords);
    const triangles = delaunay.triangles;

    const positions: number[] = [];
    const colors: number[] = [];

    for (let i = 0; i < triangles.length; i += 3) {
      const indices = [triangles[i], triangles[i + 1], triangles[i + 2]];

      for (const idx of indices) {
        const norm = normalized[idx];
        const aligned = alignedPoints[idx];
        
        let zValue: number;
        let color: THREE.Color;
        
        switch (mode) {
          case 'existing':
            zValue = norm[2];
            color = new THREE.Color(0x4a90d9);
            break;
          case 'design':
            zValue = (aligned.designZ - centroidZ) * scale;
            color = new THREE.Color(0x50c878);
            break;
          case 'difference':
            zValue = ((aligned.existingZ + aligned.designZ) / 2 - centroidZ) * scale;
            color = getDifferenceColor(aligned.difference);
            break;
        }
        
        positions.push(norm[0], zValue, -norm[1]);
        colors.push(color.r, color.g, color.b);
      }
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geometry.computeVertexNormals();

    return geometry;
  } catch (e) {
    console.error('Triangulation failed:', e);
    return null;
  }
}

function TerrainMesh({ 
  geometry, 
  opacity = 1, 
  onClick,
  normalized,
  alignedPoints
}: { 
  geometry: THREE.BufferGeometry | null;
  opacity?: number;
  onClick?: (point: SelectedPoint) => void;
  normalized?: number[][];
  alignedPoints?: AlignedPoint[];
}) {
  const handleClick = useCallback((event: ThreeEvent<MouseEvent>) => {
    if (!onClick || !normalized || !alignedPoints) return;
    
    event.stopPropagation();
    const point = event.point;
    
    let closestIdx = 0;
    let minDist = Infinity;
    
    for (let i = 0; i < normalized.length; i++) {
      const p = normalized[i];
      const dist = Math.sqrt(
        Math.pow(point.x - p[0], 2) + 
        Math.pow(point.z + p[1], 2)
      );
      if (dist < minDist) {
        minDist = dist;
        closestIdx = i;
      }
    }

    const aligned = alignedPoints[closestIdx];
    
    if (aligned) {
      onClick({
        station: aligned.station,
        x: aligned.x,
        y: aligned.y,
        existingZ: aligned.existingZ,
        designZ: aligned.designZ,
        difference: aligned.difference,
        type: aligned.difference < -0.01 ? 'cut' : aligned.difference > 0.01 ? 'fill' : 'balanced'
      });
    }
  }, [onClick, normalized, alignedPoints]);

  if (!geometry) return null;

  return (
    <mesh geometry={geometry} onClick={handleClick}>
      <meshStandardMaterial 
        vertexColors 
        transparent={opacity < 1}
        opacity={opacity}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}

function PointMarker({ position }: { position: [number, number, number] }) {
  return (
    <mesh position={position}>
      <sphereGeometry args={[0.15, 16, 16]} />
      <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.5} />
    </mesh>
  );
}

function Scene({ 
  alignedPoints,
  onPointSelect,
  showExisting,
  showDesign,
  showDifference
}: { 
  alignedPoints: AlignedPoint[];
  onPointSelect: (point: SelectedPoint | null) => void;
  showExisting: boolean;
  showDesign: boolean;
  showDifference: boolean;
}) {
  const [selectedPosition, setSelectedPosition] = useState<[number, number, number] | null>(null);

  const { existingGeometry, designGeometry, differenceGeometry, normalized, centroid, scale } = useMemo(() => {
    if (alignedPoints.length < 3) {
      return { 
        existingGeometry: null, 
        designGeometry: null, 
        differenceGeometry: null,
        normalized: [],
        centroid: { x: 0, y: 0, z: 0 },
        scale: 1
      };
    }

    const { normalized: norm, centroid: cent, scale: sc } = normalizeCoordinates(alignedPoints);

    const existingGeo = createMeshGeometry(norm, alignedPoints, 'existing', cent.z, sc);
    const designGeo = createMeshGeometry(norm, alignedPoints, 'design', cent.z, sc);
    const differenceGeo = createMeshGeometry(norm, alignedPoints, 'difference', cent.z, sc);

    return { 
      existingGeometry: existingGeo, 
      designGeometry: designGeo, 
      differenceGeometry: differenceGeo,
      normalized: norm,
      centroid: cent,
      scale: sc
    };
  }, [alignedPoints]);

  const handlePointClick = useCallback((point: SelectedPoint) => {
    onPointSelect(point);
    
    const normX = (point.x - centroid.x) * scale;
    const normY = (point.y - centroid.y) * scale;
    const normZ = (point.existingZ - centroid.z) * scale;
    setSelectedPosition([normX, normZ, -normY]);
  }, [onPointSelect, centroid, scale]);

  return (
    <>
      <ambientLight intensity={0.6} />
      <directionalLight position={[10, 10, 5]} intensity={1} />
      <directionalLight position={[-10, -10, -5]} intensity={0.3} />
      
      <OrbitControls 
        enablePan={true}
        enableZoom={true}
        enableRotate={true}
        minDistance={2}
        maxDistance={50}
      />

      {showExisting && existingGeometry && (
        <TerrainMesh 
          geometry={existingGeometry} 
          opacity={showDifference ? 0.3 : 0.8}
          onClick={handlePointClick}
          normalized={normalized}
          alignedPoints={alignedPoints}
        />
      )}

      {showDesign && designGeometry && (
        <TerrainMesh 
          geometry={designGeometry} 
          opacity={showDifference ? 0.3 : 0.8}
        />
      )}

      {showDifference && differenceGeometry && (
        <TerrainMesh 
          geometry={differenceGeometry}
          onClick={handlePointClick}
          normalized={normalized}
          alignedPoints={alignedPoints}
        />
      )}

      {selectedPosition && <PointMarker position={selectedPosition} />}

      <gridHelper args={[20, 20, 0x444444, 0x222222]} rotation={[0, 0, 0]} />
      <axesHelper args={[5]} />
    </>
  );
}

export default function CutFill3DView({ existingData, designData, language }: CutFill3DViewProps) {
  const [selectedPoint, setSelectedPoint] = useState<SelectedPoint | null>(null);
  const [showExisting, setShowExisting] = useState(true);
  const [showDesign, setShowDesign] = useState(true);
  const [showDifference, setShowDifference] = useState(true);

  const isRTL = language === 'ar';

  const alignedPoints = useMemo(() => {
    if (existingData.length < 3 || designData.length < 3) return [];
    
    const aligned = alignDatasets(existingData, designData);
    return samplePoints(aligned, 5000);
  }, [existingData, designData]);

  const stats = useMemo(() => {
    if (alignedPoints.length === 0) return null;
    
    let cutCount = 0, fillCount = 0, balancedCount = 0;
    let totalCut = 0, totalFill = 0;
    
    for (const p of alignedPoints) {
      if (p.difference < -0.01) {
        cutCount++;
        totalCut += Math.abs(p.difference);
      } else if (p.difference > 0.01) {
        fillCount++;
        totalFill += p.difference;
      } else {
        balancedCount++;
      }
    }
    
    return { cutCount, fillCount, balancedCount, totalCut, totalFill };
  }, [alignedPoints]);

  if (existingData.length < 3 || designData.length < 3) {
    return (
      <div className="flex items-center justify-center h-[500px] bg-black/20 rounded-xl border border-white/10">
        <div className="text-center text-gray-400">
          <div className="text-6xl mb-4">🗺️</div>
          <p className="text-lg">
            {language === 'ar' 
              ? 'يرجى رفع ملفات الأرض الطبيعية والتصميمية أولاً (3 نقاط على الأقل)'
              : 'Please upload existing and design surface files first (at least 3 points)'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="flex flex-wrap gap-4 mb-4 p-3 bg-white/5 rounded-lg border border-white/10">
        <label className="flex items-center gap-2 text-white cursor-pointer">
          <input
            type="checkbox"
            checked={showExisting}
            onChange={(e) => setShowExisting(e.target.checked)}
            className="w-4 h-4 accent-blue-500"
            data-testid="toggle-existing"
          />
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 rounded bg-blue-500"></span>
            {language === 'ar' ? 'الأرض الطبيعية' : 'Existing Ground'}
          </span>
        </label>

        <label className="flex items-center gap-2 text-white cursor-pointer">
          <input
            type="checkbox"
            checked={showDesign}
            onChange={(e) => setShowDesign(e.target.checked)}
            className="w-4 h-4 accent-green-500"
            data-testid="toggle-design"
          />
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 rounded bg-green-500"></span>
            {language === 'ar' ? 'الأرض التصميمية' : 'Design Surface'}
          </span>
        </label>

        <label className="flex items-center gap-2 text-white cursor-pointer">
          <input
            type="checkbox"
            checked={showDifference}
            onChange={(e) => setShowDifference(e.target.checked)}
            className="w-4 h-4 accent-yellow-500"
            data-testid="toggle-difference"
          />
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 rounded bg-gradient-to-r from-red-500 via-yellow-500 to-green-500"></span>
            {language === 'ar' ? 'الفرق (حفر/ردم)' : 'Difference (Cut/Fill)'}
          </span>
        </label>

        {alignedPoints.length < existingData.length && (
          <span className="text-amber-400 text-sm">
            ⚠️ {language === 'ar' 
              ? `تم تقليل النقاط من ${existingData.length} إلى ${alignedPoints.length} للأداء`
              : `Sampled from ${existingData.length} to ${alignedPoints.length} points for performance`}
          </span>
        )}
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        <div className="md:col-span-3">
          <div 
            className="h-[500px] bg-gradient-to-b from-gray-900 to-black rounded-xl border border-white/20 overflow-hidden"
            data-testid="3d-canvas-container"
          >
            <Canvas
              camera={{ position: [15, 15, 15], fov: 50 }}
              gl={{ antialias: true }}
            >
              <Scene 
                alignedPoints={alignedPoints}
                onPointSelect={setSelectedPoint}
                showExisting={showExisting}
                showDesign={showDesign}
                showDifference={showDifference}
              />
            </Canvas>
          </div>
          
          <div className="mt-2 text-center text-gray-400 text-sm">
            {language === 'ar' 
              ? '🖱️ اسحب للتدوير • سكرول للتكبير • Shift+سحب للتحريك • انقر على السطح لعرض التفاصيل'
              : '🖱️ Drag to rotate • Scroll to zoom • Shift+Drag to pan • Click surface for details'}
          </div>
        </div>

        <div className="md:col-span-1 space-y-4">
          <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-4">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              📍 {language === 'ar' ? 'تفاصيل النقطة' : 'Point Details'}
            </h3>
            
            {selectedPoint ? (
              <div className="space-y-3" data-testid="point-details">
                <div className="bg-black/30 rounded-lg p-3">
                  <div className="text-gray-400 text-xs mb-1">
                    {language === 'ar' ? 'المحطة' : 'Station'}
                  </div>
                  <div className="text-white font-mono">{selectedPoint.station}</div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-black/30 rounded-lg p-3">
                    <div className="text-gray-400 text-xs mb-1">X</div>
                    <div className="text-white font-mono text-sm">{selectedPoint.x.toFixed(3)}</div>
                  </div>
                  <div className="bg-black/30 rounded-lg p-3">
                    <div className="text-gray-400 text-xs mb-1">Y</div>
                    <div className="text-white font-mono text-sm">{selectedPoint.y.toFixed(3)}</div>
                  </div>
                </div>

                <div className="bg-blue-500/20 rounded-lg p-3 border border-blue-500/30">
                  <div className="text-blue-300 text-xs mb-1">
                    {language === 'ar' ? 'المنسوب الطبيعي' : 'Existing Elev.'}
                  </div>
                  <div className="text-white font-mono text-lg">{selectedPoint.existingZ.toFixed(3)} m</div>
                </div>

                <div className="bg-green-500/20 rounded-lg p-3 border border-green-500/30">
                  <div className="text-green-300 text-xs mb-1">
                    {language === 'ar' ? 'المنسوب التصميمي' : 'Design Elev.'}
                  </div>
                  <div className="text-white font-mono text-lg">{selectedPoint.designZ.toFixed(3)} m</div>
                </div>

                <div className={`rounded-lg p-3 border ${
                  selectedPoint.type === 'cut' 
                    ? 'bg-red-500/20 border-red-500/30' 
                    : selectedPoint.type === 'fill'
                    ? 'bg-green-500/20 border-green-500/30'
                    : 'bg-yellow-500/20 border-yellow-500/30'
                }`}>
                  <div className={`text-xs mb-1 ${
                    selectedPoint.type === 'cut' ? 'text-red-300' :
                    selectedPoint.type === 'fill' ? 'text-green-300' : 'text-yellow-300'
                  }`}>
                    {language === 'ar' ? 'الفرق' : 'Difference'}
                  </div>
                  <div className="text-white font-mono text-lg flex items-center gap-2">
                    {selectedPoint.difference > 0 ? '+' : ''}{selectedPoint.difference.toFixed(3)} m
                    <span className={`text-xs px-2 py-1 rounded ${
                      selectedPoint.type === 'cut' ? 'bg-red-500/30 text-red-200' :
                      selectedPoint.type === 'fill' ? 'bg-green-500/30 text-green-200' : 
                      'bg-yellow-500/30 text-yellow-200'
                    }`}>
                      {selectedPoint.type === 'cut' 
                        ? (language === 'ar' ? 'حفر' : 'CUT')
                        : selectedPoint.type === 'fill'
                        ? (language === 'ar' ? 'ردم' : 'FILL')
                        : (language === 'ar' ? 'متوازن' : 'BAL')}
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center text-gray-400 py-8">
                <div className="text-4xl mb-2">👆</div>
                <p>
                  {language === 'ar' 
                    ? 'انقر على أي نقطة في الخريطة لعرض التفاصيل'
                    : 'Click any point on the map to view details'}
                </p>
              </div>
            )}
          </div>

          {stats && (
            <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-4">
              <h4 className="text-sm font-bold text-white mb-3">
                📊 {language === 'ar' ? 'إحصائيات سريعة' : 'Quick Stats'}
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-red-300">{language === 'ar' ? 'نقاط حفر' : 'Cut points'}</span>
                  <span className="text-white">{stats.cutCount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-300">{language === 'ar' ? 'نقاط ردم' : 'Fill points'}</span>
                  <span className="text-white">{stats.fillCount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-yellow-300">{language === 'ar' ? 'متوازنة' : 'Balanced'}</span>
                  <span className="text-white">{stats.balancedCount}</span>
                </div>
              </div>
            </div>
          )}

          <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-4">
            <h4 className="text-sm font-bold text-white mb-3">
              🎨 {language === 'ar' ? 'دليل الألوان' : 'Color Legend'}
            </h4>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <span className="w-4 h-4 rounded bg-red-600"></span>
                <span className="text-gray-300">{language === 'ar' ? 'حفر كبير (> 1م)' : 'Heavy Cut (> 1m)'}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-4 h-4 rounded bg-red-400"></span>
                <span className="text-gray-300">{language === 'ar' ? 'حفر متوسط' : 'Medium Cut'}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-4 h-4 rounded bg-yellow-500"></span>
                <span className="text-gray-300">{language === 'ar' ? 'متوازن' : 'Balanced'}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-4 h-4 rounded bg-green-400"></span>
                <span className="text-gray-300">{language === 'ar' ? 'ردم متوسط' : 'Medium Fill'}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-4 h-4 rounded bg-green-600"></span>
                <span className="text-gray-300">{language === 'ar' ? 'ردم كبير (> 1م)' : 'Heavy Fill (> 1m)'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
