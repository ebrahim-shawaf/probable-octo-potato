import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { X, ChevronRight, ChevronLeft } from 'lucide-react';

interface TourStep {
  id: string;
  title: string;
  description: string;
  target?: string; // CSS selector for element to highlight
  language?: 'ar' | 'en';
}

interface FeatureTourProps {
  steps: TourStep[];
  onComplete?: () => void;
  language?: 'ar' | 'en';
  tourId: string; // unique identifier for tour
}

export default function FeatureTour({ steps, onComplete, language = 'en', tourId }: FeatureTourProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const [highlightedElement, setHighlightedElement] = useState<HTMLElement | null>(null);
  
  const isRTL = language === 'ar';

  // Check localStorage to see if tour has been shown before
  useEffect(() => {
    const hasSeenTour = localStorage.getItem(`tour-${tourId}`);
    if (!hasSeenTour) {
      setIsOpen(true);
    }
  }, [tourId]);

  // Handle highlight element
  useEffect(() => {
    if (!isOpen || !steps[currentStep]?.target) return;

    const element = document.querySelector(steps[currentStep].target!) as HTMLElement;
    if (element) {
      setHighlightedElement(element);
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [currentStep, isOpen, steps]);

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      completeTour();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const completeTour = () => {
    localStorage.setItem(`tour-${tourId}`, 'true');
    setIsOpen(false);
    onComplete?.();
  };

  if (!isOpen) return null;

  const step = steps[currentStep];
  const progress = Math.round(((currentStep + 1) / steps.length) * 100);

  return (
    <>
      {/* Overlay with highlight */}
      <div
        className="fixed inset-0 z-40 transition-opacity"
        style={{
          backgroundColor: 'rgba(0, 0, 0, 0.6)',
          backdropFilter: 'blur(2px)',
        }}
        onClick={completeTour}
      />

      {/* Highlighted element glow */}
      {highlightedElement && (
        <div
          className="fixed z-41 rounded-lg border-2 border-blue-400 shadow-lg shadow-blue-500 pointer-events-none"
          style={{
            top: `${highlightedElement.getBoundingClientRect().top - 8}px`,
            left: `${highlightedElement.getBoundingClientRect().left - 8}px`,
            width: `${highlightedElement.getBoundingClientRect().width + 16}px`,
            height: `${highlightedElement.getBoundingClientRect().height + 16}px`,
          }}
        />
      )}

      {/* Tour Card */}
      <div
        className={`fixed z-50 bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl shadow-2xl border border-blue-500/50 p-6 max-w-sm transition-all ${
          isRTL ? 'right-6' : 'left-6'
        } bottom-6`}
        style={{ direction: isRTL ? 'rtl' : 'ltr' }}
      >
        {/* Close button */}
        <button
          onClick={completeTour}
          className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
        >
          <X size={20} />
        </button>

        {/* Step number */}
        <div className="text-xs text-blue-400 font-semibold mb-2">
          {language === 'ar' ? 'خطوة' : 'Step'} {currentStep + 1} {language === 'ar' ? 'من' : 'of'} {steps.length}
        </div>

        {/* Progress bar */}
        <div className="w-full h-1 bg-slate-700 rounded-full mb-4 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-blue-500 to-blue-400 transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Title */}
        <h3 className="text-lg font-bold text-white mb-2">
          {language === 'ar' ? step?.title || '' : step?.title || ''}
        </h3>

        {/* Description */}
        <p className="text-sm text-gray-300 mb-6 leading-relaxed">
          {language === 'ar' ? step?.description || '' : step?.description || ''}
        </p>

        {/* Navigation buttons */}
        <div className="flex gap-3 justify-between">
          <Button
            onClick={handlePrev}
            disabled={currentStep === 0}
            variant="outline"
            size="sm"
            className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <ChevronLeft size={16} />
            {language === 'ar' ? 'السابق' : 'Back'}
          </Button>

          {currentStep === steps.length - 1 ? (
            <Button
              onClick={completeTour}
              size="sm"
              className="bg-blue-600 hover:bg-blue-700"
            >
              {language === 'ar' ? 'انتهى' : 'Done'}
            </Button>
          ) : (
            <Button
              onClick={handleNext}
              size="sm"
              className={`bg-blue-600 hover:bg-blue-700 flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}
            >
              {language === 'ar' ? 'التالي' : 'Next'}
              <ChevronRight size={16} />
            </Button>
          )}
        </div>

        {/* Skip option */}
        <button
          onClick={completeTour}
          className="w-full mt-3 text-xs text-gray-500 hover:text-gray-400 transition-colors"
        >
          {language === 'ar' ? 'تخطي الجولة' : 'Skip Tour'}
        </button>
      </div>
    </>
  );
}
