interface Column {
  id: number;
  length: number;
  width: number;
  height: number;
  qty: number;
}

export default function ColumnMapViewer({ columns }: { columns: Column[] }) {
  const colors = [
    '#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8',
    '#F7DC6F', '#BB8FCE', '#85C1E2', '#F8B88B', '#ABEBC6'
  ];

  if (columns.length === 0) {
    return (
      <div className="w-full h-96 bg-white/5 border border-white/20 rounded-lg flex items-center justify-center text-gray-400">
        No columns to display
      </div>
    );
  }

  const padding = 2;
  const maxWidth = Math.max(...columns.map(c => c.width)) + padding * 2;
  const maxLength = Math.max(...columns.map(c => c.length)) + padding * 2;
  const totalWidth = maxWidth * columns.length + padding * (columns.length + 1);
  const totalHeight = maxLength + padding * 2;
  
  const scale = Math.min(600 / totalWidth, 300 / totalHeight);
  const svgWidth = totalWidth * scale;
  const svgHeight = totalHeight * scale;

  let xOffset = padding * scale;

  return (
    <div className="w-full flex flex-col items-center gap-4 bg-white/5 border border-white/20 rounded-lg p-6" data-testid="map-viewer">
      <svg 
        width={svgWidth + 40} 
        height={svgHeight + 40} 
        className="border border-white/30 rounded bg-white/5"
        viewBox={`${-20} ${-20} ${svgWidth + 40} ${svgHeight + 40}`}
      >
        {/* Grid background */}
        <defs>
          <pattern id="grid" width={50} height={50} patternUnits="userSpaceOnUse">
            <path d="M 50 0 L 0 0 0 50" fill="none" stroke="white" strokeWidth="0.5" opacity="0.1"/>
          </pattern>
        </defs>
        <rect width={svgWidth + 40} height={svgHeight + 40} fill="url(#grid)" />

        {/* Columns */}
        {columns.map((col, idx) => {
          const x = xOffset;
          const y = padding * scale;
          const width = col.width * scale;
          const length = col.length * scale;
          const color = colors[idx % colors.length];
          
          xOffset += (col.width + padding) * scale;

          return (
            <g key={col.id}>
              {/* Column rectangle */}
              <rect
                x={x}
                y={y}
                width={width}
                height={length}
                fill={color}
                stroke="white"
                strokeWidth="2"
                opacity="0.8"
                data-testid={`map-column-${col.id}`}
              />
              
              {/* Column label */}
              <text
                x={x + width / 2}
                y={y + length / 2}
                textAnchor="middle"
                dominantBaseline="middle"
                fill="white"
                fontSize="12"
                fontWeight="bold"
                pointerEvents="none"
              >
                {col.width.toFixed(2)}×{col.length.toFixed(2)}
              </text>

              {/* Dimensions text */}
              <text
                x={x + width / 2}
                y={y + length + 15}
                textAnchor="middle"
                fill="white"
                fontSize="10"
                opacity="0.7"
                pointerEvents="none"
              >
                H: {col.height.toFixed(2)}m
              </text>
            </g>
          );
        })}
      </svg>

      {/* Legend */}
      <div className="w-full grid grid-cols-2 md:grid-cols-3 gap-2 text-xs">
        {columns.map((col, idx) => (
          <div key={col.id} className="flex items-center gap-2 text-gray-300">
            <div 
              className="w-4 h-4 rounded border border-white/30" 
              style={{ backgroundColor: colors[idx % colors.length] }}
            />
            <span>{col.width.toFixed(2)} × {col.length.toFixed(2)} × {col.height.toFixed(2)}m</span>
          </div>
        ))}
      </div>

      {/* Info */}
      <div className="text-center text-xs text-gray-400">
        Top-down view (2D) | Each column shown with dimensions
      </div>
    </div>
  );
}
