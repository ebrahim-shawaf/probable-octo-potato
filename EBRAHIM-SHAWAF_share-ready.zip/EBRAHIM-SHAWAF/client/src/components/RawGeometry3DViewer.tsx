import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Line, Points } from '@react-three/drei';
import { useMemo } from 'react';
import * as THREE from 'three';

interface LineGeometry {
  id: number;
  type: 'line';
  x1: number;
  y1: number;
  z1: number;
  x2: number;
  y2: number;
  z2: number;
}

interface PolylineGeometry {
  id: number;
  type: 'polyline';
  points: Array<[number, number, number]>;
}

interface CircleGeometry {
  id: number;
  type: 'circle';
  x: number;
  y: number;
  z: number;
  radius: number;
}

interface ArcGeometry {
  id: number;
  type: 'arc';
  x: number;
  y: number;
  z: number;
  radius: number;
  startAngle: number;
  endAngle: number;
}

interface TextGeometry {
  id: number;
  type: 'text';
  x: number;
  y: number;
  z: number;
  text: string;
}

type GeometryEntity = LineGeometry | PolylineGeometry | CircleGeometry | ArcGeometry | TextGeometry;

function LineSegment({ line }: { line: LineGeometry }) {
  const points = [
    [line.x1, line.z1, line.y1] as [number, number, number],
    [line.x2, line.z2, line.y2] as [number, number, number],
  ];
  
  return (
    <Line
      points={points}
      color="#3B82F6"
      lineWidth={2}
      dashed={false}
    />
  );
}

function PolylineSegment({ poly }: { poly: PolylineGeometry }) {
  const points = poly.points.map(p => [p[0], p[2], p[1]] as [number, number, number]);
  
  return (
    <Line
      points={points}
      color="#10B981"
      lineWidth={2}
      dashed={false}
    />
  );
}

function CircleSegment({ circle }: { circle: CircleGeometry }) {
  const points: [number, number, number][] = [];
  const segments = 32;
  
  for (let i = 0; i <= segments; i++) {
    const angle = (i / segments) * Math.PI * 2;
    const x = circle.x + circle.radius * Math.cos(angle);
    const y = circle.z;
    const z = circle.y + circle.radius * Math.sin(angle);
    points.push([x, y, z]);
  }
  
  return (
    <Line
      points={points}
      color="#F59E0B"
      lineWidth={2}
      dashed={false}
    />
  );
}

function ArcSegment({ arc }: { arc: ArcGeometry }) {
  const points: [number, number, number][] = [];
  const segments = 32;
  const startRad = (arc.startAngle * Math.PI) / 180;
  const endRad = (arc.endAngle * Math.PI) / 180;
  
  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    const angle = startRad + (endRad - startRad) * t;
    const x = arc.x + arc.radius * Math.cos(angle);
    const y = arc.z;
    const z = arc.y + arc.radius * Math.sin(angle);
    points.push([x, y, z]);
  }
  
  return (
    <Line
      points={points}
      color="#EF4444"
      lineWidth={2}
      dashed={false}
    />
  );
}

export default function RawGeometry3DViewer({ geometry }: { geometry: GeometryEntity[] }) {
  if (!geometry || geometry.length === 0) {
    return (
      <div className="w-full h-96 bg-slate-900 border border-white/20 rounded-lg flex items-center justify-center text-gray-400">
        لا توجد بيانات هندسية / No geometric data
      </div>
    );
  }

  const bounds = useMemo(() => {
    let minX = Infinity, maxX = -Infinity;
    let minY = Infinity, maxY = -Infinity;
    let minZ = Infinity, maxZ = -Infinity;

    geometry.forEach(entity => {
      if (entity.type === 'line') {
        minX = Math.min(minX, entity.x1, entity.x2);
        maxX = Math.max(maxX, entity.x1, entity.x2);
        minY = Math.min(minY, entity.y1, entity.y2);
        maxY = Math.max(maxY, entity.y1, entity.y2);
        minZ = Math.min(minZ, entity.z1, entity.z2);
        maxZ = Math.max(maxZ, entity.z1, entity.z2);
      } else if (entity.type === 'polyline') {
        entity.points.forEach(p => {
          minX = Math.min(minX, p[0]);
          maxX = Math.max(maxX, p[0]);
          minY = Math.min(minY, p[1]);
          maxY = Math.max(maxY, p[1]);
          minZ = Math.min(minZ, p[2]);
          maxZ = Math.max(maxZ, p[2]);
        });
      } else if (entity.type === 'circle' || entity.type === 'arc') {
        minX = Math.min(minX, entity.x - entity.radius);
        maxX = Math.max(maxX, entity.x + entity.radius);
        minY = Math.min(minY, entity.y - entity.radius);
        maxY = Math.max(maxY, entity.y + entity.radius);
        minZ = Math.min(minZ, entity.z);
        maxZ = Math.max(maxZ, entity.z);
      }
    });

    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;
    const centerZ = (minZ + maxZ) / 2;
    const sizeX = maxX - minX || 1;
    const sizeY = maxY - minY || 1;
    const sizeZ = maxZ - minZ || 1;
    const maxSize = Math.max(sizeX, sizeY, sizeZ);
    const cameraDistance = maxSize * 1.5;

    return { centerX, centerY, centerZ, sizeX, sizeY, sizeZ, maxSize, cameraDistance };
  }, [geometry]);

  return (
    <div className="w-full h-96 bg-gradient-to-b from-slate-900 to-black border border-white/20 rounded-lg overflow-hidden" data-testid="viewer-raw-geometry">
      <Canvas camera={{ position: [bounds.cameraDistance, bounds.cameraDistance, bounds.cameraDistance], fov: 50 }}>
        <PerspectiveCamera 
          makeDefault 
          position={[bounds.centerX + bounds.cameraDistance, bounds.centerY + bounds.cameraDistance, bounds.centerZ + bounds.cameraDistance]} 
          fov={50}
          near={0.1}
          far={100000}
        />
        
        {/* Lights */}
        <ambientLight intensity={0.7} />
        <directionalLight 
          position={[bounds.cameraDistance, bounds.cameraDistance, bounds.cameraDistance]} 
          intensity={1}
          castShadow
        />
        <pointLight position={[bounds.centerX, bounds.centerY + bounds.maxSize, bounds.centerZ]} intensity={0.5} />
        
        {/* Grid */}
        <gridHelper args={[bounds.maxSize * 3, 20]} position={[bounds.centerX, bounds.centerY, bounds.centerZ]} />
        
        {/* Axes */}
        <axesHelper args={[bounds.maxSize]} position={[bounds.centerX, bounds.centerY, bounds.centerZ]} />
        
        {/* Geometry */}
        {geometry.map((entity) => {
          if (entity.type === 'line') {
            return <LineSegment key={entity.id} line={entity} />;
          } else if (entity.type === 'polyline') {
            return <PolylineSegment key={entity.id} poly={entity} />;
          } else if (entity.type === 'circle') {
            return <CircleSegment key={entity.id} circle={entity} />;
          } else if (entity.type === 'arc') {
            return <ArcSegment key={entity.id} arc={entity} />;
          }
          return null;
        })}
        
        {/* Controls */}
        <OrbitControls 
          autoRotate
          autoRotateSpeed={2}
          enableDamping
          dampingFactor={0.05}
          minDistance={bounds.maxSize * 0.5}
          maxDistance={bounds.cameraDistance * 4}
        />
      </Canvas>
    </div>
  );
}
